﻿using System.Data;
using OneSupplierPlatform.i18n;
using OneSupplierPlatform.Infrastructure;
using OneSupplierPlatform.Models.Infra;
using OneSupplierPlatform_Service.Helpers;
using OneSupplierService;

namespace OneSupplierPlatform.Services
{
    public class MenuService: BaseService
    {
        public MenuService() : base()
        {
        }

        public async Task<List<MenuItemViewModel>> GetMenuAsync() 
        { 
            try
            {
                List<MenuItemViewModel> menuTree = new List<MenuItemViewModel>();
                var sql = @"select node_id AS NodeId, 
                            parent_id AS ParentId, 
                            item_text AS ItemText, 
                            item_link AS ItemLink,  
                            item_target as ItemTarget,
                            page_class as PageClass 
                            from osp_menulist_c a where active ='Y' order by a.item_order asc";
                var result = await AmscDb.QueryAsync<MenuItemViewModel>(sql);
                if (result?.ToList().Count > 0)
                {
                     menuTree = result.Where(m => m.ParentId == 0)
                               .Select(root => {
                                   root.Children = result.Where(m => m.ParentId == root.NodeId).ToList();
                                   return root;
                               }).ToList();
                }
                else 
                {
                    throw new Exception("沒有定義Menu資料");
                } 
                return menuTree;
            }
            catch (Exception ex)
            {
                Logger.LogError($"呼叫失敗: {ex.Message}");
                throw;
            } 
        }
    }
}
