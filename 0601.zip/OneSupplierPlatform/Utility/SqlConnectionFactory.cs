﻿using Newtonsoft.Json;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using System.Data;
using System.Reflection;
using Microsoft.Data.SqlClient;
using newauo.Helper;
using System.Data.Common;

namespace OneSupplierPlatform.Utility
{
    // =========================
    // Extension
    // =========================
    public static class DataReaderExtensions
    {
        public static bool HasColumn(this IDataRecord reader, string columnName)
        {
            for (int i = 0; i < reader.FieldCount; i++)
            {
                if (reader.GetName(i).Equals(columnName, StringComparison.OrdinalIgnoreCase))
                    return true;
            }
            return false;
        }
    }

    // =========================
    // Connection Factory (Multi DB)
    // =========================
    public class SqlConnectionFactory : IDbConnectionFactory
    {
        private readonly IConfiguration _config;

        public SqlConnectionFactory(IConfiguration config)
        {
            _config = config;
        }

        public IDbConnection CreateConnection(string dbName = "AMSC-SQLDB")
        {
            var connStr = _config.GetConnectionString(dbName);

            var conn = new SqlConnection(connStr);
            conn.Open();
            return conn;
        }
    }

    // =========================
    // Repository
    // =========================
    public class GenericRepository : IGenericRepository, IDisposable
    {
        private readonly IDbConnectionFactory _factory;
        private IDbConnection _conn;
        private IDbTransaction _tx;
        private readonly string _dbName;

        public GenericRepository(IDbConnectionFactory factory, string dbName = "AMSC-SQLDB")
        {
            _factory = factory;
            _dbName = dbName;
        }

        // =========================
        // Connection
        // =========================
        private IDbConnection GetConnection()
        {
            if (_conn == null)
                _conn = _factory.CreateConnection(_dbName);

            return _conn;
        }

        public void UseDatabase(string dbName)
        {
            _conn?.Dispose();
            _conn = _factory.CreateConnection(dbName);
        }

        // =========================
        // Transaction
        // =========================
        public void BeginTransaction()
        {
            _tx = GetConnection().BeginTransaction();
        }

        public void Commit()
        {
            _tx?.Commit();
            _tx = null;
        }

        public void Rollback()
        {
            _tx?.Rollback();
            _tx = null;
        }
        private SqlDbType GetSqlDbType(Type type)
        {
            type = Nullable.GetUnderlyingType(type) ?? type;

            return type switch
            {
                Type t when t == typeof(string) => SqlDbType.NVarChar,
                Type t when t == typeof(int) => SqlDbType.Int,
                Type t when t == typeof(long) => SqlDbType.BigInt,
                Type t when t == typeof(decimal) => SqlDbType.Decimal,
                Type t when t == typeof(double) => SqlDbType.Float,
                Type t when t == typeof(bool) => SqlDbType.Bit,
                Type t when t == typeof(DateTime) => SqlDbType.DateTime,
                Type t when t == typeof(Guid) => SqlDbType.UniqueIdentifier,
                _ => SqlDbType.NVarChar
            };
        }
        // =========================
        // Command
        // =========================
        private IDbCommand CreateCommand(string sql)
        {
            var cmd = GetConnection().CreateCommand();
            cmd.CommandText = sql;

            if (_tx != null)
                cmd.Transaction = _tx;

            return cmd;
        }

        private void AddParameters(IDbCommand cmd, object param)
        {
            if (param == null) return;

            var props = param.GetType().GetProperties();

            foreach (var p in props)
            {
                var dbParam = cmd.CreateParameter();
                dbParam.ParameterName = "@" + p.Name;
                dbParam.Value = p.GetValue(param) ?? DBNull.Value;
                cmd.Parameters.Add(dbParam);
            }
        }

        // =========================
        // Execute Helpers
        // =========================
        private async Task ExecuteAsync(string sql, List<IDataParameter> parameters)
        {
            using var cmd = CreateCommand(sql);

            foreach (var p in parameters)
                cmd.Parameters.Add(p);

            await ((SqlCommand)cmd).ExecuteNonQueryAsync();
        }

        private IDataParameter CreateParameter(string name, object value, Type type = null)
        {
            var cmd = GetConnection().CreateCommand();

            var param = cmd.CreateParameter();
            param.ParameterName = name;

            if (value == null)
            {
                param.Value = DBNull.Value;
                return param;
            }

            // =========================
            // TYPE SAFE BINDING
            // =========================
            if (param is SqlParameter sqlParam && type != null)
            {
                sqlParam.SqlDbType = GetSqlDbType(type);
            }

            param.Value = value;
            return param;
        }

        // =========================
        // INSERT
        // =========================
        public async Task InsertAsync<T>(T entity)
        {
            var type = typeof(T);
            var table = GetTableName(type);
            var props = GetProps(type);

            var cols = new List<string>();
            var vals = new List<string>();
            var parameters = new List<IDataParameter>();

            foreach (var p in props)
            {
                var dbGeneratedAttr = p.GetCustomAttribute<DatabaseGeneratedAttribute>();
                if (dbGeneratedAttr != null && dbGeneratedAttr.DatabaseGeneratedOption == DatabaseGeneratedOption.Identity)
                {
                    continue; // 跳過此欄位，不寫入 INSERT 語法中
                }
                var val = p.GetValue(entity);
                if (val == null) continue;

                var col = GetColumnName(p);

                cols.Add(col);
                vals.Add("@" + col);

                parameters.Add(CreateParameter("@" + col, val, p.PropertyType));
            }

            var sql = $@"
INSERT INTO {table}
({string.Join(",", cols)})
VALUES
({string.Join(",", vals)})
";

            await ExecuteAsync(sql, parameters);
        }

        // =========================
        // UPDATE
        // =========================
        public async Task UpdateAsync<T>(T entity)
        {
            var type = typeof(T);
            var table = GetTableName(type);

            var keyProps = GetKeyProperties(type);
            var props = GetProps(type);

            var sets = new List<string>();
            var where = new List<string>();
            var parameters = new List<IDataParameter>();

            foreach (var p in props)
            {
                var skipAttr = p.GetCustomAttribute<SkipAttribute>();
                if (skipAttr != null)
                {
                    continue;
                }
                var col = GetColumnName(p);
                var val = p.GetValue(entity) ?? DBNull.Value;

                if (keyProps.Contains(p))
                    where.Add($"{col}=@{col}");
                else
                    sets.Add($"{col}=@{col}");

                parameters.Add(CreateParameter("@" + col, val, p.PropertyType));
            }

            var sql = $@"
UPDATE {table}
SET {string.Join(",", sets)}
WHERE {string.Join(" AND ", where)}
";

            await ExecuteAsync(sql, parameters);
        }

        // =========================
        // DELETE
        // =========================
        public async Task DeleteAsync<T>(object keys)
        {
            var type = typeof(T);
            var table = GetTableName(type);
            var keyProps = GetKeyProperties(type);

            var where = new List<string>();
            var parameters = new List<IDataParameter>();

            foreach (var kp in keyProps)
            {
                var col = GetColumnName(kp);
                var val = GetKeyValue(keys, kp.Name);
                if (!IsValidValue(val))
                    continue;
                where.Add($"{col}=@{col}");
                parameters.Add(CreateParameter("@" + col, val, kp.PropertyType));
            }
            if (where.Count == 0)
                throw new Exception("No valid keys provided for DeleteAsync");
            var sql = $"DELETE FROM {table} WHERE {string.Join(" AND ", where)}";
            await ExecuteAsync(sql, parameters);
        }

        // =========================
        // GET
        // =========================
        public async Task<T> GetAsync<T>(object keys) where T : new()
        {
            var type = typeof(T);
            var table = GetTableName(type);
            var keyProps = GetKeyProperties(type);

            var where = new List<string>();
            var parameters = new List<IDataParameter>();

            foreach (var kp in keyProps)
            {
                var col = GetColumnName(kp);
                var val = GetKeyValue(keys, kp.Name);
                if (!IsValidValue(val))
                    continue;
                where.Add($"{col}=@{col}");
                parameters.Add(CreateParameter("@" + col, val, kp.PropertyType));
            }
            if (where.Count == 0)
                throw new Exception("No valid keys provided for GetAsync");
            var sql = $"SELECT * FROM {table} WHERE {string.Join(" AND ", where)}";

            using var cmd = CreateCommand(sql);
            foreach (var p in parameters)
                cmd.Parameters.Add(p);

            using var reader = await ((SqlCommand)cmd).ExecuteReaderAsync();

            if (!reader.Read()) return default;

            var obj = new T();

            foreach (var p in GetProps(type))
            {
                var col = GetColumnName(p);

                if (!reader.HasColumn(col)) continue;

                var val = reader[col];
                if (val == DBNull.Value) continue;

                p.SetValue(obj,
                    Convert.ChangeType(val,
                    Nullable.GetUnderlyingType(p.PropertyType) ?? p.PropertyType));
            }

            return obj;
        }
        public async Task SaveManyAsync<T>(IEnumerable<T> entities) where T : new()
        {
            if (_tx == null)
            {
                throw new InvalidOperationException("必須先呼叫 BeginTransaction() 才能執行此操作。");
            }
             
            var conn = _tx.Connection;
            if (conn == null)
            {
                throw new InvalidOperationException("目前的交易已失去連線，可能已被關閉。");
            }
            var list = entities?.ToList();
            if (list == null || list.Count == 0)
                return;

            var type = typeof(T);
            var table = GetTableName(type);
            var keyProps = GetKeyProperties(type);
            var props = GetProps(type);

            var items = list.Select(e =>
            (
                Entity: e,
                KeyValues: keyProps.ToDictionary(
                    k => k.Name,
                    k => k.GetValue(e)
                )
            )).ToList();

            var existingKeys = await GetExistingKeysAsync<T>(table, keyProps, items);

            var inserts = new List<T>();
            var updates = new List<T>();

            foreach (var item in items)
            {
                var key = BuildKeyString(item.KeyValues);

                if (existingKeys.Contains(key))
                    updates.Add(item.Entity);
                else
                    inserts.Add(item.Entity);
            }

            if (inserts.Count > 0)
                await BulkInsertFastAsync(conn, _tx, table, inserts, props);

            if (updates.Count > 0)
                //await BulkUpdateFastAsync(table, updates, props, keyProps);
                await BulkUpdateFastAsync(conn, _tx, table,updates, props, keyProps);

        }
        private async Task BulkInsertFastAsync<T>(IDbConnection conn,          // 1. 從外層傳入連線
                                                  IDbTransaction tx,           // 2. 從外層傳入交易
                                                  string table,
                                                  List<T> list,
                                                  List<PropertyInfo> props)
        {
            using var cmd = conn.CreateCommand();
            cmd.Transaction = tx; 
            var cols = new List<string>();
            var vals = new List<string>();
            var validProps = new List<PropertyInfo>();

            foreach (var p in props)
            {
                var dbGeneratedAttr = p.GetCustomAttribute<DatabaseGeneratedAttribute>();
                if (dbGeneratedAttr != null && dbGeneratedAttr.DatabaseGeneratedOption == DatabaseGeneratedOption.Identity)
                {
                    continue; // 跳過自增值欄位
                }

                var col = GetColumnName(p);
                cols.Add(col);
                vals.Add("@" + col);
                validProps.Add(p); // 存入有效屬性清單，供後續迴圈使用
            }
            cmd.CommandText = $@"
                INSERT INTO {table}
                ({string.Join(",", cols)})
                VALUES
                ({string.Join(",", vals)})
                ";


            foreach (var p in validProps)
            {
                var col = GetColumnName(p);
                var param = cmd.CreateParameter();
                param.ParameterName = "@" + col;

                cmd.Parameters.Add(param);
            }

          
            foreach (var entity in list)
            {
                for (int i = 0; i < validProps.Count; i++)
                {
                    var prop = validProps[i];
                    var val = prop.GetValue(entity); 
                    ((IDbDataParameter)cmd.Parameters[i]).Value = val ?? DBNull.Value;
                }
                await ((SqlCommand)cmd).ExecuteNonQueryAsync();
            }

        }
        private async Task BulkUpdateFastAsync<T>(IDbConnection conn,          // 1. 從外層傳入連線
                                                    IDbTransaction tx,           // 2. 從外層傳入交易
                                                    string table,
                                                    List<T> list,
                                                    List<PropertyInfo> props,
                                                    List<PropertyInfo> keyProps)
        {
            using var cmd = conn.CreateCommand();
            cmd.Transaction = tx;   
           
            var sets = new List<string>();
            var where = new List<string>();
            var validProps = new List<PropertyInfo>();

            foreach (var p in props)
            {
                var dbGeneratedAttr = p.GetCustomAttribute<DatabaseGeneratedAttribute>();
                if (dbGeneratedAttr != null && dbGeneratedAttr.DatabaseGeneratedOption == DatabaseGeneratedOption.Identity)
                {
                    continue; // 跳過自增值欄位
                }
                var skipAttr = p.GetCustomAttribute<SkipAttribute>();
                if (skipAttr != null) continue;

                var col = GetColumnName(p);
                var pname = "@" + col;

                if (keyProps.Contains(p))
                {
                    where.Add($"{col}={pname}");
                }
                else
                {
                    sets.Add($"{col}={pname}");
                }

                validProps.Add(p); // 依序存入有效屬性清單，確保後續索引完全對齊
            }

          
            cmd.CommandText = $@"
                    UPDATE {table}
                    SET {string.Join(",", sets)}
                    WHERE {string.Join(" AND ", where)}
                    "; 
            foreach (var p in validProps)
            {
                var col = GetColumnName(p);
                var param = cmd.CreateParameter();
                param.ParameterName = "@" + col;

                cmd.Parameters.Add(param);
            }

         
            foreach (var entity in list)
            { 
                for (int i = 0; i < validProps.Count; i++)
                {
                    var prop = validProps[i];
                    var val = prop.GetValue(entity); 
                    ((IDbDataParameter)cmd.Parameters[i]).Value = val ?? DBNull.Value;
                }

                // 執行更新
                await ((SqlCommand)cmd).ExecuteNonQueryAsync();
            }
        }

        private async Task<HashSet<string>> GetExistingKeysAsync<T>(string table,
                                                                    List<PropertyInfo> keyProps,
                                                                    List<(T Entity, Dictionary<string, object> KeyValues)> items)
        {
            // build temp key table
            var allParams = new List<IDataParameter>();
            var where = new List<string>();

            int i = 0;

            foreach (var item in items)
            {
                var cond = new List<string>();

                foreach (var kp in keyProps)
                {
                    var dbGeneratedAttr = kp.GetCustomAttribute<DatabaseGeneratedAttribute>();
                    if (dbGeneratedAttr != null && dbGeneratedAttr.DatabaseGeneratedOption == DatabaseGeneratedOption.Identity)
                    {
                        continue; // 跳過此欄位，不寫入 INSERT 語法中
                    }
                    var col = GetColumnName(kp);
                    var val = item.KeyValues[kp.Name];

                    var pname = $"@p{i}_{kp.Name}";
                    cond.Add($"{col} = {pname}");

                    allParams.Add(CreateParameter(pname, val, kp.PropertyType));
                }

                where.Add($"({string.Join(" AND ", cond)})");
                i++;
            }

            var sql = $@"
                            SELECT {string.Join(",", keyProps.Select(GetColumnName))}
                            FROM {table}
                            WHERE {string.Join(" OR ", where)}
                            ";

            using var cmd = CreateCommand(sql);
            foreach (var p in allParams)
                cmd.Parameters.Add(p);

            using var reader = await ((SqlCommand)cmd).ExecuteReaderAsync();

            var result = new HashSet<string>();

            while (await reader.ReadAsync())
            {
                var dict = new Dictionary<string, object>();

                foreach (var kp in keyProps)
                {
                    var col = GetColumnName(kp);
                    dict[kp.Name] = reader[col];
                }

                result.Add(BuildKeyString(dict));
            }

            return result;
        }
        private string BuildKeyString(Dictionary<string, object> dict)
        {
            return string.Join("||",
                dict.OrderBy(x => x.Key)
                    .Select(x => $"{x.Key}:{x.Value}")
            );
        }
        // =========================
        // SAVE
        // =========================
        public async Task SaveAsync<T>(T entity) where T : new()
        {
            var keyProps = GetKeyProperties(typeof(T));

            var keyDict = new Dictionary<string, object>();

            foreach (var kp in keyProps)
            {
                var val = kp.GetValue(entity);

                if (!IsValidValue(val))
                    continue;

                keyDict[kp.Name] = val;
            }

            if (keyDict.Count == 0)
                throw new Exception("No valid key values for SaveAsync");

            var existing = await GetAsync<T>(keyDict);

            if (existing == null)
                await InsertAsync(entity);
            else
                await UpdateAsync(entity);
        }

        // =========================
        // QUERY
        // =========================
        public async Task<List<T>> QueryAsync<T>(string sql, object param = null) where T : new()
        {
            using var cmd = CreateCommand(sql);
            AddParameters(cmd, param);

            using var reader = await ((SqlCommand)cmd).ExecuteReaderAsync();

            var list = new List<T>();
            var props = typeof(T).GetProperties();

            while (await reader.ReadAsync())
            {
                var obj = new T();

                foreach (var p in props)
                {
                    var col = GetColumnName(p);

                    if (!reader.HasColumn(col)) continue;

                    var val = reader[col];
                    if (val == DBNull.Value) continue;

                    p.SetValue(obj,
                        Convert.ChangeType(val,
                        Nullable.GetUnderlyingType(p.PropertyType) ?? p.PropertyType));
                }

                list.Add(obj);
            }

            return list;
        }

        public async Task<T> QuerySingleAsync<T>(string sql, object param = null) where T : new()
        {
            var list = await QueryAsync<T>(sql, param);
            return list.FirstOrDefault();
        }

        public async Task<T> ExecuteScalarAsync<T>(string sql, object param = null)
        {
            using var cmd = CreateCommand(sql);
            AddParameters(cmd, param); 
            var result = await ((SqlCommand)cmd).ExecuteScalarAsync(); 
            if (result == null || result == DBNull.Value)
            {
                return default;
            } 
            return (T)Convert.ChangeType(result, Nullable.GetUnderlyingType(typeof(T)) ?? typeof(T));
        }

        public async Task<int> ExecuteSqlAsync(string sql, object param = null)
        {
            using var cmd = CreateCommand(sql);
            AddParameters(cmd, param);
            return await ((SqlCommand)cmd).ExecuteNonQueryAsync();
        }

        // =========================
        // Helpers
        // =========================
        private string GetTableName(Type type)
        {
            var attr = type.GetCustomAttribute<TableAttribute>();
            return attr?.Name ?? type.Name;
        }

        private List<PropertyInfo> GetKeyProperties(Type type)
        { 
            var keys = type.GetProperties()
                .Where(p => p.GetCustomAttribute<KeyAttribute>() != null)
                .ToList();

            if (!keys.Any())
                throw new Exception($"No [Key] defined on {type.Name}");

            return keys;
        }

        private string GetColumnName(PropertyInfo prop)
        {
            var json = prop.GetCustomAttribute<JsonPropertyAttribute>();
            return json?.PropertyName ?? prop.Name;
        }

        private List<PropertyInfo> GetProps(Type t)
        {
            return t.GetProperties()
                .Where(p => p.CanRead && p.CanWrite)
                .ToList();
        }

        private object GetKeyValue(object keyObj, string propName)
        {
            if (keyObj == null) return null;
            if (keyObj is System.Collections.IDictionary dict)
            {
                return dict.Contains(propName) ? dict[propName] : null;
            }
            var prop = keyObj.GetType().GetProperty(propName);
            return prop?.GetValue(keyObj);
        }

        public void Dispose()
        {
            _tx?.Dispose();
            _conn?.Close();
            _conn?.Dispose();
        }

        private bool IsValidValue(object value)
        {
            if (value == null) return false;

            if (value is string s && string.IsNullOrWhiteSpace(s))
                return false;

            return true;
        }
    }
}
