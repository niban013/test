﻿using System.Security.Claims;
using Microsoft.AspNetCore.Mvc;
using OneSupplierPlatform.i18n;
using OneSupplierPlatform.Models;

namespace OneSupplierPlatform.Controllers
{
    public abstract class BaseController : Controller
    {
        protected CapUser CurrentUser
        {
            get
            {
                return new CapUser
                {
                    UserId = User.FindFirstValue(ClaimTypes.NameIdentifier),

                    EmployeeId = User.FindFirstValue("EmployeeId"),

                    RealName = User.FindFirstValue(ClaimTypes.Name),

                    Email = User.FindFirstValue(ClaimTypes.Email),

                    DepartmentId = User.FindFirstValue("DepartmentId"),

                    BossLevel = Convert.ToInt32(User.FindFirstValue("BossLevel")),

                    Site = User.FindFirstValue("Site"),

                    CompanyName = User.FindFirstValue("CompanyName")
                };
            }
        }
        private LocalizedKeys? _localizer;

        protected LocalizedKeys Localizer => _localizer ??= HttpContext.RequestServices.GetRequiredService<LocalizedKeys>();


        private ILogger? _logger;
        protected ILogger Logger => _logger ??= HttpContext.RequestServices.GetRequiredService<ILoggerFactory>().CreateLogger(GetType());
    }

}
     
