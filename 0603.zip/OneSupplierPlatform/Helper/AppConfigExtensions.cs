﻿using Microsoft.AspNetCore.Html;
using Microsoft.AspNetCore.Mvc.Rendering;
using System.Text.Json;

namespace OneSupplierPlatform_Service.Helpers
{
    public static class AppConfigExtensions
    {
        public static IHtmlContent AppConfig(
            this IHtmlHelper html,
            string[] includeOnly = null,
            string[] excludeKeys = null)
        {
            var config = html.ViewContext.HttpContext.RequestServices
                .GetRequiredService<IConfiguration>();

            // ⭐ 只允許「appsettings sections」，不掃 root
            var sections = GetAppSettingsSections(config, includeOnly);

            var root = sections.ToDictionary(
                s => s,
                s =>
                {
                    var section = config.GetSection(s);

                    if (section.Exists())
                        return Bind(section, excludeKeys);

                    return null;
                }
            );

            var json = JsonSerializer.Serialize(root);

            return new HtmlString($@"
<script>
    window.appConfig = {json};
</script>");
        }

        // =========================
        // bind specific section only
        // =========================
        private static object Bind(
            IConfigurationSection section,
            string[] excludeKeys)
        {
            var children = section.GetChildren();

            if (!children.Any())
                return section.Value;

            return children
                .Where(x => !IsExcluded(x.Key, excludeKeys))
                .ToDictionary(
                    x => x.Key,
                    x => Bind(x, excludeKeys)
                );
        }

        // =========================
        // ONLY appsettings.json sections
        // 👉 不再掃 IConfiguration root
        // =========================
        private static List<string> GetAppSettingsSections(
            IConfiguration config,
            string[] includeOnly)
        {
            var rootSection = config.GetChildren();

            var sections = rootSection
                .Select(x => x.Key)
                .Where(k => !string.IsNullOrWhiteSpace(k))
                .ToList();

            // includeOnly filter
            if (includeOnly != null && includeOnly.Length > 0)
            {
                sections = sections
                    .Where(s => includeOnly.Any(i =>
                        string.Equals(i, s, StringComparison.OrdinalIgnoreCase)))
                    .ToList();
            }

            return sections;
        }

        // =========================
        // exclude rule
        // =========================
        private static bool IsExcluded(string key, string[] excludeKeys)
        {
            return excludeKeys != null &&
                   excludeKeys.Any(e =>
                       string.Equals(e, key, StringComparison.OrdinalIgnoreCase));
        }
    }
}
