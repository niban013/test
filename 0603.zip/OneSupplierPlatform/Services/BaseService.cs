﻿using OneSupplierPlatform.i18n;
using OneSupplierPlatform.Infrastructure;
using OneSupplierPlatform.Models;
using OneSupplierService;
using System.Security.Claims;
using ClaimTypes = System.Security.Claims.ClaimTypes;

namespace OneSupplierPlatform.Services
{
    public abstract class BaseService
    {
        private ILogger? _logger;
        private LocalizedKeys? _localizer;
        private IConfiguration? _config;
        //private SQLDBHelper? _db;
        private OneSupplierPlatformServiceSoapClient? _asmxClient;

        protected ILogger Logger => _logger ??= AppFinder.ServiceProvider?
            .GetRequiredService<ILoggerFactory>().CreateLogger(GetType())
            ?? throw new Exception("Logger 未初始化");

        protected LocalizedKeys Localizer => _localizer ??= AppFinder.ServiceProvider?
            .GetRequiredService<LocalizedKeys>()
            ?? throw new Exception("Localizer 未初始化");

        //protected SQLDBHelper AmscDb => _db ??= AppFinder.GetService<SQLDBHelper>();


        protected IConfiguration Config => _config ??= AppFinder.GetService<IConfiguration>();



        protected OneSupplierPlatformServiceSoapClient AsmxClient => _asmxClient ??= AppFinder.GetService<OneSupplierPlatformServiceSoapClient>();


        protected CapUser CurrentUser
        {
            get
            {
                // 💡 利用您的 AppFinder 拿到專屬於當次請求的 IHttpContextAccessor
                var httpContextAccessor = AppFinder.GetService<IHttpContextAccessor>();
                var user = httpContextAccessor?.HttpContext?.User;

                if (user == null || !user.Identity.IsAuthenticated)
                {
                    return null;
                }

                return new CapUser
                {
                    UserId = user.FindFirstValue(ClaimTypes.NameIdentifier),
                    EmployeeId = user.FindFirstValue("EmployeeId"),
                    RealName = user.FindFirstValue(ClaimTypes.Name),
                    Email = user.FindFirstValue(ClaimTypes.Email),
                    DepartmentId = user.FindFirstValue("DepartmentId"),
                    BossLevel = Convert.ToInt32(user.FindFirstValue("BossLevel") ?? "0"),
                    Site = user.FindFirstValue("Site"),
                    CompanyName = user.FindFirstValue("CompanyName")
                };
            }
        }

    }
}
