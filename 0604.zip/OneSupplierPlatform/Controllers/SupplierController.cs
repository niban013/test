﻿using AutoMapper;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using OneSupplierPlatform.Helper;
using OneSupplierPlatform.Models;
using OneSupplierPlatform.Models.Infra;
using OneSupplierPlatform.Service;
using OneSupplierPlatform.Services;
using OneSupplierPlatform.Utility;
using System.Text;
using System.Text.Json.Serialization;


namespace OneSupplierPlatform.Controllers
{
    public class FormInfo
    {
        public string headerid { get; set; } = "";
        public string formno { get; set; } = "";

        public string applytype { get; set; } = "";
    }
    public class StepContext
    {
        public int Current { get; set; }

        public List<int>? ValidateSteps { get; set; }
    }
    public class SupplierSaveViewModel
    {
        public FormInfo FormInfo { get; set; }
        public Step1Data Step1 { get; set; }
        public Step2Data Step2 { get; set; }
        public Dictionary<string, string> Step3 { get; set; } // Step3 欄位極多且多為字串，建議用字典
        public string mode { get; set; }
        public StepContext StepContext { get; set; }
        public bool hasError { get; set; }
    }

    public class Step1Data
    {
        public string suppliername { get; set; }
        public string applytype { get; set; }
        public DecisionData decision { get; set; }
    }

    public class Step2Data : Dictionary<string, object>
    {
        // Step2 欄位太多（company_code, vendor_class...），
        // 繼承 Dictionary 可以讓你直接用 payload.Step2["company_code"] 取值，
        // 同時也能定義常用的強型別屬性。
        public DecisionData decision
        {
            get => ContainsKey("Step2") ? (DecisionData)this["Step2"] : null;
            set => this["Step2"] = value;
        }
    }

    public class DecisionData
    {
        public object Types { get; set; }
        public object Datas { get; set; }
    }
    public class StepPayload
    {
        public Dictionary<string, object>? Types { get; set; }

        public Dictionary<string, object>? Datas { get; set; }
    }
    public class StepRequest
    {
        public int StepIndex { get; set; }

        public FormInfo FormInfo { get; set; }
        public Dictionary<string, StepPayload>? FlowData { get; set; }
    }
    public class SupplierController : BaseController
    {
        private static readonly List<WizardStepOption> Steps = new()
        {
            new WizardStepOption { StepIndex = 1, Title = "Apply New Supplier", PartialView = "Supplier/_StepApplyNewSupplier", Locked = false },
            new WizardStepOption { StepIndex = 2, Title = "Supplier Information", PartialView = "Supplier/_StepSupplierInformation" },
            new WizardStepOption { StepIndex = 3, Title = "File List", PartialView = "Supplier/_StepFileList" }
        };

        private readonly ISupplierService _supplierService;
        private readonly DynamicFieldService _dynamicFieldService;
        private readonly IMapper _mapper;
        private readonly OneSupplierFLMService _oneSupplierFLMService;

        private readonly IHttpClientFactory _httpClientFactory;
        private readonly ITransactionContext _db;


        private readonly IConfiguration _config;
        public SupplierController(ITransactionContext db, IConfiguration config, IHttpClientFactory httpClientFactory, OneSupplierFLMService oneSupplierFLMService, IMapper mapper, ISupplierService supplierService, DynamicFieldService dynamicFieldService)
        {
            _db = db;
            _supplierService = supplierService;
            _dynamicFieldService = dynamicFieldService;
            _mapper = mapper;
            _oneSupplierFLMService = oneSupplierFLMService;
            _httpClientFactory = httpClientFactory;
            _config = config;
        }


        public async Task<IActionResult> Index(int? formno, string? headerid, string applytype)
        {
            //await _db.UseTransactionAsync(async ctx =>
            //{
            //    //await ctx.u;
            //});
            //// 1. 動態計算真正的目標步進
            //// 如果網址有帶 targetStep，就用網址帶的數字；如果完全沒帶（即從選單全新申請），則預設為步驟 1
            //int actualTargetStep = targetStep ?? 1;

            //// 2. 💡 留給您未來的草稿還原機制 (目前您先註解掉，未來要恢復時只要把 formId 傳入即可)
            //if (formno.HasValue)
            //{
            //    // SupplierSaveViewModel draftData = await _supplierService.GetDraftByIdAsync(formId.Value);
            //    // if (draftData != null) { ... 塞入 ViewBag ... }

            //    // 💡 防呆安全網：既然都有傳 formId 過來了，如果網址忘了寫 targetStep，通常代表要直接去步驟 2 編輯
            //    if (targetStep == null)
            //    {
            //        actualTargetStep = 2;
            //    }
            //}

            //// 3. 將最終計算出來的目標步驟塞入 ViewBag 傳給前端
            //// 正常填寫：此時值為 1 ➡️ 前端 Vue 判定 isJumpIn = false，正常顯示所有步驟。
            //// 查詢跳轉：此時值為 2 ➡️ 前端 Vue 判定 isJumpIn = true，自動執行 POST 並隱藏第一步。
            //ViewBag.TargetStep = actualTargetStep;
            //ViewBag.FormNo = formno;
            // 4. 維持您原本的設計，將 Steps 列表傳給 View

            if (formno > 0)
            {
                var decision = new DecisionData
                {
                    Types = new Dictionary<string, string> { { "suppliername", "" }, { "applytype", applytype } },
                    Datas = new Dictionary<string, string>() { }
                };
                var step2 = new Step2Data();

                step2["step2"] = decision;


                var boot = new
                {
                    FormInfo = new FormInfo() { headerid = headerid, formno = formno.ToString(), applytype = applytype },
                    targetStep = formno > 0 ? 2 : 1,
                    flowData = step2
                };
                ViewBag.Boot = JsonConvert.SerializeObject(boot);
            }
            //await (_db as GenericRepository).UseTransactionAsync(async db =>
            //{
            //    await db.InsertAsync(a);
            //    await db.UpdateAsync(b);
            //});
            //await _tx.Run(async ctx =>
            //{
            //    await ctx.;

            //});
            //var id = await tx.Run(async ctx =>
            //{

            //    await ctx.Repo().InsertAsync(a);
            //    return a.Id;
            //});
            //tx.Run(ctx =>
            //{
            //    ctx.Repo().Execute("UPDATE ...");
            //});
            return View(Steps);
        }

        [HttpPost]
        public async Task<IActionResult> Step([FromBody] StepRequest req)
        {
            var stepIndex = req.StepIndex;

            if (stepIndex < 1 || stepIndex > Steps.Count)
                return BadRequest("Invalid step index");

            var stepKey = "step" + req.StepIndex;
            var step = req.FlowData?[stepKey];

            var formno = req.FormInfo?.formno;
            var type = step?.Types;
            var decision = step?.Datas;

            var stepInfo = Steps[stepIndex - 1];

            object model = stepIndex switch
            {
                1 => await GenerateStep(stepIndex),
                2 => await GenerateStep(stepIndex, formno, type, decision),
                3 => await GenerateStep(stepIndex, formno, type),
                _ => null
            };
            ViewBag.Title = stepInfo.Title;
            return PartialView(stepInfo.PartialView, model);
        }

        async Task<IStepViewModel> GenerateStep(int stepIndex, string formno = "", Dictionary<string, object>? types = null, Dictionary<string, object>? values = null)
        {
            IStepViewModel? model = null;
            switch (stepIndex)
            {
                case 1:
                    Dictionary<string, List<TableSchema>> dic = new Dictionary<string, List<TableSchema>>();
                    var maker = new List<TableSchema>
                    {
                        new()
                        {
                            TableId = "tbMaker1",
                            AjaxUrl = "Supplier/GetMakerData",
                            FetchMode = FetchMode.All,
                            Message="* Existed in the company",

                            Features = new TableFeatures
                            {
                                Checkbox = false,
                                Export = true,
                                RowButtons = true,
                                ColumnToggle = true,
                                RowSelect = true,
                                SelectAll = true,
                                VirtualScroll = true,
                                ColumnFilter = false,   // 可選，每欄都有 filter
                                StickyHeader = true    // 可選，表頭固定
                            },

                            Config = new TableConfig
                            {
                                PageLength = 2,
                                VirtualScrollHeight = "500px",
                                Searching = false,
                                Ordering = false,
                                Paging = true,
                                LengthChange = false,
                                StateSave = true
                            },


                            Columns =  TableSchema.Create<vmMakerDetail>(new()
                            {
                                x => x.MakerCode,       // 自動轉為 "maker_code"
                                x => x.MakerLocalName,  // 自動轉為 "maker_local_name"
                                x => x.MakerEngName,
                                x => x.MakerShortName,
                                x => x.MakerEngName,
                                "Country",              // 自動轉為 "country"
                                "City",                 // 自動轉為 "city"
                                x => x.FacilityAddress,
                            }).Columns,


                            RowButtons =
                            {
                                new(){ Title="Add Another Maker Type", Event="addMakerType", Icon="bi-pencil"},
                                new(){ Title="Add New Site", Event="addNewSite", Icon="bi-pencil"}
                            }
                        },
                        new()
                        {
                            TableId = "tbMaker2",
                            AjaxUrl = "",
                            FetchMode = FetchMode.All,
                            Message="* Existed in the group companyd(excluding itself)",
                            Features = new TableFeatures
                            {
                                Checkbox = false,
                                Export = true,
                                RowButtons = true,
                                ColumnToggle = true,
                                RowSelect = true,
                                SelectAll = true,
                                VirtualScroll = true,
                                ColumnFilter = false,   // 可選，每欄都有 filter
                                StickyHeader = true    // 可選，表頭固定
                            },

                            Config = new TableConfig
                            {
                                PageLength = 20,
                                VirtualScrollHeight = "500px",
                                Searching = false,
                                Ordering = false,
                                Paging = false,
                                LengthChange = false,
                                StateSave = true
                            },

                            Columns =  TableSchema.Create<vmMakerDetail>(new()
                            {
                                x => x.MakerCode,       // 自動轉為 "maker_code"
                                x => x.MakerLocalName,  // 自動轉為 "maker_local_name"
                                x => x.MakerEngName,
                                x => x.MakerShortName,
                                x => x.MakerEngName,
                                "Country",              // 自動轉為 "country"
                                "City",                 // 自動轉為 "city"
                                x => x.FacilityAddress,
                                x => x.MakerStatus,
                            }).Columns,

                            RowButtons =
                            {
                                new(){ Title="Copy Maker", Event="cpMaker", Icon="bi-pencil"},
                            }
                        }
                    };
                    var vendor = new List<TableSchema>
                    {
                        new()
                        {
                              TableId = "tbVendor",
                              AjaxUrl = "Supplier/GetVendorData",
                              FetchMode = FetchMode.All,

                              Features = new TableFeatures
                              {
                                  Checkbox = false,
                                  Export = true,
                                  RowButtons = true,
                                  ColumnToggle = true,
                                  RowSelect = true,
                                  SelectAll = true,
                                  VirtualScroll = true,
                                  ColumnFilter = false,   // 可選，每欄都有 filter
                                  StickyHeader = true    // 可選，表頭固定
                              },

                              Config = new TableConfig
                              {
                                  PageLength = 20,
                                  VirtualScrollHeight = "500px",
                                  Searching = false,
                                  Ordering = false,
                                  Paging = false,
                                  LengthChange = false,
                                  StateSave = true
                              },

                              Columns =  TableSchema.Create<vmVendorDetail>(new()
                              {
                                    x => x.OUSite,
                                    x => x.Inactive,
                                    x => x.GroupName,
                                    x => x.GroupCode,
                                    x => x.VendorName,
                                    "VandorNameAlt",
                                    "VandorCode",
                                    x => x.SSRName,
                                    x => x.TaxRegistration,
                                    x => x.ApplyType,
                              }).Columns,
                        }
                    };
                    dic["maker"] = maker;
                    dic["vendor"] = vendor;
                    //dic = JsonConvert.DeserializeObject<Dictionary<string, List<TableSchema>>>(mock.j4);
                    model = new StepViewModel<TableSchema>
                    {
                        StepIndex = stepIndex,
                        Title = "第一頁",
                        Data = dic
                    };

                    break;
                case 2:
                    //先找CONFIG
                    //Dictionary<string, List<BaseDynamicField>> dic2 = new Dictionary<string, List<BaseDynamicField>>();
                    //string[] sections = ["Supplier Information", "Vendor Subrange", "Company Profile"];
                    ////string[] sections = ["Supplier Information"];
                    //foreach (var item in sections)
                    //{
                    //    dic2[item.Replace(" ", "")] = await _supplierService.GetConfigFieldAsync(item, types);
                    //}
                    ////var userFromDb = new UserProfile { CompanyCode = "Johnny", MakerType = "Normal", RequestReason = "test@me.com" };
                    //if (!string.IsNullOrEmpty(formno))
                    //{
                    //    await _supplierService.MappingFormData(dic2, formno);
                    //}

                    //_dynamicFieldService.FillSchemaWithDictionary(dic2, values);
                    var dic2 = JsonConvert.DeserializeObject<Dictionary<string, List<BaseDynamicField>>>(mock.j2);
                    //Logger.LogInformation(JsonConvert.SerializeObject(dic2));
                    model = new StepViewModel<BaseDynamicField>
                    {
                        StepIndex = stepIndex,
                        Title = "第二頁",
                        Data = (values == null || values.Count == 0) ? dic2 : await _supplierService.MappingSendData(dic2, values)
                    };
                    break;
                case 3:
                    Dictionary<string, List<BaseDynamicField>> dic3 = new();
                    dic3 = JsonConvert.DeserializeObject<Dictionary<string, List<BaseDynamicField>>>(mock.j3);
                    //dic3["STEP3"] = await _supplierService.GetConfigFileListAsync(formno, types);

                    //if (!string.IsNullOrEmpty(formno))
                    //{
                    //    await _supplierService.MappingFormData(dic3, formno);
                    //}
                    //Logger.LogInformation(JsonConvert.SerializeObject(dic3));
                    //_dynamicFieldService.FillSchemaWithDictionary(dic3, values);
                    model = new StepViewModel<BaseDynamicField>
                    {
                        StepIndex = stepIndex,
                        Title = "第三頁",
                        Data = dic3
                    };
                    break;
            }
            return model;
        }


        [HttpPost]
        public async Task<IActionResult> Draft([FromForm] DraftRequest req)
        {
            try
            {
                if (req.Payload != null)
                {
                    return BadRequest(new { success = false, message = "資料格式錯誤" });
                }

                //if (!ModelState.IsValid)
                //{
                //    return BadRequest(new { success = false, message = "資料欄位驗證失敗", errors = ModelState });
                //} 
                FormInfo form = await _supplierService.SaveAsync(req);
                return Ok(new { success = true, message = "暫存成功", FormInfo = form });
            }
            catch (Exception ex)
            {
                Logger.LogError(ex, ex.Message);
                return StatusCode(500, new { success = false, message = ex.Message });
            }
        }


        //[HttpPost]
        //public async Task<FormInfo> draft([FromBody] SupplierSaveViewModel payload)
        //{
        //    FormInfo form = new FormInfo();
        //    try
        //    {
        //        if (payload == null) return BadRequest("資料格式錯誤");
        //        // payload = JsonConvert.DeserializeObject<SupplierSaveViewModel>(data); 
        //        form = await _supplierService.SaveAsync(payload); 
        //    }
        //    catch (Exception ex)
        //    {

        //    }
        //    return Ok(new { success = true, message = "已成功接收並轉換",Form = form });
        //}
        //[HttpPost]
        //public async Task<IActionResult> submit([FromBody] SupplierSaveViewModel payload)
        //{
        //    if (payload == null) return BadRequest("資料格式錯誤");
        //    // payload = JsonConvert.DeserializeObject<SupplierSaveViewModel>(data); 
        //    await _supplierService.SaveAsync(payload);

        //    return Ok(new { success = true, message = "已成功接收並轉換" });
        //}
        //[HttpPost]
        //public async Task<IActionResult> Save([FromBody] SupplierSaveViewModel payload)
        //{
        //    //if (payload == null) return BadRequest("資料格式錯誤");
        //    var data = """

        //        {
        //          "Step1": {
        //            "suppliername": "MITSUI",
        //            "applytype": "Vendor",
        //            "decision": {
        //              "type": {
        //                "applytype": "Vendor"
        //              },
        //              "value": {
        //                "EventName": "addVendor"
        //              }
        //            }
        //          },
        //          "Step2": {
        //            "company_code": "AMSCTW",
        //            "vendor_class": "VC1",
        //            "vendor_group_code": "",
        //            "technology": "",
        //            "request_reason": "yyy",
        //            "upload_ssaaf": "",
        //            "ssr_description": "yyy",
        //            "currency": "",
        //            "payment_term": "",
        //            "incoterm": "",
        //            "freight_term": "",
        //            "tax_code": "",
        //            "bank_name": "y",
        //            "bank_branch": "y",
        //            "branch_country": "yy",
        //            "account_name": "yy",
        //            "account_number": "yy",
        //            "branch_address": "y",
        //            "bank_key": "y",
        //            "routing_number": "y",
        //            "swift_code": "yy",
        //            "iban": "y",
        //            "company_english_name": "y",
        //            "company_local_name": "y",
        //            "company_owner": "y",
        //            "historical_name": "y",
        //            "country": "",
        //            "city": "y",
        //            "facility_address": "y",
        //            "latitude": 22,
        //            "longitude": 33,
        //            "postal_code": "q",
        //            "website_url": "q",
        //            "tax_identification": "q",
        //            "vat_number": "q",
        //            "duns_number": "qe",
        //            "head_duns_number": "rtr",
        //            "register_number": "t",
        //            "contact_person": "fgdsg",
        //            "position": "sfdg",
        //            "e_mail": "gfg",
        //            "window_phone_number": "gsg",
        //            "company_office_number": "sgs",
        //            "fax_number": "gsgs",
        //            "language": "sgsg",
        //            "subsidiary": "gsg",
        //            "supplier_relationship": "sgs",
        //            "edi_connection": "",
        //            "decision": {
        //              "type": {
        //                "vendor_class": "VC1"
        //              },
        //              "value": {}
        //            }
        //          },
        //          "Step3": {
        //            "vc1_ssa.score": "",
        //            "vc1_ssa.file": "",
        //            "vc1_vda63_pa_self.score": "",
        //            "vc1_vda63_pa_self.file": "",
        //            "vc1_iatf16949.expired": "",
        //            "vc1_iatf16949.file": "",
        //            "vc1_iso9001.expired": "",
        //            "vc1_iso9001.file": "",
        //            "vc1_iso14001.expired": "",
        //            "vc1_iso14001.file": "",
        //            "vc1_tisax.expired": "",
        //            "vc1_tisax.file": "",
        //            "vc1_iso27001.expired": "",
        //            "vc1_iso27001.file": "",
        //            "vc1_mpa.score": "",
        //            "vc1_mpa.file": "",
        //            "vc1_poi": "",
        //            "vc1_poi.file": "",
        //            "vc1_amsc_qrs": "",
        //            "vc1_amsc_qrs.file": "",
        //            "vc1_fss.score": "",
        //            "vc1_fss.file": "",
        //            "vc1_amsc_plg": "",
        //            "vc1_amsc_plg.file": "",
        //            "vc1_pscr": "",
        //            "vc1_pscr.file": "",
        //            "vc1_sp02_23_tp_sra.score": "",
        //            "vc1_sp02_23_tp_sra.file": "",
        //            "vc1_wa": "",
        //            "vc1_wa.file": "",
        //            "vc1_ic": "",
        //            "vc1_ic.file": "",
        //            "vc1_rba": "",
        //            "vc1_rba.file": "",
        //            "vc1_gdpr": "",
        //            "vc1_gdpr.file": "",
        //            "vc1_cr_pdf": "",
        //            "vc1_cr_pdf.file": "",
        //            "vc1_obd_pdf": "",
        //            "vc1_obd_pdf.file": "",
        //            "vc1_pi": "",
        //            "vc1_pi.file": "",
        //            "vc1_omc_agent.score": "",
        //            "vc1_omc_agent.file": "",
        //            "vc1_email_cert_nc.score": "",
        //            "vc1_email_cert_nc.file": "",
        //            "vc1_ship_rem_cn.score": "",
        //            "vc1_ship_rem_cn.file": ""
        //          }
        //        }
        //        """;
        //    payload = JsonConvert.DeserializeObject<SupplierSaveViewModel>(data);

        //    // 取值範例
        //    //var name = payload.Step1.suppliername;
        //    //var vendorClass = payload.Step2["vendor_class"]?.ToString();
        //    await _supplierService.SaveAsync(payload);

        //    return Ok(new { success = true, message = "已成功接收並轉換" });
        //}
        //[HttpPost]
        //public IActionResult Save([FromBody] Dictionary<string, string> finalPayload)
        //{

        //    var result = JsonConvert.SerializeObject(finalPayload);




        //    // 檢查是否有資料
        //    if (finalPayload == null || !finalPayload.Any())
        //    {
        //        return BadRequest("未收到有效的 JSON 資料");
        //    }

        //    // 1. 這裡可以直接看到您的資料結構，例如：
        //    // var userName = finalPayload["BasicSection"]["UserName"];

        //    // 2. 接著執行您之前設定好的 AutoMapper 轉換
        //    // var userProfile = _mapper.Map<UserProfile>(finalPayload);

        //    // var userProfile = _mapper.Map<UserProfile>(rawData);
        //    //  var dbData = userProfile.ToDbParameters();

        //    _supplierService.Save(finalPayload);
        //    // 3. 執行 DB 儲存邏輯...

        //    return Ok(new { success = true, message = "已成功接收並轉換" });
        //}

        [HttpGet]
        public async Task<IActionResult> GetMakerData(string makername, string companyid)
        {
            if (string.IsNullOrEmpty(makername))
            {
                return Json(new
                {
                    success = true,
                    tbMaker1 = new List<vmMakerDetail>(), // 給第一個表的資料
                    tbMaker2 = new List<vmMakerDetail>()       // 給第二個表的資料
                });
            }


            var lsvwMaker1 = JsonConvert.DeserializeObject<List<vmMakerDetail>>(mock.j6);
            //var lsvwMaker1 = await _supplierService.GetMakerDataFromGroupAsync(makername, companyid);

            if (lsvwMaker1.Count == 0)
            {
                return NotFound(new { message = "找不到供應商資料" });
            }
            var lsvwMaker2 = JsonConvert.DeserializeObject<List<vmMakerDetail>>(mock.j7);
            //var lsvwMaker2 = await _supplierService.GetMakerDataInternalAsync(makername);

            if (lsvwMaker2.Count == 0)
            {
                return NotFound(new { message = "找不到供應商資料" });
            }

            //Logger.LogInformation(JsonConvert.SerializeObject(lsvwMaker1));
            //Logger.LogInformation(JsonConvert.SerializeObject(lsvwMaker2));

            return Json(new
            {
                success = true,
                tbMaker1 = lsvwMaker1,  // 這裡的 Key 就是前端 <table id="SupplierGrid">
                tbMaker2 = lsvwMaker2     // 這裡的 Key 就是前端 <table id="OrderGrid"> 
            });
        }

        [HttpGet]
        public async Task<IActionResult> GetVendorData(string vendorname)
        {
            if (string.IsNullOrEmpty(vendorname))
            {
                return Json(new
                {
                    success = true,
                    tbVendor = new List<vmVendorDetail>(),
                });
            }

            //await _supplierService.GetVendorInfoAsync(vendorname);
            //Logger.LogInformation(JsonConvert.SerializeObject(lsvmVender));

            var lsvmVender = JsonConvert.DeserializeObject<List<vmVendorDetail>>(mock.j5);
            //await _supplierService.GetVendorInfoAsync(vendorname);

            if (lsvmVender.Count == 0)
            {
                return NotFound(new { message = "找不到供應商資料" });
            }
            return Json(new
            {
                success = true,
                tbVendor = lsvmVender,  // 這裡的 Key 就是前端 <table id="SupplierGrid"> 
            });
        }

        [HttpGet]

        public async Task<IActionResult> GetSupplierForm()
        {

            var sectionConfigs = new Dictionary<string, List<BaseDynamicField>>();
            //var data = await _supplierService.GetConfigFieldAsync("Vendor","");
            sectionConfigs["Vendor"] = new List<BaseDynamicField>();//data;

            //// 模擬從資料庫查詢回來的結果
            //var fieldList = new List<DynamicField>
            //{
            //    // 第一列
            //    //new DynamicField {
            //    //    ColId = "Company", ColName = "Company", Section = "Basic",
            //    //    EnumType = FieldType.Select2, Must = true, Order = 1,
            //    //    attribute = "AMSCTW:AMSC Taiwan,AMSCCN:AMSC China"
            //    //},
            //    //new DynamicField {
            //    //    ColId = "Type", ColName = "Type", Section = "Basic",
            //    //    EnumType = FieldType.Textbox, DefaultValue = "New Vendor", Readonly = true, Order = 2
            //    //},
            //    //new DynamicField {
            //    //    ColId = "SupplierType", ColName = "Supplier Type", Section = "Basic",
            //    //    EnumType = FieldType.Dropdown, Must = true, Order = 3,
            //    //    attribute = "Trade,Manufacturer,Service"
            //    //},
            //    //new DynamicField {
            //    //    ColId = "EffectiveDate", ColName = "Effective Date", Section = "Basic",
            //    //    EnumType = FieldType.Date, Must = true, Order = 4, DefaultValue = "2026-03-24"
            //    //},

            //    // 第二列
            //    //new DynamicField {
            //    //    ColId = "GroupName", ColName = "Group Name", Section = "GroupInfo",
            //    //    EnumType = FieldType.Textbox, Must = true, Order = 5, Placeholder = "請輸入群組名稱"
            //    //},
            //    //new DynamicField {
            //    //    ColId = "GroupCode", ColName = "Group Code", Section = "GroupInfo",
            //    //    EnumType = FieldType.Textbox, Readonly = true, Order = 6
            //    //},
            //    //new DynamicField {
            //    //    ColId = "VendorType", ColName = "Vendor Type", Section = "GroupInfo",
            //    //    EnumType =  FieldType.Dropdown, Must = true, Order = 7,
            //    //    attribute = "Domestic,Overseas"
            //    //},

            //    // 地址與其他
            //    //new DynamicField {
            //    //    ColId = "City", ColName = "City", Section = "Address",
            //    //   EnumType = FieldType.Textbox, Must = true, Order = 8
            //    //},
            //    //new DynamicField {
            //    //    ColId = "Address", ColName = "Address", Section = "Address",
            //    //    EnumType = FieldType.Textarea, Must = true, Order = 9, Width = 6
            //    //}
            //};

            //// 將 List 依照 Section 分組，轉成 Dictionary<string, List<DynamicField>>
            //var viewModel = fieldList
            //    .OrderBy(f => f.Order)
            //    .GroupBy(f => f.Section)
            //    .ToDictionary(g => g.Key, g => g.ToList());

            // 回傳 Partial View 並帶入 Model
            return PartialView("Supplier/_VendorInfo", sectionConfigs);
        }
        [HttpPost]
        public async Task<IActionResult> UploadSSAAF(IFormFile file)
        {
            if (file == null || file.Length == 0)
            {
                return BadRequest("請選擇檔案");
            }

            // 安全性檢查：驗證副檔名
            var ext = Path.GetExtension(file.FileName).ToLowerInvariant();
            if (ext != ".xls" && ext != ".xlsx")
            {
                return BadRequest("僅支援 Excel 檔案");
            }
            return Json(await _supplierService.UploadSSAAF(file));
        }

        [HttpPost]
        public async Task<IActionResult> GetERP([FromBody] Dictionary<string, object> requestData)
        {
            if (!requestData.ContainsKey("methodName")) return BadRequest("Missing methodName");

            string methodName = requestData["methodName"].ToString();
            var parameters = requestData["params"]; // 這是實際要傳給 ASMX 的參數 
            string asmxUrl = $"{_config["ExternalServices:ErpUrl"]}/{methodName}";

            using (var client = _httpClientFactory.CreateClient())
            {

                var jsonPayload = JsonConvert.SerializeObject(parameters);
                var content = new StringContent(jsonPayload, System.Text.Encoding.UTF8, "application/json");

                try
                {
                    var response = await client.PostAsync(asmxUrl, content);
                    var result = await response.Content.ReadAsStringAsync();

                    return Content(result, "application/json");
                }
                catch (Exception ex)
                {
                    return StatusCode(500, ex.Message);
                }
            }
        }

        // ⭐ 1. 擴充強型別結構，塞入更多欄位（例如分行 Branch、 SwiftCode）
        private record BankItem(string Id, string Name, string Branch, string SwiftCode);

        [HttpGet]
        public async Task<IActionResult> SearchBanks(string? searchTerm, int page = 1)
        {
            try
            {
                List<BankDataDto> lsBank = new List<BankDataDto>();
                string asmxUrl = $"{_config["ExternalServices:ErpUrl"]}/FetchBankInfo";
                Dictionary<string, object> parameters = new Dictionary<string, object>();
                const int pageSize = 10;

                //using (var client = _httpClientFactory.CreateClient())
                //{
                //    parameters["bankname"] = searchTerm;
                //    var jsonPayload = JsonConvert.SerializeObject(parameters);
                //    var content = new StringContent(jsonPayload, System.Text.Encoding.UTF8, "application/json");
                //    var response = await client.PostAsync(asmxUrl, content);
                //    var result = await response.Content.ReadAsStringAsync();
                //    var wrapper = System.Text.Json.JsonSerializer.Deserialize<ApiOuterWrapper>(result);

                //    if (wrapper != null && !string.IsNullOrEmpty(wrapper.D))
                //    {
                //        lsBank = System.Text.Json.JsonSerializer.Deserialize<List<BankDataDto>>(wrapper.D) ?? new();
                //    }
                //}

                //Logger.LogInformation(JsonConvert.SerializeObject(lsBank));
                //lsBank = JsonConvert.DeserializeObject<List<BankDataDto>>();
                lsBank = new List<BankDataDto>
{
    new(
        bank_name: "Taiwan Cooperative Bank",
        bank_number: "006",
        bank_branch_name: "Hsinchu Branch",
        Bank_Country: "TW",
        branch_number: "0015",
        EFT_Swift_Code: "TACBTWTPXXX",
        Bank_Key: "TCB001"
    ),
    new(
        bank_name: "CTBC Bank",
        bank_number: "822",
        bank_branch_name: "Taichung Branch",
        Bank_Country: "TW",
        branch_number: "0102",
        EFT_Swift_Code: "CTCBTWTPXXX",
        Bank_Key: "CTBC822"
    ),
    new(
        bank_name: "Bank of Taiwan",
        bank_number: "004",
        bank_branch_name: "Taipei Main Branch",
        Bank_Country: "TW",
        branch_number: "0001",
        EFT_Swift_Code: "BKTWTWTPXXX",
        Bank_Key: "BOT004"
    )
};
                var totalCount = lsBank.Count();
                var pagedData = lsBank
                    .Skip((page - 1) * pageSize)
                    .Take(pageSize)
                    .Select(b => new
                    {
                        id = b.Bank_Country + b.Bank_Key + b.bank_branch_name,
                        text = b.Bank_Country + " " + b.Bank_Key + " " + b.bank_branch_name,
                        bankName = b.bank_name,
                        bankKey = b.Bank_Key,
                        bankCountry = b.Bank_Country,
                        branchName = b.branch_number,
                        swiftCode = b.EFT_Swift_Code
                    })
                    .ToList();

                bool morePages = (page * pageSize) < totalCount;

                return Json(new
                {
                    items = pagedData,
                    morePages = morePages
                });

            }
            catch (Exception ex)
            {
                return StatusCode(500, ex.Message);
            }


            //    // 2. 模擬多欄位的資料庫庫存
            //    var allBanks = new List<BankItem>
            //{
            //    new("004", "004 臺灣銀行", "總行營業部", "BKONTWTPXXX"),
            //    new("007", "007 第一銀行", "中山分行", "FIRSTWTPXXX"),
            //    new("012", "012 台北富邦銀行", "安和分行", "FUBONWTPXXX"),
            //    new("013", "013 國泰世華銀行", "敦南分行", "CATHAYWTPXXX"),
            //    new("822", "822 中國信託銀行", "城中分行", "CTBCWTPXXX")
            //};

            //    var query = allBanks.AsQueryable();
            //    if (!string.IsNullOrWhiteSpace(searchTerm))
            //    {
            //        query = query.Where(b => b.Name.Contains(searchTerm, StringComparison.OrdinalIgnoreCase));
            //    }


        }


        //[HttpPost]
        //public async Task<IActionResult> test([FromBody] AsyncValidationRequest req)
        //{
        //    //var json = dic["field"].ToString();
        //    //var dict = JsonConvert.DeserializeObject<Dictionary<string, string>>(json);
        //req.Fields["Latitude"] = "12";
        //req.Fields["Longitude"] = "12";
        //return Json(new
        //{
        //    valid = true,
        //    data = req.Fields
        //});
        //}
        [HttpPost]
        public async Task<IActionResult> GetLatLngByGoogle([FromBody] AsyncValidationRequest req)
        {
            vmGeography geoObj = new vmGeography();
            if (string.IsNullOrEmpty(req.Value.ToString()))
            {
                req.Fields["latitude"] = "";
                req.Fields["longitude"] = "";
                return Json(new
                {
                    valid = false,
                    data = req.Fields
                });
            }

            string asmxUrl = $"{_config["GoogleConfig:Url"]}";

            try
            {
                using (var client = _httpClientFactory.CreateClient())
                {

                    client.DefaultRequestHeaders.Add("sysid", _config["GoogleConfig:SysId"]);
                    client.DefaultRequestHeaders.Add("systoken", _config["GoogleConfig:SysToken"]);


                    vmGeography.PostData postData = new vmGeography.PostData { addr = req.Value.ToString() };
                    string json = JsonConvert.SerializeObject(postData);

                    var content = new StringContent(json, Encoding.UTF8, "application/json");


                    HttpResponseMessage httpResponse = await client.PostAsync(asmxUrl, content);
                    httpResponse.EnsureSuccessStatusCode();

                    string response = await httpResponse.Content.ReadAsStringAsync();


                    var result = JsonConvert.DeserializeObject<dynamic>(response);

                    if (result.status == "OK")
                    {
                        geoObj.LONGITUDE = result.results[0].geometry.location.lng;
                        geoObj.LATITUDE = result.results[0].geometry.location.lat;
                    }
                    else
                    {

                    }
                }


                req.Fields["latitude"] = geoObj.LATITUDE;
                req.Fields["longitude"] = geoObj.LONGITUDE;

            }
            catch (Exception ex)
            {
                req.Fields["latitude"] = "";
                req.Fields["longitude"] = "";
                return Json(new
                {
                    valid = false,
                    data = req.Fields
                });
            }
            return Json(new
            {
                valid = true,
                data = req.Fields
            });
        }

        [HttpGet]
        public IActionResult GetB5Modal()
        {
            // 直接回傳局部檢視，不需撈取資料庫
            return PartialView("_BankModal");
        }
    }
    public class AsyncValidationRequest
    {
        public object? Value { get; set; }

        public string? StepKey { get; set; }

        // trigger field
        public string? Field { get; set; }

        // map fields
        public Dictionary<string, string>? Fields { get; set; }

        // whole form data
        public Dictionary<string, object>? Data { get; set; }
    }

    public record ApiOuterWrapper([property: JsonPropertyName("d")] string D);
    public record BankDataDto(
        [property: JsonPropertyName("bank_name")] string bank_name,
        [property: JsonPropertyName("bank_number")] string bank_number,
        [property: JsonPropertyName("bank_branch_name")] string bank_branch_name,
        [property: JsonPropertyName("Bank_Country")] string Bank_Country,
        [property: JsonPropertyName("branch_number")] string branch_number,
        [property: JsonPropertyName("EFT_Swift_Code")] string EFT_Swift_Code,
        [property: JsonPropertyName("Bank_Key")] string Bank_Key
    );
}