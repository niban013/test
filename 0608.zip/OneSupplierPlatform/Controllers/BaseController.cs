﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;
using OneSupplierPlatform.Configuration;
using OneSupplierPlatform.i18n;
using OneSupplierPlatform.Infrastructure;
using OneSupplierPlatform.Models;
using System.Security.Claims;

namespace OneSupplierPlatform.Controllers
{
    public abstract class BaseController : Controller
    {
        protected CapUser CurrentUser
        {
            get
            {
                return new CapUser
                {
                    UserId = User.FindFirstValue(ClaimTypes.NameIdentifier),

                    EmployeeId = User.FindFirstValue("EmployeeId"),

                    RealName = User.FindFirstValue(ClaimTypes.Name),

                    Email = User.FindFirstValue(ClaimTypes.Email),

                    DepartmentId = User.FindFirstValue("DepartmentId"),

                    BossLevel = Convert.ToInt32(User.FindFirstValue("BossLevel")),

                    Site = User.FindFirstValue("Site"),

                    CompanyName = User.FindFirstValue("CompanyName")
                };
            }
        }
        private LocalizedKeys? _localizer;
        private SupplierQueryDto? _query;

        protected SupplierQueryDto Query
            => _query ??= EnterpriseQueryBinder.Bind<SupplierQueryDto>(Request.Query);
        protected LocalizedKeys Localizer => _localizer ??= HttpContext.RequestServices.GetRequiredService<LocalizedKeys>();
        private AppOptions? _config;

        protected AppOptions Config =>
            _config ??=
                HttpContext.RequestServices
                    .GetRequiredService<IOptions<AppOptions>>()
                    .Value;

        private ILogger? _logger;
        protected ILogger Logger => _logger ??= HttpContext.RequestServices.GetRequiredService<ILoggerFactory>().CreateLogger(GetType());
    }

}

