﻿using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using OneSupplierPlatform.Models.Infra;

namespace OneSupplierPlatform.Controllers
{ 
    public class ErrorController : Controller
    {
        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        [Route("Error/Index")]
        public IActionResult Index(string? requestId)
        {
            if (TempData["IsFromErrorFilter"] == null)
            {
                // 使用者手動輸入 URL，直接踢走
                return RedirectToAction("Index", "Home");
            }

            var viewModel = new ErrorViewModel
            {
                RequestId = requestId ?? Activity.Current?.Id ?? HttpContext.TraceIdentifier
            };
            return View(viewModel);
        }
    }
}
