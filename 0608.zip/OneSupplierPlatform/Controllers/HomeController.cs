using System.ComponentModel.Design;
using System.Diagnostics;
using System.Linq;
using Microsoft.AspNetCore.Mvc;
using newauo.Helper;
using OneSupplierPlatform.Filter;
using OneSupplierPlatform.Models.Infra;
using OneSupplierPlatform.Services;

namespace OneSupplierPlatform.Controllers
{
    [CapAuthorize]
    public class HomeController : BaseController
    {
        private readonly ILogger<HomeController> _logger;
        private readonly FlowerService _flowerService; 
        public HomeController(ILogger<HomeController> logger, FlowerService flowerService)
        {
            _logger = logger;
            _flowerService = flowerService;
        }
        public IActionResult Index()
        {
            //ViewBag.User = CurrentUser;
           // var ss = _flowerService.GetFormNo();
            return View();
        }
        ////[AllowCapAnonymous]
        ////[HttpPost]
        ////public IActionResult SetCapToken([FromBody] CapTokenModel model)
        ////{
        ////    if (model != null && !string.IsNullOrEmpty(model.Token))
        ////    {
        ////        // ��J��� Session
        ////        HttpContext.Session.SetString("CapAuthToken", model.Token);
        ////        return Json(new { success = true });
        ////    }
        ////    return Json(new { success = false });
        ////}
        // �s�W�o�@�q
        //public IActionResult NewSupplier()
        //{
        //    ViewData["Title"] = "New Supplier";
        //    return View();
        //}
        //public IActionResult Index()
        //{
        //    //var dd = Localizer.Hello;
        //    Logger.LogError($"�I�s����");
        //    Logger.LogError($"�I�s����");
        //    Logger.LogError($"�I�s����");
        //    return View();
        //}

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }

        //[HttpGet]
        //public async Task<IActionResult> GetSupplierData(string makername, string companyid, string makerlist)
        //{
        //    if (string.IsNullOrEmpty(makername)) return BadRequest();

        //    SupplierService _supplierService = new SupplierService();
        //    var viewModel = await _supplierService.GetSupplierDetail(makername, companyid, makerlist);

        //    if (viewModel == null)
        //    {
        //        return NotFound(new { message = "�䤣������Ӹ��" });
        //    }

        //    return Json(new { data = viewModel });
        //    // return Json(viewModel); // �^�ǵ��e�� JavaScript 
        //}

        //[HttpGet]
        //public async Task<IActionResult> GetDynamicFields()
        //{

        //    SupplierService _supplierService = new SupplierService();
        //    var viewModel = await _supplierService.GetDynamicFields();
        //    // �^�� Partial View�A�ñN��Ƽҫ��ǤJ
        //    // �T�O�z�� Views/Shared/ �άO Views/Home/ �U�� _DynamicFields.cshtml
        //    return PartialView("_DynamicFields", viewModel);
        //}
    }
}
