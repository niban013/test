﻿using Microsoft.AspNetCore.Mvc;
using System.Collections.Concurrent;

namespace OneSupplierPlatform.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class I18nController : ControllerBase
    {
        private readonly ConcurrentDictionary<string, string> _langCache;

        public I18nController(ConcurrentDictionary<string, string> langCache)
        {
            _langCache = langCache;
        }

        [HttpGet]
        public IActionResult Get([FromQuery] string culture)
        {
            if (string.IsNullOrEmpty(culture))
                culture = "zh-TW";

            if (!_langCache.TryGetValue(culture, out var json))
                json = "{}";

            return Content(json, "application/json");
        }
    }
}
