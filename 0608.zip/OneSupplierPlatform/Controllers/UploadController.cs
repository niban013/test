﻿using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Mvc;
using OneSupplierPlatform.Models;
using OneSupplierPlatform.Services;

namespace newauo.Controllers
{
    [Route("[controller]")]
    public class UploadController : Controller
    {
        private readonly ISupplierService _supplierService;
        private readonly IConfiguration _config;
        public UploadController(SupplierService supplierService, IConfiguration config)
        {
            _supplierService = supplierService;
            _config = config;
        }

        [HttpGet("UploadFile")]
        public bool UploadFile()
        {

            return true;

        }
        [HttpGet("UploadFileAsync")]
        public async Task<bool> UploadFileAsync()
        {

            return true;

        }
        [HttpPost("UploadFileAsync")]
        public async Task<bool> UploadFileAsync([FromForm] List<FlmFileInfo> files)
        { 
            return await _supplierService.UploadFileAsync(files); 
        }

        [HttpPost("GetFileAsync")]
        public async Task<List<FlmFileInfo>> GetFileAsync(string itemKey, string formNo)
        {
            return await _supplierService.GetFileAsync(itemKey, formNo);
        } 
    }
}
