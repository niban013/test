﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;

namespace newauo.Helper
{
    [AttributeUsage(AttributeTargets.Property, AllowMultiple = false)]
    public class SkipAttribute : Attribute
    { 
        public string Reason { get; set; }

        public SkipAttribute() { }

        public SkipAttribute(string reason)
        {
            Reason = reason;
        }
    }
    public class CapAuthorizeAttribute : Attribute, IAuthorizationFilter
    {
        public void OnAuthorization(AuthorizationFilterContext context)
        {
            var config = context.HttpContext.RequestServices
                .GetRequiredService<IConfiguration>();

            var enabled = config.GetValue<bool>("CapAuth:Enabled");

            // ⭐ CAP 關閉 → 直接放行
            if (!enabled)
                return;

            // ⭐ 沒登入才擋
            if (!context.HttpContext.User.Identity?.IsAuthenticated ?? true)
            {
                context.Result = new UnauthorizedResult();
            }
        }
    }
}
