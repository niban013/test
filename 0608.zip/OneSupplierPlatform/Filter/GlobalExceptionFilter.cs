﻿using Microsoft.AspNetCore.Mvc.Filters;
using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;
using OneSupplierPlatform.HandleException;
using Microsoft.AspNetCore.Mvc.ViewFeatures;

namespace OneSupplierPlatform.Filter
{
    public class GlobalExceptionFilter : IExceptionFilter
    {
        private readonly ILogger<GlobalExceptionFilter> _logger;

        private readonly ITempDataDictionaryFactory _tempDataFactory;

        public GlobalExceptionFilter(ILogger<GlobalExceptionFilter> logger, ITempDataDictionaryFactory tempDataFactory)
        {
            _logger = logger;
            _tempDataFactory = tempDataFactory;
        }

        public void OnException(ExceptionContext context)
        {
            var requestId = Activity.Current?.Id ?? context.HttpContext.TraceIdentifier; 
            NLog.MappedDiagnosticsLogicalContext.Set("LogRequestId", requestId); 
            _logger.LogError(context.Exception, "【全域錯誤攔截】路徑: {Path} | 訊息: {Message}",
                context.HttpContext.Request.Path,
                context.Exception.Message);

            bool isFatal = context.Exception switch
            {
                ShowException => false,           // 自定義商務錯誤 -> 不轉向
                ArgumentException => false,      // 參數錯誤 -> 不轉向
                _ => true                        // 其餘系統錯誤 (Null, DB, etc.) -> 轉向
            };

           
            // 致命錯誤給罐頭訊息（安全），非致命給原始訊息（提示）
            string message = isFatal ? "系統發生連線、資料庫等不可預期錯誤，請聯繫管理員。" : context.Exception.Message;

            bool isAjax = context.HttpContext.Request.Headers["X-Requested-With"] == "XMLHttpRequest";

            var tempData = _tempDataFactory.GetTempData(context.HttpContext);
            tempData["IsFromErrorFilter"] = true;

            if (isAjax)
            { 
                context.Result = new JsonResult(new
                {
                    success = false,
                    requestId = requestId,
                    isFatal = isFatal, // ⭐ 告訴前端要不要轉向
                    message = message,
                    redirectUrl = $"/Error/Index?requestId={requestId}"
                })
                { StatusCode = 500 };
            }
            else
            {  
                context.Result = new RedirectToActionResult("Index", "Error", new { requestId });
            } 
            context.ExceptionHandled = true;
        }
    }
}
