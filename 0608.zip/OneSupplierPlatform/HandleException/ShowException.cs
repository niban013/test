﻿using System;
namespace OneSupplierPlatform.HandleException
{
    public class ShowException : Exception
    { 
        public ShowException() : base() { } 
        public ShowException(string message) : base(message) { } 
        public ShowException(string message, Exception innerException)
            : base(message, innerException) { }
    }
}
