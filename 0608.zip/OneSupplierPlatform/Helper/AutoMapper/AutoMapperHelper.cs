﻿using System.Reflection;
using AutoMapper;
using OneSupplierPlatform.Models;
using OneSupplierPlatform.Models.Infra;

namespace OneSupplierPlatform.Helper.AutoMapper
{
    [AttributeUsage(AttributeTargets.Class)]
    public class AutoMapDynamicAttribute : Attribute { }

    [AttributeUsage(AttributeTargets.Property)]
    public class DynamicFieldAttribute : Attribute
    {
        /// <summary>
        /// 區塊名稱 (Key)
        /// </summary>
        public string Section { get; set; } // 區塊名稱 (Key)
        /// <summary>
        /// 顯示名稱(欄位補充說明)
        /// </summary>
        public string Label { get; set; } = "";
        /// <summary>
        /// 對應 DB 的欄位名
        /// </summary>
        public string DbColumn { get; set; }
    }


    public class DynamicMappingProfile : Profile
    {
        public DynamicMappingProfile()
        {
            var modelTypes = AppDomain.CurrentDomain.GetAssemblies() 
            .Where(s => s.FullName != null && s.FullName.StartsWith("OneSupplierPlatform"))
            .SelectMany(s => s.GetTypes())
            .Where(t => t.GetCustomAttribute<AutoMapDynamicAttribute>() != null);

            foreach (var type in modelTypes)
            {
                // 規則 A：從 Dictionary<string, List<DynamicField>> 轉向 Model
                var listConverter = typeof(DynamicToModelConverter<>).MakeGenericType(type);
                CreateMap(typeof(Dictionary<string, List<BaseDynamicField>>), type)
                    .ConvertUsing(listConverter);

                // 規則 B：從 Dictionary<string, Dictionary<string, string>> 轉向 Model
                var nestedConverter = typeof(FlexibleNestedToModelConverter<>).MakeGenericType(type);
                CreateMap(typeof(Dictionary<string, Dictionary<string, string>>), type)
                    .ConvertUsing(nestedConverter);
            } 
        } 
    }
    public class FlexibleNestedToModelConverter<T> : ITypeConverter<Dictionary<string, Dictionary<string, string>>, T> where T : new()
    {
        public T Convert(Dictionary<string, Dictionary<string, string>> source, T destination, ResolutionContext context)
        {
            var model = new T();
            var flatData = source.SelectMany(x => x.Value)
                                 .ToDictionary(k => k.Key, v => v.Value, StringComparer.OrdinalIgnoreCase);

            foreach (var prop in typeof(T).GetProperties())
            {
                var attr = prop.GetCustomAttribute<DynamicFieldAttribute>();

                // 嘗試從字典取值，優先序：1. 屬性名 (Age) 2. DB 欄位名 (USR_AGE)
                string value = null;
                if (!flatData.TryGetValue(prop.Name, out value))
                {
                    if (attr?.DbColumn != null)
                        flatData.TryGetValue(attr.DbColumn, out value);
                }

                if (!string.IsNullOrWhiteSpace(value))
                {
                    try
                    {
                        var targetType = Nullable.GetUnderlyingType(prop.PropertyType) ?? prop.PropertyType;
                        prop.SetValue(model, System.Convert.ChangeType(value, targetType));
                    }
                    catch { /* skip */ }
                }
            }
            return model;
        }
    }

    // 針對 List<DynamicField> 的轉換器
    public class DynamicToModelConverter<T> : ITypeConverter<Dictionary<string, List<BaseDynamicField>>, T> where T : new()
    {
        public T Convert(Dictionary<string, List<BaseDynamicField>> source, T destination, ResolutionContext context)
        {
            var model = new T();
            if (source == null) return model; 
            var allFields = source.SelectMany(x => x.Value)
                                  .ToDictionary(f => f.ColId, f => f.ColValue, StringComparer.OrdinalIgnoreCase);

            foreach (var prop in typeof(T).GetProperties())
            {
                if (allFields.TryGetValue(prop.Name, out var value) && !string.IsNullOrWhiteSpace(value))
                {
                    try
                    {
                        var targetType = Nullable.GetUnderlyingType(prop.PropertyType) ?? prop.PropertyType;
                        prop.SetValue(model, System.Convert.ChangeType(value, targetType));
                    }
                    catch { /* 忽略錯誤 */ }
                }
            }
            return model;
        }
    }
}
