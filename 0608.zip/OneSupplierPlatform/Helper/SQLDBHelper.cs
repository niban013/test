﻿
using Dapper;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;


namespace OneSupplierPlatform_Service.Helpers
{
    public class SQLDBHelper
    {
        private readonly string _connectionString;

        // 直接注入 Configuration 取得連線字串，不再透過 DbContext
        public SQLDBHelper(IConfiguration configuration)
        {
            _connectionString = configuration.GetConnectionString("AMSC-SQLDB");
        }

        public async Task<IEnumerable<T>> QueryAsync<T>(string sql, object? parameters = null)
        {
            using (var connection = new SqlConnection(_connectionString))
            {
                return await connection.QueryAsync<T>(sql, parameters);
            }
        }

        public async Task<bool> ExecuteAsync<T>(string sql)
        { 
            using (var connection = new SqlConnection(_connectionString))
            {
                
                int rowsAffected = connection.Execute(sql); 
                return rowsAffected > 0 ? true : false; 
            } 
        }

        public async Task<T?> ExecuteScalarAsync<T>(string sql, object? parameters = null, CancellationToken cancellationToken = default)
        {
            using (var connection = new SqlConnection(_connectionString))
            {
                var command = new CommandDefinition(
                    commandText: sql,
                    parameters: parameters,
                    cancellationToken: cancellationToken
                ); 
                return await connection.ExecuteScalarAsync<T>(command);
            }
        }
    }
}