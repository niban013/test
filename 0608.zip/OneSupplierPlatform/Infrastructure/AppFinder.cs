﻿ 

namespace OneSupplierPlatform.Infrastructure
{
    public static class AppFinder
    { 
        public static IServiceProvider ServiceProvider { get; set; } = null!;
        public static T GetService<T>()
        {
            var httpContext = ServiceProvider.GetRequiredService<IHttpContextAccessor>().HttpContext;
            if (httpContext != null)
            {
                return httpContext.RequestServices.GetRequiredService<T>();
            }
            return ServiceProvider.GetRequiredService<T>();
        } 
    }
}
