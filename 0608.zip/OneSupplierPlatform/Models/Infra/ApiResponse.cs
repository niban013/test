﻿namespace OneSupplierPlatform.Models.Infra
{
    public class UploadFileResponse
    {
        public string FileId { get; set; }

        public string FileName { get; set; }

        public long Size { get; set; }

        public string Mime { get; set; }
    }
    public class ApiResponse<T>
    {
        public bool Success { get; set; }

        public string Message { get; set; }

        public T Data { get; set; }

        public static ApiResponse<T> Ok(
            T data,
            string message = "success")
        {
            return new ApiResponse<T>
            {
                Success = true,
                Message = message,
                Data = data
            };
        }

        public static ApiResponse<T> Fail(
            string message)
        {
            return new ApiResponse<T>
            {
                Success = false,
                Message = message,
                Data = default
            };
        }
    }

}
