namespace OneSupplierPlatform.Models.Infra
{
    public interface IStepViewModel { }
    public class StepViewModel<T> : IStepViewModel
    {
        public int StepIndex { get; set; }
        public string Title { get; set; }

        public string StepKey 
        {
            get => "Step"+ StepIndex.ToString();
        }
       
        public Dictionary<string, List<T>> Data { get; set; } = new Dictionary<string, List<T>>();
    }
}
