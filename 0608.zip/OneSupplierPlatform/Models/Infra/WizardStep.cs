﻿namespace OneSupplierPlatform.Models.Infra
{
    public class WizardOptions
    {
        public List<WizardStepOption> Steps { get; set; } = new();
        public bool AllowJumpToCompletedStep { get; set; } = true;
        public bool AutoSave { get; set; } = true;
    }

    public class WizardStepOption
    {
        public string Title { get; set; }
        public string PartialView { get; set; }
        public bool Completed { get; set; } = false;
        public bool Locked { get; set; } = true;
        public int StepIndex { get; set; }
        public Dictionary<string, object> Custom { get; set; } = new();
    }
}
