using System.Runtime.Intrinsics.X86;
using System.Xml.Linq;
using System;
using System.Diagnostics.Metrics;

namespace One_Supplier_Platform.Models
{
    public class vmDynamicField
    {
        public string FieldId { get; set; }
        public string Label { get; set; }
        public string FieldType { get; set; }// Text, Dropdown, Select2, Label
        public string Value { get; set; }
        public List<string> Options { get; set; }

        // �s�W�G�O�_������ (Must)
        public bool IsRequired { get; set; }
    }
}
