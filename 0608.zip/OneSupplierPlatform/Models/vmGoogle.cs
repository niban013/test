﻿namespace OneSupplierPlatform.Models
{ 
    /// <summary>
    /// 地理位置 / 經緯度
    /// </summary>
    public class vmGeography
    {
        //距離
        public string DISTANCE { get; set; }
        //單位
        public string UNIT { get; set; }
        //使用哪種API計算
        public string MAP_FROM { get; set; }
        // 地址
        public string ADDRESS { get; set; }
        // 緯度
        public string LATITUDE { get; set; }
        // 經度
        public string LONGITUDE { get; set; }

        public bool RESULT { get; set; } = false;

        //Post資料集
        public class PostData
        {
            //來源(經度)
            public string oriLng { get; set; }
            //來源(緯度)
            public string oriLat { get; set; }
            //目的(經度)
            public string destLng { get; set; }
            //目的(緯度)
            public string destLat { get; set; }
            //地址
            public string addr { get; set; }
        }
    }
}
