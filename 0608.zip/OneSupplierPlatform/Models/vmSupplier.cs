using System.Runtime.Intrinsics.X86;
using System.Xml.Linq;
using System;
using System.Diagnostics.Metrics;
using System.Text.Json.Serialization;
using Newtonsoft.Json;
using OneSupplierPlatform.Helper.AutoMapper;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using newauo.Helper;

namespace OneSupplierPlatform.Models
{
    public class vmSupplier
    {
        public string supplierName { get; set; }
        //public bool ShowRequestId => !string.IsNullOrEmpty(RequestId);
    }

    public class vmVendorDetail
    {
        [JsonProperty("ORG")]
        public string OUSite { get; set; }
        [JsonProperty("Inactive")]
        public string Inactive { get; set; }
        [JsonProperty("Group_Name")]
        public string GroupName { get; set; }
        [JsonProperty("Group_Code")]
        public string GroupCode { get; set; }
        [JsonProperty("Vendor_Name")]
        public string VendorName { get; set; }
        [JsonProperty("Vendor_Name_alt")]
        public string VandorNameAlt { get; set; }
        [JsonProperty("Vendor_Code")]
        public string VandorCode { get; set; }
        [JsonProperty("Vendor_Site_Id")]
        public string SSRName { get; set; }
        [JsonProperty("Vat_Registration_Num")]
        public string TaxRegistration { get; set; }
        [JsonProperty("Supplier_Type")]
        public string ApplyType { get; set; }
    }


    public class vmMakerDetail
    {
        public string EventName { get; set; } = "";
        public string MakerSn { get; set; }
        [JsonProperty("maker_code")]
        public string MakerCode { get; set; }
        [JsonProperty("maker_local_name")]
        public string MakerLocalName { get; set; }
        [JsonProperty("maker_english_name")]
        public string MakerEngName { get; set; }
        [JsonProperty("maker_short_name")]
        public string MakerShortName { get; set; }
        [JsonProperty("country")]
        public string Country { get; set; }
        [JsonProperty("city")]
        public string City { get; set; }

        public string companyid { get; set; }
        [JsonProperty("facility_address")]
        public string FacilityAddress { get; set; }

        public string companyname { get; set; }

        [JsonProperty("maker_status")]
        public string MakerStatus { get; set; }

        [JsonProperty("maker_type")]
        public string MakerType { get; set; }

        [JsonProperty("maker_group_code")]
        public string MakerGroupCode { get; set; }

    }


    [AutoMapDynamic]
    public class UserProfile
    {
        [DynamicField(Section = "Supplier Information", Label = "CompanyCode", DbColumn = "company_code")]
        public string CompanyCode { get; set; }

        [DynamicField(Section = "Supplier Information", Label = "MakerType", DbColumn = "maker_type")]
        public string MakerType { get; set; }

        [DynamicField(Section = "Supplier Information", Label = "RequestReason", DbColumn = "request_reason")]
        public string RequestReason { get; set; }
    }


    [Table("osp_vendor_header_r")]
    public class VendorHeader
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        [JsonProperty("headerid")]
        public string HeaderId { get; set; } = "0";
        [JsonProperty("form_no")]
        public string FormNo { get; set; }
        [JsonProperty("form_status")]
        public string FormStatus { get; set; }
        [JsonProperty("company_code")]
        public string CompanyCode { get; set; }
        [JsonProperty("vendor_code")]
        public string VendorCode { get; set; }
        [JsonProperty("maker_code")]
        public string MakerCode { get; set; }
        [JsonProperty("maker_type")]
        public string MakerType { get; set; }
        [JsonProperty("business_type")]
        public string BusinessType { get; set; }

        [JsonProperty("vendor_class")]
        public string VendorClass { get; set; }

        [JsonProperty("vendor_Group_code")]
        public string VendorGroupCode { get; set; }

        [JsonProperty("maker_group_code")]
        public string MakerGroupCode { get; set; }

        [JsonProperty("technology")]
        public string Technology { get; set; }
        [JsonProperty("request_reason")]
        public string RequestReason { get; set; }
        [JsonProperty("upload_ssaaf")]
        public string UploadSSAAF { get; set; }
        [Skip]
        [JsonProperty("upload_ssaaf_id")]
        public string upload_ssaaf_id { get; set; } 

        [JsonProperty("company_english_name")]
        public string CompanyEnglishName { get; set; }

        [JsonProperty("company_local_name")]
        public string CompanyLocalName { get; set; }

        [JsonProperty("maker_english_name")]
        public string MakerEnglishName { get; set; }

        [JsonProperty("maker_local_name")]
        public string MakerLocalName { get; set; }

        [JsonProperty("company_owner")]
        public string CompanyOwner { get; set; }

        [JsonProperty("historical_name")]
        public string HistoricalName { get; set; }

        [JsonProperty("country")]
        public string Contry { get; set; }

        [JsonProperty("city")]
        public string City { get; set; }

        [JsonProperty("facility_address")]
        public string FacilityAddress { get; set; }

        [JsonProperty("latitude")]
        public string Latitude { get; set; }

        [JsonProperty("longitude")]
        public string Longitude { get; set; }

        [JsonProperty("postal_code")]
        public string PostalCode { get; set; }

        [JsonProperty("website_url")]
        public string WebsiteUrl { get; set; }
        [JsonProperty("tax_identification")]
        public string TaxIdentification { get; set; }

        [JsonProperty("vat_number")]
        public string VatNumber { get; set; }

        [JsonProperty("duns_number")]
        public string DunsNumber { get; set; }

        [JsonProperty("head_duns_number")]
        public string headDunsNumber { get; set; }

        [JsonProperty("register_number")]
        public string RegisterNumber { get; set; }

        [JsonProperty("contact_person")]
        public string ContactPerson { get; set; }

        [JsonProperty("position")]
        public string Position { get; set; }

        [JsonProperty("e_mail")]
        public string Email { get; set; }

        [JsonProperty("window_phone_number")]
        public string WindowPhoneNumber { get; set; }

        [JsonProperty("company_office_number")]
        public string CompanyOfficeNumber { get; set; }

        [JsonProperty("fax_number")]
        public string FaxNumber { get; set; }

        [JsonProperty("language")]
        public string Language { get; set; }
        [JsonProperty("subsidiary")]
        public string Subsidiary { get; set; }

        [JsonProperty("supplier_relationship")]
        public string SupplierRelationship { get; set; }

        [JsonProperty("trading_partner_no")]
        public string TradingPartnerNo { get; set; }

        [JsonProperty("edi_connection")]
        public string EdiConnection { get; set; }

        [JsonProperty("emp_no")]
        public string EmpNo { get; set; } = "";

        [JsonProperty("emp_name")]
        public string EmpName { get; set; }

        [JsonProperty("emp_dept")]
        public string EmpDept { get; set; }

        [JsonProperty("active")]
        public string Active { get; set; }

        [JsonProperty("create_date")]
        public string CreateDate { get; set; }

        public string Apply_type { get; set; }
    }

    [Table("osp_vendor_subrange_r")]
    public class VendorSubrange
    {
        [Key]
        [JsonProperty("headerid")]
        public string HeaderId { get; set; }
        [Key]
        [JsonProperty("form_no")]
        public string FormNo { get; set; }
        [Key]
        [JsonProperty("line_id")]
        public string LineId { get; set; }

        [JsonProperty("company_code")]
        public string CompanyCode { get; set; }
        [JsonProperty("ssr_id")]
        public string SSRId { get; set; }

        [JsonProperty("ssr_description")]
        public string SSRdescription { get; set; }
        [JsonProperty("currency")]
        public string Currency { get; set; }
        [JsonProperty("payment_term")]
        public string PaymentTerm { get; set; }

        [JsonProperty("payment_term_desc")]
        public string PaymentTermDesc { get; set; }

        [JsonProperty("incoterm")]
        public string Incoterm { get; set; }
        [JsonProperty("incoterm_port")]
        public string IncotermPort { get; set; }

        [JsonProperty("freight_term")]
        public string FreightTerm { get; set; }

        [JsonProperty("freight_term_desc")]
        public string FreightTermDesc { get; set; }

        [JsonProperty("tax_code")]
        public string TaxCode { get; set; }

        [JsonProperty("contacts")]
        public string Contacts { get; set; }

        [JsonProperty("contacts_mail")]
        public string ContactsMail { get; set; }

        [JsonProperty("contacts_phone")]
        public string ContactsPhone { get; set; }

        [JsonProperty("blocked")]
        public string Blocked { get; set; }
    }
    [Table("osp_vendor_bank_r")]
    public class VendorBank
    {
        [Key]
        [JsonProperty("headerid")]
        public string HeaderId { get; set; }
        [Key]
        [JsonProperty("form_no")]
        public string FormNo { get; set; }
        [Key]
        [JsonProperty("bank_id")]
        public string BankId { get; set; }
        [JsonProperty("bank_ext_id")]
        public string BankExtId { get; set; }

        [JsonProperty("bank_name")]
        public string BankName { get; set; }
        [JsonProperty("bank_branch")]
        public string BankBranch { get; set; }

        [JsonProperty("account_name")]
        public string AccountName { get; set; }
        [JsonProperty("account_number")]
        public string AccountNumber { get; set; }

        [JsonProperty("branch_country")]
        public string BranchCountry { get; set; }
        [JsonProperty("branch_province")]
        public string BranchProvince { get; set; }
        [JsonProperty("branch_address")]
        public string BranchAddress { get; set; }
        [JsonProperty("branch_address2")]
        public string BranchAddress2 { get; set; }
        [JsonProperty("branch_address3")]
        public string BranchAddress3 { get; set; }
        [JsonProperty("bank_key")]
        public string BankKey { get; set; }

        [JsonProperty("routing_number")]
        public string RoutingNumber { get; set; }
        [JsonProperty("swift_code")]
        public string SwiftCode { get; set; }

        [JsonProperty("iban")]
        public string Iban { get; set; }
        [JsonProperty("f_bank_number")]
        public string FbankNumber { get; set; }
        [JsonProperty("f_branch_number")]
        public string FbranchNumber { get; set; }
        [JsonProperty("f_bank_name")]
        public string FbankName { get; set; }

        [JsonProperty("f_branch_name")]
        public string FbranchName { get; set; }
        [JsonProperty("f_swift_code")]
        public string FswiftCode { get; set; }

        [JsonProperty("bank_edit_flag")]
        public string BankEditFlag { get; set; }

    }

    [Table("osp_vendor_file_r")]
    public class VendorFile
    { 
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        [JsonProperty("SN")]
        public string SN { get; set; }
        [Key]
        [JsonProperty("headerid")]
        public string HeaderId { get; set; }
        [Key]
        [JsonProperty("formno")]
        public string FormNo { get; set; }
        [Key]
        [JsonProperty("item_id")]
        public string ItemId { get; set; }
        [Skip("����쬰��ݤ����޿�ϥΡA�����ͫe�ݰʺA���")]
        [JsonProperty("item_name")]
        public string ItemName { get; set; }
        [Skip("����쬰��ݤ����޿�ϥΡA�����ͫe�ݰʺA���")]
        [JsonProperty("FileId")]
        public string FileId { get; set; }
        [Skip("����쬰��ݤ����޿�ϥΡA�����ͫe�ݰʺA���")]
        [JsonProperty("FileName")]
        public string FileName { get; set; }

        [JsonProperty("Active")]
        public string Active { get; set; }

        [JsonProperty("CUser")]
        public string CUser { get; set; }
        [JsonProperty("CDate")]
        public DateTime CDate { get; set; }

        [JsonProperty("Score")]
        public string Score { get; set; }

        [JsonProperty("Expire_Date")]
        public string expired { get; set; } = "";
    }
}




 
