﻿using System.Data;
using System.Reflection;
using OneSupplierPlatform.Helper.AutoMapper;
using OneSupplierPlatform.Models;
using OneSupplierPlatform.Models.Infra;


namespace OneSupplierPlatform.Services
{
    public class DynamicFieldService
    {
        public void FillSchemaWithDictionary(Dictionary<string, List<BaseDynamicField>> schema, Dictionary<string, object> dic)
        {
            try
            {
                if (dic == null || schema == null) return;
                 
                var lookup = dic.ToDictionary(x => x.Key, x => x.Value, StringComparer.OrdinalIgnoreCase); 
                foreach (var section in schema.Values)
                {
                    foreach (var field in section)
                    {
                         
                        if (lookup.TryGetValue(field.ColId, out var val))
                        {
                            // 確保轉成字串，如果是 null 則給 null
                            field.ColValue = val?.ToString();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
            } 
        }
    }
}
