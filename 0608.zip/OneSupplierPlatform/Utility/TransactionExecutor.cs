﻿namespace OneSupplierPlatform.Utility
{
    public class TransactionExecutor
    {
        private readonly GenericRepository _ctx;

        public TransactionExecutor(GenericRepository ctx)
        {
            _ctx = ctx;
        }

        public async Task Run(Func<ITransactionContext, Task> action)
        {
            _ctx.Begin();

            try
            {
                await action(_ctx);
                _ctx.Commit();
            }
            catch
            {
                _ctx.Rollback();
                throw;
            }
        }
    }
}
