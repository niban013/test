﻿using Dapper;
using Newtonsoft.Json;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Reflection;

namespace OneSupplierPlatform.Utility
{
    public static class TransactionRepositoryExtensions
    {
        // =====================================================
        // SAVE
        // =====================================================
        public static async Task SaveAsync<T>(this ITransactionContext ctx, T entity)
        {
            await ctx.UpsertAsync(entity);
        }

        public static async Task UpsertAsync<T>(this ITransactionContext ctx, T entity)
        {
            var type = typeof(T);
            var table = GetTableName(type);
            var keyProps = GetKeyProperties(type);

            var keyDict = keyProps.ToDictionary(
                k => k.Name,
                k => k.GetValue(entity)
            );

            var exists = await ctx.ExistsAsync(table, keyProps, keyDict);

            if (exists)
                await ctx.UpdateAsync(entity);
            else
                await ctx.InsertAsync(entity);
        }

        // =====================================================
        // EXISTS
        // =====================================================
        public static async Task<bool> ExistsAsync(
            this ITransactionContext ctx,
            string table,
            List<PropertyInfo> keyProps,
            Dictionary<string, object> keys)
        {
            var where = new List<string>();
            var param = new DynamicParameters();

            foreach (var kp in keyProps)
            {
                var col = GetColumnName(kp);
                where.Add($"{col}=@{col}");
                param.Add("@" + col, keys[kp.Name]);
            }

            var sql = $@"
SELECT 1 FROM {table}
WHERE {string.Join(" AND ", where)}";

            var result = await ctx.Connection.QueryFirstOrDefaultAsync<int?>(
                sql, param, ctx.Transaction);

            return result.HasValue;
        }

        // =====================================================
        // INSERT
        // =====================================================
        public static async Task InsertAsync<T>(this ITransactionContext ctx, T entity)
        {
            var type = typeof(T);
            var table = GetTableName(type);
            var props = GetProps(type);

            var cols = new List<string>();
            var vals = new List<string>();
            var param = new DynamicParameters();

            foreach (var p in props)
            {
                if (IsIdentity(p)) continue;

                var val = p.GetValue(entity);
                if (val == null) continue;

                var col = GetColumnName(p);

                cols.Add(col);
                vals.Add("@" + col);
                param.Add("@" + col, val);
            }

            var sql = $@"
INSERT INTO {table}
({string.Join(",", cols)})
VALUES
({string.Join(",", vals)})
";

            await ctx.Connection.ExecuteAsync(sql, param, ctx.Transaction);
        }

        // =====================================================
        // UPDATE
        // =====================================================
        public static async Task UpdateAsync<T>(this ITransactionContext ctx, T entity)
        {
            var type = typeof(T);
            var table = GetTableName(type);

            var keyProps = GetKeyProperties(type);
            var props = GetProps(type);

            var sets = new List<string>();
            var where = new List<string>();
            var param = new DynamicParameters();

            foreach (var p in props)
            {
                var col = GetColumnName(p);
                var val = p.GetValue(entity) ?? DBNull.Value;

                if (keyProps.Contains(p))
                    where.Add($"{col}=@{col}");
                else
                    sets.Add($"{col}=@{col}");

                param.Add("@" + col, val);
            }

            var sql = $@"
UPDATE {table}
SET {string.Join(",", sets)}
WHERE {string.Join(" AND ", where)}
";

            await ctx.Connection.ExecuteAsync(sql, param, ctx.Transaction);
        }

        // =====================================================
        // DELETE
        // =====================================================
        public static async Task DeleteAsync<T>(this ITransactionContext ctx, object keys)
        {
            var type = typeof(T);
            var table = GetTableName(type);
            var keyProps = GetKeyProperties(type);

            var where = new List<string>();
            var param = new DynamicParameters();

            foreach (var kp in keyProps)
            {
                var col = GetColumnName(kp);
                var val = GetKeyValue(keys, kp.Name);

                if (!IsValidValue(val))
                    continue;

                where.Add($"{col}=@{col}");
                param.Add("@" + col, val);
            }

            var sql = $@"DELETE FROM {table} WHERE {string.Join(" AND ", where)}";

            await ctx.Connection.ExecuteAsync(sql, param, ctx.Transaction);
        }

        // =====================================================
        // GET
        // =====================================================
        public static async Task<T> GetAsync<T>(this ITransactionContext ctx, object keys)
            where T : new()
        {
            var type = typeof(T);
            var table = GetTableName(type);
            var keyProps = GetKeyProperties(type);

            var where = new List<string>();
            var param = new DynamicParameters();

            foreach (var kp in keyProps)
            {
                var col = GetColumnName(kp);
                var val = GetKeyValue(keys, kp.Name);

                if (!IsValidValue(val))
                    continue;

                where.Add($"{col}=@{col}");
                param.Add("@" + col, val);
            }

            var sql = $@"SELECT * FROM {table} WHERE {string.Join(" AND ", where)}";

            return await ctx.Connection.QueryFirstOrDefaultAsync<T>(
                sql, param, ctx.Transaction);
        }

        // =====================================================
        // QUERY
        // =====================================================
        public static async Task<List<T>> QueryAsync<T>(
            this ITransactionContext ctx,
            string sql,
            object param = null)
        {
            var result = await ctx.Connection.QueryAsync<T>(
                sql, param, ctx.Transaction);

            return result.ToList();
        }

        public static Task<T> QuerySingleAsync<T>(
            this ITransactionContext ctx,
            string sql,
            object param = null)
        {
            return ctx.Connection.QueryFirstOrDefaultAsync<T>(
                sql, param, ctx.Transaction);
        }

        public static Task<int> ExecuteReturnAsync(
            this ITransactionContext ctx,
            string sql,
            object param = null)
        {
            return ctx.Connection.ExecuteAsync(sql, param, ctx.Transaction);
        }

        public static Task<T> ExecuteScalarAsync<T>(
            this ITransactionContext ctx,
            string sql,
            object param = null)
        {
            return ctx.Connection.ExecuteScalarAsync<T>(sql, param, ctx.Transaction);
        }

        // =====================================================
        // HELPERS（完整保留）
        // =====================================================
        private static string GetTableName(Type type)
        {
            var attr = type.GetCustomAttribute<TableAttribute>();
            return attr?.Name ?? type.Name;
        }

        private static List<PropertyInfo> GetKeyProperties(Type type)
        {
            var keys = type.GetProperties()
                .Where(p => p.GetCustomAttribute<KeyAttribute>() != null)
                .ToList();

            if (!keys.Any())
                throw new Exception($"No [Key] defined on {type.Name}");

            return keys;
        }

        private static List<PropertyInfo> GetProps(Type type)
            => type.GetProperties()
                .Where(p => p.CanRead && p.CanWrite)
                .ToList();

        private static string GetColumnName(PropertyInfo prop)
        {
            var json = prop.GetCustomAttribute<JsonPropertyAttribute>();
            return json?.PropertyName ?? prop.Name;
        }

        private static object GetKeyValue(object obj, string name)
            => obj.GetType().GetProperty(name)?.GetValue(obj);

        private static bool IsIdentity(PropertyInfo p)
        {
            var attr = p.GetCustomAttribute<DatabaseGeneratedAttribute>();
            return attr != null &&
                   attr.DatabaseGeneratedOption == DatabaseGeneratedOption.Identity;
        }

        private static bool IsValidValue(object value)
        {
            if (value == null) return false;
            if (value is string s && string.IsNullOrWhiteSpace(s))
                return false;

            return true;
        }
    }
}
