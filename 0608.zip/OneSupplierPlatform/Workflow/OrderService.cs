﻿namespace OneSupplierPlatform.Workflow
{
    public class OrderResultDto
    {
        public int Id { get; set; }

        public string OrderNo { get; set; }

        public string Status { get; set; }

        public string Message { get; set; }

        public DateTime ActionTime { get; set; }
    }
    public class OrderService
    {
        public Task<OrderResultDto> Submit(OrderDto dto)
        {
            return Task.FromResult(new OrderResultDto
            {
                Id = dto.Id,
                Status = "Submitted"
            });
        }

        public Task<OrderResultDto> Reject(OrderDto dto)
        {
            return Task.FromResult(new OrderResultDto
            {
                Id = dto.Id,
                Status = "Rejected"
            });
        }
    }
}
