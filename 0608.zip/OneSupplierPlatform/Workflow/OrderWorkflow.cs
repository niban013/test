﻿using OneSupplierPlatform.Models.Infra;

namespace OneSupplierPlatform.Workflow
{
    public class OrderDto
    {
        public int Id { get; set; }

        public string OrderNo { get; set; }

        public string SupplierCode { get; set; }

        public decimal Amount { get; set; }
    }
    public class OrderWorkflow : WorkflowBase<OrderService>
    {
        public OrderWorkflow(OrderService service)
            : base(service)
        {
        }

        public Task<ApiResponse<object>> Submit(OrderDto dto)
            => ExecuteAsync(nameof(Submit), dto);

        public Task<ApiResponse<object>> Reject(OrderDto dto)
            => ExecuteAsync(nameof(Reject), dto);

        ////public Task<ApiResponse<object>> Approve(OrderDto dto)
        ////    => ExecuteAsync(nameof(Approve), dto);
    }
}
