﻿using OneSupplierPlatform.Models.Infra;

namespace OneSupplierPlatform.Workflow
{
    public abstract class WorkflowBase<TService>
    {
        protected readonly TService Service;

        protected WorkflowBase(TService service)
        {
            Service = service;
        }

        // ⭐ 統一入口：用 action name 呼叫 service method
        protected async Task<ApiResponse<object>> ExecuteAsync(
            string action,
            object dto)
        {
            try
            {
                var method = typeof(TService)
                    .GetMethod(action);

                if (method == null)
                    return ApiResponse<object>.Fail($"Method not found: {action}");

                var resultTask = method.Invoke(Service, new[] { dto });

                if (resultTask is not Task task)
                    return ApiResponse<object>.Fail("Service must return Task");

                await task.ConfigureAwait(false);

                var resultProperty = task.GetType().GetProperty("Result");

                var result = resultProperty?.GetValue(task);

                return ApiResponse<object>.Ok(result);
            }
            catch (Exception ex)
            {
                return ApiResponse<object>.Fail(ex.Message);
            }
        }
    }
}
