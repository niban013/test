﻿using OneSupplierPlatform.Models.Infra;
using System.Collections.Concurrent;
using System.Linq.Expressions;
using System.Reflection;
using System.Text.Json;

namespace OneSupplierPlatform.Workflow
{

    public class WorkflowHandler
    {
        public Type ServiceType { get; set; }

        public Type PayloadType { get; set; }

        public Func<IServiceProvider, object> ServiceFactory { get; set; }

        public Func<object, object, Task<object>> Executor { get; set; }
    }
    public static class WorkflowExecutorCache
    {
        private static readonly ConcurrentDictionary<MethodInfo,
            Func<object, object, Task<object>>> _cache = new();

        public static Func<object, object, Task<object>> Get(MethodInfo method)
            => _cache.GetOrAdd(method, Compile);

        private static Func<object, object, Task<object>> Compile(MethodInfo method)
        {
            var serviceParam = Expression.Parameter(typeof(object), "service");
            var dtoParam = Expression.Parameter(typeof(object), "dto");

            var parameters = method.GetParameters();

            if (parameters.Length != 1)
                throw new InvalidOperationException(
                    $"Workflow method must have exactly 1 parameter: {method.DeclaringType?.Name}.{method.Name}");

            var serviceType = method.DeclaringType!;
            var dtoType = parameters[0].ParameterType;

            // cast service
            var castService = Expression.Convert(serviceParam, serviceType);

            // cast dto
            var castDto = Expression.Convert(dtoParam, dtoType);

            // call method
            var call = Expression.Call(castService, method, castDto);

            // wrap Task / Task<T>
            var wrapped = Expression.Call(
                typeof(WorkflowExecutorCache),
                nameof(WrapResult),
                Type.EmptyTypes,
                call
            );

            var lambda = Expression.Lambda<Func<object, object, Task<object>>>(
                wrapped,
                serviceParam,
                dtoParam
            );

            return lambda.Compile();
        }

        // unwrap Task / Task<T>
        public static async Task<object> WrapResult(Task task)
        {
            await task.ConfigureAwait(false);

            if (task == null)
                return null;

            var type = task.GetType();

            if (!type.IsGenericType)
                return null;

            var resultProperty = type.GetProperty("Result");

            return resultProperty?.GetValue(task);
        }
    }
    public class WorkflowDispatcher
    {
        private readonly IServiceProvider _sp;
        private readonly Dictionary<string, WorkflowHandler> _handlers = new();

        public WorkflowDispatcher(IServiceProvider sp)
        {
            _sp = sp;
        }

        // =========================
        // Scan
        // =========================
        public void Scan(params Assembly[] assemblies)
        {
            foreach (var asm in assemblies)
            {
                var serviceTypes = asm.GetTypes()
                    .Where(t =>
                        t.IsClass &&
                        !t.IsAbstract &&
                        t.Name.EndsWith("Service"));

                foreach (var type in serviceTypes)
                {
                    var module = type.Name.Replace("Service", "");

                    var methods = type.GetMethods(BindingFlags.Public | BindingFlags.Instance)
                        .Where(m =>
                            m.DeclaringType == type &&
                            !m.IsSpecialName &&
                            !m.IsGenericMethodDefinition &&
                            typeof(Task).IsAssignableFrom(m.ReturnType) &&
                            m.GetParameters().Length == 1);

                    foreach (var method in methods)
                    {
                        _handlers[$"{module}.{method.Name}"] = new WorkflowHandler
                        {
                            ServiceType = type,
                            PayloadType = method.GetParameters()[0].ParameterType,

                            ServiceFactory = sp => sp.GetRequiredService(type),

                            Executor = WorkflowExecutorCache.Get(method)
                        };
                    }
                }
            }
        }

        // =========================
        // Execute
        // =========================
        public async Task<ApiResponse<object>> Execute(WorkflowRequest request)
        {
            var key = $"{request.Module}.{request.Action}";

            if (!_handlers.TryGetValue(key, out var handler))
            {
                return ApiResponse<object>.Fail($"Not found: {key}");
            }
            Console.WriteLine(request.Payload.GetType().FullName);
            Console.WriteLine(request.Payload.ToString());
            var service = handler.ServiceFactory(_sp);

            //var json = request.Payload.GetRawText();

            var dto = JsonSerializer.Deserialize(
                request.Payload,
                handler.PayloadType,
                new JsonSerializerOptions
                {
                    PropertyNameCaseInsensitive = true
                });
            var result = await handler.Executor(service, dto);

            return ApiResponse<object>.Ok(result);
        }
    }
}
