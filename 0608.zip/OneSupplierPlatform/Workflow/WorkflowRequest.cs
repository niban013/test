﻿namespace OneSupplierPlatform.Workflow
{
    public class WorkflowRequest
    {
        public string Module { get; set; }

        public string Action { get; set; }

        public string Payload { get; set; }
    }
}
