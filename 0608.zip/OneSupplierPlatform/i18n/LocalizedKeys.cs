﻿

using System.Globalization;
using System.Text.Json;
using System.Collections.Concurrent;

namespace OneSupplierPlatform.i18n
{
    public class LocalizedKeys
    {
        private readonly ConcurrentDictionary<string, string> _langCache;

        public LocalizedKeys(ConcurrentDictionary<string, string> langCache)
        {
            _langCache = langCache;
        }

        private Dictionary<string, string> GetLang()
        {
            var culture = CultureInfo.CurrentUICulture.Name;

            if (_langCache.TryGetValue(culture, out var json))
            {
                return JsonSerializer.Deserialize<Dictionary<string, string>>(json)
                       ?? new Dictionary<string, string>();
            }

            return new Dictionary<string, string>();
        }

        public string T(string key)
        {
            if (string.IsNullOrEmpty(key)) return string.Empty;
            return GetLang().GetValueOrDefault(key) ?? key; // 找不到翻譯時回傳 Key 本身
        }
         // --- 新增：索引器 (可用 @Localizer["Dynamic_Key"]) ---
        public string this[string key] => T(key);

        public string Home => T("Home");
        public string Submit => T("Submit");
        public string Required => T("Required");
        public string Apply => T("Apply");
        public string NewSupplier => T("NewSupplier");
        public string Query => T("Query");
        public string Management => T("Management");
    }
}