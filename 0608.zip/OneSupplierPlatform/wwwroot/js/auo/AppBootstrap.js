﻿const REQUIRED_MODULES = [
    
    "FieldBinder",
    "FlowStore",
    //"FormValidation"
];
window.AppBootstrap = (() => {

    const modules = {};
    let ready = false;

    function checkReady() {
        ready = REQUIRED_MODULES.every(k => modules[k]);
        return ready;
    }

    return {

        register(name, instance) {
            modules[name] = instance;
            checkReady();
        },

        get(name) {
            return modules[name];
        },

        isReady() {
            return ready;
        },

        wait(timeout = 3000) {
            return new Promise((resolve) => {

                const start = Date.now();

                const loop = () => { 

                    const ready = REQUIRED_MODULES.every(k => modules[k]);

                    if (ready) {
                        resolve(this.modules);
                        return;
                    }

                    if (Date.now() - start > timeout) {
                        console.warn("Bootstrap timeout (non-blocking)");
                        resolve(this.modules); // ⭐ 不 reject
                        return;
                    }

                    requestAnimationFrame(loop);
                };

                loop();
            });
        }
    };

})();