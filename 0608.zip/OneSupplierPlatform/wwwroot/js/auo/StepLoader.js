﻿
window.API_BASE_URL = "OneSupplierPlatform";
window.StepRegistry = (() => { 
    const modules = {};
    const waiters = {}; 
    return { 
        register(name, module) { 
            modules[name] = module; 
            if (waiters[name]) {
                waiters[name].forEach(fn => fn(module));
                delete waiters[name];
            }
        }, 

        get(name) {
            return modules[name];
        },

        wait(name, timeoutMs = 10000) {
            return new Promise((resolve, reject) => {

                // 已存在直接回
                if (modules[name]) {
                    resolve(modules[name]);
                    return;
                }

                const timer = setTimeout(() => {
                    //reject(new Error(`Step module timeout: ${name}`));
                }, timeoutMs);

                waiters[name] ||= [];
                waiters[name].push((module) => {
                    clearTimeout(timer);
                    resolve(module);
                });
            });
        },

        // ⭐ 新增（很重要）
        clear(name) {
            delete modules[name];
        }
    }; 

})();
window.StepLoader = (() => {
    function injectHtmlWithScripts(container, html) {
        try {
            const parser = new DOMParser();
            const doc = parser.parseFromString(html, "text/html");

            container.innerHTML = "";

            doc.body.childNodes.forEach(node => {
                if (node.tagName === "SCRIPT") return;
                container.appendChild(node.cloneNode(true));
            });

            doc.querySelectorAll("script").forEach(oldScript => {
                const s = document.createElement("script");

                if (oldScript.src) {
                    s.src = oldScript.src;
                } else {
                    s.textContent = oldScript.textContent;
                }

                document.body.appendChild(s);
            });

            return true; // ✅ 成功

        } catch (err) {
            console.error("inject failed:", err);
            return false; // ❌ 直接 fail
        }
    }
    function renderError(err, container) {
        if (!container) container = document.getElementById("step-container");

        container.innerHTML = `
        <div style="color:red;padding:12px">
            ${err.message}
        </div>
    `;

        return container;
    }
    function isErrorPage(html) {

        return (
            html.includes("Server Error") ||
            html.includes("Exception") ||
            html.includes("Request failed") ||
            html.includes("Runtime Error") ||

            // 🔥 最重要
            !html.includes("StepRegistry.register")
        );
    }
    async function load(stepIndex, ctx) {
        const storeKey = "decision";
        const store = AppBootstrap.get("FlowStore");

        const prevStep = stepIndex > 1 ? stepIndex - 1 : stepIndex;

        const extraData = store.get(`step${prevStep}`, storeKey);

        window.FlowStore.safeSet("supplier", "FormInfo", ctx.boot?.FormInfo);

        let flowData = null;

        if (ctx.boot?.flowData && ctx.boot?.flowData?.step1 == null && stepIndex <= 2) {
            flowData = ctx.boot?.flowData;
        } else {
            flowData = extraData
                ? {
                    [`step${stepIndex}`]: {
                        types: extraData.type,
                        datas: JSON.parse(JSON.stringify(extraData.value))
                    }
                }
                : null;
        }

        const payload = {
            stepIndex,
            FormInfo: ctx.boot?.FormInfo,
            flowData
        };

        let res, html;

        // =========================
        // 1️⃣ FETCH LAYER
        // =========================
        try {
            res = await fetch(`${window.AppBasePath}Supplier/Step`, {
                method: "post",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify(payload)
            });

            if (!res.ok) {
                throw new Error(await res.text());
            }

            html = await res.text();

        } catch (err) {
            console.error("Fetch failed:", err);
            return renderError(err);
        }

        const container = document.getElementById("step-container");
        const key = `step${stepIndex}`;

        // =========================
        // 2️⃣ DESTROY OLD STEP
        // =========================
        try {
            if (ctx.currentPage?.destroy) {
                ctx.currentPage.destroy(container, ctx.currentStep);
            }
        } catch (e) {
            console.warn("destroy failed:", e);
        }

        window.FieldBinder.unbindAll(container);
        StepRegistry.clear(key);
        GraphV2.unregisterStep(key);

        // =========================
        // 3️⃣ CHECK MVC ERROR PAGE
        // =========================
        if (isErrorPage(html)) {

            console.error("MVC returned error page");
            container.innerHTML = html;
            window.__FLOW_ERROR__ = true;
            window.dispatchEvent(new CustomEvent("flow-error"));

            return container;
            //return renderError(
            //    new Error("Invalid step response (MVC error page)"),
            //    container
            //);
        }

        // =========================
        // 4️⃣ INJECT LAYER
        // =========================
        injectHtmlWithScripts(container, html);

        // =========================
        // 5️⃣ MODULE CHECK
        // =========================
        let module = StepRegistry.get(key);

        // 如果 inject 後立即 register 成功
        if (!module) {

            try {

                module = await StepRegistry.wait(key, 8000);

            } catch (err) {

                console.error("Module wait failed:", err);

                return renderError(
                    new Error(`Step module timeout: ${key}`),
                    container
                );
            }
        }

        // inject 後 + wait 後仍不存在
        if (!module) {

            return renderError(
                new Error("Step module not registered"),
                container
            );
        }

        // =========================
        // 6️⃣ INIT
        // =========================
        ctx.currentPage = module;

        try {

            module.init?.(container, {
                formData: store,
                currentStep: ctx.currentStep
            });

        } catch (err) {

            console.error("Module init failed:", err);

            return renderError(err, container);
        }
        return container;
    }

    return { load };

})();