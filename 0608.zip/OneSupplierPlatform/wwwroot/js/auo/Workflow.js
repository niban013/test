﻿// =========================
// ApiClient (transport layer)
// =========================
const ApiClient = {

    async run(module, action, payload) {
        const request = {
            module,
            action,
            payload: JSON.stringify(payload)

        };
        console.log("send:", request);
        console.log("json:", JSON.stringify(request));

        const res = await fetch(`${window.AppBasePath}workflow/run`, {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify(request)
        });

        const json = await res.json();

        if (!json.Success) {
            throw new Error(json.Message || "Workflow failed");
        }

        return json.data;
    }
};

// =========================
// Context factory
// =========================
function createContext(module, action, payload) {

    return {
        module,
        action,
        payload,
        result: null,
        error: null,
        loading: false,
        startTime: Date.now()
    };
}

// =========================
// Default Hooks
// =========================
const DefaultHooks = {

    async before(ctx) { },

    async after(ctx) {
        console.log(`[Workflow] ${ctx.module}.${ctx.action} success`);
    },

    async error(ctx) {
        console.error(`[Workflow] ${ctx.module}.${ctx.action} error`, ctx.error);
    },

    async finally(ctx) { }
};

// =========================
// Core Engine
// =========================
const WorkflowCore = {

    hooks: DefaultHooks,

    async execute(module, action, payload) {

        const ctx = createContext(module, action, payload);

        try {

            ctx.loading = true;

            await this.hooks.before(ctx);

            ctx.result = await ApiClient.run(
                module,
                action,
                payload
            );

            await this.hooks.after(ctx);

            return ctx.result;
        }
        catch (err) {

            ctx.error = err;

            await this.hooks.error(ctx);

            throw err;
        }
        finally {

            ctx.loading = false;

            await this.hooks.finally(ctx);
        }
    }
};

// =========================
// Module Proxy Factory
// =========================
function createModule(moduleName) {

    return new Proxy({}, {

        get(_, action) {

            return async (payload) => {

                return await WorkflowCore.execute(
                    moduleName,
                    action,
                    payload
                );
            };
        }
    });
}

// =========================
// Workflow Framework (Public API)
// =========================
const Workflow = (() => {

    const modules = {};

    return {

        // get module instance
        use(moduleName) {

            if (!modules[moduleName]) {
                modules[moduleName] = createModule(moduleName);
            }

            return modules[moduleName];
        },

        // global hooks
        setHooks(customHooks) {

            Object.assign(WorkflowCore.hooks, customHooks);
        },

        // optional: replace core hooks
        hooks: WorkflowCore.hooks
    };

})();