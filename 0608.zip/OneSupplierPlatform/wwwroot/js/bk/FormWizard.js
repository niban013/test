﻿const WizardHook = Object.freeze({
    BEFORE_NEXT: "beforeNext",
    BEFORE_PREV: "beforePrev",
    AFTER_LOAD: "afterLoad",
    ON_LEAVE: "onLeave"
});

const privateState = new WeakMap();

const ensureJsonString = (val) => {
    // 判斷是否為物件且不是 null (排除 typeof null === 'object' 的情況)
    if (typeof val === 'object' && val !== null) {
        try {
            return JSON.stringify(val);
        } catch (e) {
            console.error("JSON stringify 失敗:", e);
            return val;
        }
    }
    // 如果是字串或其他基本型別，直接回傳
    return val;
};


/**
 * 將兩個參數（字串或物件）解析並合併為一個 JSON 物件
 */
const mergeToJson = (param1, param2) => {
    const parse = (val) => {
        if (!val) return {};
        if (typeof val === "string") {
            try {
                return JSON.parse(val);
            } catch (e) {
                console.error("解析 JSON 字串失敗:", val);
                return {}; // 解析失敗回傳空物件
            }
        }
        if (typeof val === "object" && val !== null) {
            return val;
        }
        return {};
    };

    // 解析兩者並合併，後者 (param2) 的屬性會覆蓋前者 (param1)
    return { ...parse(param1), ...parse(param2) };
};

const _on = (instance, hookEnum, handler) => {
    const state = privateState.get(instance);
    if (!state) return; // 安全檢查

    // 這裡要用 state.handlers，因為 state 是從 WeakMap 取出的物件
    if (!state.handlers[hookEnum]) {
        state.handlers[hookEnum] = [];
    }
    state.handlers[hookEnum].push(handler);
};




const _runHandlers = async (instance, hookEnum, payload = {}, options = {}) => {
    const state = privateState.get(instance);
    let result = true;
    const ctx = {
        ...payload,
        step: instance.currentStep,
        direction: options.direction || null,
        wizard: instance,
        setResult: (val) => result = val
    };

    // 1️⃣ step-local hooks
    const stepLocal = instance.stepHooks[instance.currentStep]?.[hookEnum] || [];
    for (const fn of stepLocal) {
        const res = await fn(ctx);
        if (res === false) return false; // 阻止繼續
    }

    // 2️⃣ plugins 原有 hook
    for (const plugin of instance.plugins) {
        if (plugin[hookEnum]) {
            const res = await plugin[hookEnum](ctx);
            if (res === false) result = false;
        }
    }

    // 3️⃣ 全域 handlers
    const handlers = state.handlers[hookEnum] || [];
    for (const fn of handlers) {
        const res = await fn(ctx);
        if (res === false) result = false;
    }
    return result;
};
const updateUI = (instance) => {
    // 實作原本 updateUI 的邏輯 
    //$(this.prevBtnId).prop("disabled", this.currentStep === 0);
    $(instance.prevBtnId).css("visibility", instance.currentStep === 1 ? "hidden" : "visible");
    $(instance.nextBtnId).text(instance.currentStep === instance.totalSteps ? "完成" : "下一步");

    $(`${instance.stepsId} li`).removeClass("active");
    $(`${instance.stepsId} li[data-step=${instance.currentStep}]`).addClass("active");

    let progress = (instance.currentStep / instance.totalSteps) * 100;
    $(instance.progressBarId).css("width", progress + "%");
};
const isSameValue = (a, b) => {
    // ⭐ 完全相等（string / number / boolean）
    if (a === b) return true;

    // ⭐ array 比較
    if (Array.isArray(a) && Array.isArray(b)) {
        if (a.length !== b.length) return false;
        return a.every((v, i) => v === b[i]);
    }

    // ⭐ File 比較（只比 name + size + lastModified）
    if (a instanceof File && b instanceof File) {
        return a.name === b.name &&
            a.size === b.size &&
            a.lastModified === b.lastModified;
    }

    return false;
};
const cleanupVMFields = (instance, stepKey) => {
    const vmData = window.vm?.get(stepKey);
    if (!vmData) return;
    const prevRedirect = instance.stepRedirect[instance.currentStep - 1] || {};
    // ⭐ 取得目前畫面所有欄位
    const currentFields = new Set();

    $(`${instance.containerId} [vmodel]`).each(function () {
        const name = $(this).attr("id") || $(this).attr("name");
        if (name) currentFields.add(name);
    });
    // ⭐ 沒有 pageredirect → 完全略過（保留 VM）

    // ⭐ 刪除不存在的欄位
    Object.keys(vmData).forEach(key => {

        if (!currentFields.has(key)) {
            //delete vmData[key];
            window.vm?.delete(stepKey, key);
            // window.vm?.get(stepKey);
        }
        const redirectVal = prevRedirect[key];
        if (redirectVal === undefined || redirectVal === null || redirectVal === "") {
            return;
        }
        const currentVal = vmData[key];
        if (isSameValue(currentVal, redirectVal)) {
            return;
        }
        else {
            window.vm?.set(stepKey, key, redirectVal);
        }

    });
};
const restorePageVMWithRedirect = (instance, stepKey) => {
    const vmData = window.vm?.get(stepKey);
    if (!vmData) return;

    const prevRedirect = instance.stepRedirect[instance.currentStep - 1] || {};

    // 取得當前畫面所有欄位
    const currentFields = {};

    $(`${instance.containerId} [vmodel]`).each(function () {
        const $el = $(this);
        const name = $el.attr("id") || $el.attr("name");

        if (name) {
            currentFields[name] = $el;
        }
    });

    // 遍歷 pageVM
    Object.keys(vmData).forEach(key => {

        // 保留 pageredirect
        //if (key === "pageredirect") return;

        // ❌ 不在畫面上 → 刪掉
        if (!(key in currentFields)) {
            //delete vmData[key];
            window.vm?.delete(stepKey, key);
            return;
        }

        // ✅ 在畫面上 → 判斷 pageredirect 是否有值
        //const $el = $(`${instance.containerId} [name="${key}"]`);
        //if (!$el.length) return;

        const redirectVal = prevRedirect[key];

        // ⭐ 沒有 pageredirect → 完全略過（保留 VM）
        if (redirectVal === undefined || redirectVal === null || redirectVal === "") {
            return;
        }
        const currentVal = vmData[key];
        if (isSameValue(currentVal, redirectVal)) {
            return;
        }

        //ValueHandler.set(currentFields[key], redirectVal, {
        //    silent: true,     // 避免 trigger input（避免 loop）
        //    vm: window.vm,
        //    tabKey: stepKey,
        //    field: key,
        //    inline: true      // ⭐ file 顯示用
        //});
        //if ($el.is(":checkbox")) {
        //    $el.prop("checked", Array.isArray(redirectVal) && redirectVal.includes($el.val()));
        //} else if ($el.is(":radio")) {
        //    $el.prop("checked", $el.val() === redirectVal);
        //} else if ($el.is("[type='file']")) {
        //    // ⭐ File input 特別處理
        //    const vmFile = vmData[key]; // VM 已有 File 物件或檔名
        //    if (vmFile) {
        //        // 這裡只能顯示檔名，File 物件無法直接設定到 input
        //        const $fileLabel = $el.siblings(".file-label"); // 假設有 label 顯示
        //        if ($fileLabel.length) $fileLabel.text(vmFile.name || vmFile);
        //    }
        //} else {
        //    $el.val(redirectVal);
        //}

        // ⭐ 同步回 VM
        //vmData[key] = redirectVal;
    });
};
const updateStepBadge = (instance, stepIndex) => {
    const $badge = $(`${instance.stepsId} li[data-step= ${stepIndex}] .step-badge`);
    const stepKey = "Step" + stepIndex;
    const vmData = window.vm?.get(stepKey);

    if (!vmData) {
        $badge.removeClass("done partial").addClass("empty").text(stepIndex);
        return;
    }

    let total = 0;
    let filled = 0;

    Object.keys(vmData).forEach(key => {
        if (key === "pageredirect") return;

        total++;
        const val = vmData[key];

        if (val !== null && val !== undefined && val !== "" &&
            !(Array.isArray(val) && val.length === 0)) {
            filled++;
        }
    });

    if (filled === 0) {
        // 🔴 未填
        $badge.removeClass("done partial").addClass("empty").text();
    } else if (filled < total) {
        // 🟡 部分完成
        $badge.removeClass("done empty").addClass("partial").text();
    } else {
        // 🟢 完成 ✔
        $badge.removeClass("partial empty").addClass("done").html("✔");
    }

    $badge.show();
};
// 檢查 Redirect Data 是否一致
const isSameRedirectData = (a, b) => {
    return JSON.stringify(a) === JSON.stringify(b);
};

// 執行守衛邏輯 (例如驗證)
const runGuards = async (instance, type) => {
    // 這裡可以實作自定義的驗證邏輯
    if (type === "next") {
        if (await _runHandlers(instance, WizardHook.BEFORE_NEXT) === false) return false;
        if (await _runHandlers(instance, WizardHook.ON_LEAVE, {}, { direction: "forward" }) === false) return false;
    }
    if (type === "prev") {
        if (await _runHandlers(instance, WizardHook.BEFORE_PREV) === false) return false;
        if (await _runHandlers(instance, WizardHook.ON_LEAVE, {}, { direction: "backward" }) === false) return false;
    }
    return true;
};

// 執行 Hook (取代原本的 this.runHook)
const runHook = async (instance, hookEnum, payload = {}, options = {}) => {
    // 內部呼叫原本定義好的私有 _runHandlers
    return await _runHandlers(instance, hookEnum, payload, options);
};


// 靜態綁定邏輯私有化 (原本的 static bindHook)
const bindHook = (containerSelector, hookEnum, handler) => {
    const $container = $(containerSelector);
    if (!$container.length) {
        console.warn("bindWizardHook: container not found", containerSelector);
        return;
    }
    const eventName = `wizard:${hookEnum}`;
    $container.off(eventName).on(eventName, async function (e, ctx) {
        try {
            const res = await handler(ctx);
            // 如果 handler 明確回傳 false，則阻止事件傳遞
            if (res === false) {
                e.preventDefault();
                e.stopPropagation();
                return false;
            }
        } catch (err) {
            console.error(`Error in wizard hook [${hookEnum}]:`, err);
        }
    });
};

// ⭐ 私有化 getRedirectData
const getRedirectData = (instance) => {
    const result = {};

    instance.redirectFields.each(function () {
        const $el = $(this);
        const name = $el.attr("id") || $el.attr("name");
        if (!name) return;

        let val;

        if ($el.is(":checkbox")) {
            if (!result[name]) result[name] = [];
            if ($el.prop("checked")) {
                result[name].push($el.val());
            }
            return;
        }

        if ($el.is(":radio")) {
            if ($el.prop("checked")) {
                result[name] = $el.val();
            }
            return;
        }

        val = $el.val();

        if ($el.is("select[multiple]")) {
            result[name] = val || [];
        } else {
            result[name] = val;
        }
    });

    return result;
};


const loadStep = async (instance, stepIndex, type, shouldClearData = true, extraData = null, callback = null) => {
    const stepKey = "Step" + stepIndex;
    // ⭐ 使用 ensureJsonString 確保傳給 loadStep 的是字串 
    $(instance.nextBtnId).prop("disabled", true);
    const query = new URLSearchParams({ stepIndex, Type: ensureJsonString(type) || '' });
    if (extraData) {
        query.append("SendData", JSON.stringify(extraData));
    }
    try {
        const resp = await fetch(`${instance.baseUrl}/Step?${query.toString()}`);
        const html = await resp.text();
        $(instance.containerId).html(html);

        instance.redirectFields = $(instance.containerId).find('.pageredirect[name]');

        updateUI(instance);
        instance.bindTestButtons();
        await runHook(instance, WizardHook.AFTER_LOAD);

        // 刪除不存在的欄位
        if (shouldClearData) {
            cleanupVMFields(instance, stepKey);
            //restorePageVMWithRedirect(instance, stepKey);    // restore pageVM 並以 pageredirect 為主
        }

    } catch (err) {
        console.error("Load step error:", err);
    } finally {
        for (let i = 1; i <= instance.totalSteps; i++) {
            updateStepBadge(instance, i);
        }
        $(instance.nextBtnId).prop("disabled", false);
        instance.isBack = false;
        if (typeof callback === "function") await callback();
    }
};

class FormWizard {
    constructor(options) {
        // 配置參數
        this.containerId = options.containerId || "#wizard-content";
        this.stepsId = options.stepsId || "#wizard-steps";
        this.nextBtnId = options.nextBtnId || "#nextBtn";
        this.prevBtnId = options.prevBtnId || "#prevBtn";
        this.progressBarId = options.progressBarId || "#wizard-progress-bar";
        this.baseUrl = options.baseUrl || "/Wizard";
        this.stepRedirect = {}; // ⭐ 新增：記錄每一步 pageredirect
        this.isBack = false;    // ⭐ 新增：是否為 backward
        // 狀態變數 (封裝在執行個體內)
        this.currentStep = 1;
        this.totalSteps = $(`${this.stepsId} li`).length;
        this.stepTypes = {};
        this.stepHooks = {}; // { stepIndex: { beforeNext: [], afterLoad: [], ... } }
        this.plugins = [];

        // ⭐ 初始化私有事件表
        privateState.set(this, {
            handlers: {}
        });
        this.init();
    }

    useStep(stepIndex, hooks) {
        if (!this.stepHooks[stepIndex]) this.stepHooks[stepIndex] = {};
        Object.keys(hooks).forEach(hookName => {
            if (!this.stepHooks[stepIndex][hookName]) this.stepHooks[stepIndex][hookName] = [];
            this.stepHooks[stepIndex][hookName].push(hooks[hookName]);
        });
    }

    // 外部簡化調用
    beforeNext(fn) { _on(this, WizardHook.BEFORE_NEXT, fn); }
    beforePrev(fn) { _on(this, WizardHook.BEFORE_PREV, fn); }
    afterLoad(fn) { _on(this, WizardHook.AFTER_LOAD, fn); }
    onLeave(fn) { _on(this, WizardHook.ON_LEAVE, fn); }




    init() {
        // 載入第一步
        loadStep(this, this.currentStep, false);

        // 綁定「下一步」
        $(this.nextBtnId).off("click").on("click", () => {
            this.next();
        });

        // 綁定「上一步」
        $(this.prevBtnId).off("click").on("click", () => {
            this.prev();
        });

        // 綁定步驟點擊 

        $(`${this.stepsId} li`).off("click").on("click", (e) => {
            // 注意：用了箭頭函數，要取得點擊的元素請用 e.currentTarget
            const $el = $(e.currentTarget);
            const index = $el.data("step");

            if (index === undefined || index === this.currentStep) return;

            this.isBack = index < this.currentStep;
            this.currentStep = index;
            const type = this.isBack ? "" : this.stepTypes[this.currentStep - 1] || "";

            // 呼叫私有函數 loadStep
            loadStep(this, this.currentStep, type, this.isBack == true ? false : true);
        });

        $(`${this.stepsId} .step-badge`).hide();

    }

    async next(extraData = null, callback = null) {
        if (!await runGuards("next")) return;
        const val = getRedirectData(this); // ⭐ 改這裡
        const oldVal = this.stepRedirect[this.currentStep]; //找舊的
        // ⭐ 比對整包條件
        const oldcompareJObject = mergeToJson(oldVal)
        const compareJObject = mergeToJson(val, extraData)

        let shouldClearData = false;
        if (!this.isBack && oldVal && !isSameRedirectData(oldcompareJObject, compareJObject)) {
            const ok = confirm("條件已改變，是否繼續？");
            if (!ok) {
                return;
            }
            else {
                shouldClearData = true;
            }
        }

        // ⭐ 記錄條件
        this.stepRedirect[this.currentStep] = JSON.parse(JSON.stringify(compareJObject));
        this.stepTypes[this.currentStep] = val;
        updateStepBadge(this.currentStep);


        if (this.currentStep < this.totalSteps) {
            this.isBack = false;
            this.currentStep++;
            // ⭐ 傳整包 JSON 給後端
            loadStep(this, this.currentStep, JSON.stringify(val), shouldClearData, extraData, callback);
        } else {
            alert("流程完成!");
        }
    }

    async prev() {
        if (!await runGuards("prev")) return;

        if (this.currentStep > 1) {
            this.currentStep--;
            this.isBack = true; // ⭐ backward 不比對 pageredirect
            // ⭐ backward 不帶條件
            loadStep(this, this.currentStep, this.isBack == true ? false : true);
        }
    }


    getStepValue(stepIndex, fieldName) {
        const stepData = window.vm?.get("Step" + stepIndex)
        return stepData?.[fieldName] ?? null;
    }

    bindTestButtons() {
        const self = this;

        $("#testBtn1").off("click").on("click", function () {

            // ⭐ 設定條件1
            $(`${self.containerId} [name="customerId"]`).val("1001");
            $(`${self.containerId} [name="type"]`).val("A");

            // ⭐ 觸發 change（避免 select2 / validation 問題）
            $(`${self.containerId} [name="type"]`).trigger("change");

            // ⭐ 模擬下一步
            self.next();
        });

        $("#testBtn2").off("click").on("click", function () {

            // ⭐ 設定條件2
            $(`${self.containerId} [name="customerId"]`).val("2002");
            $(`${self.containerId} [name="type"]`).val("B");

            $(`${self.containerId} [name="type"]`).trigger("change");

            self.next();
        });
    }

}