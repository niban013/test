﻿window.Helpers = (() => {

    const store = () => AppBootstrap.get("FlowStore");

    const state = () => window.AppController.getState();

    function extractFileData(obj) {
        if (!obj || typeof obj !== "object") return undefined; 
        if (isFileModel(obj)) {
            return { clientId: obj.clientId, id: obj.id, name: obj.name, file: obj.file, token: obj.token, lazy: obj.lazy };
        } 
        return Object.entries(obj).reduce((acc, [key, value]) => { 
            if (key === "__version" || key.includes("__async")) return acc; 
            const extracted = extractFileData(value); 
            if (extracted !== undefined) {
                acc[key] = extracted;
            }
            return acc;
        }, Array.isArray(obj) ? [] : {});
    }
    function isFileModel(v) {
        return v && typeof v === "object" && "clientId" in v && "name" in v;
    }
    function clean(obj) {

        if (obj === undefined || obj === null)
            return null;

        return JSON.parse(JSON.stringify(obj, (key, value) => {
            if (key === "__version")
                return undefined;
            if (key.indexOf('__async') > 0)
                return undefined;
            if (key.indexOf('.file') > 0)
                return undefined;
            if (value && typeof value === "object") { 
                if (isFileModel(value)) {
                    return {
                        clientId: value.clientId,
                        id: value.id,
                        name: value.name, 
                        token: value.token,
                        lazy: value.lazy
                    };
                }

                // HTML File（保險）
                if (value instanceof File) {
                    return {
                        name: value.name,
                        size: value.size,
                        type: value.type
                    };
                }
            }

            return value;
        }));
    }
    //function normalizeStepKeys(steps) {

    //    if (!steps) {
    //        return state().stepsRef.value.map(s => `step${s.StepIndex}`);
    //    }

    //    const arr = Array.isArray(steps) ? steps : [steps];

    //    return arr.map(s => {

    //        if (typeof s === "number") {
    //            return `step${s}`;
    //        }

    //        if (typeof s === "string") {

    //            // 已經是 step2
    //            if (s.startsWith("step")) return s;

    //            // "2"
    //            return `step${s}`;
    //        }

    //        return null;
    //    }).filter(Boolean);
    //}
    function collectPayload() {

        const payload = {};

        const savedFullForm =
            window.FlowStore.get("supplier", "FormInfo") || {};

        // =========================
        // ALWAYS full steps
        // =========================
        state().stepsRef.value.forEach(s => {

            const stepKey = `step${s.StepIndex}`;

            payload[stepKey] =
                clean(store().getStep(stepKey));
        });

        payload["FormInfo"] = { ...savedFullForm };

        return payload;
    }

    // =========================
    // validate steps
    // =========================

    async function validateAllSteps({ showError, steps }) {

        let allValid = true; 
        const targetStepNumbers = Array.isArray(steps)
            ? steps.map(Number)
            : String(steps).split(',').map(Number); 
        const targetSteps = state().stepsRef.value.filter(s =>
            targetStepNumbers.includes(Number(s.StepIndex))
        );

        for (const s of targetSteps) {

            const stepKey = `step${s.StepIndex}`;

            if (showError) {
                store().markStepSubmitted(stepKey);
            }

            const ok = await GraphV2.validateStep(stepKey);

            if (!ok) {
                allValid = false;
            }
        }

        return allValid;
    }


    //async function validateAllSteps({ showError, steps }) {

    //    let allValid = true;

    //    const stepKeys = normalizeStepKeys(steps);

    //    const targetSteps = state().stepsRef.value.filter(s =>
    //        stepKeys.includes(`step${s.StepIndex}`)
    //    );

    //    for (const s of targetSteps) {

    //        const stepKey = `step${s.StepIndex}`;

    //        if (showError) {
    //            store().markStepSubmitted(stepKey);
    //        }

    //        const ok = await GraphV2.validateStep(stepKey);

    //        if (!ok) {
    //            allValid = false;
    //        }
    //    }

    //    return allValid;
    //}

    // =========================
    // submit form (core)
    // =========================
    async function submitForm({
        url,
        mode = "draft",
        currentStep,
        validateSteps = 3
    }) {
          
        let finalValidateSteps = String(validateSteps).split(',').map(Number)
            .filter(num => !isNaN(num) && num > 0); 
        if (finalValidateSteps.length === 0) {
            throw err;
        }
        else {
            if (mode === "submit") {
                finalValidateSteps = finalValidateSteps
            } else {
                finalValidateSteps = [Number(currentStep)];
            }
        }
         
        const isSubmit = mode === "submit";

        // =========================
        // validation
        // =========================
        const validationResult =
            await validateAllSteps({
                showError: isSubmit,
                steps: finalValidateSteps
            });

        if (isSubmit && !validationResult) { 
            return { success: false, message: "validation_failed" };
        }

        // =========================
        // payload（只用 currentStep）
        // =========================
        const payload = collectPayload(currentStep); 

        const fullPayload = {
         /*   FormInfo: formno,*/
            ...payload,
            mode,
            StepContext: {
                Current: currentStep,
                ValidateSteps: finalValidateSteps
            },
            hasError: !validationResult
        };
        const FormInfo = window.FlowStore.get("supplier", "FormInfo") || {};

        const formData = new FormData(); 
        const step2File = extractFileData(store().getStep('step2'));  

        if (step2File) {
            formData.append(`File.ItemId`,"upload_ssaaf");
            formData.append(`File.ItemName`, "upload_ssaaf");
            formData.append(`File.Headerid`, isEmpty(FormInfo?.headerid) ? '' : FormInfo?.headerid);
            formData.append(`File.FormNo`, isEmpty(FormInfo?.formno) ? '' : FormInfo?.formno);
            formData.append(`File.FileId`, isEmpty(step2File?.upload_ssaaf?.id) ? '' : step2File?.upload_ssaaf?.id);
            formData.append(`File.FileName`, isEmpty(step2File?.upload_ssaaf?.name) ? '' : step2File?.upload_ssaaf?.name);
            formData.append(`File.File`, step2File?.upload_ssaaf?.file);  
            formData.append(`File.Status`,'Pending'); 
        }

        formData.append("Payload", JSON.stringify(fullPayload)); 
        const res = await fetch(url, {
            method: "POST",
            body: formData
        });

        return await res.json();

        //const res = await fetch(url, {
        //    method: "POST",
        //    headers: { "Content-Type": "application/json" },
        //    body: JSON.stringify(fullPayload)
        //});

        //return await res.json();
    }

    // =========================
    // save draft
    // =========================
    async function saveDraft(currentStep) {

        return await submitForm({
            url: `${window.AppBasePath}Supplier/Draft`,
            mode: "draft",
            currentStep: currentStep
        });
    }

    // =========================
    // finish submit
    // =========================
    async function finishSubmit() {

        return await submitForm({
            url: `${window.AppBasePath}Supplier/Draft`,
            mode: "submit",
            currentStep: -1
        });
    }

    // =========================
    // next step confirm
    // =========================
    async function stepNextWithConfirm({
        stepKey = "step1",
        nextStep,
        storeKey = "decision",
        value,
        type,
        autoGoTo = true
    }) {

        const s = store();

        const oldValue =  s.get(stepKey, storeKey);

        const isFirstTime = typeof oldValue === "undefined";

        const mergedValue = {
            type,
            value
        };

        const isSame =
            JSON.stringify(oldValue) ===
            JSON.stringify(mergedValue);

        let forceReload = false;

        if (!isSame && !isFirstTime) {

            const ok =
                await window.showConfirm(
                    "條件已改變",
                    "是否要重新載入下一步？"
                );

            if (!ok) {
                return { success: false };
            }

            forceReload = true;
        }

        // =========================
        // save decision
        // =========================
        s.safeSet(stepKey, storeKey, mergedValue);

        // =========================
        // go next
        // =========================
        if (autoGoTo && nextStep !== undefined) {

            await window.AppController.goTo(nextStep);

            if (forceReload) {

                const nextStepKey = "step" + nextStep;

                s.clearStep(nextStepKey);

                GraphV2.clearStep(nextStepKey);
                GraphV2.unregisterStep(nextStepKey);

                await window.AppController.load?.();
            }
        }

        return {
            success: true,
            isSame,
            forceReload
        };
    }

    return {

        collectPayload,
        submitForm,
        saveDraft,
        finishSubmit,
        stepNextWithConfirm
    };

})();
 

const FormStore = (() => {

    const state = Vue.reactive({ steps: {} });
    const errors = Vue.reactive({ steps: {} });
    const status = Vue.reactive({ steps: {} });

    const touched = {};
    const submitState = Vue.reactive({});
    const ensure = (step) => {

        state.steps[step] ||= {};
        errors.steps[step] ||= {};
        status.steps[step] ||= {};

        state.steps[step].__version ||= {};
        touched[step] ||= new Set();
    };

    return {
        markStepSubmitted(step) {
            submitState[step] = true;
        },

        unmarkStepSubmitted(step) {
            submitState[step] = false;
        },

        isStepSubmitted(step) {
            return !!submitState[step];
        },
        getStep(step) {
            ensure(step);
            return state.steps[step];
        },

        get(step, key) {
            ensure(step);
            return state.steps[step][key];
        },
        isStepValid(step) {
            ensure(step);
            return Object.values(errors.steps[step]).every(x => !x);
        },

        // =========================
        // 🚀 safe write (version aware)
        // =========================
        safeSet(step, key, val, meta = {}) {

            ensure(step);

            const stepObj = state.steps[step];

            const current = stepObj.__version[key] || 0;

            if (meta.version != null && meta.version < current) return;

            stepObj.__version[key] = current + 1;
            //console.log("🔥 BEFORE SET:", step, key, stepObj);

            stepObj[key] = val;
            console.log("🔥 AFTER SET:", stepObj);

        },

        setError(step, key, val) {
            ensure(step);
            errors.steps[step][key] = val;
        },

        clearError(step, key) {
            ensure(step);
            errors.steps[step][key] = null;
        },

        getError(step, key) {
            return errors.steps?.[step]?.[key];
        },

        setStatus(step, key, val) {
            ensure(step);
            status.steps[step][key] = val;
        },

        getStatus(step, key) {
            return status.steps?.[step]?.[key];
        },

        setTouched(step, key) {
            ensure(step);
            touched[step].add(key);
        },

        isTouched(step, key) {
            return touched?.[step]?.has(key);
        },
        deleteField(step, key) {
            ensure(step);

            delete state.steps[step][key];
            delete errors.steps[step][key];
            delete status.steps[step][key];
            delete state.steps[step].__version[key];

            touched[step]?.delete(key);
        },
        resetField(step, key) {
            ensure(step);

            state.steps[step][key] = null;
            errors.steps[step][key] = null;
            status.steps[step][key] = null;

            touched[step]?.delete(key);
        },
        clearStep(step) {

            const stepObj = state.steps[step];

            if (stepObj) {
                // 2. 逐一刪除所有屬性（這會觸發 Vue UI 偵測到屬性消失）
                Object.keys(stepObj).forEach(key => {
                    delete stepObj[key];
                });

                // 3. 重新初始化內部必要的結構
                stepObj.__version = {};
            }

            // 4. 對於 errors 和 status，如果 UI 有綁定，也建議用同樣方式處理
            if (errors.steps[step]) {
                Object.keys(errors.steps[step]).forEach(k => delete errors.steps[step][k]);
            }
            if (status.steps[step]) {
                Object.keys(status.steps[step]).forEach(k => delete status.steps[step][k]);
            }

            // 5. Touched 是普通 Set，可以直接替換
            touched[step] = new Set();

            console.log(`✅ Step [${step}] 已清空，UI 應同步更新`);


            //state.steps[step] = { __version: {} };
            //errors.steps[step] = {};
            //status.steps[step] = {};
            //touched[step] = new Set();
        },
        getErrors(step) {
            ensure(step);
            return errors.steps[step];
        }
         
    };

})();
window.FlowStore = (() => {

    const toStepKey = (stepKey) => {
        let state = window.AppController.getState();
        if (!stepKey) return stepKey;

        const prefix = state.flowId + ".";

        if (stepKey.startsWith(prefix)) {
            return stepKey;
        }

        if (stepKey.includes(".")) {
            console.warn("⚠️ stepKey already has prefix:", stepKey);
            return stepKey;
        }

        return prefix + stepKey;
    };

    return {

        get(stepKey, key) {
            return FormStore.get(toStepKey(stepKey), key);
        },

        getStep(stepKey) {
            return FormStore.getStep(toStepKey(stepKey));
        },

        safeSet(stepKey, key, val, meta) {
            return FormStore.safeSet(toStepKey(stepKey), key, val, meta);
        },

        setError(stepKey, key, val) {
            return FormStore.setError(toStepKey(stepKey), key, val);
        },
        setStatus(stepKey, key, val) {
            return FormStore.setStatus(toStepKey(stepKey), key, val);
        },
        getStatus(stepKey, key) {
            return FormStore.getStatus(toStepKey(stepKey), key);
        },
        getError(stepKey, key) {
            return FormStore.getError(toStepKey(stepKey), key);
        },
        clearError(stepKey, key) {
            return FormStore.clearError(toStepKey(stepKey), key);
        },
        isTouched(stepKey, key) {
            return FormStore.isTouched(toStepKey(stepKey), key);
        },
        isStepValid(stepKey) {
            return FormStore.isStepValid(toStepKey(stepKey));
        },
        isStepSubmitted(stepKey) {
            return FormStore.isStepSubmitted(toStepKey(stepKey));
        },
        setTouched(stepKey, key) {
            return FormStore.setTouched(toStepKey(stepKey), key);
        },
        markStepSubmitted(stepKey) {
            return FormStore.markStepSubmitted(toStepKey(stepKey));
        },
        deleteField(stepKey, key) {
            return FormStore.deleteField(toStepKey(stepKey), key);
        },

        clearStep(stepKey) {
            return FormStore.clearStep(toStepKey(stepKey));
        },

        resetField(stepKey, key) {
            return FormStore.resetField(toStepKey(stepKey), key);
        },
        getErrors(stepKey) {
            return FormStore.getErrors(toStepKey(stepKey));
        }
    };

})();


window.AppController = (() => { 
    const state = {
        flowId: "default",
        stepsRef: null,
        currentStep: null,
        setStep: null, 
        currentPage: null,
        loading: false, 
        flowStartStep: 1,
        _beforeHooks: []
    };


    function initSelect2(container) {
        function setSelect2Background(select) {
            let color = select.find("option:selected").data("color") || "";
            select.next(".select2-container")
                .find(".select2-selection--single")
                .css("background-color", color);
        }
        function formatOption(item) {
            if (!item.id) return item.text;
            let color = $(item.element).data("color") || "";
            return $('<div style="background:' + color + '; padding:4px 6px;">' + item.text + '</div>');
        }

        function formatSelection(item) { return item.text; }

        $(container).find("select.select2").each(function () {

            const $el = $(this);

            if ($el.data("select2")) return;

            $el.select2({
                width: "100%",
                placeholder: $el.attr("placeholder") || "請選擇",
                allowClear: true,
                templateResult: formatOption,
                templateSelection: formatSelection
            });
            setTimeout(() => {
                setSelect2Background($el);
            }, 0);
            $el.on("select2:select select2:clear", function () {
                setSelect2Background($el);
                // 🔥 強制同步 value
                const value = $el.val();

                // 🔥 直接用原生 dispatch（比 trigger 穩）
                $el[0].dispatchEvent(new Event("change", { bubbles: true }));
            });

            $el.trigger("change.select2");
        });
    }


    function getStepKey() {
        return `step${state.currentStep.value || 1}`;
    }
    function minStep() {
        return state.flowStartStep;
    }
    async function init({ steps, currentStep, setStep, boot }) {

        state.flowId = window.__FLOW_ID__ || "default";
        state.stepsRef = steps;
        state.currentStep = currentStep;
        state.setStep = setStep;
        state.boot = boot;
        await registerModules();
        state.flowStartStep = boot?.targetStep || 1;
        state.setStep(state.flowStartStep);
        await load();


        const ribbon = document.querySelector('.wizard-ribbon');
        if (ribbon) {
            ribbon.style.setProperty('--total', steps.value.length);
        }
    }
    async function registerModules() {

        /*//AppBootstrap.register("FormStore", FormStore);*/
        AppBootstrap.register("StepLoader", StepLoader);
        AppBootstrap.register("FlowStore", FlowStore);
        //AppBootstrap.register("FormValidation", FormValidation);
        AppBootstrap.register("FilePlugin", FilePlugin);
        AppBootstrap.register("FieldBinder", FieldBinder);
        //AppBootstrap.register("ComputedRegistry", ComputedRegistry);
        //AppBootstrap.register("ComputedEngine", ComputedEngine);
        //if (window.FieldBinder)
        //    AppBootstrap.register("FieldBinder", FieldBinder);
        // 如果你有這些
        //if (window.FieldStatus)
        //    AppBootstrap.register("FieldStatus", FieldStatus);

        //if (window.ValidationCenter)
        //    AppBootstrap.register("ValidationCenter", ValidationCenter);

        await AppBootstrap.wait(); // 🔥 等全部 ready

        //const computed = AppBootstrap.get("ComputedEngine");
        //computed.init();
        //computed.enable();


    }

    const scrollToTop = () => {
        const el = document.getElementById("step-container");
        if (el) {
            el.scrollTop = 0;
        }
    };  

    async function load() {

        if (state.loading) return;
        state.loading = true;
       
        try {
            
            const StepLoader = AppBootstrap.get("StepLoader");
            const stepIndex = state.currentStep.value;
            const stepKey = `step${stepIndex}`;
            //window.Loading.show();
            const container = await StepLoader.load(stepIndex, state);
        /*    state.currentPage = window.StepPages?.[stepKey];*/
            initSelect2(container)
       /*     hydrateFields(container, stepKey);*/
            scrollToTop();
       
            const fieldBinder = AppBootstrap.get("FieldBinder");
            fieldBinder.bindFields(container, stepKey, 'readOnly');
            window.dispatchEvent(new CustomEvent("flow-buttons", {
                detail: {
                    draft: false,
                    finish: false
                }
            }));
            return container;

        } catch (err) {

            console.error("❌ load step failed:", err);

            // 🔥 關鍵：避免卡死
            state.loading = false;
            //window.Loading.hide();
            // 🔥 可選：強制回復 UI（很重要）
            //await forceRecoverStep();

            throw err; // or swallow depending UX

        }
        finally {
            state.loading = false;
            //window.Loading.hide();
        }
    }
     
    async function next() {
        const currentStep = state.currentStep.value;
        const targetStep = currentStep + 1;

        // 1️⃣ 執行所有註冊過的 Hooks (包含你在 STEP2 init 加的那個)
        const canProceed = await runBeforeHooks(targetStep);

        // 如果 Hook 回傳 false (代表 confirm 點了取消)，就中斷，不換頁
        if (!canProceed) {
            console.log("🚫 Hook 攔截：停止換頁");
            return;
        }

        // 2️⃣ 如果 Hook 通過了，才執行原本的換頁邏輯
        const stepKey = getStepKey();
        // const store = AppBootstrap.get("FlowStore");
        // if (!store.isStepValid(stepKey)) { ... }

        // 3️⃣ 換頁前清空舊 Hook，避免 Hook 重複累積
        state._beforeHooks = [];

        state.setStep(targetStep);
        await load();
        //const stepKey = getStepKey();
        //const store = AppBootstrap.get("FlowStore");
        ////if (!store.isStepValid(stepKey)) {
        ////    alert("請修正錯誤");
        ////    return;
        ////}

        //state.setStep(state.currentStep.value + 1);
        //await load();
    }

    async function prev() {
        const target = state.currentStep.value - 1; 
        if (target < minStep()) return; // ⭐ 關鍵
        state._beforeHooks = [];
        state.setStep(state.currentStep.value - 1);
        await load();
        window.dispatchEvent(new CustomEvent("flow-reset"));
    }

    async function goTo(i) {
        const target = Number(i);
        if (target < minStep()) return; // ⭐ 防止跳回 step1
        // 🔥 先跑 hook
        const ok = await runBeforeHooks(target);

        if (!ok) return;

        state._beforeHooks = []; 

        state.setStep(target);
        await load();
    }
    async function saveDraft(currentStep) {
        Swal.fire({
            title: '正在儲存草稿...',
            text: '請稍後，系統正處理交易中。',
            allowOutsideClick: false,
            didOpen: () => {
                Swal.showLoading();
            }
        });

        try {
           
            const result = await window.Helpers.saveDraft(currentStep); 
            if (!result.success) {
                showAlert('草稿儲存失敗', `${result?.message}`, 'error');
                return;
            }

            const store = AppBootstrap.get("FlowStore");
            store.safeSet('formno', 'FormInfo', result.FormInfo);

          
            await Swal.fire({
                icon: 'success',
                title: '草稿已儲存',
                text: `申請單編號：${result.FormInfo?.formno}`,
                confirmButtonText: '確定'
            });
            location.href = `/Supplier/Index?formno=${result.FormInfo.formno}&headerid=${result.FormInfo.headerid}&applytype=${result.FormInfo.applytype}`; 
        } catch (error) { 
            showAlert('系統錯誤', '連線失敗或發生未知錯誤', 'error');
        }



        //const result = await window.Helpers.saveDraft(currentStep);

        //if (!result.success)
        //{
        //    showAlert('草稿儲存失敗', `${result?.message}`,'error'); 
        //    return;
        //}
           
        //const store = AppBootstrap.get("FlowStore");
        //store.safeSet('formno', 'FormInfo', result.FormInfo);
     
        //showAlert('草稿已儲存', `申請單編號：${result.FormInfo?.formno}`, 'success'); 
        //location.href = `/Supplier/Index?formno=${result.FormInfo.formno}&applytype=${result.FormInfo.applytype}`;
    }
    async function finish() { 

        Swal.fire({
            title: '正在送簽...',
            text: '請稍後，系統正處理交易中。',
            allowOutsideClick: false,
            didOpen: () => {
                Swal.showLoading();
            }
        });

        try {

            const result = await window.Helpers.finishSubmit();
            if (!result.success) {
                showAlert('送簽失敗', `${result?.message}`, 'error');
                return;
            }

            const store = AppBootstrap.get("FlowStore");
            store.safeSet('formno', 'FormInfo', result.FormInfo);


            await Swal.fire({
                icon: 'success',
                title: '送簽成功',
                text: `申請單編號：${result.FormInfo?.formno}`,
                confirmButtonText: '確定'
            });
            //location.href = `/Supplier/Index?formno=${result.FormInfo.formno}&headerid=${result.FormInfo.headerid}&applytype=${result.FormInfo.applytype}`;
        } catch (error) {
            showAlert('系統錯誤', '連線失敗或發生未知錯誤', 'error');
        }


        //const result =  await window.Helpers.finishSubmit(); 
        //if (!result.success) {
        //    showAlert('送簽失敗', `${result?.message}`, 'error');
        //    return;
        //}
        //const store = AppBootstrap.get("FlowStore");
        //store.safeSet('formno', 'FormInfo', result.FormInfo);
        //showAlert('送簽成功', `申請單編號：${result.FormInfo?.formno}`, 'success'); 
    }
    //async function finish() {
    //    const store = AppBootstrap.get("FlowStore");
    //    const payload = {};
    //    state.stepsRef.value.forEach(s => {
    //        payload[`step${s.StepIndex}`] = store.getStep(`step${s.StepIndex}`);  
    //        store.markStepSubmitted(`step${s.StepIndex}`);
    //    });

    //    console.log("FINAL:", payload);

    //    await fetch("/Supplier/Save", {
    //        method: "POST",
    //        headers: { "Content-Type": "application/json" },
    //        body: JSON.stringify(payload, (key, value) => {
    //            // 如果 key 是 __version，回傳 undefined 就會被從 JSON 中剔除
    //            if (key === "__version") return undefined;
    //            return value;
    //        })
    //    });
    //}

    async function runBeforeHooks(targetStep) {
        for (const hook of state._beforeHooks) {
            const ok = await hook({
                currentStep: state.currentStep.value,
                targetStep,
                state
            });
            if (!ok) return false;
        }
        return true;
    }

    return {
        init,
        next,
        prev,
        goTo,
        finish,
        load, saveDraft,
        addBeforeHook(fn) {
            state._beforeHooks.push(fn);
        },
        getState: () => state,
    };

})();