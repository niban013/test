using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using OneSupplierPlatform.Helper;
using OneSupplierPlatform.Models.Infra;
using OneSupplierPlatform.Services.Infra;
using System.Security.Claims;

namespace OneSupplierPlatform.Component
{
    public class MenuViewComponent : ViewComponent
    {
        private readonly MenuService _menuService;
        public MenuViewComponent(MenuService menuService)
        {
            _menuService = menuService;
        }


        public async Task<IViewComponentResult> InvokeAsync()
        {
            ViewBag.EmpId = HttpContext.User.FindFirstValue("EmployeeId") ?? "001";
            ViewBag.UserName = HttpContext.User.FindFirstValue(ClaimTypes.Name) ?? "Guest";
            ViewBag.EmpDeputyPhoto = HttpContext.User.FindFirstValue("Photo") ?? "";
            //Logger.LogInformation(JsonConvert.SerializeObject(await _menuService.GetMenuAsync()));
            //return View(await _menuService.GetMenuAsync());
            return View(JsonConvert.DeserializeObject<List<MenuItemViewModel>>(mock.j8));
        }

        //private List<MenuItemViewModel> GetMockData()
        //{
        //    var list = new List<MenuItemViewModel>
        //    {
        //        new() { NodeId = 1, ParentId = 0, ItemText = "Home", ItemLink = "/" },

        //        // Apply
        //        new() { NodeId = 2, ParentId = 0, ItemText = "Apply", ItemLink = "#" },

        //        // Query
        //        new() { NodeId = 3, ParentId = 0, ItemText = "Query", ItemLink = "#" },

        //        new() { NodeId = 4, ParentId = 0, ItemText = "Management", ItemLink = "/Admin" },

        //        // Apply �l���
        //        new() { NodeId = 5, ParentId = 2, ItemText = "New Supplier", ItemLink = "/Supplier/Index" },

        //        // Help
        //        new() { NodeId = 6, ParentId = 0, ItemText = "Help", ItemLink = "/Help" },

        //        // Query �l���
        //        new() { NodeId = 7, ParentId = 3, ItemText = "SupplierQuery", ItemLink = "/SupplierQuery" },
        //    };

        //    // �إ߶��h
        //    var root = list
        //        .Where(x => x.ParentId == 0)
        //        .ToList();

        //    foreach (var item in root)
        //    {
        //        item.Children = list
        //            .Where(x => x.ParentId == item.NodeId)
        //            .ToList();
        //    }

        //    return root;
        //}
    }
}
