﻿using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Mvc;

namespace OneSupplierPlatform.Controllers.Infra
{
    public class AuthController : BaseController
    { 
        public AuthController()
        {
          
        }

        [Route("Auth/SignOut", Name = "SignOut")]
        public async Task<IActionResult> Logout()
        {
            var cookieName = Config.CapAuth.CookieName;
            var logoutUrl = Config.CapAuth.LogoutUrl;

            // ==========================
            // 1. 清 MVC session
            // ==========================
            await HttpContext.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);

            // ==========================
            // 2. 清 CAP cookie（本機）
            // ==========================
            Response.Cookies.Delete(cookieName);

            // ==========================
            // 3. 導向 CAP Logout（SSO 核心）
            // ==========================
            // 🌟 修正：回傳與 AppPath 的網址都必須加上 Request.PathBase
            var returnUrl =
                $"{Request.Scheme}://" +
                $"{Request.Host}" +
                $"{Request.PathBase}";

            var url =
                $"{logoutUrl}" +
                $"?ReturnUrl={Uri.EscapeDataString(returnUrl)}" +
                $"&AppPath={Uri.EscapeDataString(returnUrl)}";

            return Redirect(url);
        }


        public IActionResult Denied()
        {
            return Content("Access Denied");
        }
    }
}
