﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;
using OneSupplierPlatform.i18n;
using OneSupplierPlatform.Infrastructure.AppSetting;
using OneSupplierPlatform.Infrastructure.Transfer;
using OneSupplierPlatform.Models.Infra;
using System.Security.Claims;

namespace OneSupplierPlatform.Controllers.Infra
{
    public abstract class BaseController : Controller
    {
        private LocalizedKeys? _localizer;
        private AppOptions? _config;
        private QueryStringDto? _query;
        protected CapUser CurrentUser
        {
            get
            {
                var http = HttpContext;

                // =========================
                // 1. iframe override user（最高優先）
                // =========================
                if (http.Items.TryGetValue("CurrentUser", out var obj) &&
                    obj is CapUser iframeUser)
                {
                    return new CapUser
                    {
                        UserId = iframeUser.UserId,
                        RealName = iframeUser.RealName,
                        EmployeeId = iframeUser.EmployeeId,
                        DepartmentId = iframeUser.DepartmentId,
                        Email = iframeUser.Email,
                        BossLevel = iframeUser.BossLevel,
                        CompanyName = iframeUser.CompanyName,
                        Site = iframeUser.Site
                    };
                }

                // =========================
                // 2. CAP / ASP.NET Identity
                // =========================
                var user = http.User;

                return new CapUser
                {
                    UserId = user.FindFirstValue(ClaimTypes.NameIdentifier),
                    RealName = user.FindFirstValue(ClaimTypes.Name),
                    EmployeeId = user.FindFirstValue("EmployeeId"),
                    Email = user.FindFirstValue(ClaimTypes.Email),
                    DepartmentId = user.FindFirstValue("DepartmentId"),
                    CompanyName = user.FindFirstValue("CompanyName"),
                    Site = user.FindFirstValue("Site"),
                    BossLevel = int.TryParse(user.FindFirstValue("BossLevel"), out var b) ? b : 0
                };
            }
        }


        protected QueryStringDto ParsedQueries => _query ??=
            Request.Query != null && Request.Query.Count > 0
                ? TransQueryStringBinder.Bind<QueryStringDto>(Request.Query)
                : new QueryStringDto();
        protected LocalizedKeys Localizer => _localizer ??= HttpContext.RequestServices.GetRequiredService<LocalizedKeys>();

        protected AppOptions Config => _config ??= HttpContext.RequestServices.GetRequiredService<IOptions<AppOptions>>().Value;
        //protected ITransactionContext DbCenter => DBCenter ??= AppFinder.GetService<ITransactionContext>() ?? throw new Exception("ITransactionContext 未初始化");
    }

}

