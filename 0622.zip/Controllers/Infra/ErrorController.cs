﻿using Microsoft.AspNetCore.Mvc;
using OneSupplierPlatform.HandleException;
using System.Text.Json;

namespace OneSupplierPlatform.Controllers.Infra
{
    public class ErrorController : Controller
    {
        public IActionResult Index(string requestId)
        {
            if (TempData["ErrorResponse"] is string json)
            {
                var model =
                    JsonSerializer.Deserialize<ErrorResponse>(json);

                return View(model);
            }

            return View(new ErrorResponse
            {
                RequestId = requestId,
                Title = "系統錯誤",
                Message = "系統發生錯誤",
                IsFatal = true
            });
        }
        //public IActionResult Index(string requestId)
        //{
        //    var model = new ErrorResponse
        //    {
        //        RequestId = requestId
        //    };

        //    return View(model);
        //}

        public IActionResult Partial(string requestId)
        {
            var model = new ErrorResponse
            {
                RequestId = requestId
            };

            return PartialView("_ErrorContent", model);
        }
    }
}
