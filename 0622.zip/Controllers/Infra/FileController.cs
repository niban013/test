﻿using Com.Auo.HttpModule20.Library.Helpers;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using OneSupplierFLM;
using OneSupplierPlatform.HandleException;
using OneSupplierPlatform.Infrastructure.Log;
using OneSupplierPlatform.Models.Infra;
using OneSupplierPlatform.Models.Supplier;
using OneSupplierPlatform.Services.Infra;
using UploadFileResponse = OneSupplierPlatform.Models.Infra.UploadFileResponse;

namespace OneSupplierPlatform.Controllers.Infra
{
    [Route("[controller]")]
    public class FileController : BaseController
    {
        private readonly FileService _fileService;
        private readonly IWebHostEnvironment _env;
        private readonly FLMService _flmService;
        public FileController(IWebHostEnvironment env, FileService fileService, FLMService flmService)
        {
            _flmService = flmService;
            _env = env;
            _fileService = fileService;
        }

        [HttpPost("UploadFile")]
        public async Task<IActionResult> UploadFileAsync([FromForm] FlmFileInfo file)
        {
            try
            {
                if (string.IsNullOrEmpty(file.Headerid))
                {
                    throw new Exception("Headerid遺失");
                }
                if (string.IsNullOrEmpty(file.FormNo))
                {
                    throw new Exception("FormNo遺失");
                }
                file.CUser = CurrentUser.EmployeeId;
                var fileId = await _fileService.UploadFileAsync(file);
                // 模擬 upload
                //var fileId = Guid.NewGuid().ToString();

                var response = new UploadFileResponse
                {
                    FileId = fileId,
                    FileName = file.FileName,
                    Size = file.File?.Length ?? 0,
                    Mime = file.File?.ContentType
                };
                return this.ToResponse(ExecuteResult<UploadFileResponse>.Ok(response));
            }
            catch (BusinessException exsh)
            {
                return this.ToResponse<UploadFileResponse>($"上傳失敗：{exsh.Message}");
            }
            catch (Exception ex)
            {
                LogHelper.Error("Controller 攔截到系統未處理異常", ex);
                return this.SystemError<UploadFileResponse>(ex);
            }
        }

        [HttpGet("GetFileList")]
        public async Task<IActionResult> GetFileListAsync(string formno, string key)
        {
            try
            {
                var list = await _fileService.GetFilesAsync(key, formno);
                return this.ToResponse(ExecuteResult<List<FlmFileInfo>>.Ok(list));
            }
            catch (BusinessException exsh)
            {
                return this.ToResponse<List<FlmFileInfo>>($"取得清單失敗：{exsh.Message}");
            }
            catch (Exception ex)
            {
                LogHelper.Error("Controller 攔截到系統未處理異常", ex);
                return this.SystemError<List<FlmFileInfo>>(ex);
            }
        }

        [HttpGet("GetFile/{id}")]
        public async Task<IActionResult> GetFileAsync([FromRoute] string id)
        {
            try
            {
                var fileInfo = await _fileService.GetFileAsync(id);

                if (fileInfo == null || fileInfo.bytes == null)
                {
                    throw new BusinessException("檔案不存在");
                }

                return File(
                    fileInfo.bytes,
                    fileInfo.Mime ?? "application/octet-stream",
                    fileInfo.FileName ?? "download"
                );
            }
            catch (BusinessException exsh)
            {
                return this.ToResponse<object>($"取得檔案失敗：{exsh.Message}");
            }
            catch (Exception ex)
            {
                LogHelper.Error("Controller 攔截到系統未處理異常", ex);
                return this.SystemError<object>(ex);
            }
        }

        [HttpPost("DeleteFile/{id}")]
        public async Task<IActionResult> DeleteFileAsync([FromRoute] string id)
        {
            try
            {
                var result = await _fileService.DeleteFileAsync(id);

                if (!result)
                {
                    throw new BusinessException("檔案不存在");
                }
                return this.ToResponse(ExecuteResult<object>.Ok(id));
            }
            catch (BusinessException exsh)
            {
                return this.ToResponse<object>($"刪除檔案失敗：{exsh.Message}");
            }
            catch (Exception ex)
            {
                LogHelper.Error("Controller 攔截到系統未處理異常", ex);
                return this.SystemError<object>(ex);
            }
        }

        [AllowAnonymous]
        [HttpGet("FileGet")]
        public async Task<IActionResult> FileGet(string formno, string empNo)
        {
            try
            {
                // 變數來源保持不變
                string sysID = Config.FLMConfig.Security.SysId;
                string bizID = "vendor" + "_" + formno;
                //var d = await _oneSupplierFLMService.GetFileIDByBizIDAsync(bizID);
                string action = "VDTMPF";
                string language = "zh-CHT";
                string pageUrl = Config.FLMConfig.FLM_FileGet;

                //foreach (var item in d.ToList())
                //{
                //    await _oneSupplierFLMService.DeleteFileFromFileServerAsync(item, "empNo");
                //} 
                // 1. 組成原始查詢字串
                string orignQueryString = $"sys_id={sysID}&biz_id={bizID}&action={action}&emp_no={empNo}&language={language}";

                // 2. 加密並與主網址組合
                string encryptedQuery = SecurityHelper.Encrypt(orignQueryString, true);
                string fileUrl = $"{pageUrl}{encryptedQuery}";

                return this.ToResponse(ExecuteResult<string>.Ok(fileUrl));
            }
            catch (BusinessException exsh)
            {
                return this.ToResponse<object>($"刪除檔案失敗：{exsh.Message}");
            }
            catch (Exception ex)
            {
                LogHelper.Error("Controller 攔截到系統未處理異常", ex);
                return this.SystemError<object>(ex);
            }
        }
    }
}
