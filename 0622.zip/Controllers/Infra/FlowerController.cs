﻿using Microsoft.AspNetCore.Mvc;
using OneSupplierPlatform.Infrastructure.FlowerControl;
using OneSupplierPlatform.Models.Infra;

namespace OneSupplierPlatform.Controllers.Infra
{
    public class FlowerController : BaseController
    {
        private readonly FlowerDispatcher _dispatcher;


        public FlowerController(FlowerDispatcher dispatcher)
        {
            _dispatcher = dispatcher;
        }

        [HttpPost]
        public async Task<IActionResult> Run([FromBody] FlowerRequest request)
        {
            var result = await _dispatcher.Execute(request);
            return Ok(result);
        }
    }
}
