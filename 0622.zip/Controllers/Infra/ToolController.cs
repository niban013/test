using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using OneSupplierPlatform.HandleException;
using OneSupplierPlatform.Infrastructure.Log;
using OneSupplierPlatform.Models.Infra;
using OneSupplierPlatform.Models.Tool;
using OneSupplierPlatform.Services.Infra;
using System.Text;

namespace OneSupplierPlatform.Controllers.Infra
{
    public class ToolController : BaseController
    {
        private readonly IHttpClientFactory _httpClientFactory;
        private readonly ToolService _toolService;
        public ToolController(IHttpClientFactory httpClientFactory, ToolService toolService)
        {
            _httpClientFactory = httpClientFactory;
            _toolService = toolService;
        }
        [HttpGet]
        public IActionResult GetPopUpModal(string name)
        {
            return PartialView(name);
        }

        [HttpPost]
        public async Task<IActionResult> GetERP([FromBody] Dictionary<string, object> requestData)
        {
            try
            {
                if (!requestData.ContainsKey("methodName"))
                {
                    throw new Exception("Missing methodName");
                }

                string methodName = requestData["methodName"].ToString();
                var parameters = requestData["params"];
                string asmxUrl = $"{Config.ExternalServices.ErpUrl}/{methodName}";

                using (var client = _httpClientFactory.CreateClient())
                {
                    var jsonPayload = JsonConvert.SerializeObject(parameters);
                    var content = new StringContent(jsonPayload, Encoding.UTF8, "application/json");


                    var response = await client.PostAsync(asmxUrl, content);
                    var result = await response.Content.ReadAsStringAsync();
                    if (!response.IsSuccessStatusCode)
                    {
                        throw new Exception($"ERP Service Error: {result}");
                        //return StatusCode((int)response.StatusCode, ExecuteResult<object>.Fail($"ERP Service Error: {result}"));
                    }
                    object erpData;
                    try
                    {
                        erpData = JsonConvert.DeserializeObject<object>(result);
                    }
                    catch (JsonReaderException)
                    {
                        erpData = result;
                    }
                    return Ok(ExecuteResult<object>.Ok(erpData));
                }
            }
            catch (Exception ex)
            {
                throw new BusinessException(ex.Message);
            }
        }


        private record BankItem(string Id, string Name, string Branch, string SwiftCode);

        [HttpGet]
        public async Task<IActionResult> SearchBanks(string actionname, string? searchTerm, int page = 1)
        {
            try
            {
                const int pageSize = 10;
                List<BankDataDto> lsBank = new List<BankDataDto>();
                Dictionary<string, object> parameters = new Dictionary<string, object>();
                if (!string.IsNullOrEmpty(searchTerm ?? string.Empty))
                {
                    parameters["bankname"] = searchTerm ?? string.Empty; // �קK null
                }
                lsBank = await _toolService.GetBankInfo(actionname, parameters);
                LogHelper.Info(JsonConvert.SerializeObject(lsBank));

                var totalCount = lsBank.Count; // List �ϥ� .Count �� .Count() �į��n
                var pagedData = lsBank
                    .Skip((page - 1) * pageSize)
                    .Take(pageSize)
                    .Select(b => new
                    {
                        id = b.Bank_Country + b.Bank_Key + b.bank_branch_name,
                        text = b.Bank_Country + " " + b.Bank_Key + " " + b.bank_branch_name,
                        bankName = b.bank_name,
                        bankKey = b.Bank_Key,
                        bankCountry = b.Bank_Country,
                        branchName = b.branch_number,
                        swiftCode = b.EFT_Swift_Code
                    })
                    .ToList();

                bool morePages = page * pageSize < totalCount;

                var finalResult = ExecuteResult<object>.Ok(new
                {
                    items = pagedData,
                    morePages
                });
                return Ok(finalResult);
            }
            catch (Exception ex)
            {
                throw new BusinessException(ex.Message);
            }
        }
        [HttpPost]
        public async Task<IActionResult> GetLatLngByGoogle([FromBody] AsyncValidationRequest req)
        {
            try
            {
                vmGeography geoObj = new vmGeography();
                if (req.Value == null || string.IsNullOrEmpty(req.Value.ToString()))
                {
                    req.Fields["latitude"] = "";
                    req.Fields["longitude"] = "";
                    throw new Exception("�a�}���i����");
                }
                string asmxUrl = $"{Config.GoogleConfig.Url}";
                using (var client = _httpClientFactory.CreateClient())
                {
                    client.DefaultRequestHeaders.Add("sysid", Config.GoogleConfig.SysId);
                    client.DefaultRequestHeaders.Add("systoken", Config.GoogleConfig.SysToken);

                    vmGeography.PostData postData = new vmGeography.PostData { addr = req.Value.ToString() };
                    string json = JsonConvert.SerializeObject(postData);
                    var content = new StringContent(json, Encoding.UTF8, "application/json");

                    HttpResponseMessage httpResponse = await client.PostAsync(asmxUrl, content);

                    if (!httpResponse.IsSuccessStatusCode)
                    {
                        req.Fields["latitude"] = "";
                        req.Fields["longitude"] = "";
                        return Ok(ExecuteResult<object>.Fail($"Google �A�Ȳ��`: {httpResponse.ReasonPhrase}"));
                    }

                    string response = await httpResponse.Content.ReadAsStringAsync();
                    var result = JsonConvert.DeserializeObject<dynamic>(response);

                    if (result != null && result.status == "OK")
                    {
                        geoObj.LONGITUDE = result.results[0].geometry.location.lng;
                        geoObj.LATITUDE = result.results[0].geometry.location.lat;

                        req.Fields["latitude"] = geoObj.LATITUDE;
                        req.Fields["longitude"] = geoObj.LONGITUDE;
                    }
                    else
                    {
                        req.Fields["latitude"] = "";
                        req.Fields["longitude"] = "";
                        throw new Exception("�䤣��Ӧa�}���g�n��");
                    }
                }
                return Ok(ExecuteResult<object>.Ok(req.Fields));
            }
            catch (Exception ex)
            {
                throw;// new BusinessException(ex.Message);
            }
        }
    }
}
