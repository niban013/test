﻿using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using OneSupplierPlatform.Controllers.Infra;
using OneSupplierPlatform.Infrastructure.Log;
using OneSupplierPlatform.Models.Supplier;
using OneSupplierPlatform.Services;

namespace OneSupplierPlatform.Controllers
{
    public class SupplierApproveController : BaseController
    {
        private readonly ISupplierService _supplierService;
        public SupplierApproveController(ISupplierService supplierService)
        {
            _supplierService = supplierService;
        }

        public async Task<IActionResult> Approve()
        {
            // 完全還原您上傳圖片中的資料內容
            //var viewModel = new SupplierApplicationViewModel
            //{
            //    // 頂部表單資訊 (原圖中為空白，此處補上範例格式，可依需求調整)
            //    FormNo = "FORM-2026-0001",
            //    Applier = "John Doe",
            //    ApplyDate = "2026-05-29",
            //    FormStatus = "Pending",

            //    // 1. Supplier Information 區塊
            //    OuSite = "AMSCTW",
            //    VendorType = "New Vendor",
            //    SupplierType = "VCL",
            //    EffectiveDate = "2026-05-29",
            //    GroupName = "None Group",
            //    GroupCode = "C99999",

            //    // 2. Vendor Subrange 區塊清單 (使用 C# 12 集合表達式)
            //    VendorSubranges = [
            //        new() {
            //            SsrName = "EUR",
            //            Currency = "EUR",
            //            PaymentName = "O/A 120 Days on 25th",
            //            TaxDesc = "VB: 購買國外勞務",
            //            Phone = "0049-71189970",
            //            Email = "anselm.christiansen@gleisslutzn.com",
            //            Fax = "0049-711855096",
            //            FreightCode = "03",
            //            FobCode = "DDP"
            //        }
            //    ],

            //    // 3. Bank Line 區塊清單
            //    BankLines = [
            //        new() {
            //            BankName = "第一商業銀行",
            //            BankBranch = "丹鳳分行",
            //            BankAccountName = "振儀科技股份有限公司",
            //            BankAccountNo = "23910015424",
            //            Country = "TW",
            //            Province = "",       // 原圖中為空字串
            //            City = "",           // 原圖中為空字串
            //            BranchAddress = "",  // 原圖中為空字串
            //            BankKey = "0072399"
            //        }
            //    ]
            //};
            var dd = JsonConvert.SerializeObject(this.ParsedQueries);
            LogHelper.Info(dd);
            var viewModel = new SupplierApplicationViewModel();
            try
            {
                viewModel = await _supplierService.GetSupplierApplicationAsync(this.ParsedQueries);
                // 將填有假資料的 viewModel 傳遞給您的 .cshtml 視圖

                viewModel.CurrentPhase = ParsedQueries.CallPhaseId;
            }
            catch (Exception ex)
            {

            }

            return View(viewModel);
        }
    }
}
