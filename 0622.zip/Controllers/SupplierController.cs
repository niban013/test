﻿using Microsoft.AspNetCore.Mvc;
using newauo.Helper;
using Newtonsoft.Json;
using OneSupplierPlatform.Controllers.Infra;
using OneSupplierPlatform.HandleException;
using OneSupplierPlatform.Helper;
using OneSupplierPlatform.Infrastructure.Log;
using OneSupplierPlatform.Models;
using OneSupplierPlatform.Models.Infra;
using OneSupplierPlatform.Models.Supplier;
using OneSupplierPlatform.Services;

namespace OneSupplierPlatform.Controllers
{
    [ErrorUiMode(ErrorUiMode.Inline)]
    public class SupplierController : BaseController
    {
        private static readonly List<WizardStepOption> Steps = new()
        {
            new WizardStepOption { StepIndex = 1, Title = "Apply New Supplier", PartialView = "Supplier/_StepApplyNewSupplier", Locked = false },
            new WizardStepOption { StepIndex = 2, Title = "Supplier Information", PartialView = "Supplier/_StepSupplierInformation" },
            new WizardStepOption { StepIndex = 3, Title = "File List", PartialView = "Supplier/_StepFileList" }
        };

        private readonly ISupplierService _supplierService;

        public SupplierController(ISupplierService supplierService)
        {
            _supplierService = supplierService;
        }


        public async Task<IActionResult> Index(int? formno)
        {
            try
            {
                int actualFormNo = formno.HasValue ? formno.Value : 0;
                if (actualFormNo > 0)
                {
                    //var sql = string.Format(@"select headerid HeaderId,form_status FormStatus ,apply_type from osp_vendor_header_r where form_no ={0}", actualFormNo);

                    //var headerinfo = (await DbCenter.QuerySingleAsync<VendorHeader>(sql));
                    //if (headerinfo == null)
                    //{
                    //    throw new ShowException("表單編號不存在");
                    //}

                    var decision = new DecisionData
                    {
                        Types = new Dictionary<string, string> { { "suppliername", "" }, { "applytype", "MakerVendor" } },
                        Datas = new Dictionary<string, string>() { }
                    };
                    var step2 = new Step2Data();

                    step2["step2"] = decision;

                    var mode = true;//headerinfo.FormStatus.ToLower() == "submit";

                    var boot = new
                    {
                        FormInfo = new FormInfo() { headerid = "58", formno = actualFormNo.ToString(), applytype = "MakerVendor", mode = mode },
                        targetStep = actualFormNo > 0 ? 2 : 1,
                        flowData = step2
                    };
                    ViewBag.Boot = JsonConvert.SerializeObject(boot);
                }
                return View(Steps);
            }
            catch (Exception ex)
            {
                LogHelper.Error("Controller 攔截到系統未處理異常", ex);

                // ❗只能 rethrow，不能改 UI
                throw;
            }
        }

        [HttpPost]
        public async Task<IActionResult> Step([FromBody] StepRequest req)
        {
            try
            {
                var stepIndex = req.StepIndex;
                if (stepIndex < 1 || stepIndex > Steps.Count)
                    throw new BusinessException("Invalid step index");
                var stepKey = "step" + req.StepIndex;
                var step = req.FlowData?[stepKey];

                var formno = req.FormInfo?.formno;
                var type = step?.Types;
                var decision = step?.Datas;

                var stepInfo = Steps[stepIndex - 1];

                var result = stepIndex switch
                {
                    1 => await GenerateStep(stepIndex),
                    2 => await GenerateStep(stepIndex, formno, type, decision),
                    3 => await GenerateStep(stepIndex, formno, type),
                    _ => ExecuteResult<IStepViewModel>.Fail("Invalid step")
                };
                var model = result.EnsureSuccess();

                ViewBag.Title = stepInfo.Title;

                return PartialView(stepInfo.PartialView, model);
            }
            catch (Exception ex)
            {
                LogHelper.Error("Controller 攔截到系統未處理異常", ex);
                throw new BusinessException(ex.Message, ErrorUiMode.Inline);
            }
        }

        async Task<ExecuteResult<IStepViewModel>> GenerateStep(int stepIndex, string formno = "", Dictionary<string, object>? types = null, Dictionary<string, object>? values = null)
        {
            IStepViewModel? model = null;

            try
            {
                //throw new Exception("料號不存在");
                switch (stepIndex)
                {
                    case 1:
                        Dictionary<string, List<TableSchema>> dic = new Dictionary<string, List<TableSchema>>();
                        var maker = new List<TableSchema>
                        {
                            new()
                            {
                                TableId = "tbMaker1",
                                AjaxUrl = "Supplier/GetMakerData",
                                FetchMode = FetchMode.All,
                                Message="* Existed in the company",

                                Features = new TableFeatures
                                {
                                    Checkbox = false,
                                    Export = true,
                                    RowButtons = true,
                                    ColumnToggle = true,
                                    RowSelect = true,
                                    SelectAll = true,
                                    VirtualScroll = true,
                                    ColumnFilter = false,   // 可選，每欄都有 filter
                                    StickyHeader = true    // 可選，表頭固定
                                },

                                Config = new TableConfig
                                {
                                    PageLength = 2,
                                    VirtualScrollHeight = "500px",
                                    Searching = false,
                                    Ordering = false,
                                    Paging = true,
                                    LengthChange = false,
                                    StateSave = true
                                },


                                Columns =  TableSchema.Create<vmMakerDetail>(new()
                                {
                                    x => x.MakerCode,       // 自動轉為 "maker_code"
                                    x => x.MakerLocalName,  // 自動轉為 "maker_local_name"
                                    x => x.MakerEngName,
                                    x => x.MakerShortName,
                                    x => x.MakerEngName,
                                    "Country",              // 自動轉為 "country"
                                    "City",                 // 自動轉為 "city"
                                    x => x.FacilityAddress,
                                }).Columns,


                                RowButtons =
                                {
                                    new(){ Title="Add Another Maker Type", Event="addMakerType", Icon="bi-pencil"},
                                    new(){ Title="Add New Site", Event="addNewSite", Icon="bi-pencil"}
                                }
                            },
                            new()
                            {
                                TableId = "tbMaker2",
                                AjaxUrl = "",
                                FetchMode = FetchMode.All,
                                Message="* Existed in the group companyd(excluding itself)",
                                Features = new TableFeatures
                                {
                                    Checkbox = false,
                                    Export = true,
                                    RowButtons = true,
                                    ColumnToggle = true,
                                    RowSelect = true,
                                    SelectAll = true,
                                    VirtualScroll = true,
                                    ColumnFilter = false,   // 可選，每欄都有 filter
                                    StickyHeader = true    // 可選，表頭固定
                                },

                                Config = new TableConfig
                                {
                                    PageLength = 20,
                                    VirtualScrollHeight = "500px",
                                    Searching = false,
                                    Ordering = false,
                                    Paging = false,
                                    LengthChange = false,
                                    StateSave = true
                                },

                                Columns =  TableSchema.Create<vmMakerDetail>(new()
                                {
                                    x => x.MakerCode,       // 自動轉為 "maker_code"
                                    x => x.MakerLocalName,  // 自動轉為 "maker_local_name"
                                    x => x.MakerEngName,
                                    x => x.MakerShortName,
                                    x => x.MakerEngName,
                                    "Country",              // 自動轉為 "country"
                                    "City",                 // 自動轉為 "city"
                                    x => x.FacilityAddress,
                                    x => x.MakerStatus,
                                }).Columns,

                                RowButtons =
                                {
                                    new(){ Title="Copy Maker", Event="cpMaker", Icon="bi-pencil"},
                                }
                            }
                        };
                        var vendor = new List<TableSchema>
                        {
                            new()
                            {
                                  TableId = "tbVendor",
                                  AjaxUrl = "Supplier/GetVendorData",
                                  FetchMode = FetchMode.All,

                                  Features = new TableFeatures
                                  {
                                      Checkbox = false,
                                      Export = true,
                                      RowButtons = true,
                                      ColumnToggle = true,
                                      RowSelect = true,
                                      SelectAll = true,
                                      VirtualScroll = true,
                                      ColumnFilter = false,   // 可選，每欄都有 filter
                                      StickyHeader = true    // 可選，表頭固定
                                  },

                                  Config = new TableConfig
                                  {
                                      PageLength = 20,
                                      VirtualScrollHeight = "500px",
                                      Searching = false,
                                      Ordering = false,
                                      Paging = false,
                                      LengthChange = false,
                                      StateSave = true
                                  },

                                  Columns =  TableSchema.Create<vmVendorDetail>(new()
                                  {
                                        x => x.OUSite,
                                        x => x.Inactive,
                                        x => x.GroupName,
                                        x => x.GroupCode,
                                        x => x.VendorName,
                                        "VandorNameAlt",
                                        "VandorCode",
                                        x => x.SSRName,
                                        x => x.TaxRegistration,
                                        x => x.ApplyType,
                                  }).Columns,
                            }
                        };
                        dic["maker"] = maker;
                        dic["vendor"] = vendor;
                        //dic = JsonConvert.DeserializeObject<Dictionary<string, List<TableSchema>>>(mock.j4);
                        model = new StepViewModel<TableSchema>
                        {
                            StepIndex = stepIndex,
                            Title = "第一頁",
                            Data = dic
                        };

                        break;
                    case 2:
                        //先找CONFIG
                        //Dictionary<string, List<BaseDynamicField>> dic2 = new Dictionary<string, List<BaseDynamicField>>();
                        //string[] sections = ["Supplier Information", "Vendor Subrange", "Company Profile", "Effective contract"];
                        ////string[] sections = ["Supplier Information"];
                        //foreach (var item in sections)
                        //{
                        //    dic2[item] = await _supplierService.GetConfigFieldAsync(item, types);
                        //}
                        ////var userFromDb = new UserProfile { CompanyCode = "Johnny", MakerType = "Normal", RequestReason = "test@me.com" };
                        //if (!string.IsNullOrEmpty(formno))
                        //{
                        //    await _supplierService.MappingFormData(dic2, formno);
                        //}

                        //_dynamicFieldService.FillSchemaWithDictionary(dic2, values);
                        var dic2 = JsonConvert.DeserializeObject<Dictionary<string, List<BaseDynamicField>>>(mock.j2);
                        //Logger.LogInformation(JsonConvert.SerializeObject(dic2));
                        model = new StepViewModel<BaseDynamicField>
                        {
                            StepIndex = stepIndex,
                            Title = "第二頁",
                            Data = (values == null || values.Count == 0) ? dic2 : await _supplierService.MappingSendData(dic2, values)
                        };
                        break;
                    case 3:
                        Dictionary<string, List<BaseDynamicField>> dic3 = new();
                        dic3 = JsonConvert.DeserializeObject<Dictionary<string, List<BaseDynamicField>>>(mock.j3);
                        //dic3["STEP3"] = await _supplierService.GetConfigFileListAsync(formno, types);

                        //if (!string.IsNullOrEmpty(formno))
                        //{
                        //    await _supplierService.MappingFormData(dic3, formno);
                        //}
                        //Logger.LogInformation(JsonConvert.SerializeObject(dic3));
                        //_dynamicFieldService.FillSchemaWithDictionary(dic3, values);
                        model = new StepViewModel<BaseDynamicField>
                        {
                            StepIndex = stepIndex,
                            Title = "第三頁",
                            Data = dic3
                        };
                        break;
                }

                return ExecuteResult<IStepViewModel>.Ok(model);
            }
            catch (BusinessException exsh)
            {
                return ExecuteResult<IStepViewModel>.Fail($"表單送出失敗：{exsh.Message}");
            }
            catch (Exception ex)
            {
                LogHelper.Error("Controller 攔截到系統未處理異常", ex);
                return ExecuteResult<IStepViewModel>.Fail("系統錯誤");
            }
        }


        [HttpPost]
        public async Task<IActionResult> Draft([FromForm] FormRequest req)
        {
            if (req.Payload == null)
            {
                throw new Exception("資料格式錯誤");
            }
            FormInfo form = null;//await _supplierService.SaveAsync(req);

            return this.ToResponse(ExecuteResult<FormInfo>.Ok(form, "草稿暫存成功"));
        }
        [HttpPost]
        public async Task<IActionResult> Send([FromForm] FormRequest req)
        {
            try
            {
                if (req.Payload == null)
                {
                    throw new BusinessException("資料格式錯誤");
                }
                var data = JsonConvert.DeserializeObject<SupplierSaveViewModel>(req.Payload);
                string message = await _supplierService.SendAsync(req);
                return this.ToResponse(ExecuteResult<FormInfo>.Ok(data.FormInfo, message));
            }
            catch (BusinessException exsh)
            {
                return this.ToResponse<FormInfo>($"表單送出失敗：{exsh.Message}");
            }
            catch (Exception ex)
            {
                LogHelper.Error("Controller 攔截到系統未處理異常", ex);
                return this.SystemError<FormInfo>(ex);
            }
        }

        [HttpGet]
        public async Task<IActionResult> GetMakerData(string makername, string companyid)
        {
            try
            {
                if (string.IsNullOrEmpty(makername))
                {
                    return Json(new
                    {
                        success = true,
                        tbMaker1 = new List<vmMakerDetail>(), // 給第一個表的資料
                        tbMaker2 = new List<vmMakerDetail>()       // 給第二個表的資料
                    });
                }


                var lsvwMaker1 = JsonConvert.DeserializeObject<List<vmMakerDetail>>(mock.j6);
                //var lsvwMaker1 = await _supplierService.GetMakerDataFromGroupAsync(makername, companyid);

                if (lsvwMaker1.Count == 0)
                {
                    throw new Exception("找不到供應商資料");
                }
                var lsvwMaker2 = JsonConvert.DeserializeObject<List<vmMakerDetail>>(mock.j7);
                //var lsvwMaker2 = await _supplierService.GetMakerDataInternalAsync(makername);

                if (lsvwMaker2.Count == 0)
                {
                    throw new Exception("找不到供應商資料");
                }

                LogHelper.Info(JsonConvert.SerializeObject(lsvwMaker1));
                LogHelper.Info(JsonConvert.SerializeObject(lsvwMaker2));

                return Json(new
                {
                    success = true,
                    tbMaker1 = lsvwMaker1,  // 這裡的 Key 就是前端 <table id="SupplierGrid">
                    tbMaker2 = lsvwMaker2     // 這裡的 Key 就是前端 <table id="OrderGrid"> 
                });
            }
            catch (Exception ex)
            {
                return this.SystemError<string>(ex);
            }
        }

        [HttpGet]
        public async Task<IActionResult> GetVendorData(string vendorname)
        {
            try
            {
                if (string.IsNullOrEmpty(vendorname))
                {
                    return Json(new
                    {
                        success = true,
                        tbVendor = new List<vmVendorDetail>(),
                    });
                }

                //var lsvmVender = await _supplierService.GetVendorInfoAsync(vendorname);
                //Logger.LogInformation(JsonConvert.SerializeObject(lsvmVender));

                var lsvmVender = JsonConvert.DeserializeObject<List<vmVendorDetail>>(mock.j5);
                await _supplierService.GetVendorInfoAsync(vendorname);

                if (lsvmVender.Count == 0)
                {
                    throw new Exception("找不到供應商資料");
                }
                return Json(new
                {
                    success = true,
                    tbVendor = lsvmVender,  // 這裡的 Key 就是前端 <table id="SupplierGrid"> 
                });
            }
            catch (Exception ex)
            {
                throw new BusinessException(ex.Message);
                ////return this.SystemError<string>(ex);
            }
        }

        [HttpGet]
        public async Task<IActionResult> GetSupplierForm()
        {

            var sectionConfigs = new Dictionary<string, List<BaseDynamicField>>();
            //var data = await _supplierService.GetConfigFieldAsync("Vendor","");
            sectionConfigs["Vendor"] = new List<BaseDynamicField>();//data;

            //// 模擬從資料庫查詢回來的結果
            //var fieldList = new List<DynamicField>
            //{
            //    // 第一列
            //    //new DynamicField {
            //    //    ColId = "Company", ColName = "Company", Section = "Basic",
            //    //    EnumType = FieldType.Select2, Must = true, Order = 1,
            //    //    attribute = "AMSCTW:AMSC Taiwan,AMSCCN:AMSC China"
            //    //},
            //    //new DynamicField {
            //    //    ColId = "Type", ColName = "Type", Section = "Basic",
            //    //    EnumType = FieldType.Textbox, DefaultValue = "New Vendor", Readonly = true, Order = 2
            //    //},
            //    //new DynamicField {
            //    //    ColId = "SupplierType", ColName = "Supplier Type", Section = "Basic",
            //    //    EnumType = FieldType.Dropdown, Must = true, Order = 3,
            //    //    attribute = "Trade,Manufacturer,Service"
            //    //},
            //    //new DynamicField {
            //    //    ColId = "EffectiveDate", ColName = "Effective Date", Section = "Basic",
            //    //    EnumType = FieldType.Date, Must = true, Order = 4, DefaultValue = "2026-03-24"
            //    //},

            //    // 第二列
            //    //new DynamicField {
            //    //    ColId = "GroupName", ColName = "Group Name", Section = "GroupInfo",
            //    //    EnumType = FieldType.Textbox, Must = true, Order = 5, Placeholder = "請輸入群組名稱"
            //    //},
            //    //new DynamicField {
            //    //    ColId = "GroupCode", ColName = "Group Code", Section = "GroupInfo",
            //    //    EnumType = FieldType.Textbox, Readonly = true, Order = 6
            //    //},
            //    //new DynamicField {
            //    //    ColId = "VendorType", ColName = "Vendor Type", Section = "GroupInfo",
            //    //    EnumType =  FieldType.Dropdown, Must = true, Order = 7,
            //    //    attribute = "Domestic,Overseas"
            //    //},

            //    // 地址與其他
            //    //new DynamicField {
            //    //    ColId = "City", ColName = "City", Section = "Address",
            //    //   EnumType = FieldType.Textbox, Must = true, Order = 8
            //    //},
            //    //new DynamicField {
            //    //    ColId = "Address", ColName = "Address", Section = "Address",
            //    //    EnumType = FieldType.Textarea, Must = true, Order = 9, Width = 6
            //    //}
            //};

            //// 將 List 依照 Section 分組，轉成 Dictionary<string, List<DynamicField>>
            //var viewModel = fieldList
            //    .OrderBy(f => f.Order)
            //    .GroupBy(f => f.Section)
            //    .ToDictionary(g => g.Key, g => g.ToList());

            // 回傳 Partial View 並帶入 Model
            return PartialView("Supplier/_VendorInfo", sectionConfigs);
        }
        [HttpPost]
        public async Task<IActionResult> UploadSSAAF(IFormFile file)
        {
            if (file == null || file.Length == 0)
            {
                return BadRequest("請選擇檔案");
            }

            // 安全性檢查：驗證副檔名
            var ext = Path.GetExtension(file.FileName).ToLowerInvariant();
            if (ext != ".xls" && ext != ".xlsx")
            {
                return BadRequest("僅支援 Excel 檔案");
            }
            return Json(await _supplierService.UploadSSAAF(file));
        }

    }

}