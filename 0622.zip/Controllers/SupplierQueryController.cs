﻿using Microsoft.AspNetCore.Mvc;
using newauo.Helper;
using Newtonsoft.Json;
using OneSupplierPlatform.Controllers.Infra;
using OneSupplierPlatform.HandleException;
using OneSupplierPlatform.Helper;
using OneSupplierPlatform.Infrastructure.Log;
using OneSupplierPlatform.Models.Supplier;
using OneSupplierPlatform.Services;

namespace OneSupplierPlatform.Controllers
{
    [ErrorUiMode(ErrorUiMode.Modal)]
    public class SupplierQueryController : BaseController
    {
        private readonly ISupplierService _supplierService;

        private List<SupplierItem> GetAllMockData()
        {
            var list = new List<SupplierItem>();
            // 這裡模擬產生 25 筆測試資料，以便測試分頁效果
            for (int i = 1; i <= 25; i++)
            {
                list.Add(new SupplierItem
                {
                    FormNo = (400 + i).ToString(),
                    VendorName = $"AUO MSC MEXICO S.A. DE C.V. ({i})",
                    VendorCode = "1600004301",
                    CreateDate = DateTime.Today,
                    FlowerStatus = i % 2 == 0 ? "SAVED" : "Return",
                    ApplyType = "ES",
                    Applicant = "Lily Huang 黃麗康",
                    Department = "MSCB_AO"
                });
            }
            return list;
        }


        public SupplierQueryController(ISupplierService supplierService)
        {
            _supplierService = supplierService;
        }

        [HttpGet]
        public async Task<IActionResult> Index()
        {
            var model = new vmSupplierQuery { PageNumber = 1 };
            //await ProcessQueryAndPagination(model); 
            //Logger.LogInformation(JsonConvert.SerializeObject(model));
            model = JsonConvert.DeserializeObject<vmSupplierQuery>(mock.j1);
            return View(model);
        }

        [HttpPost]
        public async Task<IActionResult> Index(vmSupplierQuery model)
        {
            await ProcessQueryAndPagination(model);
            //model = JsonConvert.DeserializeObject<vmSupplierQuery>(mock.j1);
            LogHelper.Info(JsonConvert.SerializeObject(model));
            return View(model);
        }


        private async Task ProcessQueryAndPagination(vmSupplierQuery model)
        {
            throw new BusinessException("檔案不存在");
            var query = await _supplierService.QuerySuppierAll(model);

            model.TotalItems = query.Count();
            if (model.PageNumber < 1) model.PageNumber = 1;
            model.Results = query
                .Skip((model.PageNumber - 1) * model.PageSize)
                .Take(model.PageSize)
                .ToList();
        }
    }
}
