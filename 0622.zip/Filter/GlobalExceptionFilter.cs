﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using Microsoft.AspNetCore.Mvc.ViewFeatures;
using newauo.Helper;
using OneSupplierPlatform.HandleException;
using OneSupplierPlatform.Infrastructure.Log;
using OneSupplierPlatform.Infrastructure.Render;
using System.Diagnostics;
using System.Text.Json;

namespace OneSupplierPlatform.Filter
{
    public class GlobalExceptionFilter : IAsyncExceptionFilter
    {
        private readonly ITempDataDictionaryFactory _tempDataFactory;
        private readonly IRazorViewToStringRenderer _renderer;

        public GlobalExceptionFilter(
            ITempDataDictionaryFactory tempDataFactory,
            IRazorViewToStringRenderer renderer)
        {
            _tempDataFactory = tempDataFactory;
            _renderer = renderer;
        }

        public async Task OnExceptionAsync(ExceptionContext context)
        {
            var ex = context.Exception;

            var requestId = Activity.Current?.Id ?? context.HttpContext.TraceIdentifier;

            var isAjax = IsAjax(context);

            LogHelper.Error($"Unhandled Exception: {ex.Message}", ex);

            var uiMode = GetUiModeFromAttribute(context) ?? ErrorPolicyResolver.Resolve(ex);

            bool isFatal = uiMode == ErrorUiMode.Redirect;

            string html = "";

            //--------------------------------------------------
            // AJAX
            //--------------------------------------------------
            if (isAjax)
            {
                if (!isFatal)
                {
                    html = await _renderer.RenderAsync(
                        "Error/_ErrorContent",
                        new ErrorResponse
                        {
                            RequestId = requestId,
                            Message = ex.Message
                        });
                }

                var response = BuildResponse(
                    ex, requestId, uiMode, isFatal, html);

                context.Result = new JsonResult(response)
                {
                    StatusCode = 200
                };

                context.ExceptionHandled = true;
                return;
            }

            //--------------------------------------------------
            // MVC
            //--------------------------------------------------
            var pageResponse = BuildResponse(ex, requestId, uiMode, isFatal);

            var tempData = _tempDataFactory.GetTempData(context.HttpContext);

            switch (uiMode)
            {
                //--------------------------------------------------
                // 1️⃣ Redirect → 一律 Error Page
                //--------------------------------------------------
                case ErrorUiMode.Redirect:

                    tempData["ErrorResponse"] = JsonSerializer.Serialize(pageResponse);

                    tempData["ErrorUiMode"] = (int)ErrorUiMode.Redirect;

                    context.Result = new RedirectResult($"/Error/Index?requestId={requestId}");

                    break;

                //--------------------------------------------------
                // 2️⃣ Modal → 回原頁 + Swal
                //--------------------------------------------------
                case ErrorUiMode.Inline:
                case ErrorUiMode.Modal:

                    tempData["ErrorResponse"] = JsonSerializer.Serialize(pageResponse);

                    tempData["ErrorUiMode"] = (int)ErrorUiMode.Modal;

                    var currentUrl = context.HttpContext.Request.Path + context.HttpContext.Request.QueryString;

                    context.Result = new RedirectResult(currentUrl);

                    break;

                default:

                    context.Result = new RedirectResult($"/Error/Index?requestId={requestId}");

                    break;
            }

            context.ExceptionHandled = true;
        }

        private ErrorResponse BuildResponse(
            Exception ex,
            string requestId,
            ErrorUiMode uiMode,
            bool isFatal,
            string html = "")
        {
            return new ErrorResponse
            {
                Success = false,

                Message = isFatal ? "系統發生錯誤，請聯絡管理員" : ex.Message,

                Title = ex is BusinessException ? "提示" : "系統錯誤",

                IsFatal = isFatal,

                UiMode = uiMode,

                RequestId = requestId,

                RedirectUrl = $"/Error/Index?requestId={requestId}",

                Html = html
            };
        }

        private static bool IsAjax(ExceptionContext context)
        {
            var request = context.HttpContext.Request;

            return request.Headers["X-Requested-With"] == "XMLHttpRequest";
        }

        private ErrorUiMode? GetUiModeFromAttribute(ExceptionContext context)
        {
            var endpoint = context.HttpContext.GetEndpoint();
            var attr = endpoint?
                .Metadata
                .GetMetadata<ErrorUiModeAttribute>();

            return attr?.Mode;
        }
    }
}
