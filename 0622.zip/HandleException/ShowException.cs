﻿namespace OneSupplierPlatform.HandleException
{
    public enum ErrorUiMode
    {
        Modal,
        Redirect,
        Inline
    }
    public class ErrorResponse
    {
        public bool Success { get; set; }
        public string Message { get; set; }
        public string Title { get; set; }
        public bool IsFatal { get; set; }

        public ErrorUiMode UiMode { get; set; }

        public string RedirectUrl { get; set; }

        public string Html { get; set; }

        public string RequestId { get; set; }
        public bool ShowRequestId => !string.IsNullOrWhiteSpace(RequestId);
    }

    public abstract class AppException : Exception
    {
        public ErrorUiMode UiMode { get; }

        public virtual bool IsFatal => false;

        protected AppException(
            string message,
            ErrorUiMode uiMode,
            Exception? innerException = null)
            : base(message, innerException)
        {
            UiMode = uiMode;
        }
    }


    public class BusinessException : AppException
    {
        public BusinessException(
            string message,
            ErrorUiMode uiMode = ErrorUiMode.Modal)
            : base(message, uiMode)
        {
        }

        public static BusinessException Modal(string message)
            => new(message, ErrorUiMode.Modal);

        public static BusinessException Inline(string message)
            => new(message, ErrorUiMode.Inline);

        public static BusinessException Redirect(string message)
            => new(message, ErrorUiMode.Redirect);
    }


    public static class ErrorPolicyResolver
    {
        public static ErrorUiMode Resolve(Exception ex)
        {
            return ex switch
            {
                AppException appEx => appEx.UiMode,
                _ => ErrorUiMode.Redirect // system error default
            };
        }

        public static bool IsFatal(Exception ex)
        {
            return ex is not AppException;
        }
    }
}
