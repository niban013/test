﻿using System.Data;
using OneSupplierPlatform.Infrastructure;
using OneSupplierPlatform.Infrastructure.DataBase;

namespace OneSupplierPlatform.Helper
{
    public class Utility
    {
        private static ITransactionContext DbCenter => AppFinder.GetService<ITransactionContext>() ?? throw new Exception("ITransactionContext 未初始化");
        public  static DataTable GetAppRoleUser(string ouSite, string roleName ="")
        {
            var wheresql = "";
            if (!string.IsNullOrEmpty(roleName)) 
            {
                wheresql += string.Format(@"and Role_Name ='{0}'", roleName);
            }
            var sql = string.Format(@"SELECT 	
                               CASE WHEN UPPER(Role_Name) = 'FINANCIAL'  THEN 'FINANCE' 	
                                    WHEN UPPER(Role_Name) = 'ACCOUNTING' THEN 'ACCOUNTANT' 	
                                    ELSE UPPER(Role_Name) 	
	                           END AS [appRole]
	
                              ,CASE WHEN UPPER(emp_id) LIKE 'AMSC-%' THEN UPPER(emp_id)	
	                                ELSE 'AMSC-' + UPPER(emp_id) --無公司名時，自動補上
	                           END AS [appUser]
                          FROM osp_systemp_role_emp	
                         WHERE UPPER(active) = 'Y'	
                         and ou_id ='{0}'	
                         {1}", ouSite, wheresql);
            return DbCenter.QueryDataTable(sql);
        }


        public static async Task<string> CheckUFLPA(string companyEnglishName,
                                                string companyLocalName,
                                                string makerEnglishName,
                                                string makerLocalName)
        {
         
            var sql = @"
                SELECT CASE WHEN EXISTS (
                    SELECT 1 
                    FROM osp_uflpa vu 
                    CROSS JOIN (
                        VALUES 
                        (@companyEnglishName), 
                        (@companyLocalName), 
                        (@makerEnglishName), 
                        (@makerLocalName)
                    ) AS input(vName)
                    WHERE input.vName IS NOT NULL AND input.vName <> '' AND (
                           UPPER(vu.vendor_Name) LIKE UPPER('%' + input.vName + '%') 
                        OR UPPER(vu.alias1)      LIKE UPPER('%' + input.vName + '%') 
                        OR UPPER(vu.alias2)      LIKE UPPER('%' + input.vName + '%') 
                        OR UPPER(vu.alias3)      LIKE UPPER('%' + input.vName + '%') 
                        OR UPPER(vu.alias4)      LIKE UPPER('%' + input.vName + '%') 
                        OR UPPER(vu.alias5)      LIKE UPPER('%' + input.vName + '%') 
                        OR UPPER(vu.alias6)      LIKE UPPER('%' + input.vName + '%') 
                        OR UPPER(vu.alias7)      LIKE UPPER('%' + input.vName + '%') 
                        OR UPPER(vu.alias8)      LIKE UPPER('%' + input.vName + '%') 
                        OR UPPER(vu.alias9)      LIKE UPPER('%' + input.vName + '%')
                    )
                ) THEN 1 ELSE 0 END"; 
            var param = new
            {
                companyEnglishName = companyEnglishName?.Trim(),
                companyLocalName = companyLocalName?.Trim(),
                makerEnglishName = makerEnglishName?.Trim(),
                makerLocalName = makerLocalName?.Trim()
            }; 
            var isHit = await DbCenter.ExecuteScalarAsync<int>(sql, param);

            return isHit == 1 ? "Y" : "N";
        }


        public static async Task<string> CheckUFLPA(string vendorName)
        {
            var sql = string.Format(@"SELECT COUNT(1)	
                              FROM osp_uflpa vu	
                             WHERE UPPER(vu.vendor_Name) LIKE UPPER('%' + @vendorName+ '%') 	
                                OR UPPER(vu.alias1)      LIKE UPPER('%' + @vendorName+ '%') 	
                                OR UPPER(vu.alias2)      LIKE UPPER('%' + @vendorName+ '%') 	
                                OR UPPER(vu.alias3)      LIKE UPPER('%' + @vendorName+ '%') 	
                                OR UPPER(vu.alias4)      LIKE UPPER('%' + @vendorName+ '%') 	
                                OR UPPER(vu.alias5)      LIKE UPPER('%' + @vendorName+ '%') 	
                                OR UPPER(vu.alias6)      LIKE UPPER('%' + @vendorName+ '%') 	
                                OR UPPER(vu.alias7)      LIKE UPPER('%' + @vendorName+ '%') 	
                                OR UPPER(vu.alias8)      LIKE UPPER('%' + @vendorName+ '%') 	
                                OR UPPER(vu.alias9)      LIKE UPPER('%' + @vendorName+ '%')	
                              ");
            return (await DbCenter.ExecuteScalarAsync<int>(sql, new { vendorName }) > 0)?"Y":"N";
        }

    }
}
