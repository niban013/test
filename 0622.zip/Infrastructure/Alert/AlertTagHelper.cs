﻿using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.AspNetCore.Mvc.ViewFeatures;
using Microsoft.AspNetCore.Razor.TagHelpers;
using OneSupplierPlatform.HandleException;

namespace OneSupplierPlatform.Infrastructure
{
    [HtmlTargetElement("Alert")]
    public class ErrorSwalTagHelper : TagHelper
    {
        private readonly ITempDataDictionaryFactory _tempDataFactory;

        public ErrorSwalTagHelper(ITempDataDictionaryFactory tempDataFactory)
        {
            _tempDataFactory = tempDataFactory;
        }
        [ViewContext]
        public ViewContext ViewContext { get; set; }

        public override void Process(TagHelperContext context, TagHelperOutput output)
        {
            var httpContext = ViewContext.HttpContext;

            var tempData = _tempDataFactory.GetTempData(httpContext);

            var json = tempData["ErrorResponse"]?.ToString();
            var uiMode = tempData["ErrorUiMode"] as int?;

            if (string.IsNullOrEmpty(json) || uiMode != (int)ErrorUiMode.Modal)
            {
                output.SuppressOutput();
                return;
            }

            var script = $@"
<script>
document.addEventListener('DOMContentLoaded', function () {{

    const err = {json};

    Swal.fire({{
        icon: err.IsFatal ? 'error' : 'warning',
        title: err.Title,
        text: err.Message
    }});

}});
</script>";

            output.TagName = null;
            output.Content.SetHtmlContent(script);

            tempData.Remove("ErrorResponse");
            tempData.Remove("ErrorUiMode");
        }
    }

}