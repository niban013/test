﻿using Microsoft.AspNetCore.Razor.TagHelpers;
using System.Text.Json;
using System.Text.RegularExpressions;

namespace OneSupplierPlatform.Infrastructure.AppSetting
{
    [HtmlTargetElement("app-setting")]
    public class AppConfigTagHelper : TagHelper
    {
        private readonly IConfiguration _config;

        public AppConfigTagHelper(IConfiguration config)
        {
            _config = config;
        }

        public override async Task ProcessAsync(
            TagHelperContext context,
            TagHelperOutput output)
        {
            var child = await output.GetChildContentAsync();
            var html = child.GetContent();

            var sectionMatches = Regex.Matches(
                html,
                @"<section(?<attrs>[^>]*)\/?>",
                RegexOptions.IgnoreCase);

            var result = new Dictionary<string, object?>();

            foreach (Match match in sectionMatches)
            {
                var attrs = match.Groups["attrs"].Value;

                var name = GetAttribute(attrs, "name");

                if (string.IsNullOrWhiteSpace(name))
                    continue;

                var configSection = _config.GetSection(name);

                if (!configSection.Exists())
                    continue;

                var rule = new SectionRule
                {
                    IncludeAll = ParseBool(GetAttribute(attrs, "all"))
                };

                var only = GetAttribute(attrs, "only");

                if (!string.IsNullOrWhiteSpace(only))
                {
                    rule.IncludeKeys = only
                        .Split(',', StringSplitOptions.RemoveEmptyEntries)
                        .Select(x => x.Trim())
                        .ToHashSet(StringComparer.OrdinalIgnoreCase);
                }

                var exclude = GetAttribute(attrs, "exclude");

                if (!string.IsNullOrWhiteSpace(exclude))
                {
                    rule.ExcludeKeys = exclude
                        .Split(',', StringSplitOptions.RemoveEmptyEntries)
                        .Select(x => x.Trim())
                        .ToHashSet(StringComparer.OrdinalIgnoreCase);
                }

                result[name] = Bind(configSection, rule);
            }

            var json = JsonSerializer.Serialize(result);

            output.TagName = "script";
            output.TagMode = TagMode.StartTagAndEndTag;

            output.Content.SetHtmlContent($@"
(function () {{

    const raw = {json};

    function proxy(obj) {{
        if (!obj || typeof obj !== 'object') return obj;

        return new Proxy(obj, {{
            get(t, p) {{
                const v = t[p];

                if (v && typeof v === 'object')
                    return proxy(v);

                return v;
            }}
        }});
    }}

    window.AppConfig = proxy(raw || {{}});

}})();
");
        }

        // =====================================================
        // Bind Engine
        // =====================================================
        private object? Bind(
            IConfigurationSection section,
            SectionRule rule)
        {
            var children = section.GetChildren().ToList();

            if (!children.Any())
            {
                return ConvertValue(section.Value);
            }

            var dict = new Dictionary<string, object?>();

            foreach (var child in children)
            {
                if (rule.ExcludeKeys.Contains(child.Key))
                    continue;

                if (!rule.IncludeAll &&
                    rule.IncludeKeys.Count > 0 &&
                    !rule.IncludeKeys.Contains(child.Key))
                {
                    continue;
                }

                dict[child.Key] = Bind(child, rule);
            }

            return dict;
        }

        private static object? ConvertValue(string? value)
        {
            if (value == null)
                return null;

            if (bool.TryParse(value, out var b))
                return b;

            if (int.TryParse(value, out var i))
                return i;

            if (double.TryParse(value, out var d))
                return d;

            return value;
        }

        private static string? GetAttribute(
            string attrs,
            string name)
        {
            var match = Regex.Match(
                attrs,
                $@"{name}\s*=\s*""([^""]*)""",
                RegexOptions.IgnoreCase);

            return match.Success
                ? match.Groups[1].Value
                : null;
        }

        private static bool ParseBool(string? value)
        {
            return bool.TryParse(value, out var result)
                && result;
        }

        private sealed class SectionRule
        {
            public bool IncludeAll { get; set; }

            public HashSet<string> IncludeKeys { get; set; }
                = new(StringComparer.OrdinalIgnoreCase);

            public HashSet<string> ExcludeKeys { get; set; }
                = new(StringComparer.OrdinalIgnoreCase);
        }
    }
}