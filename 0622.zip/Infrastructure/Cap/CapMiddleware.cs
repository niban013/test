﻿using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authorization;
using Microsoft.Extensions.Caching.Memory;
using OneSupplierPlatform.Helper.Extensions;
using OneSupplierPlatform.Infrastructure.Log;
using OneSupplierPlatform.Models.Infra;
using OneSupplierPlatform.Services.Infra;
using System.Security.Claims;

namespace OneSupplierPlatform.Infrastructure.Cap
{
    public class CapMiddleware
    {
        private readonly RequestDelegate _next;
        private readonly IConfiguration _config;
        private readonly IMemoryCache _cache;

        public CapMiddleware(RequestDelegate next, IConfiguration config, IMemoryCache cache)
        {
            _next = next;
            _config = config;
            _cache = cache;
        }

        public async Task InvokeAsync(HttpContext context, CapAuthService capService)
        {
            var enabled = _config.GetValue<bool>("CapAuth:Enabled");

            if (!enabled)
            {
                await _next(context);
                return;
            }

            var cookieName = _config["CapAuth:CookieName"];
            var path = context.Request.Path.Value?.ToLower() ?? "";

            // 排除靜態資源
            if (
                path.StartsWith("/css") ||
                path.StartsWith("/js") ||
                path.StartsWith("/lib") ||
                path.StartsWith("/images") ||
                path.StartsWith("/favicon")
            )
            {
                await _next(context);
                return;
            }

            // 排除 Auth
            if (path.StartsWith("/auth"))
            {
                await _next(context);
                return;
            }

            var iframeFlag = context.Request.Query["callPhaseId"].ToString();

            if (!string.IsNullOrWhiteSpace(iframeFlag))
            {
                var currentEmpId = context.Request.Query["EMP_ID"].ToString().Split('-').LastOrDefault();
                var user = await capService.GetUserByEmpIdAsync(currentEmpId);

                if (user == null)
                {
                    context.Response.StatusCode = 401;
                    await context.Response.WriteAsync("User not found");
                    return;
                }

                // ⭐ 不 SignIn，只掛 Request scope
                context.Items["CurrentUser"] = user;
                context.Items["IsIframe"] = true;
                await _next(context);
                return;

            }
            LogHelper.Info($"Anonymous1 - 收到請求: {context.Request.Method} {context.Request.Path}");

            var endpoint = context.GetEndpoint();
            if (endpoint?.Metadata.GetMetadata<IAllowAnonymous>() is not null)
            {
                LogHelper.Info("Anonymous2 - 偵測到 AllowAnonymous 成功放行");
                await _next(context);
                return;
            }

            LogHelper.Info($"Anonymous3 - 未偵測到過濾標記，當前 Endpoint: {endpoint?.DisplayName ?? "null (可能是404或路由未匹配)"}");


            // 1. 已登入 ASP.NET 直接放行 (確保此時 Cookie 已經解析完成)
            if (context.User.Identity?.IsAuthenticated == true)
            {
                await _next(context);
                return;
            }

            // 2. ⭐ 替代方案：檢查當次 HTTP 請求的記憶體中，是否已經執行過 RedirectToCap 轉向了
            // 如果已經轉向過卻又跑進來，代表真的陷入無效循環，此時才進行阻擋
            if (context.Items.ContainsKey("CAP_LOOP_BLOCKED"))
            {
                context.Response.StatusCode = 401;
                await context.Response.WriteAsync("SSO failed (loop blocked)");
                return;
            }

            // 取得 CAP Cookie
            var capToken = context.Request.Cookies[cookieName];

            // 沒 CAP Token
            if (string.IsNullOrWhiteSpace(capToken))
            {
                RedirectToCap(context);
                return;
            }

            // 驗證 CAP Token
            var capUser = await capService.GetUserInfoAsync(capToken);

            // CAP 驗證失敗
            if (capUser == null)
            {
                // 清掉壞 token 
                context.Response.Cookies.Delete(cookieName, new CookieOptions
                {
                    Path = "/",
                    HttpOnly = true,
                    Secure = true,
                    SameSite = SameSiteMode.Lax
                });

                RedirectToCap(context);
                return;
            }

            await SignIn(context, capUser, "CAP");

            await _next(context);
        }

        // =====================================================
        // 統一登入（加入來源 CAP / IFRAME）
        // =====================================================
        private async Task SignIn(HttpContext context, CapUser user, string source)
        {
            var claims = new List<Claim>
            {
                new Claim(ClaimTypes.NameIdentifier, user.UserId ?? ""),
                new Claim(ClaimTypes.Name, user.RealName ?? ""),
                new Claim("EmployeeId", user.EmployeeId ?? ""),
                new Claim(ClaimTypes.Email, user.Email ?? ""),
                new Claim("DepartmentId", user.DepartmentId ?? ""),
                new Claim("BossLevel", user.BossLevel.ToString()),
                new Claim("CompanyName", user.CompanyName ?? ""),
                new Claim("Site", user.Site ?? ""),
                new Claim("Photo", ExtendTool.GetUserPhotoUrl(user.EmployeeId)),

                // ⭐ 關鍵：來源標記
                new Claim("AuthSource", source)
            };

            var identity = new ClaimsIdentity(claims, CookieAuthenticationDefaults.AuthenticationScheme);
            var principal = new ClaimsPrincipal(identity);
            await context.SignInAsync(CookieAuthenticationDefaults.AuthenticationScheme, principal);
            context.User = principal;
        }


        private void RedirectToCap(HttpContext context)
        {
            var LoginUrl = _config["CapAuth:LoginUrl"];

            var returnUrl =
                $"{context.Request.Scheme}://" +
                $"{context.Request.Host}" +
                $"{context.Request.PathBase}" +
                $"{context.Request.Path}" +
                $"{context.Request.QueryString}";

            var appPath =
                $"{context.Request.Scheme}://" +
                $"{context.Request.Host}" +
                $"{context.Request.PathBase}";

            context.Items["CAP_LOOP_BLOCKED"] = true;

            var url =
                $"{LoginUrl}" +
                $"?ReturnUrl={Uri.EscapeDataString(returnUrl)}" +
                $"&AppPath={Uri.EscapeDataString(appPath)}";

            context.Response.Redirect(url);
        }

        private class IframePayload
        {
            public string EmpId { get; set; }
            public long Ts { get; set; }
            public string Nonce { get; set; }
        }
    }
}
