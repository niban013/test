﻿using Microsoft.AspNetCore.Razor.TagHelpers;
using OneSupplierPlatform.Helper.Extensions;
using OneSupplierPlatform.Models;
using OneSupplierPlatform.Services.Infra;
using System.Text;

namespace OneSupplierPlatform.Infrastructure.Columns
{

    public static class ValueResolver
    {
        public static string Resolve(string value, string defaultValue)
        {
            if (!string.IsNullOrEmpty(value)) return value;
            return ExecuteSpecial(defaultValue ?? "");
        }

        private static string ExecuteSpecial(string input)
        {
            // 所有解析與代換邏輯全部集中在這裡
            return input switch
            {
                // A. 先處理帶有 @ 的動態公式代換
                var s when s.ToUpper().Contains("@TODAY") => s.ToUpper().Replace("@TODAY", DateTime.Today.ToString("yyyy-MM-dd")),
                // B. 處理不帶 @ 的一般固定關鍵字
                "SYSTEM_TODAY" => DateTime.Today.ToString("yyyy-MM-dd"),
                // C. 都不符合（或是一般純文字），就直接回傳原字串
                _ => input
            };
        }
    }

    public static class RuleCheck
    {
        public record DisplayContext(Dictionary<string, string> FieldStates);

        public static DisplayContext ParseDisplay(string displayRaw)
        {
            if (string.IsNullOrWhiteSpace(displayRaw))
                return new DisplayContext(new());

            var fieldStates = displayRaw
                .Split(',', StringSplitOptions.RemoveEmptyEntries)
                .Select(x => x.Split(':'))
                .ToDictionary(
                    x => x[0].Trim(),
                    x => x[1].Trim()
                );

            return new DisplayContext(fieldStates);
        }

        public static bool IsActive(DisplayContext rule, string colId)
        {
            return rule.FieldStates.TryGetValue(colId, out var val)
                   && val == "Y";
        }

        // =========================
        // Must Rule
        // =========================
        public static bool IsRequired(string mustRaw)
        {
            if (string.IsNullOrWhiteSpace(mustRaw))
                return false;

            return mustRaw.Trim() == "Y";
        }
    }
    public static class RuleBuilder
    {
        public static string Build(List<ValidationRule> rules)
        {
            if (rules == null || rules.Count == 0)
                return "";

            var parts = new List<string>();

            foreach (var r in rules)
            {
                if (string.IsNullOrEmpty(r.Value))
                {
                    parts.Add(r.Name);
                }
                else
                {
                    parts.Add($"{r.Name}:{r.Value}");
                }
            }

            return string.Join("|", parts);
        }
    }
    public static class FieldRenderer
    {
        public static IServiceProvider Provider;
        public static IFileService FileService => Provider.GetRequiredService<IFileService>();

        private static string ResolveDateValue(string value, string defaultValue)
        {

            string target = !string.IsNullOrEmpty(value) ? value : defaultValue ?? "";

            if (string.IsNullOrEmpty(target)) return "";

            string[] formats = { "MM/dd/yyyy HH:mm:ss", "MM/dd/yyyy", "yyyy-MM-dd", "yyyy/MM/dd" };


            if (DateTime.TryParseExact(target, formats,
                                       System.Globalization.CultureInfo.InvariantCulture,
                                       System.Globalization.DateTimeStyles.None,
                                       out DateTime parsedDate))
            {

                return parsedDate.ToString("yyyy-MM-dd");
            }
            return "";
        }
        private static string ResolveValue(string value, string defaultValue)
        {
            return ValueResolver.Resolve(value, defaultValue);
        }
        // =========================
        // Validation attributes
        // =========================

        private static string BuildValidationAttrs(DynamicField f)
        {
            var sb = new StringBuilder();

            // ⭐ 改這裡（統一出口）
            var rules = RuleBuilder.Build(f.ValidationRules);

            if (!string.IsNullOrEmpty(rules))
                sb.Append($"data-rule='{rules}' ");   // ⭐ 建議改 singular

            // pattern 保留（browser 原生支援）
            var pattern = f.ValidationRules.FirstOrDefault(x => x.Name == "pattern")?.Value;
            if (!string.IsNullOrEmpty(pattern))
                sb.Append($"data-pattern='{pattern}' ");

            return sb.ToString();
        }
        // =========================
        // Common attributes
        // =========================
        private static string BuildCommonAttrs(DynamicField f, bool isSelect = false)
        {
            var sb = new StringBuilder();

            if (!string.IsNullOrEmpty(f.Placeholder))
                sb.Append($"placeholder='{f.Placeholder}' ");
            if (!string.IsNullOrEmpty(f.Col))
                sb.Append($"data-col='{f.Col}' ");

            // =========================
            // Behavior Rule: readonly
            // =========================
            if (f.HasBehavior("readonly"))
            {
                sb.Append(isSelect ? "disabled " : "readonly ");
            }

            return sb.ToString();
        }



        private static string BuildAllAttrs(DynamicField f, bool isSelect = false)
        {
            return BuildCommonAttrs(f, isSelect) + BuildValidationAttrs(f);
        }

        private static string WrapField(string innerHtml)
        {

            return $@"
                <div class='field'>
                    <div class='field-input'> 
                        {innerHtml} 
                    </div>
                  
                </div> 
                <div class='field-meta'>
                     <small class='field-msg'></small>
                </div>";
        }

        // =========================
        // Main render
        // =========================
        public static string RenderField(DynamicField f, string stepKey, bool hasLabel = true, int Columns = 1)
        {
            if (f.HasBehavior("hidden"))
                return RenderHiddenField(f, stepKey);

            var control = RenderControl(f, stepKey);
            var hasControl = !string.IsNullOrWhiteSpace(control);

            if (!hasControl)
            {
                return $"<div class='mb-1'>{RenderOnlyLabel(f)}</div>";
            }

            // 👉 如果只有 1 欄 (Standard)，可以用 col-3 / col-9
            // 👉 如果是多欄 (Grid)，橫向排列會擠扁，通常建議標籤改用固定寬度或直接滿版
            // 這裡我們把決定權交給 f.Width 或統一改用 row 彈性分配

            var CustomCol = Columns == 1 ? 3 : 8;
            var labelCol = hasLabel ? "col-sm-3" : "";
            var inputCol = hasLabel ? $"col-sm-{CustomCol}" : "col-12"; // 移除原本的 f.Width，讓它在欄位內滿版

            var label = hasLabel
                ? $"<div class='{labelCol} col-form-label'>{RenderOnlyLabel(f)}</div>"
                : "";

            return $@"
            <div class='row align-items-center mb-1'>
                {label}
                <div class='{inputCol}'>
                    {control}
                </div>
            </div>";
        }


        //public static string RenderField(DynamicField f, string stepKey, bool hasLabel = true)
        //{
        //    if (f.HasBehavior("hidden"))
        //        return RenderHiddenField(f, stepKey);

        //    var control = RenderControl(f, stepKey);
        //    var hasControl = !string.IsNullOrWhiteSpace(control);

        //    // 👉 沒有 control → label-only（最乾淨）
        //    if (!hasControl)
        //    {
        //        return $@"
        //            <div class='mb-1'>
        //                {RenderOnlyLabel(f)}
        //            </div>";
        //    }

        //    // 👉 有 control → 用 grid
        //    var labelCol = hasLabel ? "col-3" : "";
        //    var inputCol = hasLabel ? $"col-{f.Width}" : "col-12";

        //    var label = hasLabel
        //        ? $"<div class='{labelCol}'>{RenderOnlyLabel(f)}</div>"
        //        : "";

        //    return $@"
        //            <div class='row align-items-center mb-1'>
        //                {label}
        //                <div class='{inputCol}'>
        //                    {control}
        //                </div>
        //            </div>";
        //}
        private static string RenderOnlyLabel(DynamicField f)
        {
            return $@"
                <label class='col-form-label mb-0 d-flex align-items-center'>
                    <span class='star'>{(f.HasValidation("required") ? " * " : "")}</span>
                    <span id ='hyper_{f.ColId}' class='label-text tooltip-auto' data-title='{f.ColName}'>
                        {f.ColName}
                    </span>
                </label>";
        }

        private static string RenderHiddenField(DynamicField f, string stepKey)
        {
            var val = ResolveValue(f.ColValue, f.DefaultValue);
            return $@"<div class='input-with-icon'>
            <input type='hidden' class='form-control'
                   data-field='{f.ColId}'
                   data-step='{stepKey}'
                   value='{val}' /></div>";
        }
        // =========================
        // Controls
        // =========================
        private static string RenderControl(DynamicField f, string stepKey)
        {
            return f.EnumType switch
            {
                FieldType.Hybrid => Renderchktext(f, stepKey),
                FieldType.Label => RenderLabel(f, stepKey),
                FieldType.OnlyLabel => RenderOnlyLabel(f),
                FieldType.Textbox => RenderTextbox(f, stepKey),
                FieldType.Numeric => RenderNumeric(f, stepKey),
                FieldType.Date => RenderDate(f, stepKey),
                FieldType.Textarea => RenderTextarea(f, stepKey),
                FieldType.Dropdown or FieldType.Select2 => RenderDropdown(f, stepKey),
                FieldType.Radio => RenderRadio(f, stepKey),
                FieldType.File => RenderFile(f, stepKey),
                _ => $"<span>未知 {f.EnumType}</span>"
            };
        }
        private static string RenderLabel(DynamicField f, string stepKey)
        {
            var val = ResolveValue(f.ColValue, f.DefaultValue);
            return WrapField($@" 
                        <div class='input-with-icon'>
                            <div data-field='{f.ColId}'
                                 data-step='{stepKey}'
                                 data-type='label'
                                 class='col-form-label label-display'>
                                {val}
                            </div> 
                        <span class='field-icon'><i class='bi bi-check-circle text-success'></i></span>
                    </div>");
        }
        private static string Renderchktext(DynamicField f, string stepKey)
        {
            var val = ResolveValue(f.ColValue, f.DefaultValue);
            var attrs = BuildAllAttrs(f);

            return WrapField($@"
<div class='input-with-icon checkbox-text-wrapper'
     data-field='{f.ColId}'
     data-step='{stepKey}'
     data-type='checkbox-text'>

    <div class='form-check me-2'>
        <input class='form-check-input'
               type='checkbox'
               id='{f.ColId}_chk'
               data-role='checkbox' />
    </div>

    <input type='text'
           class='form-control form-control-sm flex-fill'
           id='{f.ColId}'
           data-role='textbox'
           value='{val}' />

    <span class='field-icon'>
        <i class='bi bi-check-circle text-success'></i>
    </span>

</div>");
        }

        private static string RenderFile(DynamicField f, string stepKey)
        {
            var attrs = BuildAllAttrs(f);

            // ⭐ accept（可用 validation rule 或 behavior）
            var accept = f.ValidationRules
                ?.FirstOrDefault(x => x.Name == "accept")?.Value;

            var multiple = f.HasBehavior("multiple") ? "multiple" : "";

            if (!string.IsNullOrEmpty(accept))
                attrs += $" accept='{accept}' ";
            return WrapField($@"
 <div class='file-wrapper'>

    <div class='file-control d-flex align-items-center gap-2'>

        <div class='input-with-icon flex-grow-1'>

            <input type='file'
                   id='{f.ColId}'
                   class='file-input'
                   data-field='{f.ColId}'
                   data-step='{stepKey}'
                   data-type='file'
                   {multiple}
                   {attrs} />

            <label for='{f.ColId}'
                   class='file-picker-btn tooltip-auto'
                   data-title='上傳檔案'>
                <i class='bi bi-upload'></i>
            </label>

            <div class='file-line d-flex align-items-center gap-2 tooltip-auto'
                 data-title='{f.ColValue}' data-fileId='{f.DefaultValue}'>

                <div class='file-name flex-grow-1 text-truncate text-muted small d-none'>
                    {f.ColValue}
                </div>

                <span class='field-icon'>
                    <i class='bi bi-check-circle text-success'></i>
                </span>

            </div>

        </div>

        <!-- actions -->
        <div class='file-actions d-none'>

            <button type='button'
                    class='btn btn-sm btn-outline-primary file-preview-btn tooltip-auto'
                    data-title='預覽'>
                👁
            </button>

            <button type='button'
                    class='btn btn-sm btn-outline-danger file-remove tooltip-auto'
                    data-title='刪除'>
                🗑
            </button>

        </div>

    </div>

</div>
");
        }
        private static string RenderTextbox(DynamicField f, string stepKey)
        {
            var val = ResolveValue(f.ColValue, f.DefaultValue);
            var attrs = BuildAllAttrs(f);

            return WrapField($@"
            <div class='input-with-icon'>
                <input type='text'
                       class='form-control'
                       data-field='{f.ColId}'
                       data-step='{stepKey}'
                       data-type='textbox'  value='{val}'
                       {attrs} />
                <span class='field-icon'><i class='bi bi-check-circle text-success'></i></span>
             </div>
            ");
        }



        private static string RenderNumeric(DynamicField f, string stepKey)
        {
            var val = ResolveValue(f.ColValue, f.DefaultValue);
            var attrs = BuildAllAttrs(f);
            //已包在rule, 可以多加，browser控制
            //var min = f.ValidationRules.FirstOrDefault(x => x.Name == "min")?.Value;
            //var max = f.ValidationRules.FirstOrDefault(x => x.Name == "max")?.Value;

            //if (!string.IsNullOrEmpty(min))
            //    attrs += $" min='{min}' ";

            //if (!string.IsNullOrEmpty(max))
            //    attrs += $" max='{max}' ";

            return WrapField($@"<div class='input-with-icon'>
                <input type='number'
                       class='form-control'
                       data-field='{f.ColId}'
                       data-step='{stepKey}'
                       data-type='number'   value='{val}'
                       {attrs} />
   <span class='field-icon'><i class='bi bi-check-circle text-success'></i></span>
 </div>");
        }

        private static string RenderDate(DynamicField f, string stepKey)
        {
            var val = ResolveDateValue(f.ColValue, f.DefaultValue);
            var attrs = BuildAllAttrs(f);

            return WrapField($@"<div class='input-with-icon'>
<input type='date'
       class='form-control'
       data-field='{f.ColId}'
       data-step='{stepKey}'
       data-type='date'   value='{val}'
       {attrs} />
   <span class='field-icon'><i class='bi bi-check-circle text-success'></i></span>
 </div>");
        }

        private static string RenderTextarea(DynamicField f, string stepKey)
        {
            var val = ResolveValue(f.ColValue, f.DefaultValue);
            var attrs = BuildAllAttrs(f);

            return WrapField($@" <div class='input-with-icon'>
<textarea class='form-control'
          data-field='{f.ColId}'
          
          data-step='{stepKey}'
          data-type='textarea'
          {attrs}>{val}</textarea>     
<span class='field-icon'><i class='bi bi-check-circle text-success'></i></span>
 </div>");
        }
        private static string RenderRadio(DynamicField f, string stepKey)
        {
            string layoutClass = f.HasBehavior("horizontal") ? "radio-horizontal" : "radio-vertical";

            var val = ResolveValue(f.ColValue, f.DefaultValue);
            var attrs = BuildAllAttrs(f);

            var sb = new StringBuilder();

            sb.Append($@" <div class='input-with-icon'>
<div class='field'
     data-field='{f.ColId}'
     data-step='{stepKey}'
     data-type='radio'
     {attrs}>
     
    <div class='radio-group  {layoutClass}'>");

            foreach (var op in f.Options ?? new())
            {
                var id = $"{f.ColId}_{op.Value}";

                var isChecked =
                    string.Equals(op.Value?.Trim(),
                                  val?.ToString()?.Trim(),
                                  StringComparison.OrdinalIgnoreCase);

                sb.Append($@"
<label for='{id}'>
    <input type='radio'
           id='{id}'
           name='{f.ColId}'
       
           value='{op.Value}'
           {(isChecked ? "checked" : "")}
           {(f.HasBehavior("readonly") ? "disabled" : "")} />
    {op.Text}
</label>");
            }

            sb.Append(@"<span class='field-icon'><i class='bi bi-check-circle text-success'></i></span>
    </div>
</div>
 </div>");

            return sb.ToString();
        }
        private static string RenderDropdown(DynamicField f, string stepKey)
        {
            var classList = new List<string> { };
            if (f.EnumType == FieldType.Select2) classList.AddRange(new List<string>() { "form-control", "select2" });
            if (f.EnumType == FieldType.Dropdown) classList.AddRange(new List<string>() { "form-control", "valueInput", "dropdownColor" });

            string classes = string.Join(" ", classList);

            var attrs = BuildAllAttrs(f, true);
            var current = ResolveValue(f.ColValue, f.DefaultValue);
            var sb = new StringBuilder();

            sb.Append($@"<div class='input-with-icon'>
                <select class='{classes}'
                        data-field='{f.ColId}'
                        data-step='{stepKey}'
                        data-value ='{current}'
                        data-type='dropdown'
                        {attrs}>");

            sb.Append("<option value=''>請選擇</option>");

            foreach (var op in f.Options)
            {
                var selected = op.Value == current ? "selected" : ""; // ⭐ 在這裡

                var isNumber = decimal.TryParse(op.Color, out _);

                var colorAttr = isNumber
                    ? ""
                    : $"data-color='{op.Color}' style='background-color:{op.Color}'";

                sb.Append($@"
                    <option value='{op.Value}' {colorAttr} {selected}>
                        {op.Text}
                    </option>");
            }

            sb.Append("</select><span class='field-icon'><i class='bi bi-check-circle text-success'></i></span></div>");

            return WrapField(sb.ToString());
        }
    }

    [HtmlTargetElement("df-field")]
    public class DfFieldTagHelper : TagHelper
    {
        public BaseDynamicField Field { get; set; }
        public string StepKey { get; set; }

        public string Name { get; set; }

        public string Col { get; set; }
        public string? Value { get; set; }
        public FieldType? EnumType { get; set; }
        // ===== Validation =====
        public bool? IsMust { get; set; } = null;
        public string AsyncUrl { get; set; }

        // numeric only
        public int? Min { get; set; }
        public int? Max { get; set; }

        // textbox only
        public int? MaxLength { get; set; }
        public string? Pattern { get; set; } = "";

        // ===== UI =====
        public string? Placeholder { get; set; } = "";

        public string DefaultValue { get; set; } = "";
        // ===== Behavior =====
        public bool? Readonly { get; set; }
        public bool? IsDisplay { get; set; }
        public string Target { get; set; } = "";
        public string? OptionStr { get; set; } = "";
        public bool HasLabel { get; set; } = true;
        public int? Width { get; set; } = 3;
        public int? Order { get; set; } = 1;
        public override void Process(TagHelperContext context, TagHelperOutput output)
        {
            BaseDynamicField selected;

            // =========================
            // CASE 1: DB FIELD
            // =========================
            if (Field != null)
            {
                selected = Field;

                if (!string.IsNullOrEmpty(Col) &&
                    Field.Children?.TryGetValue(Col, out var child) == true)
                {
                    selected = child;
                }

                // ⭐ 防止 DB object 被污染（重要）
                selected = selected.Clone();
            }
            else
            {
                // =========================
                // CASE 2: STANDALONE
                // =========================
                selected = new BaseDynamicField()
                {
                    ColId = Name,
                    ColName = Name,
                    Col = Col,
                    ColValue = Value ?? "",

                    MustRaw = IsMust.HasValue
                        ? IsMust.Value ? "Y" : "N"
                        : "Y",
                    Min = Min,
                    Max = Max,
                    Pattern = Pattern,

                    Placeholder = Placeholder ?? "",
                    DefaultValue = DefaultValue ?? "",

                    Readonly = Readonly ?? false,

                    Width = Width ?? 3,
                    Order = Order ?? 0,
                    OptionStr = OptionStr ?? "",
                    // ⭐ 必補
                    DisplayRaw = IsDisplay.HasValue
                        ? IsDisplay.Value ? "Y" : "N"
                        : "Y",

                    EnumTypeRaw = EnumType?.ToString().ToLower() ?? "label"
                };
            }
            // =========================
            // MUST OVERRIDE
            // =========================
            if (IsMust.HasValue)
            {
                selected.MustRaw = IsMust.Value ? "Y" : "N";
            }
            // =========================
            // TYPE OVERRIDE
            // =========================
            if (EnumType.HasValue)
            {
                selected.EnumTypeRaw = EnumType.Value.ToString().ToLower();
            }

            // =========================
            // DISPLAY OVERRIDE
            // =========================
            if (IsDisplay.HasValue)
            {
                selected.DisplayRaw = IsDisplay.Value ? "Y" : "N";
            }

            // =========================
            // PIPELINE
            // =========================
            var f = DynamicFieldPipeline.Build(selected);

            output.TagName = null;
            output.Content.SetHtmlContent(
                FieldRenderer.RenderField(f, StepKey, HasLabel)
            );
        }
    }

    [HtmlTargetElement("df-form")]
    public class DfFormTagHelper : TagHelper
    {
        [HtmlAttributeName("columns")]
        public int Columns { get; set; } = 2;
        public List<BaseDynamicField> Fields { get; set; }
        public string StepKey { get; set; }

        public bool HasLabel { get; set; } = true;

        public override void Process(TagHelperContext context, TagHelperOutput output)
        {
            var sb = new StringBuilder();

            // 1. 依據原本的 Order 先行排序
            var allFields = Fields.OrderBy(x => x.Order).ToList();

            // 2. 將「顯示」與「隱藏」欄位拆開 (避免隱藏欄位干擾排版順序)
            var visibleFields = new List<BaseDynamicField>();
            var hiddenFields = new List<BaseDynamicField>();

            foreach (var f in allFields)
            {
                var runtimeField = DynamicFieldPipeline.Build(f);
                if (runtimeField.HasBehavior("hidden"))
                    hiddenFields.Add(f);
                else
                    visibleFields.Add(f);
            }

            // 判斷是否啟用兩欄排版
            bool isGrid = Columns == 2;

            if (isGrid)
            {
                sb.Append("<div class='row'>");
            }

            // 3. ⭐ 當設定為兩欄時，直接在 C# 記憶體中交叉洗牌資料順序
            var renderedFields = visibleFields;
            if (isGrid)
            {
                renderedFields = ReorderFieldsForGrid(visibleFields);
            }

            // 4. 依序輸出顯示欄位
            foreach (var field in renderedFields)
            {
                var runtimeField = DynamicFieldPipeline.Build(field);

                if (isGrid)
                {
                    // 手機版滿版 (col-12)，桌機版一半 (col-md-6)
                    sb.Append("<div class='col-12 col-md-6'>");
                }

                sb.Append(
                    FieldRenderer.RenderField(
                        runtimeField,
                        StepKey,
                        HasLabel,
                        Columns // ⚠️ 記得確保 RenderField 有接收 Columns 參數，若沒有可移除
                    )
                );

                if (isGrid)
                {
                    sb.Append("</div>");
                }
            }

            // 5. 輸出隱藏欄位 (統一集中在底端，不影響畫面的視覺排列)
            foreach (var field in hiddenFields)
            {
                var runtimeField = DynamicFieldPipeline.Build(field);
                sb.Append("<div class='d-none'>");
                sb.Append(FieldRenderer.RenderField(runtimeField, StepKey, HasLabel, Columns));
                sb.Append("</div>");
            }

            if (isGrid)
            {
                sb.Append("</div>");
            }

            output.TagName = null;
            output.Content.SetHtmlContent(sb.ToString());
        }

        /// <summary>
        /// 記憶體洗牌演算法：將縱向順序重新洗牌配對成 Bootstrap 橫向渲染所需的順序
        /// </summary>
        private List<BaseDynamicField> ReorderFieldsForGrid(List<BaseDynamicField> source)
        {
            if (source == null || source.Count <= 2) return source;

            var result = new List<BaseDynamicField>();
            int totalCount = source.Count;
            int halfCount = (totalCount + 1) / 2; // 計算左邊那一排該分配到幾個欄位

            for (int i = 0; i < halfCount; i++)
            {
                // 塞入左邊那一排的欄位
                result.Add(source[i]);

                // 計算並塞入對應右邊那一排的欄位
                int rightIndex = i + halfCount;
                if (rightIndex < totalCount)
                {
                    result.Add(source[rightIndex]);
                }
            }

            return result;
        }



        //public override void Process2(TagHelperContext context, TagHelperOutput output)
        //{
        //    var sb = new StringBuilder();

        //    foreach (var field in Fields.OrderBy(x => x.Order))
        //    {
        //        // ⭐ 單一 Pipeline
        //        var runtimeField = DynamicFieldPipeline.Build(field);

        //        sb.Append(
        //            FieldRenderer.RenderField(
        //                runtimeField,
        //                StepKey,
        //                HasLabel
        //            )
        //        );
        //    }

        //    output.TagName = null;

        //    output.Content.SetHtmlContent(
        //        sb.ToString()
        //    );
        //}
    }

    public static class DynamicFieldPipeline
    {
        public static DynamicField Build(BaseDynamicField db)
        {
            Normalize(db);

            var domain = ToDomain(db);

            return domain;
        }

        private static void Normalize(BaseDynamicField f)
        {
            f.ColId ??= "";
            f.ColName ??= "";
            f.ColValue ??= "";
            f.Placeholder ??= "";
            f.Pattern ??= "";

            f.Width ??= 3;
            f.Order ??= 0;
        }

        private static DynamicField ToDomain(BaseDynamicField f)
        {
            var domain = new DynamicField
            {
                ColId = f.ColId,
                ColName = f.ColName,
                Col = f.Col,
                ColValue = f.ColValue,
                EnumType = f.EnumType,
                Options = OptionParser.Parse(f.OptionStr ?? ""),
                Width = f.Width ?? 3,
                Order = f.Order ?? 0,
                Placeholder = f.Placeholder,
                DefaultValue = f.DefaultValue ?? "",
            };

            domain.ValidationRules = BuildValidation(f);
            domain.BehaviorRules = BuildBehavior(f);
            if (f.Children != null && f.Children.Count > 0)
            {
                foreach (var c in f.Children)
                {
                    domain.Children ??= new Dictionary<string, DynamicField>();

                    domain.Children[c.Key] = ToDomain(c.Value);
                }
            }
            return domain;
        }

        private static List<ValidationRule> BuildValidation(BaseDynamicField f)
        {
            var rules = new List<ValidationRule>();

            if (f.IsMust)
                rules.Add(new ValidationRule("required"));

            if (f.EnumType == FieldType.Numeric)
            {
                if (f.Min.HasValue)
                    rules.Add(new ValidationRule("min", f.Min.ToString()));

                if (f.Max.HasValue && Convert.ToInt32(f.Max) > 0)
                    rules.Add(new ValidationRule("max", f.Max.ToString()));
            }
            if (f.EnumType == FieldType.Textbox)
            {
                //if (e.MaxLength.HasValue)
                //    Add("maxlength", e.MaxLength.Value.ToString());

                if (!string.IsNullOrEmpty(f.AsyncUrl))
                    rules.Add(new ValidationRule("async", f.AsyncUrl.ToString()));
                if (f.Max.HasValue && Convert.ToInt32(f.Max) > 0)
                    rules.Add(new ValidationRule("max", f.Max.ToString()));
                // ✔ ⭐ 新增 map 
                if (!string.IsNullOrEmpty(f.Target))
                    rules.Add(new ValidationRule("map", f.Target.ToString()));
                if (!string.IsNullOrEmpty(f.Pattern))
                    rules.Add(new ValidationRule("pattern", f.Pattern.ToString()));
            }

            if (f.EnumType == FieldType.Textarea)
            {
                if (f.Max.HasValue && Convert.ToInt32(f.Max) > 0)
                    rules.Add(new ValidationRule("max", f.Max.ToString()));
            }

            if (f.EnumType == FieldType.File)
            {
                if (!string.IsNullOrEmpty(f.AsyncUrl))
                    rules.Add(new ValidationRule("async", f.AsyncUrl.ToString()));

                if (!string.IsNullOrEmpty(f.Target))
                    rules.Add(new ValidationRule("map", f.Target.ToString()));

                if (!string.IsNullOrEmpty(f.Pattern))
                    rules.Add(new ValidationRule("accept", f.Pattern.ToString()));
                // ⭐ maxsize（你可以用 Max 當 MB）
                if (f.Max.HasValue && Convert.ToInt32(f.Max) > 0)
                    rules.Add(new ValidationRule("maxsize", f.Max.ToString()));
            }
            if (f.EnumType == FieldType.Date)
            {
                if (f.Max.HasValue && Convert.ToInt32(f.Max) > 0)
                    rules.Add(new ValidationRule("max", f.Max.ToString()));
            }
            return rules;
        }

        private static List<BehaviorRule> BuildBehavior(BaseDynamicField f)
        {
            var rules = new List<BehaviorRule>();

            if (f.Readonly)
                rules.Add(new BehaviorRule("readonly"));

            if (!f.IsDisplay)
                rules.Add(new BehaviorRule("hidden"));

            if (f.Position.Length > 0)
                rules.Add(new BehaviorRule(f.Position));
            if (f.Position.Length == 0)
                rules.Add(new BehaviorRule("horizontal"));
            //if (f.IsMust)
            //    rules.Add(new BehaviorRule("required"));

            return rules;
        }
    }
}