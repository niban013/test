﻿using Dapper;
using newauo.Helper;
using Newtonsoft.Json;
using OneSupplierPlatform.Infrastructure.DataBase;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Data;
using System.Linq.Expressions;
using System.Reflection;

namespace OneSupplierPlatform.Infrastructure.DataBase
{
    public static class TransactionRepositoryExtensions
    {
        public static async Task<SqlMapper.GridReader> QueryMultipleAsync(this ITransactionContext ctx, string sql, object? param = null)
        { 
            // 呼叫 Dapper 原生的 SqlMapper.QueryMultipleAsync
            return await ctx.Connection.QueryMultipleAsync(sql, param);
        }
        // =====================================================
        // SAVE
        // =====================================================
        public static async Task SaveAsync<T>(this ITransactionContext ctx, T entity)
        {
            await ctx.UpsertAsync(entity);
        }

        public static async Task UpsertAsync<T>(this ITransactionContext ctx, T entity)
        {
            var type = typeof(T);
            var table = GetTableName(type);
            var keyProps = GetKeyProperties(type);

            var keyDict = keyProps.ToDictionary(
                k => k.Name,
                k => k.GetValue(entity)
            );

            var exists = await ctx.ExistsAsync<T>(table, keyProps, keyDict);

            if (exists)
                await ctx.UpdateAsync(entity);
            else
                await ctx.InsertAsync(entity);
        }

        // =====================================================
        // EXISTS
        // =====================================================
        public static async Task<bool> ExistsAsync<T>(
            this ITransactionContext ctx,
            string table,
            List<PropertyInfo> keyProps,
            Dictionary<string, object> keys)
        {
            var where = new List<string>();
            var param = new DynamicParameters();

            foreach (var kp in keyProps)
            {
                var col = GetColumnName(kp);
                where.Add($"{col}=@{col}");
                param.Add("@" + col, keys[kp.Name]);
            }

            var sql = $@"
                        SELECT 1 FROM {table}
                        WHERE {string.Join(" AND ", where)}";

            var result = await ctx.Connection.QueryFirstOrDefaultAsync<int?>(sql, param, ctx.Transaction);

            return result.HasValue;
        }
        public static DataTable QueryDataTable(this ITransactionContext ctx, string sql, object param = null)
        {
            var dataTable = new DataTable();
            using (var reader = ctx.Connection.ExecuteReader(sql, param, ctx.Transaction))
            {
                dataTable.Load(reader);
            }
            return dataTable;
        }
        // =====================================================
        // INSERT
        // =====================================================
        public static async Task InsertAsync<T>(this ITransactionContext ctx, T entity)
        {
            var type = typeof(T);
            var table = GetTableName(type);
            var props = GetProps(type);

            var cols = new List<string>();
            var vals = new List<string>();
            var param = new DynamicParameters();

            foreach (var p in props)
            {
                if (IsIdentity(p)) continue;

                var val = p.GetValue(entity);
                if (val == null) continue;

                var col = GetColumnName(p);

                cols.Add(col);
                vals.Add("@" + col);
                param.Add("@" + col, val);
            }

            var sql = $@"
INSERT INTO {table}
({string.Join(",", cols)})
VALUES
({string.Join(",", vals)})
";

            await ctx.Connection.ExecuteAsync(sql, param, ctx.Transaction);
        }

        // =====================================================
        // UPDATE
        // =====================================================
        public static async Task UpdateAsync<T>(this ITransactionContext ctx, T entity)
        {
            var type = typeof(T);
            var table = GetTableName(type);

            var keyProps = GetKeyProperties(type);
            var props = GetProps(type);

            var allNonKeyPropNames = props
                 .Where(p => !keyProps.Contains(p) && p.GetCustomAttribute<SkipAttribute>() == null)
                 .Select(p => p.Name);

            var selectedPropNames = new HashSet<string>(allNonKeyPropNames, StringComparer.OrdinalIgnoreCase);

            // 直接呼叫內部的核心處理邏輯
            await ctx.UpdateFieldsInternalAsync(entity, selectedPropNames);
        }

        public static async Task UpdateAsync<T>(this ITransactionContext ctx, T entity, Expression<Func<T, object>> fieldsExpression)
        {
            if (fieldsExpression == null)
            {
                throw new ArgumentNullException(nameof(fieldsExpression), "必須指定要更新的欄位運算式。");
            }

            var selectedPropNames = new HashSet<string>(StringComparer.OrdinalIgnoreCase);

            // 解析 Lambda 運算式並收集欄位名稱
            if (fieldsExpression.Body is NewExpression newExp)
            {
                foreach (var member in newExp.Members)
                {
                    selectedPropNames.Add(member.Name);
                }
            }
            else if (fieldsExpression.Body is UnaryExpression unaryExp && unaryExp.Operand is MemberExpression memberExp)
            {
                selectedPropNames.Add(memberExp.Member.Name);
            }
            else if (fieldsExpression.Body is MemberExpression memberExp2)
            {
                selectedPropNames.Add(memberExp2.Member.Name);
            }

            // 直接呼叫內部的核心處理邏輯
            await ctx.UpdateFieldsInternalAsync(entity, selectedPropNames);
        }
        private static async Task UpdateFieldsInternalAsync<T>(this ITransactionContext ctx, T entity, HashSet<string> selectedPropNames)
        {
            var type = typeof(T);
            var table = GetTableName(type);
            var keyProps = GetKeyProperties(type);
            var props = GetProps(type);

            var sets = new List<string>();
            var where = new List<string>();
            var param = new DynamicParameters();

            foreach (var p in props)
            {
                var skipAttr = p.GetCustomAttribute<SkipAttribute>();
                if (skipAttr != null) continue;

                var col = GetColumnName(p);
                var val = p.GetValue(entity);

                if (keyProps.Contains(p))
                {
                    // 主鍵必定進入 WHERE 條件
                    where.Add($"{col}=@{col}");
                    param.Add("@" + col, val);
                }
                else if (selectedPropNames.Contains(p.Name))
                {
                    // 指定欄位進入 SET 條件
                    sets.Add($"{col}=@{col}");
                    param.Add("@" + col, val);
                }
            }

            // 防呆：如果完全沒有需要 SET 的欄位，不執行 SQL 直接返回
            if (sets.Count == 0) return;

            var sql = $@"
UPDATE {table}
SET {string.Join(",", sets)}
WHERE {string.Join(" AND ", where)}
";

            await ctx.Connection.ExecuteAsync(sql, param, ctx.Transaction);
        }


        // =====================================================
        // DELETE
        // =====================================================
        public static async Task DeleteAsync<T>(this ITransactionContext ctx, object keys)
        {
            var type = typeof(T);
            var table = GetTableName(type);
            var keyProps = GetKeyProperties(type);

            var where = new List<string>();
            var param = new DynamicParameters();

            foreach (var kp in keyProps)
            {
                var col = GetColumnName(kp);
                var val = GetKeyValue(keys, kp.Name);

                if (!IsValidValue(val))
                    continue;

                where.Add($"{col}=@{col}");
                param.Add("@" + col, val);
            }
            if (where.Count == 0)
                throw new Exception("No valid keys provided for DeleteAsync");

            var sql = $@"DELETE FROM {table} WHERE {string.Join(" AND ", where)}";

            await ctx.Connection.ExecuteAsync(sql, param, ctx.Transaction);
        }

        // =====================================================
        // GET
        // =====================================================
        public static async Task<T> GetAsync<T>(this ITransactionContext ctx, object keys)
            where T : new()
        {
            var type = typeof(T);
            var table = GetTableName(type);
            var keyProps = GetKeyProperties(type);

            var where = new List<string>();
            var param = new DynamicParameters();

            foreach (var kp in keyProps)
            {
                var col = GetColumnName(kp);
                var val = GetKeyValue(keys, kp.Name);

                if (!IsValidValue(val))
                    continue;

                where.Add($"{col}=@{col}");
                param.Add("@" + col, val);
            }
            if (where.Count == 0)
                throw new Exception("No valid keys provided for DeleteAsync");

            var sql = $@"SELECT * FROM {table} WHERE {string.Join(" AND ", where)}";

            return await ctx.Connection.QueryFirstOrDefaultAsync<T>(sql, param, ctx.Transaction);
        }

        // =====================================================
        // QUERY
        // =====================================================
        public static async Task<List<T>> QueryAsync<T>(this ITransactionContext ctx, string sql, object param = null)
        {
            var result = await ctx.Connection.QueryAsync<T>(sql, param, ctx.Transaction);

            return result.ToList();
        }

        public static Task<T> QuerySingleAsync<T>(this ITransactionContext ctx, string sql, object param = null)
        {
            return ctx.Connection.QueryFirstOrDefaultAsync<T>(sql, param, ctx.Transaction);
        }
        public static T QuerySingle<T>(this ITransactionContext ctx, string sql, object param = null)
             => ctx.Connection.QueryFirstOrDefault<T>(sql, param, ctx.Transaction);

        public static Task<int> ExecuteReturnAsync(this ITransactionContext ctx, string sql, object param = null)
            => ctx.Connection.ExecuteAsync(sql, param, ctx.Transaction);
        public static int ExecuteReturn(this ITransactionContext ctx, string sql, object param = null)
            => ctx.Connection.Execute(sql, param, ctx.Transaction);

        public static async Task<bool> ExecuteAsync(this ITransactionContext ctx, string sql, object param = null)
            => await ctx.ExecuteReturnAsync(sql, param) > 0;
        public static bool Execute(this ITransactionContext ctx, string sql, object param = null)
           => ctx.ExecuteReturn(sql, param) > 0;

        //public static Task<int> ExecuteAsync(
        //    this ITransactionContext ctx,
        //    string sql,
        //    object param = null)
        //{
        //    return ctx.Connection.ExecuteAsync(sql, param, ctx.Transaction);
        //}

        public static Task<T> ExecuteScalarAsync<T>(this ITransactionContext ctx, string sql, object param = null)
        {
            return ctx.Connection.ExecuteScalarAsync<T>(sql, param, ctx.Transaction);
        }


        public static async Task SaveManyAsync<T>(this ITransactionContext ctx, IEnumerable<T> entities) where T : new()
        {
            if (ctx.Transaction == null)
            {
                throw new InvalidOperationException("必須先呼叫 BeginTransaction() 才能執行此操作。");
            }

            var conn = ctx.Connection;
            if (conn == null)
            {
                throw new InvalidOperationException("目前的交易已失去連線，可能已被關閉。");
            }
            var list = entities?.ToList();
            if (list == null || list.Count == 0)
                return;

            var type = typeof(T);
            var table = GetTableName(type);
            var keyProps = GetKeyProperties(type);
            var props = GetProps(type);

            var items = list.Select(e =>
            {
                var rowDict = keyProps.ToDictionary(
                    kp => GetColumnName(kp),
                    kp => kp.GetValue(e)
                );
                return (Entity: e, Key: rowDict);
            }).ToList();

            var existingKeys = await ctx.GetExistingKeySetAsync(table, keyProps, items);

            var inserts = new List<T>();
            var updates = new List<T>();

            foreach (var item in items)
            {
                var key = BuildKeyString(item.Key, keyProps);
                if (existingKeys.Contains(key))
                    updates.Add(item.Entity);
                else
                    inserts.Add(item.Entity);
            }

            if (inserts.Count > 0)
                await ctx.BulkInsertFastAsync(table, inserts, props);

            if (updates.Count > 0)
                await ctx.BulkUpdateFastAsync(table, updates, props, keyProps);

        }
        private static async Task BulkInsertFastAsync<T>(this ITransactionContext ctx,
                            string table,
                            List<T> list,
                            List<PropertyInfo> props)
        {

            var cols = props.Where(p => !IsIdentity(p))
                             .Select(GetColumnName)
                             .ToList();

            var sql = $@"
                        INSERT INTO {table}
                        ({string.Join(",", cols)})
                        VALUES
                        ({string.Join(",", cols.Select(c => "@" + c))})";

            foreach (var item in list)
            {
                var param = new DynamicParameters();

                foreach (var p in props)
                {
                    if (IsIdentity(p)) continue;

                    param.Add("@" + GetColumnName(p), p.GetValue(item));
                }

                await ctx.Connection.ExecuteAsync(sql, param, ctx.Transaction);
            }


        }
        private static async Task BulkUpdateFastAsync<T>(this ITransactionContext ctx,
                                                        string table,
                                                        List<T> list,
                                                        List<PropertyInfo> props,
                                                        List<PropertyInfo> keyProps)
        {
            var setParts = new List<string>();
            var whereParts = new List<string>();

            foreach (var p in props)
            {
                if (IsIdentity(p)) continue;
                if (p.GetCustomAttribute<SkipAttribute>() != null) continue;

                var col = GetColumnName(p);

                if (keyProps.Contains(p))
                    whereParts.Add($"{col} = @{col}");
                else
                    setParts.Add($"{col} = @{col}");
            }

            var sql = $@"
                        UPDATE {table}
                        SET {string.Join(",", setParts)}
                        WHERE {string.Join(" AND ", whereParts)}";

            foreach (var entity in list)
            {
                var param = new DynamicParameters();

                foreach (var p in props)
                {
                    if (IsIdentity(p)) continue;
                    if (p.GetCustomAttribute<SkipAttribute>() != null) continue;

                    var col = GetColumnName(p);
                    var val = p.GetValue(entity);

                    param.Add("@" + col, val);
                }

                await ctx.Connection.ExecuteAsync(sql, param, ctx.Transaction);
            }
        }

        private static async Task<HashSet<string>> GetExistingKeySetAsync<T>(
                                           this ITransactionContext ctx,
                                            string table,
                                            List<PropertyInfo> keyProps,
                                            List<(T Entity, Dictionary<string, object> Key)> items)
        {
            var result = new HashSet<string>();
            if (items.Count == 0) return result;

            // build IN-style batch query per key
            var param = new DynamicParameters();

            var conditions = new List<string>();

            for (int i = 0; i < items.Count; i++)
            {
                var group = new List<string>();

                foreach (var kp in keyProps)
                {
                    var col = GetColumnName(kp);
                    var pname = $"p{i}_{col}";
                    group.Add($"{col} = @{pname}");
                    param.Add(pname, items[i].Key[col]);
                }

                conditions.Add("(" + string.Join(" AND ", group) + ")");
            }

            var sql = $@"
                        SELECT {string.Join(",", keyProps.Select(GetColumnName))}
                        FROM {table}
                        WHERE {string.Join(" OR ", conditions)}";

            var rows = await ctx.Connection.QueryAsync(sql, param, ctx.Transaction);

            foreach (IDictionary<string, object> row in rows)
            {
                result.Add(BuildFastKey(row, keyProps));
            }

            return result;
        }
        private static string BuildFastKey(IDictionary<string, object> row, List<PropertyInfo> keyProps)
        {
            var dict = new Dictionary<string, object>(row, StringComparer.OrdinalIgnoreCase);
            return BuildKeyString(dict, keyProps);
        }

        private static string BuildKeyString(Dictionary<string, object> dict, List<PropertyInfo> keyProps)
        {
            var sortedPairs = keyProps
                .Select(kp =>
                {
                    var dbCol = GetColumnName(kp).ToLower();
                    var matchedKey = dict.Keys.FirstOrDefault(k => k.Equals(dbCol, StringComparison.OrdinalIgnoreCase)
                                                                || k.Equals(kp.Name, StringComparison.OrdinalIgnoreCase));

                    var rawVal = matchedKey != null ? dict[matchedKey] : null;

                    var valStr = rawVal == null || rawVal == DBNull.Value ? "" : rawVal.ToString();

                    return $"{dbCol}:{valStr}";
                })
                .OrderBy(pair => pair);

            return string.Join("|", sortedPairs);
        }

        // =====================================================
        // HELPERS（完整保留）
        // =====================================================
        private static string GetTableName(Type type)
        {
            var attr = type.GetCustomAttribute<TableAttribute>();
            return attr?.Name ?? type.Name;
        }

        private static List<PropertyInfo> GetKeyProperties(Type type)
        {
            var keys = type.GetProperties()
                .Where(p => p.GetCustomAttribute<KeyAttribute>() != null)
                .ToList();

            if (!keys.Any())
                throw new Exception($"No [Key] defined on {type.Name}");

            return keys;
        }

        private static List<PropertyInfo> GetProps(Type type)
            => type.GetProperties()
                .Where(p => p.CanRead && p.CanWrite)
                .ToList();

        private static string GetColumnName(PropertyInfo prop)
        {
            var json = prop.GetCustomAttribute<JsonPropertyAttribute>();
            return json?.PropertyName ?? prop.Name;
        }

        private static object GetKeyValue(object obj, string name)
            => obj.GetType().GetProperty(name)?.GetValue(obj);

        private static bool IsIdentity(PropertyInfo p)
        {
            var attr = p.GetCustomAttribute<DatabaseGeneratedAttribute>();
            return attr != null &&
                   attr.DatabaseGeneratedOption == DatabaseGeneratedOption.Identity;
        }

        private static bool IsValidValue(object value)
        {
            if (value == null) return false;
            if (value is string s && string.IsNullOrWhiteSpace(s))
                return false;

            return true;
        }
    }
}
