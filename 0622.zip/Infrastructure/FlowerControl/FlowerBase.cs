﻿using OneSupplierPlatform.Models.Infra;

namespace OneSupplierPlatform.Infrastructure.FlowerControl
{
    public abstract class FlowerBase<TService>
    {
        protected readonly TService Service;

        protected FlowerBase(TService service)
        {
            Service = service;
        }

        // ⭐ 統一入口：用 action name 呼叫 service method
        protected async Task<ExecuteResult<object>> ExecuteAsync(
            string action,
            object dto)
        {
            try
            {
                var method = typeof(TService)
                    .GetMethod(action);

                if (method == null)
                    return ExecuteResult<object>.Fail($"Method not found: {action}");

                var resultTask = method.Invoke(Service, new[] { dto });

                if (resultTask is not Task task)
                    return ExecuteResult<object>.Fail("Service must return Task");

                await task.ConfigureAwait(false);

                var resultProperty = task.GetType().GetProperty("Result");

                var result = resultProperty?.GetValue(task);

                return ExecuteResult<object>.Ok(result);
            }
            catch (Exception ex)
            {
                return ExecuteResult<object>.Fail(ex.Message);
            }
        }
    }
}
