﻿
namespace OneSupplierPlatform.Infrastructure.Log
{
    public static class LogContext
    {
        private static readonly AsyncLocal<Dictionary<string, object?>> _state = new();

        public static void Set(string key, object? value)
        {
            _state.Value ??= new Dictionary<string, object?>();
            _state.Value[key] = value;
        }

        public static object? Get(string key)
        {
            return _state.Value != null && _state.Value.ContainsKey(key)
                ? _state.Value[key]
                : null;
        }

        public static IReadOnlyDictionary<string, object?>? Data => _state.Value;
    }
}
