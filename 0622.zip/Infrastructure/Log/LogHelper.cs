﻿
namespace OneSupplierPlatform.Infrastructure.Log
{
    public static class LogHelper
    {
        private static ILogger _logger;

        public static void Init(ILoggerFactory loggerFactory)
        {
            _logger = loggerFactory.CreateLogger("Global");
        }

        public static void Info(string message, object? data = null,
          [System.Runtime.CompilerServices.CallerMemberName] string member = "",
          [System.Runtime.CompilerServices.CallerFilePath] string file = "")
        {
            _logger.LogInformation("{Message} {@Data} {@Context}",
                message, data, LogContext.Data);
        }

        public static void Warn(string message, object? data = null)
        {
            _logger.LogWarning("{Message} {@Data} {@Context}",
                message, data, LogContext.Data);
        }

        public static void Error(string message, Exception ex = null, object? data = null)
        {

            if (ex != null)
            {
                _logger.LogError(ex, "{Message} {@Data} {@Context}", message, data, LogContext.Data);
            }
            else
            {
                _logger.LogError("{Message} {@Data} {@Context}", message, data, LogContext.Data);
            }

        }
    }
}
