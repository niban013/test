﻿
namespace OneSupplierPlatform.Infrastructure.Log
{
    public class LogMiddleware
    {
        private readonly RequestDelegate _next;

        public LogMiddleware(RequestDelegate next)
        {
            _next = next;
        }

        public async Task Invoke(HttpContext context)
        {
            var endpoint = context.GetEndpoint();

            var controller = context.Request.RouteValues["controller"]?.ToString();
            var action = context.Request.RouteValues["action"]?.ToString();

            NLog.MappedDiagnosticsLogicalContext.Set("Controller", controller);
            NLog.MappedDiagnosticsLogicalContext.Set("Action", action);
            LogContext.Set("TraceId", Guid.NewGuid().ToString());
            LogContext.Set("UserId", context.User?.Identity?.Name ?? "anonymous");
            LogContext.Set("Path", context.Request.Path);

            await _next(context);
        }
    }
}
