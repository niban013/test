﻿using System.Collections.Concurrent;
using System.Reflection;

namespace OneSupplierPlatform.Infrastructure.Transfer
{
    public class QueryStringDto
    {
        public string CallerId { get; set; }
        public string CallPhaseId { get; set; }
        public string ViewPhaseId { get; set; }
        public string FormKind { get; set; }

        public string FormNo { get; set; }

        public string FormApproveId { get; set; }
        public string EmpId { get; set; } 
    }
    public class TransQueryStringBinder
    {  
        private static readonly ConcurrentDictionary<Type, PropertyInfo[]> _propCache = new();

        public static T Bind<T>(IQueryCollection query) where T : new()
        {
            var obj = new T();
            var type = typeof(T);

            var props = _propCache.GetOrAdd(type,
                t => t.GetProperties(BindingFlags.Public | BindingFlags.Instance));

            foreach (var q in query)
            {
                var key = ToPascalCase(q.Key);

                var prop = props.FirstOrDefault(p =>
                    p.Name.Equals(key, StringComparison.OrdinalIgnoreCase));

                if (prop == null || !prop.CanWrite) continue;

                var value = ConvertValue(q.Value.ToString(), prop.PropertyType);
                prop.SetValue(obj, value);
            }

            return obj;
        }

        private static string ToPascalCase(string input)
        {
            if (string.IsNullOrWhiteSpace(input))
                return input;

            return string.Concat(
                input.Split(new[] { '_', '-', ' ' }, StringSplitOptions.RemoveEmptyEntries)
                     .Select(x => char.ToUpperInvariant(x[0]) + x[1..].ToLowerInvariant()));
        }

        private static object? ConvertValue(string value, Type type)
        {
            if (string.IsNullOrWhiteSpace(value))
                return null;

            var targetType = Nullable.GetUnderlyingType(type) ?? type;

            try
            {
                if (targetType == typeof(string)) return value;
                if (targetType == typeof(int)) return int.Parse(value);
                if (targetType == typeof(long)) return long.Parse(value);
                if (targetType == typeof(decimal)) return decimal.Parse(value);
                if (targetType == typeof(bool)) return value == "1" || value.ToLower() == "true";
                if (targetType == typeof(DateTime)) return DateTime.Parse(value);
                if (targetType.IsEnum) return Enum.Parse(targetType, value, true);

                return value;
            }
            catch
            {
                return null;
            }
        }
    }
}
