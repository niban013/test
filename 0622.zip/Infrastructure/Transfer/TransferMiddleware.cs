﻿using OneSupplierPlatform.Infrastructure.Log;

namespace OneSupplierPlatform.Infrastructure.Transfer
{
    public static class TransferMiddlewareExtensions
    {
        public static IApplicationBuilder UseTransferMiddleware(this IApplicationBuilder builder)
        {
            return builder.UseMiddleware<TransferMiddleware>();
        }
    }
    public class TransferMiddleware
    {
        private readonly RequestDelegate _next;
        public TransferMiddleware(RequestDelegate next)
        {
            _next = next;
        }

        public async Task InvokeAsync(HttpContext context)
        {
            // 檢查請求路徑是否為 Transfer.aspx（不區分大小寫）
            if (context.Request.Path.Equals("/Transfer.aspx", StringComparison.OrdinalIgnoreCase))
            {
                string queryString = context.Request.QueryString.Value;
                string pathBase = context.Request.PathBase.Value ?? string.Empty;
                string targetUrl = $"{pathBase}/SupplierApprove/Approve{queryString}";

                LogHelper.Info($"Transfer - 收到請求: {targetUrl}");
                context.Response.Redirect(targetUrl);
                return;
            }

            // 若不是目標路徑，繼續執行下一個 Middleware
            await _next(context);
        }
    }

}
