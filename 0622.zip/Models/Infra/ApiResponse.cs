﻿using Microsoft.AspNetCore.Mvc;
using OneSupplierPlatform.HandleException;

namespace OneSupplierPlatform.Models.Infra
{
    public class UploadFileResponse
    {
        public string FileId { get; set; }

        public string FileName { get; set; }

        public long Size { get; set; }

        public string Mime { get; set; }
    }


    public class ApproveDataModel
    {
        public bool Success { get; set; } = false;

        public string Message { get; set; }
    }

    public static class ResultExtensions
    {
        public static T EnsureSuccess<T>(this ExecuteResult<T> result)
        {
            if (result.Success)
                return result.Data;

            throw new BusinessException(result.Message, ErrorUiMode.Inline);
        }
    }

    public class ExecuteResult<T>
    {
        public bool Success { get; set; }

        public string Message { get; set; }

        public T Data { get; set; }

        public static ExecuteResult<T> Ok(T data, string message = "success")
        {
            return new ExecuteResult<T>
            {
                Success = true,
                Message = message,
                Data = data
            };
        }

        public static ExecuteResult<T> Fail(string message)
        {
            return new ExecuteResult<T>
            {
                Success = false,
                Message = message,
                Data = default
            };
        }

        public static implicit operator ExecuteResult<T>(string errorMessage)
        {
            return Fail(errorMessage);
        }

        public static implicit operator ExecuteResult<T>(T data)
        {
            return Ok(data);
        }
    }

    public static class ControllerExtensions
    {
        /// <summary>
        /// 核心語法糖：將 ExecuteResult 轉為 HTTP 200 Ok
        /// </summary>
        public static OkObjectResult ToResponse<T>(this ControllerBase controller, ExecuteResult<T> result)
        {
            return controller.Ok(result);
        }

        /// <summary>
        /// 系統大錯語法糖：同樣回傳 HTTP 200 Ok，但自動包裝成 ExecuteResult<T>.Fail，並帶入真正的錯誤訊息
        /// </summary>
        public static OkObjectResult SystemError<T>(this ControllerBase controller, Exception ex)
        {
            // 核心邏輯：自動包裝成失敗格式，並傳遞真實的錯誤訊息
            return controller.Ok(ExecuteResult<T>.Fail($"【系統嚴重錯誤】{ex.Message}"));
        }
    }

}
