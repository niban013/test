﻿namespace OneSupplierPlatform.Models.Infra
{
    public class FlowerRequest
    {
        public string Module { get; set; }

        public string Action { get; set; }

        public string Payload { get; set; }
    }
}
