﻿using System.Text.Json.Serialization;

namespace OneSupplierPlatform.Models.Infra
{
    public class AsyncValidationRequest
    {
        public object? Value { get; set; }

        public string? StepKey { get; set; }

        // trigger field
        public string? Field { get; set; }

        // map fields
        public Dictionary<string, string>? Fields { get; set; }

        // whole form data
        public Dictionary<string, object>? Data { get; set; }
    }

    public record ApiOuterWrapper([property: JsonPropertyName("d")] string D);
    public record BankDataDto(
        [property: JsonPropertyName("bank_name")] string bank_name,
        [property: JsonPropertyName("bank_number")] string bank_number,
        [property: JsonPropertyName("bank_branch_name")] string bank_branch_name,
        [property: JsonPropertyName("Bank_Country")] string Bank_Country,
        [property: JsonPropertyName("branch_number")] string branch_number,
        [property: JsonPropertyName("EFT_Swift_Code")] string EFT_Swift_Code,
        [property: JsonPropertyName("Bank_Key")] string Bank_Key
    );
}
