﻿namespace OneSupplierPlatform.Models.Infra
{
    public class WizardOptions
    {
        public List<WizardStepOption> Steps { get; set; } = new();
        public bool AllowJumpToCompletedStep { get; set; } = true;
        public bool AutoSave { get; set; } = true;
    }

    public class WizardStepOption
    {
        public string Title { get; set; }
        public string PartialView { get; set; }
        public bool Completed { get; set; } = false;
        public bool Locked { get; set; } = true;
        public int StepIndex { get; set; }
        public Dictionary<string, object> Custom { get; set; } = new();
    }


    public class FormInfo
    {
        public string headerid { get; set; } = "";
        public string formno { get; set; } = "";

        public string applytype { get; set; } = "";

        public bool mode { get; set; } = false;
    }
    public class StepContext
    {
        public int Current { get; set; }

        public List<int>? ValidateSteps { get; set; }
    }
    public class SupplierSaveViewModel
    {
        public FormInfo FormInfo { get; set; }
        public Step1Data Step1 { get; set; }
        public Step2Data Step2 { get; set; }
        public Dictionary<string, string> Step3 { get; set; } // Step3 欄位極多且多為字串，建議用字典
        public string mode { get; set; }
        public StepContext StepContext { get; set; }
        public bool hasError { get; set; }
    }

    public class Step1Data
    {
        public string suppliername { get; set; }
        public string applytype { get; set; }
        public DecisionData decision { get; set; }
    }

    public class Step2Data : Dictionary<string, object>
    {
        // Step2 欄位太多（company_code, vendor_class...），
        // 繼承 Dictionary 可以讓你直接用 payload.Step2["company_code"] 取值，
        // 同時也能定義常用的強型別屬性。
        public DecisionData decision
        {
            get => ContainsKey("Step2") ? (DecisionData)this["Step2"] : null;
            set => this["Step2"] = value;
        }
    }

    public class DecisionData
    {
        public object Types { get; set; }
        public object Datas { get; set; }
    }
    public class StepPayload
    {
        public Dictionary<string, object>? Types { get; set; }

        public Dictionary<string, object>? Datas { get; set; }
    }
    public class StepRequest
    {
        public int StepIndex { get; set; }

        public FormInfo FormInfo { get; set; }
        public Dictionary<string, StepPayload>? FlowData { get; set; }
    }
}
