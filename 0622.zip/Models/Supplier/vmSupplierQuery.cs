﻿using System.ComponentModel.DataAnnotations;
using System.Security.Cryptography.X509Certificates;
namespace OneSupplierPlatform.Models.Supplier
{
    public class FlmFileInfo
    {
        public string ItemId { get; set; }
        public string ItemName { get; set; }
        public string Headerid { get; set; }
        public string FormNo { get; set; }
        public string? FileId { get; set; }
        public string FileName { get; set; }
        public string? Active { get; set; } = "Y";
        public string? CUser { get; set; }
        public string? CDate { get; set; }

        public IFormFile File { get; set; }

        public string? Mime { get; set; }

        public byte[]? bytes { get; set; }

        public string? Status { get; set; } = "Success";
    }
    public class vmSupplierQuery
    {
        // === 查詢條件 (原本欄位保持不變) ===
        public string? VendorName { get; set; }
        public string? VendorCode { get; set; }
        public string? FormNo { get; set; }
        public string? FormStatus { get; set; }
        public DateTime? CreateDateFrom { get; set; }
        public DateTime? CreateDateTo { get; set; }

        // === 💡 新增：分頁控制參數 ===
        public int PageNumber { get; set; } = 1;      // 當前頁碼 (預設第 1 頁)
        public int PageSize { get; set; } = 10;        // 每頁筆數 (預設 10 筆)
        public int TotalItems { get; set; }            // 總資料筆數
        public int TotalPages => (int)Math.Ceiling((double)TotalItems / PageSize); // 計算總頁數

        // === 查詢結果清單 ===
        public List<SupplierItem> Results { get; set; } = new List<SupplierItem>();
    }

    public class SupplierItem
    {
        public string? HeaderId { get; set; }
        public string? FormNo { get; set; }
        public string? VendorName { get; set; }
        public string? VendorNameAlt { get; set; }
        public string? VendorCode { get; set; }
        public DateTime? CreateDate { get; set; }
        public string? FlowerStatus { get; set; }
        public string? ApplyType { get; set; }
        public string? Applicant { get; set; }
        public string? Department { get; set; }
    }


    public class SupplierApplicationViewModel
    {
        public bool Approve { get; set; } = true;
        public string CurrentPhase { get; set; } = "";
        public VendorItem VendorItem { get; set; }
        // 清單關聯
        public List<VendorSubrangeItem> VendorSubranges { get; set; } = [];
        public List<BankLineItem> BankLines { get; set; } = [];
    }

    public class VendorItem
    {
        // 頂部表單資訊
        public string? FormNo { get; set; }
        public string? Applier { get; set; }
        public string? CompanyCode { get; set; }
        public string? ApplyDate { get; set; }
        public string? FormStatus { get; set; }

        public string? EmpNo { get; set; }
        // Supplier Information
        public string OuSite { get; set; } = "AMSCTW";
        public string VendorType { get; set; } = "New Vendor";
        public string SupplierType { get; set; } = "VCL";
        public string? EffectiveDate { get; set; }
        public string GroupName { get; set; } = "None Group";
        public string GroupCode { get; set; } = "C99999";

        public string CountFlag { get; set; } = "1";
        public string TradingPartnerNo { get; set; }

        public string ApplyType { get; set; }

    }
    public class VendorSubrangeItem
    {
        public string? SsrName { get; set; }
        public string? Currency { get; set; }
        public string? PaymentName { get; set; }
        public string? TaxDesc { get; set; }
        public string? Phone { get; set; }
        public string? Email { get; set; }
        public string? Fax { get; set; }
        public string? FreightCode { get; set; }
        public string? FobCode { get; set; }
      
    }

    public class BankLineItem
    {
        public string? BankName { get; set; }
        public string? BankBranch { get; set; }
        public string? BankAccountName { get; set; }
        public string? BankAccountNo { get; set; }
        public string? Country { get; set; }
        public string? Province { get; set; }
        public string? City { get; set; }
        public string? BranchAddress { get; set; }
        public string? BankKey { get; set; }


        public string? FBankName { get; set; }
        public string? FBankNumber { get; set; }
        public string? FBankBranch { get; set; }
        public string? FBranchNumber { get; set; }
        public string? FSwiftCode { get; set; } 

    }
}




 
