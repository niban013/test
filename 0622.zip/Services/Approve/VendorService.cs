﻿using System.Globalization;
using Dapper;
using Microsoft.SqlServer.Server;
using Newtonsoft.Json;
using OneSupplierPlatform.Controllers;
using OneSupplierPlatform.Infrastructure.DataBase;
using OneSupplierPlatform.Models.Infra;
using OneSupplierPlatform.Models.Supplier;
using OneSupplierPlatform.Services.Infra;

namespace OneSupplierPlatform.Services.Approve
{
    public class VendorService : BaseService
    {
        private readonly FlowerService _flowerService;
        private readonly ToolService _toolService;
        public VendorService(ToolService toolService,FlowerService flowerService, IHttpContextAccessor httpContextAccessor) : base(httpContextAccessor)
        {
            _flowerService = flowerService;
            _toolService = toolService;
        }
        public async Task<ApproveDataModel> SaveFormInfo(SupplierApplicationViewModel dto)
        {
            ApproveDataModel result = new ApproveDataModel();

            //////var dd = ParsedQueries;
            //////int formno = Convert.ToInt32(dto.VendorItem.FormNo);
            //////var isApproveYes = dto.Approve;
            //////var approveId = ParsedQueries.FormApproveId;
            //////var util = _flowerService.FlowERUtil;
            //////var phaseId = ParsedQueries.CallPhaseId;
            //////var appStatus = dto.Approve ? "Approving" : "Reject";
            //////var ApplyType = "";
            //////var currency = dto.VendorSubranges?.FirstOrDefault()?.Currency;
            //////switch (dto.VendorItem.ApplyType)
            //////{
            //////    case "Vendor":
            //////    case "Maker":
            //////    case "MakerVendor":
            //////        ApplyType = "New Vendor";
            //////        break;
            //////}


            //////if (isApproveYes)
            //////{
            //////    #region -- 簽核「同意」作業 --
            //////    Logger.LogInformation($"3_APPROVE_FORM = {(isApproveYes ? "簽核-同意" : "簽核-否決")}");

            //////    #region --*[3] 如簽核階段為「ACCOUNTANT」：財務-會計(帳務) --
            //////    Logger.LogInformation("4_Accountant_phase = " + phaseId.ToString());
            //////    if (phaseId == Config.ApproveParas.ACCOUNTANT)
            //////    {
            //////        Logger.LogInformation("ACCOUNTANT_phaseid:" + phaseId.ToString());


            //////        //[3-2] 更新：ContFlag。for 後續階段是否要長出來。 [ContFlag=2] 長出PH.10、[ContFlag=3] 長出PH.10及11
            //////        Logger.LogInformation("ACCOUNTANT_cont_class:" + dto.VendorItem.CountFlag);
            //////        if (!string.IsNullOrEmpty(dto.VendorItem.CountFlag))
            //////        {
            //////            if (new[] { "New Vendor", "New Vendor Site", "Assign Vendor", "Active Vendor" }.Contains(ApplyType))
            //////            {
            //////                //UpdateContFlag(Convert.ToInt32(dto.VendorItem.FormNo), dto.VendorItem.CountFlag);
            //////                //SQL :UPDATE osp_vendor_header_r SET contract_cn = @cont_flag WHERE form_no = @form_no

            //////                await UpdateFormFieldsAsync("osp_vendor_header_r", formno, new Dictionary<string, object> { { "cont_flag", dto.VendorItem.CountFlag } });


            //////                var parFlag = new Com.Auo.Flower.Interface.Parameter[1];
            //////                parFlag[0] = new Com.Auo.Flower.Interface.Parameter("Cont_Flag", dto.VendorItem.CountFlag);
            //////                util.AddFlag(FlowerService.FormKind, formno, parFlag);
            //////            }
            //////        }


            //////    }
            //////    #endregion --*[3] 如簽核階段為「ACCOUNTANT」：財務-會計(帳務) --
            //////    #region -- [4] 如簽核階段為「ACCOUNTANT_CONT」：最後的財務-會計(帳務) >> PH.12 --
            //////    if (phaseId == Config.ApproveParas.ACCOUNTANT_CONT) //Accountant
            //////    {
            //////        if (_flowerService.isLastApprover(approveId, formno, true))
            //////        {
            //////            appStatus = "Closed";
            //////            Logger.LogInformation("ACCOUNTANT_CONT CLOSE! ");
            //////        }
            //////    }
            //////    #endregion -- [4] 如簽核階段為「ACCOUNTANT_CONT」：最後的財務-會計(帳務) >> PH.12 --

            //////    #region --*[5] 如簽核階段為「FINANCE」：財務-資金(付款) --
            //////    Logger.LogInformation("FINANCE_phaseid:" + phaseId.ToString());
            //////    if (phaseId == Config.ApproveParas.FINANCE)
            //////    {
            //////        // UpdateTradintPartnerNO(formno, dto.VendorItem.TradingPartnerNo);

            //////        await UpdateFormFieldsAsync("osp_vendor_header_r", formno, new Dictionary<string, object> { { "trading_partner_no", dto.VendorItem.TradingPartnerNo } });
            //////        //SQL :UPDATE osp_vendor_header_r SET trading_partner_no = @trading_partner_no WHERE form_no = @form_no


            //////        if (ApplyType != "Inactive Vendor")
            //////        {
            //////            //檢查：for Revise Vendor >> 不允許在Effective Date之前簽核表單
            //////            if (ApplyType == "Revise Vendor")
            //////            {
            //////                var effectivDate = Convert.ToDateTime(dto.VendorItem.EffectiveDate);
            //////                if (effectivDate > DateTime.Now)
            //////                {
            //////                    result.Message = "不允許在Effective Date之前簽核表單，請諒解！\nCan not approve form before effective date,if have any question,please contact administrator!";
            //////                    return result;
            //////                }
            //////            }

            //////            #region -- 檢查：Bank --
            //////            if (string.IsNullOrEmpty(dto.BankLines.FirstOrDefault().FBankName))
            //////            {
            //////                result.Message = "銀行名稱不能為空！\nBank Name can not be null !";
            //////                return result;
            //////            }
            //////            if (string.IsNullOrEmpty(dto.BankLines.FirstOrDefault().FBankBranch))
            //////            {
            //////                result.Message = "Bank Branch不能為空！\nBank Branch can not be null !";
            //////                return result;
            //////            }

            //////            var (isOk, msg) = CheckBankInfo(dto.BankLines.FirstOrDefault());
            //////            if (!isOk)
            //////            {
            //////                result.Message = msg;
            //////                return result;
            //////            }

            //////            //檢查：銀行信息 與 ERP是否一致（代碼相同名字不同）

            //////            if (!string.IsNullOrEmpty(dto.BankLines.FirstOrDefault().BankKey))
            //////            {
            //////                var bankInfo = (await FetchBankInfo("ddsFCountry.SelectedValue.ToString().Trim()", dto.BankLines.FirstOrDefault().BankKey))?.FirstOrDefault();
            //////                if (bankInfo != null)
            //////                {
            //////                    var bankNameERP = bankInfo.bank_name;
            //////                    var branchNameERP = bankInfo.bank_branch_name;

            //////                    if (bankNameERP != dto.BankLines.FirstOrDefault().BankName || branchNameERP != dto.BankLines.FirstOrDefault().FBankBranch)
            //////                    {
            //////                        result.Message = "銀行信息與ERP不一致！ERP為："
            //////                            + bankNameERP + " " + branchNameERP + "(" + dto.BankLines.FirstOrDefault().BankKey + ")，請確認！\nThe bank informations that you filled in can not match with the ERP's.The bank which existed in ERP is "
            //////                            + bankNameERP + " " + branchNameERP + "(" + dto.BankLines.FirstOrDefault().BankKey + ").Pls check it!";
            //////                        return result;
            //////                    }
            //////                }
            //////            }
            //////            #endregion -- 檢查：Bank --



            //////            #region -- 檢查：幣別 --
            //////            //var dtLocalCurrency = GetLocalCurrency(dto.VendorItem.CompanyCode);
            //////            //var localCurrency = (dtLocalCurrency.Rows.Count > 0 ? dtLocalCurrency.Rows[0]["currency"].ToString() : "");
            //////            //if (!localCurrency.Equals(currency) && dto.BankLines.FirstOrDefault().FSwiftCode == "")
            //////            //{
            //////            //    result.Message = "若申請幣別非本位幣，請填寫Swift Code！\nThe Currency is not local Currency,please input swift code";
            //////            //    return result;
            //////            //}
            //////            #endregion -- 檢查：幣別 --


            //////            //UpdateBankEditFlag(formno, "Y");

            //////            await UpdateFormFieldsAsync("osp_vendor_bank_r", formno, new Dictionary<string, object> { { "bank_edit_flag", "Y" } });
            //////            //SQL :UPDATE osp_vendor_bank_r SET bank_edit_flag = @bank_edit_flag WHERE form_no = @form_no

            //////            var updateData = new Dictionary<string, object>
            //////            {
            //////                { "bank_edit_flag", "Y" },
            //////                { "f_bank_name", dto.BankLines.FirstOrDefault().FBankName },
            //////                { "bank_key", dto.BankLines.FirstOrDefault().BankKey},
            //////                { "f_swift_code", dto.BankLines.FirstOrDefault().FSwiftCode },
            //////                { "account_type", "" },
            //////                { "f_city_name", dto.BankLines.FirstOrDefault().City },
            //////                { "f_country_code", dto.BankLines.FirstOrDefault().Country },
            //////                { "f_country_name", dto.BankLines.FirstOrDefault().Country },
            //////            };
            //////            await UpdateFormFieldsAsync("osp_vendor_bank_r", formno, updateData);

            //////            //UpdateFinBankInfo(Form_No, txtFBankName.Text, txtFBankBranch.Text, dto.BankLines.FirstOrDefault().BankKey, /*txtFBankNum.Text, txtFBranchNum.Text,*/ txtFSwiftCode.Text, ddlFAccountType.SelectedValue.ToString().Trim(), txtFCity.Text, ddsFCountry.SelectedValue.ToString().Trim(), ddsFCountry.SelectedText.ToString().Trim());


            //////            //SQL :UPDATE osp_vendor_bank_r
            //////            //   SET
            //////            //       f_bank_name = @f_bank_name,
            //////            //       f_branch_name = @f_branch_name,
            //////            //       --f_bank_number = @f_bank_number,  
            //////            //       --f_branch_number = @f_branch_number, 
            //////            //       bank_key = @bank_key,
            //////            //       f_swift_code = @f_swift_code,
            //////            //       account_type = @account_type,
            //////            //       f_city_name = @f_city_name,
            //////            //       f_country_code = @f_country_code,
            //////            //       f_country_name = @f_country_name
            //////            // WHERE form_no = @form_no

            //////            if (_flowerService.isLastApprover(approveId, Convert.ToInt32(dto.VendorItem.FormNo)))
            //////            {
            //////                await UpdateFormFieldsAsync("osp_vendor_header_r", formno, new Dictionary<string, object> { { "approved_date", DateTime.Now } });
            //////                //UpdateApprovedDate(Convert.ToInt32(dto.VendorItem.FormNo));
            //////                //SQL :UPDATE osp_vendor_header_r SET approved_date = @approved_date WHERE form_no = @form_no 

            //////            }
            //////        }
            //////    }
            //////    #endregion --*[5] 如簽核階段為「FINANCE」：財務-資金(付款) --
            //////    #region -- [7] 如簽核階段為「APPLIER」--
            //////    if (phaseId == Config.ApproveParas.APPLIER)
            //////    {
            //////        //if (trNotice.Visible == true)
            //////        //{
            //////        //    result.Message = "此廠商未到生效日，您無法送簽表單！\nThe Vendor Information had not been active.you can not approve this form!";
            //////        //    return result;
            //////        //}


            //////        //try
            //////        //{
            //////        //    apiOData.SendERP(Convert.ToInt32(dto.VendorItem.FormNo));  //Spec待提供 by echo lee
            //////        //}
            //////        //catch (Exception ex)
            //////        //{
            //////        //    Logger.LogError(ex.Message);
            //////        //    //SendERP若有錯誤則吞掉上面的錯誤
            //////        //}

            //////        await UpdateFormFieldsAsync("osp_vendor_header_r", formno, new Dictionary<string, object> { { "approved_date", DateTime.Now } });
            //////        // 2. 傳入 Table 名稱、FormNo 與字典物件 
            //////        //UpdateApprovedDate(Convert.ToInt32(dto.VendorItem.FormNo));
            //////        //SQL : UPDATE osp_vendor_header_r SET approved_date = @approved_date WHERE form_no = @form_no

            //////        appStatus = ((dto.VendorItem.CountFlag == "2" || dto.VendorItem.CountFlag == "3") ? "Approving" : "Closed");
            //////    }
            //////    #endregion -- [7] 如簽核階段為「APPLIER」--
            //////    #endregion -- 簽核「同意」作業 --

            //////}
            //////else
            //////{
            //////    #region -- 簽核「否決」作業 --
            //////    if (phaseId == Config.ApproveParas.APPLIER)
            //////    {
            //////        //if (ViewState["AllowReject"] != null && (bool)ViewState["AllowReject"] == false)
            //////        //{
            //////        //    result.Message = "資料已導入ERP，不允許否決表單！\nThis form was sent to ERP, can not be reject.";
            //////        //    return result;
            //////        //}
            //////    }

            //////    #region --*[5] 如簽核階段為「FINANCE」：財務-資金(付款) --
            //////    Logger.LogInformation("FINANCE_phaseid:" + phaseId.ToString());
            //////    if (phaseId == Config.ApproveParas.FINANCE)
            //////    {
            //////        await UpdateFormFieldsAsync("osp_vendor_header_r", formno, new Dictionary<string, object> { { "trading_partner_no", dto.VendorItem.TradingPartnerNo } });
            //////        //UpdateTradintPartnerNO(Form_No, ddlTradingPartnerNO.SelectedValue.Trim());
            //////    }
            //////    #endregion --*[5] 如簽核階段為「FINANCE」：財務-資金(付款) --

            //////    #endregion -- 簽核「否決」作業 --
            //////}

            //////await UpdateFormFieldsAsync("osp_vendor_header_r", formno, new Dictionary<string, object> { { "form_status", appStatus } });
            ////////UpdateFlowerStatus(Form_No, appStatus);
            ////////SQL :UPDATE osp_vendor_header_r SET form_status = @flower_status WHERE form_no = @form_no


            result.Message = "";
            result.Success = true; 
            return result;


                //Logger.LogInformation("ApproveFormYes:" + JsonConvert.SerializeObject(dd));
                //return Task.FromResult(new ApproveDataModel
                //{
                //    Success = true,
                //    Message = ""

            //});
        }

        //private void UpdateApprovedDate(int formno)
        //{
        //    var sql = "UPDATE osp_vendor_header_r SET approved_date = @approved_date WHERE form_no = @form_no";
        //    DbCenter.ExecuteAsync(sql, new { approved_date = approved_date, form_no = formno })

        //}

        private async Task UpdateFormFieldsAsync(string tableName, int formNo, Dictionary<string, object> fieldsToUpdate)
        { 
            if (fieldsToUpdate == null || fieldsToUpdate.Count == 0) return; 
            var setClauses = fieldsToUpdate.Select(kvp => $"{kvp.Key} = @{kvp.Key}");
            var setSql = string.Join(", ", setClauses); 
            var sql = $"UPDATE {tableName} SET {setSql} WHERE form_no = @FormNoParameter"; 
            var parameters = new DynamicParameters(); 
            foreach (var kvp in fieldsToUpdate)
            {
                parameters.Add(kvp.Key, kvp.Value);
            }
            parameters.Add("FormNoParameter", formNo); 
            await DbCenter.ExecuteAsync(sql, parameters);
        }
         


        public async Task<List<BankDataDto>> FetchBankInfo(string country, string bankkey)
        {
            Dictionary<string, object> parameters = new Dictionary<string, object>(); 
            parameters["country"] = country;
            parameters["bankey"] = bankkey;
            return await _toolService.GetBankInfo("FetchBankByCountryInfo", parameters);
        }


        private (bool Success, string Message) CheckBankInfo(BankLineItem item)
        {
            var isLess = false;
             
            if (!string.IsNullOrEmpty(item.FBankName.Trim()))
            {
                isLess = item.FBankName.Trim().Length > 360;
                if (!isLess)
                {
                    return (false, "Bank Name最大長度為360位，請注意一個中文字符占用3位！\nBank Name should limited 360 bytes, one chinese word is 3 bytes!"); 
                }

                //if (UIHelper.IsHasSymbol(txtFBankName.Text.Trim()))
                //{
                //    ShowWarning("Bank Name包含非法字符！\nBank Name has some invalidate character!");
                //    return false;
                //}
            }

            //txtFBankBranch
            if (!string.IsNullOrEmpty(item.FBankBranch.Trim()))
            {
                isLess = item.FBankBranch.Trim().Length > 360;
                if (!isLess)
                { 
                    return (false, "Bank Branch最大長度為360位，請注意一個中文字符占用3位！\nBank Branch should limited 360 bytes, one chinese word is 3 bytes!");
                }

                //if (UIHelper.IsHasSymbol(txtFBankBranch.Text.Trim()))
                //{
                //    ShowWarning("Bank Branch包含非法字符！\nBank Branch has some invalidate character!");
                //    return false;
                //}
            }
             
            //txtFSwiftCode
            if (!string.IsNullOrEmpty(item.FSwiftCode.Trim())) 
            {
                isLess = item.FSwiftCode.Trim().Length > 25;
                if (!isLess)
                {
                    return (false, "Swift Code最大長度為25位，請注意一個中文字符占用3位！\nSwift Code should limited 25 bytes, one chinese word is 3 bytes!");                    
                }
            }
            return (true, ""); 
        }




        //public Task<ApproveDataModel> ApproveFormYes(SupplierApplicationViewModel dto)
        //{
        //    var dd = ParsedQueries;

        //    Logger.LogInformation("ApproveFormYes:"+JsonConvert.SerializeObject(dd));
        //    return Task.FromResult(new ApproveDataModel
        //    { 
        //       Success = true,
        //       Message =""

        //    });
        //}

        //public Task<ApproveDataModel> ApproveFormNo(SupplierApplicationViewModel dto)
        //{
        //    return Task.FromResult(new ApproveDataModel
        //    {
        //        Success = true,
        //        Message = "Rejected"
        //        //Id = dto.Id,
        //        //Status = "Rejected"
        //    });
        //}

        public Task<ApproveDataModel> OnWithdrawForm(SupplierApplicationViewModel dto)
        {
            return Task.FromResult(new ApproveDataModel
            {
                Success = true,
                Message = "Return"
                //Id = dto.Id,
                //Status = "Rejected"
            });
        }
         
    }
}
