﻿using Microsoft.Extensions.Options;
using OneSupplierPlatform.i18n;
using OneSupplierPlatform.Infrastructure;
using OneSupplierPlatform.Infrastructure.AppSetting;
using OneSupplierPlatform.Infrastructure.DataBase;
using OneSupplierPlatform.Infrastructure.Transfer;
using OneSupplierPlatform.Models.Infra;
using OneSupplierService;
using System.Security.Claims;
using ClaimTypes = System.Security.Claims.ClaimTypes;

namespace OneSupplierPlatform.Services.Infra
{
    public abstract class BaseService
    {
        private LocalizedKeys? _localizer;
        private AppOptions? _config;
        private OneSupplierPlatformServiceSoapClient? _asmxClient;
        private ITransactionContext? DBCenter;

        private readonly IHttpContextAccessor _httpContextAccessor;


        protected BaseService(IHttpContextAccessor httpContextAccessor)
        {
            _httpContextAccessor = httpContextAccessor;
        }


        private QueryStringDto? _query;
        protected QueryStringDto ParsedQueries => _query ??= _httpContextAccessor.HttpContext?.Request.Query != null
             ? TransQueryStringBinder.Bind<QueryStringDto>(_httpContextAccessor.HttpContext.Request.Query)
             : new QueryStringDto();

        protected LocalizedKeys Localizer => _localizer ??= AppFinder.ServiceProvider?
            .GetRequiredService<LocalizedKeys>()
            ?? throw new Exception("Localizer 未初始化");

        protected AppOptions Config => _config ??= AppFinder.ServiceProvider?.GetRequiredService<IOptions<AppOptions>>().Value;
        protected OneSupplierPlatformServiceSoapClient AsmxClient => _asmxClient ??= AppFinder.GetService<OneSupplierPlatformServiceSoapClient>();

        protected ITransactionContext DbCenter => DBCenter ??= AppFinder.GetService<ITransactionContext>() ?? throw new Exception("ITransactionContext 未初始化");
        protected CapUser CurrentUser
        {
            get
            {
                var http = _httpContextAccessor?.HttpContext;

                if (http == null)
                    return null;

                // iframe
                if (http.Items.TryGetValue("CurrentUser", out var obj) &&
                    obj is CapUser iframeUser)
                {
                    return new CapUser
                    {
                        UserId = iframeUser.UserId,
                        EmployeeId = iframeUser.EmployeeId,
                        RealName = iframeUser.RealName,
                        DepartmentId = iframeUser.DepartmentId,
                        Email = iframeUser.Email,
                        BossLevel = iframeUser.BossLevel,
                        CompanyName = iframeUser.CompanyName,
                        Site = iframeUser.Site
                    };
                }

                // CAP login
                var user = http.User;

                return new CapUser
                {
                    UserId = user.FindFirstValue(ClaimTypes.NameIdentifier),
                    EmployeeId = user.FindFirstValue("EmployeeId"),
                    RealName = user.FindFirstValue(ClaimTypes.Name),
                    Email = user.FindFirstValue(ClaimTypes.Email),
                    DepartmentId = user.FindFirstValue("DepartmentId"),
                    CompanyName = user.FindFirstValue("CompanyName"),
                    Site = user.FindFirstValue("Site"),
                    BossLevel = int.TryParse(user.FindFirstValue("BossLevel"), out var b) ? b : 0
                };
            }
        }

    }
}
