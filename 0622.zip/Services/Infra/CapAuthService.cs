﻿
using System.Text.Json;
using OneSupplierPlatform.Infrastructure.DataBase;
using OneSupplierPlatform.Models.Infra;

namespace OneSupplierPlatform.Services.Infra
{
    public class CapAuthService:BaseService
    {
        private readonly HttpClient _http; 
        public CapAuthService(HttpClient http, IHttpContextAccessor httpContextAccessor) : base(httpContextAccessor)
        { 
            _http = http;
        }

        // 取得 User 資訊
        public async Task<CapUser?> GetUserInfoAsync(string token)
        {
            var ApiUrl = Config.CapAuth.ApiUrl;
            var url =
                $"{ApiUrl}/GetUserInfoByToken?authToken={token}";

            var response = await _http.GetAsync(url);

            // ⭐ 關鍵：401 / 403 直接當作失效
            if (response.StatusCode == System.Net.HttpStatusCode.Unauthorized ||
                response.StatusCode == System.Net.HttpStatusCode.Forbidden)
            {
                return null;
            }

            if (!response.IsSuccessStatusCode)
            {
                return null;
            }

            var json = await response.Content.ReadAsStringAsync();

            if (string.IsNullOrWhiteSpace(json))
                return null;

            // ⭐ 有些 CAP 會回 error JSON
            if (json.Contains("invalid", StringComparison.OrdinalIgnoreCase))
                return null;

            return JsonSerializer.Deserialize<CapUser>(
                json,
                new JsonSerializerOptions
                {
                    PropertyNameCaseInsensitive = true
                });
        }


        public async Task<CapUser?> GetUserByEmpIdAsync(string empid) 
        {
            var sql = string.Format(@"	select CAST(NEWID() AS varchar(36)) AS UserId
	            ,emp_name RealName
	            ,emp_no EmployeeId
	            ,org_id DepartmentId 
	            ,e_mail Email 
	            ,boss_level BossLevel
	            ,company CompanyName
	            ,site Site
	            from emp_data_all where emp_no='{0}'", empid);
            return (await DbCenter.QueryAsync<CapUser?>(sql))?.FirstOrDefault();
        }
        // 功能權限
        public async Task<bool> CheckAuthAsync(
            string token,
            string company,
            string sysId,
            string func)
        {
            var ApiUrl = Config.CapAuth.ApiUrl  ;
            var url =
                $"{ApiUrl}/CheckAuth" +
                $"?authToken={token}" +
                $"&company={company}" +
                $"&sysId={sysId}" +
                $"&func={func}";

            var response = await _http.GetAsync(url);

            if (!response.IsSuccessStatusCode)
                return false;

            var result =
                await response.Content.ReadAsStringAsync();

            return result.Contains(
                "true",
                StringComparison.OrdinalIgnoreCase);
        }
    }
}
