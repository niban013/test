﻿using Microsoft.AspNetCore.StaticFiles;
using OneSupplierFLM;
using OneSupplierPlatform.Helper.Extensions;
using OneSupplierPlatform.Infrastructure.DataBase;
using OneSupplierPlatform.Infrastructure.Log;
using OneSupplierPlatform.Models.Supplier;


namespace OneSupplierPlatform.Services.Infra
{

    public interface IFileService
    {
        Task<string> UploadFileAsync(FlmFileInfo file);

        Task<List<FlmFileInfo>> GetFilesAsync(string itemKey, string formNo);


        Task<FlmFileInfo> GetFileAsync(string fileid);


        Task<bool> DeleteFileAsync(string fileid);
    }



    public class FileService : BaseService, IFileService
    {
        private readonly FLMService _flmService;
        public FileService(FLMService flmService, IHttpContextAccessor httpContextAccessor) : base(httpContextAccessor)
        {
            _flmService = flmService;
        }

        public async Task<string> UploadFileAsync(FlmFileInfo file)
        {
            var uploadfileId = string.Empty;
            var bDelete = false;
            var sql = "";
            if (string.IsNullOrEmpty(file.FileId))
            {
                sql = string.Format(@"select fileid from osp_vendor_file_r
                                where  item_id ='{0}' and fileName='{1}' and formno ='{2}' 
                                and Active ='Y'", file.ItemId, file.FileName, file.FormNo);
            }
            else
            {
                sql = string.Format(@"select fileid from osp_vendor_file_r
                                where  fileid ='{0}' and Active ='Y'", file.FileId);
            }
            var fileId = (await DbCenter.QueryAsync<string>(sql, new { })).ToList().FirstOrDefault();
            if (!string.IsNullOrEmpty(fileId))
            {
                if (await CheckFileIDByFileIdAsync(fileId))
                {
                    bDelete = await DeleteFileFromFileServerAsync(fileId, file.CUser);
                }
                bDelete = true;
            }
            else
            {
                bDelete = true;
            }

            if (!bDelete)
            {
                throw new Exception("刪除檔案失敗");
            }

            var bizID = "vendor" + "_" + file.FormNo;

            if (file.File != null && file.File.Length > 0)
            {
                using (var memoryStream = new MemoryStream())
                {
                    await file.File.CopyToAsync(memoryStream);
                    byte[] fileBytes = memoryStream.ToArray();
                    uploadfileId = await UploadFileToFLMAsync(fileBytes, file.FileName, bizID, file.CUser);

                    if (!string.IsNullOrEmpty(uploadfileId))
                    {
                        if (!string.IsNullOrEmpty(fileId))
                        {
                            sql = string.Format(@"update osp_vendor_file_r
                                set FileId ='{3}'
                                where  item_id ='{0}' and fileName='{1}' and formno ='{2}'
                                and Active ='Y'", file.ItemId, file.FileName, file.FormNo, uploadfileId);
                        }
                        else
                        {
                            sql = string.Format(@"insert into osp_vendor_file_r(Headerid,FormNo,item_id,item_name,FileId,FileName,Active,CUser,CDate)
                                                values('{0}','{1}','{2}','{3}','{4}','{5}','{6}','{7}',getdate())",

                                                    file.Headerid, file.FormNo, file.ItemId, file.ItemName, uploadfileId, file.FileName, "Y", file.CUser);
                        }
                        await DbCenter.ExecuteAsync(sql);
                    }
                    else
                    {
                        uploadfileId = "fail";
                    }
                }
            }
            return uploadfileId;
        }

        //public async Task<List<FlmFileInfo>> GetFilesAsync(string itemKey, string formNo)
        //{
        //    await Task.Delay(100); // 模擬 DB delay

        //    // =========================
        //    // mock data（可依 itemKey / formNo 分流）
        //    // =========================
        //    var data = new List<FlmFileInfo>();

        //    if (itemKey == "A001")
        //    {
        //        data.Add(new FlmFileInfo
        //        {
        //            ItemId = itemKey,
        //            FileId = "1",
        //            FileName = "demo1.png"
        //        });

        //        data.Add(new FlmFileInfo
        //        {
        //            ItemId = itemKey,
        //            FileId = "2",
        //            FileName = "contract.pdf"
        //        });
        //    }
        //    else if (itemKey == "B002")
        //    {
        //        data.Add(new FlmFileInfo
        //        {
        //            ItemId = itemKey,
        //            FileId = "3",
        //            FileName = "report.xlsx"
        //        });
        //    }
        //    else
        //    {
        //        data.Add(new FlmFileInfo
        //        {
        //            ItemId = itemKey,
        //            FileId = "abc",
        //            FileName = "default.txt"
        //        });
        //    }

        //    return data;
        //}
        public async Task<List<FlmFileInfo>> GetFilesAsync(string itemKey, string formNo)
        {
            var sql = string.Format(@"select item_id ItemId,fileid FileId,filename FileName from osp_vendor_file_r 
                                    where  item_id ='{0}'  and formno ='{1}' and FileId <>''
                                    and Active ='Y'", itemKey, formNo);
            var result = await DbCenter.QueryAsync<FlmFileInfo>(sql);
            return result?.ToList() ?? new List<FlmFileInfo>();
        }

        public async Task<bool> DeleteFileAsync(string fileid)
        {
            var bDelete = false;
            var sql = string.Format(@"select fileid,headerid,cuser from osp_vendor_file_r
                                    where  FileId ='{0}'
                                    and Active ='Y'", fileid);
            var fileInfo = (await DbCenter.QueryAsync<FlmFileInfo>(sql, new { })).ToList().FirstOrDefault();
            if (fileInfo != null)
            {
                if (await CheckFileIDByFileIdAsync(fileInfo.FileId))
                {
                    bDelete = await DeleteFileFromFileServerAsync(fileInfo.FileId, fileInfo.CUser);
                }
            }
            else
            {
                bDelete = true;
            }
            if (!bDelete)
            {
                throw new Exception("刪除檔案失敗");
            }
            sql = string.Format(@"delete osp_vendor_file_r where FileId ='{0}'", fileInfo.FileId);
            var deleteFile = await DbCenter.ExecuteAsync(sql);
            sql = string.Format(@"update osp_vendor_header_r set upload_ssaaf ='' where headerid ='{0}'", fileInfo.Headerid);

            return await DbCenter.ExecuteAsync(sql);
        }

        public async Task<FlmFileInfo> GetFileAsync(string fileid)
        {
            FlmFileInfo file = new FlmFileInfo();

            var sql = string.Format(@"select item_id ItemId
                    ,FormNo FormNo
                    ,item_name ItemName
                    ,fileid FileId
                    ,filename FileName from osp_vendor_file_r 
                where FileId ='{0}'  
                and Active ='Y'", fileid);
            var result = await DbCenter.QueryAsync<FlmFileInfo>(sql);


            if (result?.ToList().FirstOrDefault() != null)
            {
                file = result?.ToList().FirstOrDefault();
                var filename = result?.ToList().FirstOrDefault().FileName;
                var empno = result?.ToList().FirstOrDefault().CUser;
                file.bytes = await GetFileAsync(fileid, filename, empno);
                file.Mime = GetMimeType(filename);
            }

            //var bytes = await File.ReadAllBytesAsync(@"C:\Users\Honjay\Pictures\下載.png");

            //var fileName = Path.GetFileName(@"C:\Users\Honjay\Pictures\下載.png");
            //file.bytes = bytes;
            //file.Mime = GetMimeType(fileName);
            //file.FileName = fileName;
            return file;
        }

        private string GetMimeType(string fileName)
        {
            var provider = new FileExtensionContentTypeProvider();
            if (!provider.TryGetContentType(fileName, out string contentType))
            {
                contentType = "application/octet-stream";
            }
            return contentType;
        }

        #region -- Function 使用FLM WebService Start --
        /// <summary>
        /// 將檔案伺服器上的檔案註銷掉.
        /// </summary>
        /// <param name="strFileID"></param>
        /// <returns></returns>
        public async Task<bool> DeleteFileFromFileServerAsync(string strFileID, string strEmpNo)
        {
            try
            {
                DeleteFileRequest dereq = new DeleteFileRequest();
                dereq.file_id = strFileID;
                dereq.emp_no = strEmpNo;
                ///  this.wsFileMgr.DeleteFile(strFileID, strEmpNo, FLM_userName,FLM_password);
                var response = await _flmService.DeleteFileAsync(dereq);

                return response.DeleteFileResult;
            }
            catch (Exception ex)
            {
                LogHelper.Error(strFileID + " delete failed", ex);
                return false;
            }
        }

        /// <summary>
        /// 上傳檔案到指定的FileServer.回傳 FileId;
        /// </summary>
        public async Task<string> UploadFileToFLMAsync(byte[] bfileData, string strFileName, string strBizId, string strUploader)
        {
            try
            {
                UploadFileRequest req = new UploadFileRequest();
                req.sys_id = Config.FLMConfig.Security.SysId;
                req.file_name = strFileName;
                req.biz_id = strBizId;
                req.file_stream = bfileData;
                req.emp_no = strUploader;

                var response = await _flmService.UploadFileAsync(req);
                return response.UploadFileResult;
            }
            catch (Exception ex)
            {
                LogHelper.Error(strFileName + " UploadFileToFLM Failed", ex);
                return string.Empty;
            }
        }

        public async Task<byte[]> GetFileAsync(string strFileId, string strFileName, string strEmpNo)
        {
            try
            {
                GetFileRequest req = new GetFileRequest();
                req.file_id = strFileId;
                req.file_name = strFileName;
                req.emp_no = strEmpNo;

                var response = await _flmService.GetFileAsync(req);

                return response.GetFileResult;
            }
            catch (Exception ex)
            {
                LogHelper.Error(" get file from dmz error!", ex);
                return null;
            }
        }

        public async Task<bool> CheckFileIDByFileIdAsync(string strFileId)
        {
            try
            {
                CheckFileIDRequest req = new CheckFileIDRequest();
                req.file_id = strFileId;
                var response = await _flmService.CheckFileIDAsync(req);
                return response.CheckFileIDResult;
            }
            catch (Exception ex)
            {
                LogHelper.Error("CheckFileIDByFileId error!", ex);
                return false;
            }
        }

        public async Task<string[]> GetFileIDByBizIDAsync(string strBizId)
        {
            try
            {
                GetFileIDByBizIDRequest req = new GetFileIDByBizIDRequest();
                req.biz_id = strBizId;
                req.sys_id = Config.FLMConfig.Security.SysId;
                var response = await _flmService.GetFileIDByBizIDAsync(req);
                return response.GetFileIDByBizIDResult;
            }
            catch (Exception ex)
            {
                LogHelper.Error(" GetFileIDByBizID error!", ex);
                return null;
            }
        }
        #endregion -- Function 使用FLM WebService End --
    }


}
