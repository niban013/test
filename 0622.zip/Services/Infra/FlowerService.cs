﻿using Com.Auo.Flower;
using Com.Auo.Flower.Interface;
using OneSupplierPlatform.Helper;
using OneSupplierPlatform.Infrastructure;
using OneSupplierPlatform.Infrastructure.Log;
using System.Collections;

namespace OneSupplierPlatform.Services.Infra
{
    public class FlowerService : BaseService
    {
        public static string FormKind => AppFinder.GetService<IConfiguration>().GetValue<string>("FlowerSettings:BPMFORMKIND");
        public static string Company => AppFinder.GetService<IConfiguration>().GetValue<string>("FlowerSettings:COMPANYCODE");


        public FlowERUtil FlowERUtil { get; } = new FlowERUtil(Company);

        public FlowerService(IHttpContextAccessor httpContextAccessor) : base(httpContextAccessor)
        {
        }

        //private string GetEmpIDByEmpNo(string empNo)
        //{
        //    if (empNo.IndexOf('-') > -1)
        //    {
        //        return empNo;
        //    }

        //    string? text = ConfigurationSettings.AppSettings["COMPANYCODE"];
        //    if (string.IsNullOrEmpty(text))
        //    {
        //        throw new Exception("COMPANYCODE have not setting in web.config.");
        //    }

        //    return text.Trim() + "-" + empNo;
        //}
        //public static string GetMethod(string url)
        //{
        //    ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls12;
        //    HttpWebRequest httpWebRequest = (HttpWebRequest)WebRequest.Create(url);
        //    httpWebRequest.Method = "GET";
        //    httpWebRequest.Headers.Add("formKind", FormKind);
        //    httpWebRequest.Headers.Add("securityCode", SecrtyCode);
        //    HttpWebResponse httpWebResponse;
        //    try
        //    {
        //        httpWebResponse = (HttpWebResponse)httpWebRequest.GetResponse();
        //    }
        //    catch (Exception ex)
        //    {
        //        return ex.Message + url + FormKind + SecrtyCode;
        //    }

        //    Stream responseStream = httpWebResponse.GetResponseStream();
        //    StreamReader streamReader = new StreamReader(responseStream, Encoding.UTF8);
        //    string result = streamReader.ReadToEnd();
        //    streamReader.Close();
        //    responseStream.Close();
        //    return result;
        //}
        //public static string SecrtyCode = ConfigurationSettings.AppSettings["BPMSECRTYCODE"].Trim();
        //public string APIUrl = System.Configuration.ConfigurationManager.AppSettings["BPMAPIURL"];
        //public int CreateNewForm(string p_strFormKind, string p_strFiller)
        //{
        //    string text = "";
        //    try
        //    {
        //        p_strFiller = GetEmpIDByEmpNo(p_strFiller);
        //        text = GetMethod(APIUrl + "/Form/CreateNewForm?formKind=" + p_strFormKind + "&filler=" + p_strFiller);
        //        return JsonConvert.DeserializeObject<ActionReturnGeneralModel>(text).formNo;
        //    }
        //    catch
        //    {
        //        throw new Exception(text);
        //    }
        //}

        public string GetFormNo()
        {
            return FlowERUtil.CreateNewForm(FormKind, CurrentUser.EmployeeId).ToString();
        }

        public string GetFormKind()
        {
            return FormKind;
        }

        //public async Task<bool> UpdateFlowerStatus(VendorHeader vh, VendorHeader vh)
        //{ 
        //    var vendor = new VendorHeader { FormNo = formno.ToString(), FormStatus = status };
        //    return await _repo.UpdateAsync(table, vendor, pk: "form_no"); 
        //}



        public string GetFormStatus(int formno)
        {
            return FlowERUtil.getFormStatus(Config.FlowerSettings.BPMFORMKIND, formno);
        }

        public Parameter[] FlowerParams(string ouSite, string applyType, string empNo, string OFAC_CONFIRM, string Cont_Flag, string UFLPA_FLAG, string STOCK_FLAG)
        {
            var dtRoleUser = Utility.GetAppRoleUser(ouSite);
            if (dtRoleUser == null || dtRoleUser.Rows.Count == 0)
            {
                throw new Exception("no RoleUser");
            }


            var htParams = new Hashtable();
            htParams.Add("form_applicant", $"AMSC-{empNo.Replace("AMSC-", "")}"); //填表人。[AMSC版] 工號需加上公司名 By Aaron@2025-11

            for (var i = 0; i < dtRoleUser.Rows.Count; i++)
            {
                var appRole = dtRoleUser.Rows[i]["appRole"].ToString(); //簽核角色
                var appUser = dtRoleUser.Rows[i]["appUser"].ToString(); //簽核人員(工號) 
                if (!htParams.ContainsKey(appRole))
                {
                    // 會計/財務
                    if (appRole == "FINANCE" || appRole == "ACCOUNTANT")
                    {
                        htParams.Add(appRole, appUser);
                        continue;
                    }
                }
            }

            if (!htParams.ContainsKey("FINANCE") || htParams["FINANCE"].ToString() == "" || !htParams.ContainsKey("ACCOUNTANT") || htParams["ACCOUNTANT"].ToString() == "")
                return null;


            htParams.Add("FLAG", "C");


            // New Vendor 申請，寫入Form.314欄位SupplierType
            if (applyType == "NS")
            {
                if (!htParams.ContainsKey("SupplierType")) htParams.Add("SupplierType", "NS");
            }

            if (!htParams.ContainsKey("Cont_Flag")) htParams.Add("Cont_Flag", Cont_Flag);

            if (OFAC_CONFIRM.ToString().Trim() != "") htParams.Add("OFAC_CONFIRM", OFAC_CONFIRM.Trim());


            if (UFLPA_FLAG == "Y")
            {
                htParams.Add("UFLPA_FLAG", UFLPA_FLAG);
                for (var i = 0; i < dtRoleUser.Rows.Count; i++)
                {
                    var appRole = dtRoleUser.Rows[i]["appRole"].ToString();
                    var appUser = dtRoleUser.Rows[i]["appUser"].ToString();

                    if (appRole == "LEGAL") htParams.Add(appRole, appUser);
                }
            }


            #region -- 組FlowER參數：from htParams to objParams --
            var paramsLength = htParams.Count;
            if (paramsLength == 0) return null;

            var objParams = new Parameter[paramsLength];
            var flag = 0;
            foreach (DictionaryEntry each in htParams)
            {
                objParams[flag] = new Parameter(each.Key.ToString(), each.Value.ToString());
                flag++;
            }
            #endregion -- 組FlowER參數：from htParams to objParams --


            return objParams;
        }

        //public static string GetPhaseIdByName(string PhaseName) => UIHelper.GetAppSetting(PhaseName);



        /// <summary>[函式] 是否為最後簽核者。<para>[必填] isCONT(股務)：是否為ACCOUNTANT_CONT。[true] cont_flag not null unApprovedTotal == 1 is last approver</para></summary>
        public bool isLastApprover(string p_strApproveId, int formno, bool isCONT = false)
        {
            //【說明】後面的簽核關卡是動態新增，所以當下是最後一關。

            LogHelper.Info($"{(isCONT ? "CONT_" : "")}isLastApprover: {p_strApproveId.ToString()};formNo={formno.ToString()}");

            //獲取簽核資訊-單筆：By 當前簽核人之 Approve ID
            var AppNow = FlowERUtil.getApproveS(p_strApproveId);

            //獲取簽核資訊-全部：By Form No
            var appList = FlowERUtil.getFormApproveHistoryS(AppNow.getFormKind(), AppNow.getFormNo());

            //簽核記錄中未簽核表單的總人數
            var unApprovedTotal = 0;

            //遍歷簽核記錄，計算未簽核表單的總人數
            foreach (var app in appList)
            {
                if (new[] { "U", "W" }.Contains(app.getAppStatus())) //[U] 可簽核：目前簽核人、[W] 待簽核
                    unApprovedTotal++;
            }

            LogHelper.Info($"isLastApprover_unApprovedTotal: {unApprovedTotal}");

            if (isCONT)
                return unApprovedTotal == 1 && AppNow.getAppStatus() == "U"; //僅有1人未簽核，且是p_strApproveId對應的當前簽核人
            else
                return unApprovedTotal == 2 && AppNow.getAppStatus() == "U"; //僅有2人未簽核，且是p_strApproveId對應的當前簽核人
        }

    }
}
