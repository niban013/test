﻿using Newtonsoft.Json;
using OneSupplierPlatform.Models.Infra;


namespace OneSupplierPlatform.Services.Infra
{
    public class ToolService : BaseService
    {
        private readonly IHttpClientFactory _httpClientFactory;
        public ToolService(IHttpContextAccessor httpContextAccessor, IHttpClientFactory httpClientFactory) : base(httpContextAccessor)
        {
            _httpClientFactory = httpClientFactory;
        }

        public async Task<List<BankDataDto>> GetBankInfo(string actionname, Dictionary<string, object> parameters = null)
        {
            List<BankDataDto> lsBank = new List<BankDataDto>();
            string asmxUrl = $"{Config.ExternalServices.ErpUrl}/{actionname}";
            using (var client = _httpClientFactory.CreateClient())
            {
                var jsonPayload = JsonConvert.SerializeObject(parameters);
                var content = new StringContent(jsonPayload, System.Text.Encoding.UTF8, "application/json");

                var response = await client.PostAsync(asmxUrl, content);

                if (!response.IsSuccessStatusCode)
                {
                    throw new Exception($"ERP 服務回應錯誤: {response.ReasonPhrase}");

                }

                var result = await response.Content.ReadAsStringAsync();
                var wrapper = System.Text.Json.JsonSerializer.Deserialize<ApiOuterWrapper>(result);

                if (wrapper != null && !string.IsNullOrEmpty(wrapper.D))
                {
                    lsBank = System.Text.Json.JsonSerializer.Deserialize<List<BankDataDto>>(wrapper.D) ?? new();
                }
            }
            return lsBank;
        }
    }


}
