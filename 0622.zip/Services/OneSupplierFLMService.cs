﻿using OneSupplierPlatform.Services;
using OneSupplierFLM;
using System.ServiceModel;

namespace OneSupplierPlatform.Service
{
    /// <summary>[STD] FLM：</summary>
    public class OneSupplierFLMService : BaseService
    {  
     
        private readonly FLMService _flmService; 

        // 在建構子中要求注入 FLMService
        public OneSupplierFLMService(FLMService flmService, IHttpContextAccessor httpContextAccessor) : base(httpContextAccessor)
        {
            _flmService = flmService; 
        }
         

        #region -- Function 使用FLM WebService Start --
        /// <summary>
        /// 將檔案伺服器上的檔案註銷掉.
        /// </summary>
        /// <param name="strFileID"></param>
        /// <returns></returns>
        public async Task<bool> DeleteFileFromFileServerAsync(string strFileID, string strEmpNo)
        { 
            try
            {
                DeleteFileRequest dereq = new DeleteFileRequest();
                dereq.file_id = strFileID;
                dereq.emp_no = strEmpNo;
                ///  this.wsFileMgr.DeleteFile(strFileID, strEmpNo, FLM_userName,FLM_password);
                var response = await _flmService.DeleteFileAsync(dereq);

                return response.DeleteFileResult;
            }
            catch (Exception ex)
            {     
                Logger.LogError(strFileID + " delete failed", ex); 
                return false;
            }
        }
       
        /// <summary>
        /// 上傳檔案到指定的FileServer.回傳 FileId;
        /// </summary>
        public async Task<string> UploadFileToFLMAsync(byte[] bfileData, string strFileName, string strBizId, string strUploader)
        { 
            try
            { 
                UploadFileRequest  req = new UploadFileRequest();
                req.sys_id = Config.FLMConfig.Security.SysId;
                req.file_name = strFileName;
                req.biz_id = strBizId;
                req.file_stream = bfileData;
                req.emp_no = strUploader;

                var response = await _flmService.UploadFileAsync(req); 
                return response.UploadFileResult;
            }
            catch (Exception ex)
            {
                Logger.LogError(strFileName + " UploadFileToFLM Failed", ex); 
                return string.Empty;
            }
        }

        public async Task<Byte[]> GetFileAsync(string strFileId, string strFileName, string strEmpNo)
        { 
            try
            { 
                GetFileRequest req = new GetFileRequest();
                req.file_id = strFileId;
                req.file_name = strFileName;
                req.emp_no = strEmpNo;

                var response = await _flmService.GetFileAsync(req);

                return response.GetFileResult;
            }
            catch (Exception ex)
            {
                Logger.LogError(" get file from dmz error!", ex); 
                return null;
            }
        }

        public async Task<bool> CheckFileIDByFileIdAsync(string strFileId)
        {
            try
            { 
                CheckFileIDRequest req = new CheckFileIDRequest(); 
                req.file_id = strFileId; 
                var response = await _flmService.CheckFileIDAsync(req);
                return response.CheckFileIDResult;
            }
            catch (Exception ex)
            {
                Logger.LogError("CheckFileIDByFileId error!", ex);
                return false;
            }
        }

        public async Task<string[]> GetFileIDByBizIDAsync(string strBizId)
        { 
            try
            { 
                GetFileIDByBizIDRequest req = new GetFileIDByBizIDRequest();
                req.biz_id = strBizId;
                req.sys_id = Config.FLMConfig.Security.SysId;
                var response =  await _flmService.GetFileIDByBizIDAsync(req);
                return response.GetFileIDByBizIDResult;
            }
            catch (Exception ex)
            { 
                Logger.LogError(" GetFileIDByBizID error!", ex); 
                return null;
            }
        }
        #endregion -- Function 使用FLM WebService End --

        //#region -- Function 使用FLM FileUpload / FileGet 頁面 Start --
        //public string UploadFilePath(string RiskNo, string EmpNo)
        //{
        //    //string strFilePath = string.Empty;
        //    //string orignQueryString = "?sys_id=" + _strFileSystemId + "&file_id=" + strFileId + "&action=D&emp_no=" + strEmpNo + "&language=en";
        //    //strFilePath = clsSysConfig.GetInstance.FLM_GetFile_URL + SecurityHelper.Encrypt(orignQueryString, true);

        //    string pageUrl = _FLM_UploadFilePath; //"http://flmtest.corpnet.auo.com/FLMPublic/Webform/FileUpload.aspx";
        //                                                     //文件上傳頁面地址(測試區)
        //    string sysID = FLM_sysId; //[必選]系統ID，新系統申請時固定分配
        //    string bizID = RiskNo;           //[必選]業務ID，由AP系統生成，用於管理一組文件，可根據其獲取文件List "478"
        //    string securityLevel = "M";      //[可選]機密等級，不填時會取默認配置
        //    string markStyle = "A";          //[可選]浮水印樣式，不填時會取默認配置
        //    string preconvertPdf = "N";      //[可選]是否預轉檔PDF，不填時默認不進行預轉檔(定時轉檔任務)
        //    string empNo = EmpNo;            //[必選]操作者工號
        //    string language = "zh-CHT";      //[必選]頁面顯示語言，en / zh-CHS / zh-CHT
        //                                     //呼叫地址
        //    string orignQueryString = "sys_id=" + sysID
        //                            + "&biz_id=" + bizID
        //                            + "&security_level=" + securityLevel + "&mark_style=" + markStyle
        //                            + "&preconvert_pdf=" + preconvertPdf
        //                            + "&emp_no=" + empNo
        //                            + "&language=" + language;

        //    string url = pageUrl + SecurityHelper.Encrypt(orignQueryString, true);
        //    //頁面參數
        //    string para = "height=600,width=800,top='+(window.screen.availHeight-630)/2+'"
        //                      + ",left='+(window.screen.availWidth-810)/2+',"
        //                      + "toolbar=no,menubar=no,scrollbars=yes,resizable=yes,location=no,status=no";

        //    //打開頁面
        //    //ClientScript.RegisterClientScriptBlock(this.GetType(), string.Empty, "<script>window.open('" + url + "','_blank','" + para + "')</script>");


        //    return url;
        //}

        //public string GetFilePath(string BizID, string FLMID, string EmpNo)
        //{
        //    string pageUrl = _FLM_GetFilePath; //"http://flmtest.corpnet.auo.com/FLMPublic/Webform/FileGet.ashx";
        //                                                  //文件獲取頁面地址(測試區)
        //    string sysID = FLM_sysId;     //系統ID[必選]，新系統申請時固定分配
        //    string bizID = BizID;               //業務ID[可選]，由AP系統生成，用於管理一組文件，可根據其獲取文件List
        //    string fileID = FLMID;                  //文件ID[可選]，獲取單個文件時使用 // "F6ABA0A5-5249-455D-A525-948FAF3E68F0"; 
        //    string action = "VDP";               //操作類型Action[必選]，VDTMPF的字符組合
        //    string empNo = EmpNo;                //操作者工號[必選] "S0912312";
        //    string language = "zh-CHT";          //頁面顯示語言[必選]，en / zh-CHS / zh-CHT

        //    string orignQueryString = "sys_id=" + sysID 
        //                            + "&biz_id=" + bizID 
        //                            + "&file_id=" + fileID
        //                            + "&action=" + action 
        //                            + "&emp_no=" + empNo 
        //                            + "&language=" + language;
        //    //呼叫地址
        //    string url = pageUrl + SecurityHelper.Encrypt(orignQueryString, true);
        //    string para = "height=600,width=800,top='+(window.screen.availHeight-630)/2+'"
        //                + ",left='+(window.screen.availWidth-810)/2+',"
        //                + "toolbar=no,menubar=no,scrollbars=yes,resizable=yes,location=no,status=no";

        //    //打開頁面
        //    //ClientScript.RegisterClientScriptBlock(this.GetType(), string.Empty, "<script>window.open('" + url + "','_blank','" + para + "')</script>");

        //    return url;
        //}

        //public string GetFileIDByBizID(string BizID, string FLMID, string EmpNo)
        //{
        //    string pageUrl = _FLM_GetFilePath; //"http://flmtest.corpnet.auo.com/FLMPublic/Webform/FileGet.ashx";
        //                                                  //文件獲取頁面地址(測試區)
        //    string sysID = FLM_sysId;     //系統ID[必選]，新系統申請時固定分配
        //    string bizID = BizID;               //業務ID[可選]，由AP系統生成，用於管理一組文件，可根據其獲取文件List
        //    string fileID = FLMID;                  //文件ID[可選]，獲取單個文件時使用 // "F6ABA0A5-5249-455D-A525-948FAF3E68F0"; 
        //    string action = "VDP";               //操作類型Action[必選]，VDTMPF的字符組合
        //    string empNo = EmpNo;                //操作者工號[必選] "S0912312";
        //    string language = "zh-CHT";          //頁面顯示語言[必選]，en / zh-CHS / zh-CHT

        //    string orignQueryString = "sys_id=" + sysID
        //                            + "&biz_id=" + bizID
        //                            + "&file_id=" + fileID
        //                            + "&action=" + action
        //                            + "&emp_no=" + empNo
        //                            + "&language=" + language;
        //    //呼叫地址
        //    string url = pageUrl + SecurityHelper.Encrypt(orignQueryString, true);
        //    string para = "height=600,width=800,top='+(window.screen.availHeight-630)/2+'"
        //                + ",left='+(window.screen.availWidth-810)/2+',"
        //                + "toolbar=no,menubar=no,scrollbars=yes,resizable=yes,location=no,status=no";

        //    //打開頁面
        //    //ClientScript.RegisterClientScriptBlock(this.GetType(), string.Empty, "<script>window.open('" + url + "','_blank','" + para + "')</script>");

        //    return url;
        //}
        //#endregion -- Function 使用FLM FileUpload / FileGet 頁面 End --
    }
}