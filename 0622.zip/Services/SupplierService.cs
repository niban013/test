﻿using MiniExcelLibs;
using Newtonsoft.Json;
using OneSupplierPlatform.HandleException;
using OneSupplierPlatform.Helper;
using OneSupplierPlatform.Helper.Extensions;
using OneSupplierPlatform.Infrastructure.Columns;
using OneSupplierPlatform.Infrastructure.DataBase;
using OneSupplierPlatform.Infrastructure.Log;
using OneSupplierPlatform.Infrastructure.Transfer;
using OneSupplierPlatform.Models;
using OneSupplierPlatform.Models.Infra;
using OneSupplierPlatform.Models.Supplier;
using OneSupplierPlatform.Services.Infra;
using System.Data;
using System.Text;


namespace OneSupplierPlatform.Services
{
    public interface ISupplierService
    {
        Task<SupplierApplicationViewModel> GetSupplierApplicationAsync(QueryStringDto ParsedQueries);
        Task<List<vmMakerDetail>> GetMakerDataFromGroupAsync(string makername, string companyid);
        Task<List<vmMakerDetail>> GetMakerDataInternalAsync(string makername);
        Task<List<vmVendorDetail>> GetVendorInfoAsync(string makername);
        Task<List<BaseDynamicField>> GetConfigFieldAsync(string section, Dictionary<string, object>? dicType);

        Task<List<BaseDynamicField>> GetConfigFileListAsync(string formno, Dictionary<string, object>? dicType);


        Task<Dictionary<string, List<BaseDynamicField>>> MappingSendData(Dictionary<string, List<BaseDynamicField>> dicMapping, Dictionary<string, object>? SendData);
        Task<Dictionary<string, List<BaseDynamicField>>> MappingFormData(Dictionary<string, List<BaseDynamicField>> dicMapping, string formno);

        Task<FormInfo> SaveAsync(FormRequest req);

        Task<string> SendAsync(FormRequest req);

        Task<Dictionary<string, string>> UploadSSAAF(IFormFile file);


        Task<List<SupplierItem>> GetSupplier();

        Task<bool> UploadFileAsync(List<FlmFileInfo> file);

        Task<List<SupplierItem>> QuerySuppierAll(vmSupplierQuery model);

        Task<List<FlmFileInfo>> GetFileAsync(string itemKey, string formNo);
    }



    public class SupplierService : BaseService, ISupplierService
    {
        private readonly FlowerService _flowerService;
        private readonly FileService _fileService;


        public SupplierService(FileService fileService, FlowerService flowerService, IHttpContextAccessor httpContextAccessor) : base(httpContextAccessor)
        {
            _flowerService = flowerService;
            _fileService = fileService;
        }


        public async Task<List<vmMakerDetail>> GetMakerDataFromGroupAsync(string makername, string companyid)
        {
            try
            {
                string jsonString = await AsmxClient.GetMakerDataFromGroupAsync(makername, companyid);

                if (string.IsNullOrEmpty(jsonString))
                {
                    throw new InvalidOperationException("遠端 SOAP 服務回傳空值，系統無法繼續處理。");
                }

                var result = JsonConvert.DeserializeObject<List<vmMakerDetail>>(jsonString);
                return result ?? new List<vmMakerDetail>();
            }
            catch (Exception ex)
            {
                LogHelper.Error($"呼叫失敗: {ex.Message}");
                throw;
            }
        }

        public async Task<List<vmMakerDetail>> GetMakerDataInternalAsync(string makername)
        {
            try
            {
                string jsonString = await AsmxClient.GetMakerDataInternalAsync(makername);
                if (string.IsNullOrEmpty(jsonString))
                {
                    throw new InvalidOperationException("遠端 SOAP 服務回傳空值，系統無法繼續處理。");
                }

                var result = JsonConvert.DeserializeObject<List<vmMakerDetail>>(jsonString);

                return result ?? new List<vmMakerDetail>();
            }
            catch (Exception ex)
            {
                LogHelper.Error($"呼叫失敗: {ex.Message}");
                throw;
            }
        }

        public async Task<List<vmVendorDetail>> GetVendorInfoAsync(string makername)
        {
            try
            {
                string jsonString = await AsmxClient.GetVendorInfoAsync(makername);
                if (string.IsNullOrEmpty(jsonString))
                {
                    throw new Exception("遠端 SOAP 服務回傳空值，系統無法繼續處理。");
                }

                var result = JsonConvert.DeserializeObject<List<vmVendorDetail>>(jsonString);

                return result ?? new List<vmVendorDetail>();
            }
            catch (Exception ex)
            {
                LogHelper.Error($"呼叫失敗: {ex.Message}");
                throw;
            }
        }



        public async Task<List<BaseDynamicField>> GetConfigFileListAsync(string formno, Dictionary<string, object>? dicType)
        {
            try
            {
                var vc_type = dicType?.GetString("vendor_class");

                DataTable dt = new DataTable();
                var sql = @" select c.Item_id ColId
                                   ,c.Item_name ColName
                                   ,object_type EnumTypeRaw
								   ,MAX(COALESCE(CAST(NULLIF(r.score, '') AS varchar(50)), CONVERT(varchar(10), r.Expire_Date, 120))) AS ColValue
							  ,case when (c.object_type ='dropdownlist' or c.object_type ='select2' or c.object_type ='radiobutton') then  
      c.default_value
      else '' end  AS OptionStr 
                                   ,CASE 
    WHEN c.score = 'Y' 
      OR c.expired_date = 'Y' 
      OR c.must_fill_data = 'Y' 
    THEN 'Y'
    ELSE 'N' 
END AS MustRaw
							    ,case when (c.object_type !='dropdownlist' or c.object_type !='select2' or c.object_type !='radiobutton') then   ''
      else c.default_value end  AS DefaultValue  
                                   ,format
                                   ,CONCAT('score:', c.score, ',', 'expired:', c.expired_date,',','file:',c.must_fill_data,',','cnt:',count(NULLIF(r.FileId, ''))) DisplayRaw
                                   ,Sort [Order] 
                            from osp_file_config_c c  left join osp_vendor_file_r r 
  on c.item_id = r.item_id 
  and r.FormNo =@formno
where 1=1 
  and vc_type =@vc_type
  and c.active='Y'  --and c.item_id ='vc1_ssa'
  GROUP BY c.Item_id, c.Item_name, c.object_type, c.must_fill_data, c.default_value, c.format,c.score       
  ,c.expired_date ,c.Sort
order by CAST( c.Sort AS INT)  Asc  ";
                var rawList = await DbCenter.QueryAsync<BaseDynamicField>(sql, new { formno = formno, vc_type = vc_type });

                var result = new List<BaseDynamicField>();

                foreach (var raw in rawList)
                {
                    var parent = new BaseDynamicField
                    {
                        ColId = raw.ColId,
                        ColName = raw.ColName,
                        MustRaw = raw.MustRaw,
                        EnumTypeRaw = "onlylabel",
                        Children = new Dictionary<string, BaseDynamicField>(),
                    };


                    var display = RuleCheck.ParseDisplay(raw.DisplayRaw);
                    string GetMustRaw(string col, string currentVal)
                    {
                        if (col == "cnt")
                        {
                            // 專注處理 cnt 的依賴邏輯
                            return display.FieldStates.GetValueOrDefault("file") == "Y" ? "Y" : "N";
                        }
                        return currentVal;
                    }
                    foreach (var fieldState in display.FieldStates)
                    {
                        var col = fieldState.Key;
                        parent.Children[col] = new BaseDynamicField
                        {
                            ColId = raw.ColId,
                            Col = col,
                            EnumTypeRaw = (col, fieldState.Value) switch
                            {
                                ("expired", _) => FieldType.Date.ToString(),
                                ("cnt", _) => FieldType.Label.ToString(),
                                ("file", _) => "file",
                                _ => raw.EnumTypeRaw
                            },
                            OptionStr = raw.OptionStr,
                            MustRaw = GetMustRaw(col, fieldState.Value),
                            DisplayRaw = (col, fieldState.Value) switch
                            {
                                ("cnt", _) => "Y",
                                ("file", _) => "Y",
                                _ => fieldState.Value
                            },
                            ColValue = (col == "cnt") ? fieldState.Value : raw.ColValue
                        };
                    }

                    result.Add(parent);
                }


                // return result?.ToList() ?? new List<BaseDynamicField>();

                //List<BaseDynamicField> result = rawList
                //    .GroupBy(x => x.ColId)
                //    .Select(group =>
                //    {
                //        // 取得群組中的第一筆資料作為 Parent 資訊
                //        var firstItem = group.First();

                //        var parentField = new BaseDynamicField()
                //        {
                //            ColId = firstItem.ColId,
                //            ColName = firstItem.ColName,
                //            Children = new Dictionary<string, BaseDynamicField>(), // 保持內部 Children 為 Dictionary 
                //            IsMust = firstItem.IsMust,
                //            IsScore = firstItem.IsScore,
                //            cnt = firstItem.cnt
                //        };

                //        // 動態將資料拆解到 score, expired, file 等子欄位
                //        foreach (var item in group)
                //        {
                //            bool isMust = item.IsMust;

                //            // 子欄位 1: Score (Dropdown)
                //            parentField.Children["score"] = new BaseDynamicField()
                //            {
                //                ColId = item.ColId,
                //                EnumTypeRaw = firstItem.EnumTypeRaw,
                //                OptionStr = item.OptionStr,
                //                ColValue = firstItem.ColValue,
                //                Col = "score"
                //                //Must = isMust
                //            };

                //            // 子欄位 2: Expired (Date)
                //            parentField.Children["expired"] = new BaseDynamicField()
                //            {
                //                ColId = item.ColId,
                //                EnumTypeRaw = FieldType.Date.ToString(),
                //                ColValue = firstItem.ColValue,
                //                Col = "expired"
                //            };

                //            // 子欄位 3: File (File)
                //            parentField.Children["file"] = new BaseDynamicField()
                //            {
                //                ColId = item.ColId,
                //                EnumTypeRaw = FieldType.File.ToString(),
                //                Col = "file"
                //                //Must = isMust
                //            };
                //        }

                //        return parentField;
                //    })
                //    .ToList();

                return result;
            }
            catch (Exception ex)
            {
                LogHelper.Error($"呼叫失敗: {ex.Message}");
                throw;
            }
        }


        public async Task<List<BaseDynamicField>> GetConfigFieldAsync(string section, Dictionary<string, object>? dicType)
        {
            try
            {
                var type = dicType?.GetString("applytype");

                var sqlWhere = string.Empty;
                var sqlSelect = string.Empty;
                switch (type)
                {
                    case "Vendor":
                        sqlSelect += ",for_vendor_column MustRaw";
                        sqlWhere += " and a.for_vendor_column in ('Y','O') ";
                        break;
                    case "Maker":
                        sqlSelect += ",for_maker_column MustRaw";
                        sqlWhere += " and a.for_maker_column in ('Y','O') ";
                        break;
                    case "MakerVendor":
                        sqlSelect += ", CASE  WHEN for_vendor_column ='Y' or  for_maker_column ='Y' THEN 'Y' WHEN for_vendor_column ='Y' and  for_maker_column ='O' THEN 'Y' WHEN for_vendor_column ='O' and  for_maker_column ='Y' THEN 'Y' ELSE 'N' END AS MustRaw";
                        sqlWhere += " and (a.for_vendor_column in ('Y','O') or  a.for_maker_column in ('Y','O'))";
                        break;
                }

                LogHelper.Info("正在執行業務邏輯...");
                DataTable dt = new DataTable();
                var sql = string.Format(@"select * from (
                            select NODE_ID NodeId
                            ,PARENT_ID ParentId
                            {0}
                            ,section Section
                            ,a.column_code ColId
                            ,a.column_name ColName
                            ,object_type EnumTypeRaw
                            ,Sort [Order]
                            ,NULLIF(SSAF_Sheet, 'NA') SheetName
                            ,NULLIF(SSAF_Column, 'NA') SheetColumn 
                            ,display DisplayRaw
                            ,Position
                           ,ISNULL(
                                    STRING_AGG(
                                        CASE 
                                            WHEN a.object_type IN ('dropdownlist','select2','radiobutton') THEN
                                                CASE 
                                                    WHEN b.attribute_text IS NULL AND b.attribute_value IS NULL THEN '' 
                                                    ELSE ISNULL(b.attribute_text, '') + ',' + ISNULL(b.attribute_value, '') 
                                                END
                                        END, 
                                        '^'
                                    ) WITHIN GROUP (ORDER BY a.Sort ASC)
                                 , '') AS OptionStr
                                ,ISNULL(MAX(case when a.object_type IN ('textbox','date')  and (b.attribute_text = 'default')then b.attribute_value end), '') DefaultValue 
                                ,ISNULL(MAX(case when a.object_type ='textbox' and (b.attribute_text = 'AsyncUrl' or b.attribute_text = 'Google') then b.attribute_value end), '') asyncurl 
                                ,ISNULL(MAX(CASE WHEN a.object_type IN ('File') AND b.attribute_text='Pattern' THEN b.attribute_value END), '') AS Pattern
                                ,ISNULL(MAX(CASE WHEN a.object_type IN ('File','textbox','decimal','textarea') AND b.attribute_text='Max' THEN b.attribute_value END), '0') AS Max                                
                            from 
							osp_column_config_c a left join osp_column_parameter_c b 
							on a.column_code = b.column_code and a.column_name = b.column_name and a.Active ='Y' and b.Active ='Y'
                            where a.section =@section
                            {1}
                           GROUP BY 
                                    NODE_ID,
                                    PARENT_ID,
                                    for_maker_column,
                                    for_vendor_column,
                                    section,
                                    a.column_code,
                                    a.column_name,
                                    object_type,
                                    Sort,
                                    SSAF_Sheet,
                                    SSAF_Column,
                                    display,
                                    Position
                            ) c

							order by [Order] Asc", sqlSelect, sqlWhere);
                var result = await DbCenter.QueryAsync<BaseDynamicField>(sql, new { section = section });

                return result?.ToList() ?? new List<BaseDynamicField>();
            }
            catch (Exception ex)
            {
                LogHelper.Error($"呼叫失敗: {ex.Message}");
                throw;
            }
        }


        public async Task<Dictionary<string, List<BaseDynamicField>>> MappingFormData(Dictionary<string, List<BaseDynamicField>> dicMapping, string formno)
        {
            List<dynamic> models = new List<dynamic>();
            var sql = string.Format(@"SELECT a.*, b.FileId upload_ssaaf_id 
                                        FROM osp_vendor_header_r a 
                                        LEFT JOIN osp_vendor_file_r b 
                                          ON a.form_no = b.FormNo 
                                          AND a.upload_ssaaf = b.FileName and b.item_id = 'upload_ssaaf'
                                          AND a.headerid = b.Headerid 
                                        WHERE a.form_no = '{0}' 
                                          AND a.Active = 'Y';", formno);

            var headerinfo = (await DbCenter.QueryAsync<VendorHeader>(sql)).FirstOrDefault();
            if (headerinfo != null)
            {
                models.Add(headerinfo);
            }
            sql = string.Format(@"select * from osp_vendor_subrange_r a
						    where a.form_no ='{0}'", formno);

            var subrangeinfo = (await DbCenter.QueryAsync<VendorSubrange>(sql)).FirstOrDefault();
            if (subrangeinfo != null)
            {
                models.Add(subrangeinfo);
            }

            sql = string.Format(@"select * from osp_vendor_bank_r a
						    where a.form_no ='{0}'", formno);

            var bankinfo = (await DbCenter.QueryAsync<VendorBank>(sql)).FirstOrDefault();
            if (bankinfo != null)
            {
                models.Add(bankinfo);
            }

            foreach (var item in models)
            {
                // 2. 💡 呼叫剛剛寫好的擴充方法，此時字典的 Key 就會是 "form_no" 而非 C# 的 FormNo
                Dictionary<string, object> jsonFields = ((object)item).ToJsonFieldDictionary();

                foreach (var stepKey in dicMapping.Keys)
                {
                    // 拿到該步驟所有的動態欄位定義清單
                    List<BaseDynamicField> fieldsInStep = dicMapping[stepKey];

                    if (fieldsInStep == null) continue;

                    foreach (var field in fieldsInStep)
                    {
                        if (field.ColId == "upload_ssaaf")
                        {
                            if (jsonFields.TryGetValue("upload_ssaaf_id", out var dbValue2))
                            {
                                field.DefaultValue = dbValue2?.ToString();
                            }
                        }
                        // 3. 核心比對：檢查資料庫查出來的欄位(jsonFields)，有沒有對應前端這個 FieldCode
                        // 備註：使用 TryGetValue 效能最好，且能防範欄位不存在時報錯
                        if (jsonFields.TryGetValue(field.ColId, out var dbValue))
                        {
                            // 4. 完美匹配成功！將資料庫的值塞入 FieldValue
                            // 依據您的欄位型別，轉為字串儲存；若資料庫為 null 則給予空字串或 null
                            field.ColValue = dbValue?.ToString();

                            // 偵錯日誌（可選）
                            // Console.WriteLine($"成功配對：步驟[{stepKey}] 欄位[{field.FieldCode}] 填入值 ➡️ {field.FieldValue}");
                        }
                    }
                }
            }

            return dicMapping;

        }


        public async Task<Dictionary<string, List<BaseDynamicField>>> MappingSendData(Dictionary<string, List<BaseDynamicField>> dicMapping, Dictionary<string, object>? SendData)
        {
            var finalData = ExtendTool.MapKeysToJsonProperty<vmMakerDetail>(SendData);


            var sql = string.Format(@"select * from osp_column_config_attr a
						    where  a.type = 'Copy_Data' and a.[function] =@function
							and a.Active ='Y'");
            var result = await DbCenter.QueryAsync<dynamic>(sql, new { function = SendData["EventName"] });

            var dictmp = result.ToDictionary(
                    x => (string)x.column_code,
                    x => (string)x.attr_value1
                );

            if (finalData != null)
            {
                foreach (var section in dicMapping)
                {
                    foreach (var field in section.Value)
                    {
                        // 1. 從資料庫配置 (dicConfig) 找該欄位的規則 (O/Y/N)
                        if (dictmp.TryGetValue(field.ColId, out string rule))
                        {
                            // 2. 從前端傳入的 SendData 找該欄位的實際數值
                            finalData.TryGetValue(field.ColId, out string? actualValue);
                            string colValue = actualValue ?? "";

                            switch (rule.ToUpper())
                            {
                                case "O": // Copy 不可改 (唯讀)
                                    field.ColValue = colValue;
                                    field.Readonly = true;
                                    break;

                                case "Y": // Copy 可改 (非唯讀)
                                    field.ColValue = colValue;
                                    field.Readonly = false;
                                    break;

                                case "N": // 不 Copy
                                    field.Readonly = false;
                                    // 不覆蓋 field.ColValue，維持預設
                                    break;
                            }
                        }
                    }
                }
            }
            return dicMapping;
        }
        public async Task<string> SendAsync(FormRequest req)
        {
            try
            {
                string message = "";
                var data = JsonConvert.DeserializeObject<SupplierSaveViewModel>(req.Payload);
                if (data == null)
                {
                    throw new Exception("資料序列化錯誤");
                }

                VendorHeader vendorHeader = await DbCenter.GetAsync<VendorHeader>(new { HeaderId = data.FormInfo.headerid });

                data.Step2.PopulateTo(vendorHeader, new[] { "upload_ssaaf" });

                var formKind = _flowerService.GetFormKind();
                var iFormNo = Convert.ToInt32(data.FormInfo.formno);
                var applyType = "NS";
                var formStatus = _flowerService.GetFormStatus(iFormNo);

                LogHelper.Info("SubmitFlower Page> btnSubmit_click> formno:" + iFormNo + ";formStatus : " + formStatus);
                if (string.IsNullOrEmpty(formStatus))
                {
                    throw new BusinessException("表單已過期，無法送簽，請重新申請表單！\nForm NO has expired, Please apply a new form!");
                }

                #region -- [FlowER] 取簽核參數：(1)設定簽核關卡人員、(2)設定參數-FLAG、SupplierType、Cont_Flag、OFAC_CONFIRM、UFLPA_FLAG、STOCK_FLAG... --             

                var objParas1 = _flowerService.FlowerParams(
                    vendorHeader.CompanyCode,  //company_code.value
                    applyType, //目前先傳入"NS", new supplier
                    CurrentUser.EmployeeId,   //CAP的emp no
                    "N", //預設帶N
                    string.IsNullOrEmpty(vendorHeader.ContractCN) ? "" : vendorHeader.ContractCN, //contract_cn.value
                    await Utility.CheckUFLPA(vendorHeader.CompanyEnglishName, vendorHeader.CompanyLocalName, vendorHeader.MakerEnglishName, vendorHeader.MakerLocalName), //用CheckUFLPA(string sSupplierName)檢查
                    "N"  //預設帶N
                );
                if (objParas1 == null)
                {
                    throw new BusinessException("簽核人未設定，請聯繫IT！\nThis OU_Site has not been setted in the config table at apply steps, please connect IT!");

                }
                #endregion -- [FlowER] 取簽核參數：(1)設定簽核關卡人員、(2)設定參數-FLAG、SupplierType、Cont_Flag、OFAC_CONFIRM、UFLPA_FLAG、STOCK_FLAG... --


                //var isRevise = (applyType == "ES");
                //if (isRevise) UpdateFlag("modifyImportantFlag", isImportantInfo, false);

                //[FlowER] AddFlag：配置簽核參數
                _flowerService.FlowERUtil.AddFlag(formKind, iFormNo, objParas1);

                //[FlowER] 送簽
                if (_flowerService.FlowERUtil.SendForm(formKind, iFormNo, CurrentUser.EmployeeId))
                {
                    LogHelper.Info("SubmitFlower Page> btnSubmit_click> FormNo : " + iFormNo.ToString() + " SendForm OK!");
                    var res = _flowerService.FlowERUtil.ActiveForm(formKind, iFormNo);
                    LogHelper.Info("SubmitFlower Page> btnSubmit_click> FormNo : " + iFormNo.ToString() + "  ActiveForm OK!");

                    vendorHeader.FormStatus = "submit";
                    await DbCenter.UpdateAsync(vendorHeader, u => new { u.FormStatus });



                    //if (isRevise)
                    //{
                    //    //申請者為採購,在 SubmitFlower的時候就執行拋Interface,
                    //    //並根據生效日期來   決定是現在執行導入還是Schedule JOB來執行
                    //    var isBuyer = VendorBL.CheckBuyer(_ouSite, _EmpNo);
                    //    if (isBuyer && !isImportantInfo) VendorHeadDAL.UpdateApprovedDate(iFormNo);
                    //}

                    //【註解掉】[AMSC版] 流程已無使用。By Aaron@2025 - 11。修改VendorName需MailAlert all of buyer，Add by Kay@20110823
                    //var company = _Domain;
                    //if (company.ToUpper() == "AUO") MailAlert(_formNo, company);

                    //*返回上一頁。[1] 代表已有申請資料，從「查詢表單頁面(QueryForms.aspx)」而來；反之，為從「申請表單頁面(VendorCodeQuery.aspx)」而來。
                    //var fromUrl = _isSaved == "1" ? $"QueryForms.aspx?domain={_Domain}"
                    //                              : $"VendorCodeQuery.aspx?domain={_Domain}&kind={_applyType}";
                    message = $"送簽成功，表單號 {iFormNo}\nSend Form Success, FormNo {iFormNo}";

                }
                else
                {
                    throw new BusinessException($"送簽異常，util.SendForm回傳false！(FormNo={iFormNo}) \n常見原因為簽核關卡之人員「無有效人事資料」！\n\n Apply Exception! util.SendForm returned false.!");
                }
                return message;

            }
            catch (BusinessException ex)
            {
                LogHelper.Error(ex.Message, ex);
                throw;
            }
            catch (Exception ex)
            {
                LogHelper.Error($"SendAsync 發生非預期系統錯誤。參數: {JsonConvert.SerializeObject(req)}", ex);
                throw new Exception("伺服器處理資料時發生異常，請洽系統管理員。");
            }
        }

        /// <summary>update header中的modify_important_flag 或者 bank 中的 bank_edit_flag，可擴展到其他Flag。add by elvayang @20140304</summary>
        //private void UpdateFlag(string flagName, bool modifyImportantFlag, bool bankeditFlag)
        //{
        //    if (flagName.ToUpper() == "modifyImportantFlag".ToUpper() && modifyImportantFlag)
        //    {
        //        var mainDTO = new VendorHeadDTO
        //        {
        //            FormNo = _formNo.ToInt(),
        //            ModifyImportFlag = modifyImportantFlag ? "Y" : "N"
        //        };

        //        VendorHeadDAL.UpdareVendorHeadFlag(mainDTO);
        //    }
        //    else if (flagName.ToUpper() == "bankeditFlag".ToUpper() && bankeditFlag)
        //    {
        //        //BankDAL.UpdateBankEditFlag
        //        //(
        //        //    form_no: _formNo.ToInt(),
        //        //    bank_edit_flag: (bankeditFlag ? "Y" : "N")
        //        //);
        //    }
        //}


        public async Task<FormInfo> SaveAsync(FormRequest req)
        {
            try
            {
                var data = JsonConvert.DeserializeObject<SupplierSaveViewModel>(req.Payload);
                if (data == null)
                {
                    throw new BusinessException("資料序列化錯誤");
                }

                VendorHeader vendorHeader = null;

                await DbCenter.UseTransactionAsync(async ctx =>
                {
                    if (data.StepContext?.Current == 2)
                    {
                        if (data.Step2 == null)
                        {
                            throw new ArgumentNullException(nameof(data.Step2));
                        }

                        if (!string.IsNullOrEmpty(data.FormInfo?.formno))
                        {
                            vendorHeader = await ctx.GetAsync<VendorHeader>(new { HeaderId = data.FormInfo.headerid });
                            data.Step2["upload_ssaaf"] = string.IsNullOrEmpty(req.File.FileName) ? "" : req.File.FileName;
                            data.Step2.PopulateTo(vendorHeader);
                            await ctx.SaveAsync<VendorHeader>(vendorHeader);
                        }
                        else
                        {
                            data.Step2["upload_ssaaf"] = string.IsNullOrEmpty(req.File.FileName) ? "" : req.File.FileName;
                            vendorHeader = data.Step2.ToModel<VendorHeader>();
                            vendorHeader.FormNo = "8";// _flowerService.GetFormNo(); // 實務上建議換回 _flowerService.GetFormNo()  
                            vendorHeader.EmpNo = CurrentUser.EmployeeId;
                            vendorHeader.EmpDept = CurrentUser.DepartmentId;
                            vendorHeader.EmpName = CurrentUser.RealName;
                            vendorHeader.Email = CurrentUser.Email;
                            vendorHeader.CreateDate = DateTime.Now.ToString("yyyyMMdd");
                            vendorHeader.Active = "Y";
                            vendorHeader.Apply_type = data.Step1.applytype;
                            await ctx.SaveAsync<VendorHeader>(vendorHeader);
                            vendorHeader = await ctx.GetAsync<VendorHeader>(new { FormNo = vendorHeader.FormNo });
                            data.FormInfo.headerid = vendorHeader.HeaderId;
                            data.FormInfo.formno = vendorHeader.FormNo;
                            data.FormInfo.applytype = vendorHeader.Apply_type;
                        }


                        if (req.File.File != null && req.File.Status == "Pending")
                        {
                            FlmFileInfo f = new FlmFileInfo();
                            f.FileId = req.File.FileId ?? "";
                            f.FormNo = data.FormInfo.formno;
                            f.Headerid = data.FormInfo.headerid;
                            f.ItemName = req.File.ItemName;
                            f.ItemId = req.File.ItemId;
                            f.FileName = req.File.FileName;
                            f.File = req.File.File;
                            f.CUser = CurrentUser.EmployeeId;
                            await _fileService.UploadFileAsync(f);
                        }

                        var vendorBank = await ctx.GetAsync<VendorBank>(new { HeaderId = data.FormInfo.headerid });
                        if (vendorBank == null)
                        {
                            vendorBank = new VendorBank();
                            vendorBank.HeaderId = data.FormInfo.headerid;
                            vendorBank.FormNo = data.FormInfo.formno;
                            vendorBank.BankId = await GetMaxIdFormTable("osp_vendor_bank_r", "bank_id", data.FormInfo.formno);
                        }
                        data.Step2.PopulateTo(vendorBank);
                        await ctx.SaveAsync<VendorBank>(vendorBank);


                        var vendorSubrange = await ctx.GetAsync<VendorSubrange>(new { HeaderId = data.FormInfo.headerid });
                        if (vendorSubrange == null)
                        {
                            vendorSubrange = new VendorSubrange();
                            vendorSubrange.HeaderId = data.FormInfo.headerid;
                            vendorSubrange.FormNo = data.FormInfo.formno;
                            vendorSubrange.LineId = await GetMaxIdFormTable("osp_vendor_subrange_r", "line_id", data.FormInfo.formno);
                        }
                        data.Step2.PopulateTo(vendorSubrange);
                        await ctx.SaveAsync<VendorSubrange>(vendorSubrange);

                    }
                    if (data.StepContext.Current == 3)
                    {
                        if (data.Step3 == null)
                        {
                            throw new ArgumentNullException(nameof(data.Step3));
                        }
                        if (string.IsNullOrEmpty(data.FormInfo.headerid))
                        {
                            data.FormInfo.headerid = (await GetHeader(data.FormInfo.formno))?.HeaderId;
                        }
                        var result = JsonConvert.SerializeObject(data.Step3);
                        var ls = ExtendTool.ConvertToVendorFiles(result, data.FormInfo.headerid, data.FormInfo.formno);
                        await ctx.SaveManyAsync<VendorFile>(ls);
                    }
                });

                //ExtendTool.DeleteFile(data.FormInfo.formno, data.Step2["upload_ssaaf"].ToString());

                return new FormInfo
                {
                    headerid = data.FormInfo.headerid,
                    formno = data.FormInfo.formno,
                    applytype = data.FormInfo.applytype
                };
            }
            catch (BusinessException ex)
            {
                LogHelper.Error(ex.Message, ex);
                throw;
            }
            catch (Exception ex)
            {
                LogHelper.Error($"SaveAsync 發生非預期系統錯誤。參數: {JsonConvert.SerializeObject(req)}", ex);
                throw new Exception("伺服器處理資料時發生異常，請洽系統管理員。");
            }
        }



        public async Task<Dictionary<string, string>> UploadSSAAF(IFormFile file)
        {
            var sql = string.Format(@"select column_code,SSAF_Sheet,SSAF_Column from osp_column_config_c
                                    where SSAF_Sheet <> 'NA' and Active ='Y'");
            var result = (await DbCenter.QueryAsync<SSAAField>(sql, new { })).ToList();
            using (var stream = new MemoryStream())
            {
                await file.CopyToAsync(stream);

                foreach (var f in result)
                {
                    stream.Position = 0;
                    var row = stream.Query(sheetName: f.SSAF_Sheet, startCell: f.SSAF_Column).FirstOrDefault() as IDictionary<string, object>;

                    if (row != null)
                    {
                        var cellValue = row.Values.FirstOrDefault();
                        f.SSAF_Column_value = cellValue?.ToString();
                    }
                }
            }

            return result.ToDictionary(
                   x => (string)x.column_code,
                   x => (string)x.SSAF_Column_value
               );
        }
        public async Task<List<SupplierItem>> GetSupplier()
        {
            return null;
            //var sql = string.Format(@"select column_code,SSAF_Sheet,SSAF_Column from osp_column_config_c
            //                        where SSAF_Sheet <> 'NA' and Active ='Y'");
            //var result = (await AmscDb.QueryAsync<SSAAField>(sql, new { })).ToList();
        }
        public async Task<bool> UploadFileAsync(List<FlmFileInfo> files)
        {
            foreach (var item in files)
            {
                var bDelete = false;
                var sql = string.Format(@"select fileid from osp_vendor_file_r
                                    where  item_id ='{0}' and fileName='{1}' and formno ='{2}' 
                                    and Active ='Y'", item.ItemId, item.FileName, item.FormNo);
                var fileId = (await DbCenter.QueryAsync<string>(sql, new { })).ToList().FirstOrDefault();
                if (!string.IsNullOrEmpty(fileId))
                {
                    if (await _fileService.CheckFileIDByFileIdAsync(fileId))
                    {
                        bDelete = await _fileService.DeleteFileFromFileServerAsync(fileId, item.CUser);
                    }
                }
                else
                {
                    bDelete = true;
                }

                if (!bDelete)
                {
                    throw new BusinessException("刪除檔案失敗");
                }

                var bizID = "vendor" + "_" + item.FormNo;

                if (item.File != null && item.File.Length > 0)
                {
                    using (var memoryStream = new MemoryStream())
                    {
                        await item.File.CopyToAsync(memoryStream);
                        byte[] fileBytes = memoryStream.ToArray();
                        var uploadfileId = await _fileService.UploadFileToFLMAsync(fileBytes, item.FileName, bizID, item.CUser);

                        if (!string.IsNullOrEmpty(fileId))
                        {
                            sql = string.Format(@"update osp_vendor_file_r
                                    set FileId ='{3}'
                                    where  item_id ='{0}' and fileName='{1}' and formno ='{2}'
                                    and Active ='Y'", item.ItemId, item.FileName, item.FormNo, fileId);
                        }
                        else
                        {
                            sql = string.Format(@"insert into osp_vendor_file_r(Headerid,FormNo,item_id,item_name,FileId,FileName,Active,CUser,CDate)
                                                  values('{0}','{1}','{2}','{3}','{4}','{5}','{6}','{7}',getdate())",

                                                 "", item.FormNo, item.ItemId, "", uploadfileId, item.FileName, "Y", item.CUser);
                        }

                        return await DbCenter.ExecuteAsync(sql);
                    }
                }
            }
            return true;
        }

        public async Task<string> GetMaxIdFormTable(string table, string column, string formno)
        {
            string sql = string.Format(@"SELECT CASE 
                WHEN EXISTS (SELECT 1 FROM {0} WHERE form_no = @FormNo)
                THEN (SELECT TOP 1 {2} FROM {1} WHERE form_no = @FormNo)
                ELSE (SELECT COALESCE(MAX({3}), 0) + 1 FROM {4})
               END", table, table, column, column, table);
            return await DbCenter.ExecuteScalarAsync<string>(sql, new { FormNo = formno });
        }

        private async Task<VendorHeader> GetHeader(string formno)
        {
            const string sql = @"SELECT TOP 1 * 
                                     FROM osp_vendor_header_r 
                                     WHERE form_no = @FormNo 
                                     ORDER BY headerid DESC;";
            return await DbCenter.QuerySingleAsync<VendorHeader>(sql, new { FormNo = formno });
        }
        public async Task<List<FlmFileInfo>> GetFileAsync(string itemKey, string formNo)
        {
            var sql = string.Format(@"select item_id,fileid,filename from osp_vendor_file_r 
                                    where  item_id ='{0}'  and formno ='{1}'
                                    and Active ='Y'", itemKey, formNo);
            var result = await DbCenter.QueryAsync<FlmFileInfo>(sql);
            return result?.ToList() ?? new List<FlmFileInfo>();
        }


        public async Task<List<SupplierItem>> QuerySuppierAll(vmSupplierQuery model)
        {
            string wheresql = "";
            if (!string.IsNullOrEmpty(model.VendorName))
            {
                wheresql += string.Format(@"and a.company_local_name ='{0}'", model.VendorName);
            }
            if (!string.IsNullOrEmpty(model.VendorCode))
            {
                wheresql += string.Format(@"and a.vendor_code ='{0}'", model.VendorCode);
            }
            if (!string.IsNullOrEmpty(model.FormNo))
            {
                wheresql += string.Format(@"and a.form_no ='{0}'", model.FormNo);
            }
            if (!string.IsNullOrEmpty(model.FormStatus))
            {
                wheresql += string.Format(@"and a.form_status ='{0}'", model.FormStatus);
            }
            if (!string.IsNullOrEmpty(model.CreateDateFrom?.ToString("yyyy-MM-dd")) && !string.IsNullOrEmpty(model.CreateDateTo?.ToString("yyyy-MM-dd")))
            {
                wheresql += string.Format(@"and a.create_date BETWEEN '{0}' AND '{1}'", model.CreateDateFrom?.ToString("yyyy-MM-dd"), model.CreateDateTo?.ToString("yyyy-MM-dd"));
            }
            else if (!string.IsNullOrEmpty(model.CreateDateFrom?.ToString("yyyy-MM-dd")) && string.IsNullOrEmpty(model.CreateDateTo?.ToString("yyyy-MM-dd")))
            {
                wheresql += string.Format(@"and a.create_date <= '{0}'", model.CreateDateTo?.ToString("yyyy-MM-dd"));
            }
            else if (string.IsNullOrEmpty(model.CreateDateFrom?.ToString("yyyy-MM-dd")) && !string.IsNullOrEmpty(model.CreateDateTo?.ToString("yyyy-MM-dd")))
            {
                wheresql += string.Format(@"and a.create_date >='{0}'", model.CreateDateFrom?.ToString("yyyy-MM-dd"));
            }

            var sql = string.Format(@" select a.form_no FormNo,a.headerid HeaderId,
                   a.company_local_name VendorName,
                   a.vendor_code  VendorCode, 
                   a.create_date CreateDate,
                   a.form_status  FlowerStatus ,
                   a.apply_type ApplyType,
                   b.emp_name Applicant,
                   b.org_id Department
                   from osp_vendor_header_r a, emp_data_all b 
                   where 1=1 {0}
                   and a.emp_no = b.emp_no 
                   and form_no is not null", wheresql);
            var result = await DbCenter.QueryAsync<SupplierItem>(sql);

            return result?.ToList() ?? new List<SupplierItem>();

        }

        public async Task<SupplierApplicationViewModel> GetSupplierApplicationAsync(QueryStringDto ParsedQueries)
        {
            // 1. 編寫 SQL 語句（使用 Dapper 支持的多段查詢，並用參數化查詢防止 SQL 注入）
            var sql = @"
        -- 第一段：查詢主表資料
         select form_no FormNo
              ,emp_name Applier
              ,create_date ApplyDate
              ,company_code CompanyCode
              ,form_status FormStatus
              ,company_code OuSite
              ,apply_type  VendorType
              ,apply_type SupplierType
              ,effective_date EffectiveDate
              ,'' GroupName
              ,'' GroupCode
              , emp_no EmpNo
              ,cont_flag ContFlag
,trading_partner_no TradingPartnerNo
,apply_type ApplyType
              from osp_vendor_header_r 
             where form_no = @FormNo;

        -- 第二段：查詢 Vendor Subrange 清單
          SELECT 
     ssr_description SsrName, Currency, payment_term PaymentName, tax_code TaxDesc, contacts_phone Phone, contacts_mail Email, '' Fax,  freight_term FreightCode, '' FobCode
  FROM  osp_vendor_subrange_r
        WHERE form_no = @FormNo;

        -- 第三段：查詢 Bank Line 清單
         SELECT  bank_name BankName
                ,bank_branch BankBranch
                ,account_name BankAccountName
                ,account_number BankAccountNo
                ,branch_country Country
                ,branch_province Province
                ,'' City
                ,branch_address BranchAddress
                ,bank_key BankKey 
                ,f_bank_number FBankNumber
                ,f_branch_number FBranchNumber
                ,f_bank_name FBankName
                ,f_branch_name FBankBranch
                ,f_swift_code FSwiftCode
         from osp_vendor_bank_r
         WHERE form_no = @FormNo;
    ";


            var viewModel = new SupplierApplicationViewModel();

            var formNo = ParsedQueries.FormNo;

            using (var multi = await DbCenter.QueryMultipleAsync(sql, new { FormNo = formNo }))
            {
                var vendorData = await multi.ReadFirstOrDefaultAsync<VendorItem>();
                viewModel.VendorItem = vendorData ?? new VendorItem();
                var subranges = await multi.ReadAsync<VendorSubrangeItem>();
                viewModel.VendorSubranges = subranges.ToList();
                var bankLines = await multi.ReadAsync<BankLineItem>();
                viewModel.BankLines = bankLines.ToList();
            }
            LogHelper.Info(JsonConvert.SerializeObject(viewModel));
            return viewModel;
        }

        //public async Task<List<vmMakerDetail>> GetSupplierDetail(string makername,string companyid, string makerlist)
        //{ 
        //    var client = new wsMakerGroupServiceSoapClient(wsMakerGroupServiceSoapClient.EndpointConfiguration.wsMakerGroupServiceSoap);
        //    try
        //    { 
        //        var xmlResult = await client.GetMakerCheckGroupAsync(makername, companyid, "");

        //        var nodes = xmlResult?.Nodes;

        //        if (nodes == null || !nodes.Any())
        //        {
        //            return null;
        //        }

        //        XElement[] xmlArray = nodes.ToArray(); 
        //        DataTable dt = new DataTable();
        //        var rows = xmlArray[1].Descendants().Where(x => x.Name.LocalName == "Table").ToList();

        //        if (rows.Any())
        //        {
        //            // 自動根據第一筆資料的子標籤建立欄位
        //            foreach (var col in rows[0].Elements())
        //                dt.Columns.Add(col.Name.LocalName);

        //            // 填充資料
        //            foreach (var row in rows)
        //                dt.Rows.Add(row.Elements().Select(e => e.Value).ToArray());
        //        }

        //        var dd = dt.ToList<vmMakerDetail>();

        //        return dd; 
        //    }
        //    catch (Exception ex)
        //    {
        //        // Log Error
        //        return null;
        //    }
        //    finally
        //    {
        //        await client.CloseAsync();
        //    }
        //}



    }
    public class FormRequest
    {
        public FlmFileInfo File { get; set; }
        public string Payload { get; set; }
    }
    public class SSAAField
    {
        public string column_code { get; set; }
        public string SSAF_Sheet { get; set; }
        public string SSAF_Column { get; set; }
        public string SSAF_Column_value { get; set; }
    }



}
