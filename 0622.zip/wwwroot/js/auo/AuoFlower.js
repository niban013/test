﻿var BPM_Origin = window.AppConfig.FlowerSettings.BPMORIGIN;
function postMessageToBPM_PageLoad() {
    parent.parent.postMessage('finishInit', BPM_Origin);
}

function BPMAlert(msg) {
    let toastConfig = { showMsg: 'Y', text: msg };
    parent.parent.postMessage(toastConfig, BPM_Origin);
}

function BPMProgress(b) {
    let param = {
        type: "progress",
        bprogress: b
    }
    parent.parent.postMessage(param, BPM_Origin);
}

window.addEventListener('message', async function (e) {
    await doLocalFunction(e);
});

// 2. 核心控制邏輯
async function doLocalFunction(e) {
    var result = false;
    console.log("BPM 收到訊息:", e.data);

    // 檢查目前頁面是否有實作對應的非同步函式，有的話才執行
    if (e.data == 'approveFormYes') {
        if (typeof window.OnApproveFormYes === 'function') {
            result = await window.OnApproveFormYes();
        } else {
            console.warn("頁面未實作 window.OnApproveFormYes");
            result = false;
        }
    }

    if (e.data == 'approveFormNo') {
        if (typeof window.OnApproveFormNo === 'function') {
            result = await window.OnApproveFormNo();
        } else {
            console.warn("頁面未實作 window.OnApproveFormNo");
            result = false;
        }
    }

    // 3. 驗證通過，回傳給最上層父視窗
    if (result === true) {
        // 確保 window.BPM_Origin 存在，若不存在則預設為 '*'
        var origin = window.BPM_Origin || '*';
        parent.parent.postMessage(e.data, origin);
    }
}


// =========================
// ApiClient (transport layer)
// =========================
const ApiClient = {

    async run(module, action, payload) {
        const request = {
            module,
            action,
            payload: JSON.stringify(payload)

        };
        console.log("send:", request);
        console.log("json:", JSON.stringify(request));
        const currentQuery = window.location.search; 
        console.log('currentQuery:' + currentQuery)
        const res = await fetch(`${window.AppBasePath}flower/run/${currentQuery}`, {
            method: "POST",
            headers: {
                "X-Requested-With": "XMLHttpRequest"
            },
            body: JSON.stringify(request)
        });

        const json = await res.json();

        if (!json.Success) {
            throw new Error(json.Message || "Flower failed");
        }

        return json.Data;
    }
};

// =========================
// Context factory
// =========================
function createContext(module, action, payload) {

    return {
        module,
        action,
        payload,
        result: null,
        error: null,
        loading: false,
        startTime: Date.now()
    };
}

// =========================
// Default Hooks
// =========================
const DefaultHooks = {

    async before(ctx) { },

    async after(ctx) {
        console.log(`[Flower] ${ctx.module}.${ctx.action} success`);
    },

    async error(ctx) {
        console.error(`[Flower] ${ctx.module}.${ctx.action} error`, ctx.error);
    },

    async finally(ctx) { }
};

// =========================
// Core Engine
// =========================
const FlowerCore = {

    hooks: DefaultHooks,

    async execute(module, action, payload) {

        const ctx = createContext(module, action, payload);

        try {

            ctx.loading = true;

            await this.hooks.before(ctx);

            ctx.result = await ApiClient.run(
                module,
                action,
                payload
            );

            await this.hooks.after(ctx);

            return ctx.result;
        }
        catch (err) {

            ctx.error = err;

            await this.hooks.error(ctx);

            throw err;
        }
        finally {

            ctx.loading = false;

            await this.hooks.finally(ctx);
        }
    }
};

// =========================
// Module Proxy Factory
// =========================
function createModule(moduleName) {

    return new Proxy({}, {

        get(_, action) {

            return async (payload) => {

                return await FlowerCore.execute(
                    moduleName,
                    action,
                    payload
                );
            };
        }
    });
}

// =========================
// Flower Framework (Public API)
// =========================
const AuoFlower = (() => {

    const modules = {};

    return {

        // get module instance
        use(moduleName) {

            if (!modules[moduleName]) {
                modules[moduleName] = createModule(moduleName);
            }

            return modules[moduleName];
        },

        // global hooks
        setHooks(customHooks) {

            Object.assign(FlowerCore.hooks, customHooks);
        },

        // optional: replace core hooks
        hooks: FlowerCore.hooks
    };

})();