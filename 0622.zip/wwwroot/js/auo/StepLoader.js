﻿ function renderError(err, container) {
    if (!container) container = document.getElementById("step-container");

    container.innerHTML = `
        <div style="color:red;padding:12px">
            ${err.message}
        </div>
    `;

    return container;
}

window.StepRegistry = (() => {
    const modules = {};
    const waiters = {};
    return {
        register(name, module) {
            modules[name] = module;
            if (waiters[name]) {
                waiters[name].forEach(fn => fn(module));
                delete waiters[name];
            }
        },

        get(name) {
            return modules[name];
        },

        wait(name, timeoutMs = 10000) {
            return new Promise((resolve, reject) => {

                // 已存在直接回
                if (modules[name]) {
                    resolve(modules[name]);
                    return;
                }

                const timer = setTimeout(() => {
                    //reject(new Error(`Step module timeout: ${name}`));
                }, timeoutMs);

                waiters[name] ||= [];
                waiters[name].push((module) => {
                    clearTimeout(timer);
                    resolve(module);
                });
            });
        },

        // ⭐ 新增（很重要）
        clear(name) {
            delete modules[name];
        }
    };

})();
window.StepLifecycle = (() => {
    function injectHtmlWithScripts(container, html) {
        try {
            const parser = new DOMParser();
            const doc = parser.parseFromString(html, "text/html");

            container.innerHTML = "";

            doc.body.childNodes.forEach(node => {
                if (node.tagName === "SCRIPT") return;
                container.appendChild(node.cloneNode(true));
            });

            doc.querySelectorAll("script").forEach(oldScript => {
                const s = document.createElement("script");

                if (oldScript.src) {
                    s.src = oldScript.src;
                } else {
                    s.textContent = oldScript.textContent;
                }

                document.body.appendChild(s);
            });

            return true; // ✅ 成功

        } catch (err) {
            console.error("inject failed:", err);
            return false; // ❌ 直接 fail
        }
    }
    async function render({ key, html, container,  ctx }) {

        try {

            // =====================
            // Destroy old step
            // =====================

            try {
                ctx.currentPage?.destroy?.(container,ctx.currentStep);

            } catch (e) {

                console.warn("destroy failed:",e);
            }

            // =====================
            // Cleanup
            // =====================

            window.FieldBinder?.unbindAll?.(container);

            window.StepRegistry?.clear?.(key);

            window.GraphV2?.unregisterStep?.(key);

            // =====================
            // Inject html
            // =====================

            let isInject = injectHtmlWithScripts(container,html);
            if (!isInject) {
                throw new Error(`injectHtmlWithScripts Fail:`);
            }
            // =====================
            // Wait module register
            // =====================

            let module = window.StepRegistry.get(key);

            if (!module) { 
                module = await window.StepRegistry.wait(key,8000);
            }

            if (!module) {
                throw new Error(`Step module not registered: ${key}`);
            }

            // =====================
            // Init
            // =====================

            module.init?.(container,
                {
                    formData: AppBootstrap.get("FlowStore"),
                    currentStep: ctx.currentStep
                }
            );

            ctx.currentPage = module;

            return container;

        } catch (err) {
            console.error("Step render failed:",err);

            return renderError(err, container);
        }
    }

    return {
        render
    };

})();
window.StepLoader = (() => { 
    async function load(stepIndex, ctx ) {
        function buildPayload(stepIndex,ctx) {

            const store = AppBootstrap.get("FlowStore");

            const storeKey =  "decision";

            const prevStep =  stepIndex > 1 ? stepIndex - 1  : stepIndex;

            const extraData = store.get(`step${prevStep}`, storeKey);

            window.FlowStore.safeSet("supplier","FormInfo",ctx.boot?.FormInfo);

            let flowData;

            if (ctx.boot?.flowData && ctx.boot?.flowData?.step1 == null && stepIndex <= 2) {

                flowData = ctx.boot.flowData;

            } else { 
                flowData =
                    extraData
                        ? {
                            [`step${stepIndex}`]: {
                                types: extraData.type,
                                datas: JSON.parse(JSON.stringify(extraData.value))
                            }
                        }
                        : null;
            }

            return {
                stepIndex,
                FormInfo: ctx.boot?.FormInfo,
                flowData
            };
        }
        async function fetchStep(payload) { 
            const res = await fetch(
                        `${window.AppBasePath}Supplier/Step`,
                        {
                            method: "POST",
                            headers: {
                                "Content-Type": "application/json",
                                "X-Requested-With": "XMLHttpRequest"
                            },
                            body:JSON.stringify(payload)
                        }
                    );

            return {
                html: await res.text(),
                contentType:  res.headers.get("content-type") || "",
                response: res
            };
        }
        async function handleServerResponse(result) {

            const { html, contentType } = result;

            if (!contentType.includes("application/json")) {

                return {
                    success: true,
                    html
                };
            }

            const data = JSON.parse(html);

            if (data.Success) { 
                return {
                    success: true,
                    html
                };
            }

            window.__FLOW_ERROR__ = true;

            window.dispatchEvent(new CustomEvent("flow-error"));

            switch (data.UiMode) {

                case "Modal": 
                    showAlert( data.Title ??"提示",data.Message,"warning"); 
                    break; 
                case "Redirect": 
                    location.href =  data.RedirectUrl || "/Error/Index"; 
                    break; 
                case "Inline": {
                    const container =  document.getElementById("step-container");

                    if (!container) { 
                        location.href =  data.RedirectUrl || "/Error/Index"; 
                        break;
                    } 
                    container.innerHTML =  data.Html || ""; 
                    break;
                }
            }

            return {
                success: false
            };
        }
        try { 
            const payload = buildPayload(stepIndex,ctx);

            const result = await fetchStep(payload);

            const response = await handleServerResponse(result);
           
            if (!response.success) {
                return;
            }

            return await StepLifecycle.render({
                key: `step${stepIndex}`,
                html: response.html,
                container: document.getElementById("step-container"),
                ctx
            });

        } catch (err) { 
            console.error("load failed:", err); 
            //throw err;
            return renderError(err,document.getElementById("step-container"));
        }
    } 
    return { load };

})();