﻿window.UiRules = (() => { 
    function findField(stepKey, field) {

        const [fieldName, colRef] = field.split('.');

        const selector = colRef
            ? `[data-step='${stepKey}'][data-field='${fieldName}'][data-col='${colRef}']`
            : `[data-step='${stepKey}'][data-field='${fieldName}']`;

        return document.querySelector(selector);
    }
    function commit(stepKey, field, value) {
        GraphV2.notify(stepKey, field, value);
    }
    // =====================================================
    // UI Scheduler
    // =====================================================

    let uiQueue = [];
    let scheduled = false;

    function scheduleUI(fn) {

        uiQueue.push(fn);

        if (scheduled) return;

        scheduled = true;

        setTimeout(flushUI, 0);
    }

    function flushUI() {

        const tasks = uiQueue;

        uiQueue = [];
        scheduled = false;

        for (const fn of tasks) {
            fn();
        }
    }
    const getRealFieldValue = (stepKey, groupEl, data,targetField) => {
        // 1. data cache 優先
        if (data?.[targetField] !== undefined && data?.[targetField] !== null) {
            return data[targetField];
        }

        // 2. 找 DOM
        const fieldEl =
            document.querySelector(`[data-step='${stepKey}'][data-field='${targetField}']`) ||
            groupEl.querySelector(`[data-field='${targetField}']`);

        if (!fieldEl) return '';

        // =========================
        // SELECT（核心）
        // =========================
        if (fieldEl.tagName === "SELECT") {
            return fieldEl.value ?? '';
        }

        // =========================
        // INPUT / TEXTAREA
        // =========================
        if (fieldEl.tagName === "INPUT" || fieldEl.tagName === "TEXTAREA") {
            return fieldEl.value ?? '';
        }

        // =========================
        // fallback（保底）
        // =========================
        return fieldEl.value ?? '';
    };
    // =====================================================
    // Registry
    // =====================================================

    const registry = new Map();

    
    // =====================================================
    // Renderers
    // =====================================================

    const renderers = {

        // -----------------------------------------
        // dynamicOptions (動態異步載入下拉選單選項 + 清空舊值)
        // -----------------------------------------
        async dynamicOptions({ stepKey, field, value, data, ui }) {
            const sourceValue = value || document.querySelector(`[data-field='${field}']`)?.value;
            const targetField = ui.targetField;
            const apiMethod = ui.apiMethod;
            const apiKey = ui.apiKey || field;

            const isUserAction = window.FlowStore.isTouched(stepKey, field);

            // 1. 如果主調欄位沒值，清空目標下拉選單的「選項」與「數值」
            if (!sourceValue) {
                scheduleUI(() => {
                    window.FieldBinder.setOptions(stepKey, targetField, []);
                    const targetEl = document.querySelector(`[data-step='${stepKey}'][data-field='${targetField}']`);
                    if (targetEl) targetEl.value = "";
                });
                return { patch: { [targetField]: "" } };
            }

            try {
                // 2. 呼叫 API 載入清單
                const params = { [apiKey]: sourceValue };
                const optionList = await callAsmxProxy(apiMethod, params);

                // 3. 更新目標下拉選單的選項
                scheduleUI(() => {
                    window.FieldBinder.setOptions(stepKey, targetField, optionList || []);

                    const targetEl = document.querySelector(`[data-step='${stepKey}'][data-field='${targetField}']`);
                    if (!targetEl) return;

                    if (isUserAction) {
                        // 4. 如果是使用者手動變更，才清空畫面上的 TEXT / VALUE
                        targetEl.value = "";
                        targetEl.dispatchEvent(new Event('change', { bubbles: true }));
                    } else {
                        // 初始化情境：重新灌入已有的舊值，確保畫面選中
                        const existingValue = data?.[targetField] || targetEl.dataset.value;
                        if (existingValue !== undefined && existingValue !== null) {

                            // 關鍵修改 1：不論是否 disabled，強制設定 value 
                            targetEl.value = existingValue;

                            // 關鍵修改 2：初始化後同樣派發 change 事件，確保 disabled 狀態下 UI 也能同步更新
                            targetEl.dispatchEvent(new Event('change', { bubbles: true }));
                        }
                    }
                });


                // 5. 如果是使用者手動變更，回傳 patch 抹除狀態庫裡的舊值；初始化則不回傳 patch（保留原狀態）
                if (isUserAction) {
                    return { patch: { [targetField]: "" } };
                }

            } catch (error) {
                showAlert('代理請求失敗', `${apiMethod}`, 'error');
                scheduleUI(() => {
                    window.FieldBinder.setOptions(stepKey, targetField, []);
                    const targetEl = document.querySelector(`[data-step='${stepKey}'][data-field='${targetField}']`);
                    if (targetEl) targetEl.value = "";
                });
                return { patch: { [targetField]: "" } };
            }
        }
,


        // -----------------------------------------
        // specialRadio
        // -----------------------------------------
        specialRadio({stepKey, field,value }) {
            scheduleUI(() => {
                window.FieldBinder.setSpecailRadio(
                    stepKey,
                    field,
                    value
                );
            });
        },

        // -----------------------------------------
        // toggleGroup
        // -----------------------------------------
        toggleGroup({ stepKey, field, value, data, ui }) {
            scheduleUI(() => {
                const groupEl = document.querySelector(`[data-group="${ui.group}"]`);
                if (!groupEl) return;

                const collapse = groupEl.querySelector(".accordion-collapse");
                const fields = groupEl.querySelectorAll("[data-field]");

                // 💡 輔助函式：全方位安全獲取任何欄位控制項的最新真實數值
                const getRealFieldValue = (targetField) => {
                    if (data?.[targetField] !== undefined && data?.[targetField] !== null) {
                        return data[targetField];
                    }

                    const fieldEl =
                        document.querySelector(`[data-step='${stepKey}'][data-field='${targetField}']`) ||
                        groupEl.querySelector(`[data-field='${targetField}']`);

                    if (!fieldEl) return '';

                    // =========================
                    // 1. radio group
                    // =========================
                    const radios = fieldEl.querySelectorAll('input[type="radio"]');
                    if (radios.length > 0) {
                        const checked = fieldEl.querySelector('input[type="radio"]:checked');
                        return checked ? checked.value : '';
                    }

                    // =========================
                    // 2. checkbox group（保險）
                    // =========================
                    const checkboxes = fieldEl.querySelectorAll('input[type="checkbox"]');
                    if (checkboxes.length > 0 && checkboxes.length !== 1) {
                        const checked = fieldEl.querySelectorAll('input[type="checkbox"]:checked');
                        return Array.from(checked).map(x => x.value);
                    }

                    // =========================
                    // 3. select (🔥重點新增)
                    // =========================
                    const select = fieldEl.querySelector('select');
                    if (select) {
                        return select.value ?? '';
                    }

                    // =========================
                    // 4. input / textarea
                    // =========================
                    const input = fieldEl.querySelector('input, textarea');
                    if (input) {
                        return input.value ?? '';
                    }

                    // =========================
                    // 5. fallback（直接 element）
                    // =========================
                    if (fieldEl.value !== undefined) {
                        return fieldEl.value;
                    }

                    return '';
                };

                // ==========================================
                // 第一層：群組整體的顯隱判定 (保持動態重抓)
                // ==========================================
                let visible = false;

                if (typeof ui.showWhen === "function") {
                    visible = !!ui.showWhen(getRealFieldValue(field), data);
                } else if (ui.showWhen && typeof ui.showWhen === "object" && !Array.isArray(ui.showWhen)) {
                    visible = true;
                    for (const [targetField, targetValue] of Object.entries(ui.showWhen)) {
                        const actualValue = getRealFieldValue(targetField);

                        let fieldMatch = false;
                        if (Array.isArray(targetValue)) {
                            fieldMatch = targetValue.map(v => String(v).toLowerCase()).includes(String(actualValue).toLowerCase());
                        } else {
                            fieldMatch = String(actualValue).toLowerCase() === String(targetValue).toLowerCase();
                        }

                        if (!fieldMatch) {
                            visible = false;
                            break;
                        }
                    }
                } else if (Array.isArray(ui.showWhen)) {
                    const currentFieldVal = getRealFieldValue(field);
                    visible = ui.showWhen.map(v => String(v).toLowerCase()).includes(String(currentFieldVal).toLowerCase());
                } else {
                    const currentFieldVal = getRealFieldValue(field);
                    visible = String(currentFieldVal).toLowerCase() === String(ui.showWhen).toLowerCase();
                }

                // ==========================================
                // 第二層：動態執行群組與內部個別欄位的顯隱
                // ==========================================
                if (visible) {
                    // 1. 先把大群組秀出來
                    groupEl.classList.remove("d-none");
                    collapse?.classList.add("show");

                    // 💡 核心機制翻轉：預設全開，收集「因不符合指定條件而需要被隱藏」的黑名單欄位
                    const blackListFields = new Set();

                    if (Array.isArray(ui.showFieldsWhen)) {
                        ui.showFieldsWhen.forEach(rule => {
                            let ruleMatched = true;

                            // 檢查這條規則的所有條件是否成立
                            for (const [tField, tValue] of Object.entries(rule.when)) {
                                const actValue = getRealFieldValue(tField);

                                let m = false;
                                if (Array.isArray(tValue)) {
                                    m = tValue.map(v => String(v).toLowerCase()).includes(String(actValue).toLowerCase());
                                } else {
                                    m = String(actValue).toLowerCase() === String(tValue).toLowerCase();
                                }

                                if (!m) {
                                    ruleMatched = false;
                                    break;
                                }
                            }

                            // 💡 核心邏輯轉換：如果規則【不成立】(不等於指定值)，這些指定的欄位就要被放進「隱藏黑名單」中
                            if (!ruleMatched && Array.isArray(rule.showFields)) {
                                rule.showFields.forEach(fName => blackListFields.add(fName));
                            }
                        });
                    }

                    const patch = {};
                    let hasChanges = false;

                    // 2. 開始巡檢群組內的所有欄位
                    fields.forEach(x => {
                        const f = x.dataset.field;
                        if (!f) return;

                        // 💡 判斷當前欄位是否不幸落入隱藏黑名單中
                        const shouldHide = blackListFields.has(f);
                        const wrapper = x.closest(".col-12") || x;

                        if (shouldHide) {
                            // 如果原本就已經是隱藏狀態，跳過不重複處理，防止重複清空與無窮 change 迴圈
                            if (wrapper.classList.contains("d-none")) return;

                            // 執行單一欄位「隱藏與清空」邏輯
                            wrapper.classList.add("d-none");
                            x.disabled = true;

                            FlowStore.setDisabled(stepKey, f, true);
                            FlowStore.clearError(stepKey, f);
                            FlowStore.setStatus(stepKey, f, null);

                            if (x.tagName === "INPUT" || x.tagName === "SELECT" || x.tagName === "TEXTAREA") {
                                clearElementValue(x);
                            } else {
                                const innerInputs = x.querySelectorAll("input, select, textarea");
                                innerInputs.forEach(input => clearElementValue(input));
                            }

                            if (data?.[f] !== undefined && data?.[f] !== null && data?.[f] !== "") {
                                patch[f] = null;
                                hasChanges = true;
                            }
                        } else {
                            // 正常顯示的欄位 (預設全開，或是符合指定值允許開啟的欄位)
                            wrapper.classList.remove("d-none");
                            if (!x.dataset.lockBySys) {
                                x.disabled = false;
                                FlowStore.clearDisabled(stepKey, f);
                            } 
                            
                        }
                    });

                    if (hasChanges && typeof GraphV2.batchNotify === "function") {
                        GraphV2.batchNotify(stepKey, patch);
                    }
                }
                else {
                    // ==========================================
                    // 群組關閉邏輯 (保持你原本的代碼，完全不變)
                    // ==========================================
                    groupEl.classList.add("d-none");
                    collapse?.classList.remove("show");

                    const patch = {};
                    let hasChanges = false;

                    fields.forEach(x => {
                        x.disabled = true;
                        const f = x.dataset.field;
                        if (!f) return;

                        FlowStore.setDisabled(stepKey, f, true);
                        FlowStore.clearError(stepKey, f);
                        FlowStore.setStatus(stepKey, f, null);

                        if (x.tagName === "INPUT" || x.tagName === "SELECT" || x.tagName === "TEXTAREA") {
                            clearElementValue(x);
                        } else {
                            const innerInputs = x.querySelectorAll("input, select, textarea");
                            innerInputs.forEach(input => clearElementValue(input));
                        }

                        if (data?.[f] !== undefined && data?.[f] !== null && data?.[f] !== "") {
                            patch[f] = null;
                            hasChanges = true;
                        }
                    });

                    if (hasChanges && typeof GraphV2.batchNotify === "function") {
                        GraphV2.batchNotify(stepKey, patch);
                    }
                }
            });

            function clearElementValue(el) {
                const wasDisabled = el.disabled;
                if (wasDisabled) el.disabled = false;

                if (el.type === "checkbox" || el.type === "radio") {
                    el.checked = false;
                    el.removeAttribute('checked');
                } else if (el.tagName === "SELECT") {
                    el.selectedIndex = 0;
                    if (el.value !== "") el.value = "";
                } else {
                    el.value = "";
                    el.setAttribute('value', '');
                }

                if (wasDisabled) el.disabled = true;
                el.dispatchEvent(new Event('change', { bubbles: true }));
            }
        }
        ,
        toggleGroup2({ stepKey, field, value, data, ui }) {
            scheduleUI(() => {

                const groupEl = document.querySelector(`[data-group="${ui.group}"]`);
                if (!groupEl) return;

                const collapse = groupEl.querySelector(".accordion-collapse");
                const fields = groupEl.querySelectorAll("[data-field]");

                // =========================
                // 取值（SELECT VERSION）
                // =========================
                const getVal = (f) =>
                    getRealFieldValue(stepKey, groupEl, data, f);

                // =========================
                // group 顯示條件
                // =========================
                let visible = false;

                if (typeof ui.showWhen === "function") {
                    visible = !!ui.showWhen(getVal(field), data);

                } else if (ui.showWhen && typeof ui.showWhen === "object" && !Array.isArray(ui.showWhen)) {

                    visible = true;

                    for (const [targetField, targetValue] of Object.entries(ui.showWhen)) {
                        const actualValue = getVal(targetField);

                        const match = Array.isArray(targetValue)
                            ? targetValue.map(v => String(v).toLowerCase())
                                .includes(String(actualValue).toLowerCase())
                            : String(actualValue).toLowerCase() === String(targetValue).toLowerCase();

                        if (!match) {
                            visible = false;
                            break;
                        }
                    }

                } else if (Array.isArray(ui.showWhen)) {
                    visible = ui.showWhen
                        .map(v => String(v).toLowerCase())
                        .includes(String(getVal(field)).toLowerCase());

                } else {
                    visible = String(getVal(field)).toLowerCase() === String(ui.showWhen).toLowerCase();
                }

                // =========================
                // OPEN GROUP
                // =========================
                if (visible) {

                    groupEl.classList.remove("d-none");
                    collapse?.classList.add("show");

                    const blackListFields = new Set();

                    if (Array.isArray(ui.showFieldsWhen)) {
                        ui.showFieldsWhen.forEach(rule => {

                            let ruleMatched = true;

                            for (const [tField, tValue] of Object.entries(rule.when)) {
                                const actValue = getVal(tField);

                                const match = Array.isArray(tValue)
                                    ? tValue.map(v => String(v).toLowerCase())
                                        .includes(String(actValue).toLowerCase())
                                    : String(actValue).toLowerCase() === String(tValue).toLowerCase();

                                if (!match) {
                                    ruleMatched = false;
                                    break;
                                }
                            }

                            if (!ruleMatched && Array.isArray(rule.showFields)) {
                                rule.showFields.forEach(f => blackListFields.add(f));
                            }
                        });
                    }

                    const patch = {};
                    let hasChanges = false;

                    fields.forEach(x => {
                        const f = x.dataset.field;
                        if (!f) return;

                        const wrapper = x.closest(".col-12") || x;
                        const shouldHide = blackListFields.has(f);

                        if (shouldHide) {

                            if (wrapper.classList.contains("d-none")) return;

                            wrapper.classList.add("d-none");
                            x.disabled = true;

                            FlowStore.setDisabled(stepKey, f, true);
                            FlowStore.clearError(stepKey, f);
                            FlowStore.setStatus(stepKey, f, null);

                            clearElementValue(x);

                            if (data?.[f]) {
                                patch[f] = null;
                                hasChanges = true;
                            }

                        } else {

                            wrapper.classList.remove("d-none");
                            x.disabled = false;
                            FlowStore.clearDisabled(stepKey, f);
                        }
                    });

                    if (hasChanges && typeof GraphV2?.batchNotify === "function") {
                        GraphV2.batchNotify(stepKey, patch);
                    }

                } else {

                    // =========================
                    // CLOSE GROUP
                    // =========================
                    groupEl.classList.add("d-none");
                    collapse?.classList.remove("show");

                    const patch = {};
                    let hasChanges = false;

                    fields.forEach(x => {
                        const f = x.dataset.field;
                        if (!f) return;

                        x.disabled = true;

                        FlowStore.setDisabled(stepKey, f, true);
                        FlowStore.clearError(stepKey, f);
                        FlowStore.setStatus(stepKey, f, null);

                        clearElementValue(x);

                        if (data?.[f]) {
                            patch[f] = null;
                            hasChanges = true;
                        }
                    });

                    if (hasChanges && typeof GraphV2?.batchNotify === "function") {
                        GraphV2.batchNotify(stepKey, patch);
                    }
                }
            });

            function clearElementValue(el) {
                const wasDisabled = el.disabled;
                if (wasDisabled) el.disabled = false;

                if (el.tagName === "SELECT") {
                    el.selectedIndex = 0;
                    el.value = "";
                } else {
                    el.value = "";
                }

                el.dispatchEvent(new Event("change", { bubbles: true }));

                if (wasDisabled) el.disabled = true;
            }
        }

,
         
        // -----------------------------------------
        // asyncOptions
        // -----------------------------------------
        asyncOptions({ stepKey, field,  data, ui }) { 
            scheduleUI(async () => {
                try {
                    const list =  await ui.fetch({ stepKey,  data  });
                    window.FieldBinder.setOptions(stepKey,field,list || []);
                }
                catch (err) {
                    console.error(
                        "asyncOptions error:",
                        err
                    );
                }
            });
        },

        // -----------------------------------------
        // lookupModal
        // -----------------------------------------
        lookupModal({  stepKey, field,  ui }) { 
            scheduleUI(() => { 
                const el = findField(stepKey,field ); 
                if (!el)  return; 
                window.FieldBinder.bindLookupModal(
                    stepKey,
                    field,
                    {
                        modalUrl: ui.modalUrl,
                        modalId: ui.modalId,
                        mapping: ui.mapping
                    }
                );
            });
        },
        readonlyGroup({ stepKey, field, value, ui }) { 
            const bankName = value || document.querySelector(`[data-field='${field}']`)?.value; 
            if (!isEmpty(bankName) && bankName.toLowerCase() === 'other') { 
            
                    const targetFields = ui.targetFields || ["bank_key", "bank_name", "branch_country", "bank_branch", "swift_code"];
                    const label = ui.label || "同主檔資料"; 
                    window.FieldBinder.bindReadonlyGroup(
                        stepKey,
                        field,
                        targetFields.map(f => ({ field: f })),
                        label
                    ); 
            }
        }
    };

    // =====================================================
    // Register
    // =====================================================

    function register(cfg) { 
        const {
            stepKey,
            field,
            deps = [field],
            ui
        } = cfg;

        const id = `ui.${ui.type}.${stepKey}.${field}`;

        if (GraphV2.has(id)) return;

        GraphV2.register({ 
            id: id, 
            stepKey, 
            type: "ui", 
            deps, 
            run: async ({data,  stepKey }) => {

                const renderer =  renderers[ui.type];

                if (!renderer)  return;

                await renderer({
                    stepKey,
                    field,
                    value: data?.[field],
                    data,
                    ui
                });
            }
        });


        //if (deps && deps.length > 0) {
        //    const primaryDep = deps[0];
        //    const el = findField(stepKey, primaryDep);
        //    if (el && el.readOnly) {
        //        const currentValue = el.value || "";
        //        // 戳一下其中一個依賴項，GraphV2 就會連帶觸發這個群組的 run 函式
        //        GraphV2.notify(stepKey, primaryDep, currentValue);
        //    }
        //}


        //const el = findField(stepKey, field);

        //// 2. 如果元素存在，且目前已經被打了 disabled
        //if (el && el.disabled) {
        //    // 抓取目前的初始值 (如果有 value 屬性就拿，沒有就帶空字串)
        //    const currentValue = el.value || "";

        //    // 3. 既然它裝聾作啞不會動，我們在背後手動開一槍通知 GraphV2 發動 run
        //    GraphV2.notify(stepKey, field, currentValue);
        //}
    }

    return { 
        register, 
    };

})();