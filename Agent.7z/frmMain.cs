﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.Collections.Concurrent;
using System.Threading;

namespace InnoDriveAgent
{
    public partial class frmMain : Form
    {
        static CancellationTokenSource ctsLog;
        static CancellationToken ctsLogToken;
        public frmMain()
        {
            InitializeComponent();

        }
        private async void LogMonitor(CancellationToken cancellationToken)
        {
            while (true)
            {
                if (cancellationToken.IsCancellationRequested)
                {
                    return;
                }
                while (logQueue.Count > 0)
                {
                    ///await Task.Delay(TimeSpan.FromSeconds(1));
                    String logInfo = "";
                    logQueue.TryDequeue(out logInfo);
                    rtxtShow.Invoke(new Action(() =>
                    {
                        if (logInfo != null && logInfo.Contains("ERROR") || logInfo.Contains("error"))
                        {
                            //高亮显示
                            rtxtShow.SelectionStart = rtxtShow.Text.Length;
                            rtxtShow.SelectionLength = logInfo.Length;
                            rtxtShow.SelectionColor = Color.FromName("Red");
                        }
                        rtxtShow.AppendText(logInfo + "\r\n");
                    }));
                }
            }
        }
        long Offset = 0;//初始化偏移
        String fileName = "";
        private static ConcurrentQueue<String> logQueue = new ConcurrentQueue<String>();

        private void btnOpen_Click(object sender, EventArgs e)
        {
            OpenFileDialog dialog = new OpenFileDialog();
            dialog.Multiselect = false;//该值确定是否可以选择多个文件
            dialog.Title = "请选择文件";
            dialog.Filter = "文本文件(*.log;*.txt)|*.log;*.txt;";
            if (dialog.ShowDialog() == System.Windows.Forms.DialogResult.OK && dialog.FileName != "")
            {

            }

        }

        void ShowLog()
        {
            while (true)
            {
                Thread.Sleep(500);
                while (logQueue.Count > 0)
                {
                    String logInfo = "";
                    logQueue.TryDequeue(out logInfo);
                    rtxtShow.Invoke(new Action(() =>
                       {
                           if (logInfo != null && logInfo.Contains("ERROR") || logInfo.Contains("error"))
                           {
                               //高亮显示
                               rtxtShow.SelectionStart = rtxtShow.Text.Length;
                               rtxtShow.SelectionLength = logInfo.Length;
                               rtxtShow.SelectionColor = Color.FromName("Red");
                           }
                           rtxtShow.AppendText(logInfo + "\r\n");
                       }));
                }
            }
        }

        //void watcher_Renamed(object sender, RenamedEventArgs e)
        //{
        //    rtxtShow.Invoke(new Action(() =>
        //    {
        //        rtxtShow.AppendText("文件被重命名");
        //    }));

        //}

        //void watcher_Deleted(object sender, FileSystemEventArgs e)
        //{
        //    rtxtShow.Invoke(new Action(() =>
        //    {
        //        rtxtShow.AppendText("文件被删除");
        //    }));

        //}

        //void watcher_Created(object sender, FileSystemEventArgs e)
        //{
        //    rtxtShow.Invoke(new Action(() =>
        //    {
        //        rtxtShow.AppendText("文件被创建");
        //    }));
        //}

        void watcher_Changed(object sender, FileSystemEventArgs e)
        {
            LogToQueue();
        }

        private void LogToQueue()
        {
            Mutex mutex = new Mutex(false, "mutex");
            mutex.WaitOne();
            if (File.Exists(fileName))
            {
                using (FileStream fs = new FileStream(fileName, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
                {
                    if (fs.CanSeek)
                    {
                        if (Offset > fs.Length)//防止期间文件删除后创建导致偏移变化
                        {
                            Offset = fs.Length - 1;
                        }
                        fs.Seek(Offset, SeekOrigin.Begin);

                        byte[] b = new byte[fs.Length - Offset + 1];
                        int cnt, m = 0;
                        cnt = fs.ReadByte();
                        while (cnt != -1)
                        {
                            b[m++] = Convert.ToByte(cnt);
                            cnt = fs.ReadByte();
                        }

                        List<string> ltInfo = Encoding.UTF8.GetString(b).Split(new string[] { "\r\n" }
                            , StringSplitOptions.None).ToList();

                        foreach (String item in ltInfo)
                        {
                            logQueue.Enqueue(item);
                        }
                        Offset = fs.Length; //更新偏移位置
                    }
                    else
                    {
                        rtxtShow.Invoke(new Action(() =>
                        {
                            rtxtShow.AppendText("当前流不支持查找");
                        }));
                    }
                }
            }
            mutex.ReleaseMutex();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            switch (comboBox1.SelectedIndex)
            {
                case 0:
                    break;

                case 1:
                    dateTimePicker1.Format = System.Windows.Forms.DateTimePickerFormat.Short;
                    dateTimePicker1.MinDate = DateTime.Today.AddDays(-14);
                    dateTimePicker1.MaxDate = DateTime.Today;
                    dateTimePicker1.Value = DateTime.Today;//.AddDays(-1);

                    //DateTime StartDate = new DateTime(2023, 9, 21);
                    //DateTime EndDate = new DateTime();





                    break;
                case 2:
                    break;
                case 3:
                    break;


            }


        }
        Thread t;
        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {
            if (dateTimePicker1.Value.ToShortDateString() == DateTime.Now.ToShortDateString())
            {

                rtxtShow.Text = "";
                Offset = 0;
                fileName = Path.Combine(Application.StartupPath, "Logs", "logfile.log");
                FileSystemWatcher watcher = new FileSystemWatcher();
                watcher.Path = fileName.Substring(0, fileName.LastIndexOf("\\") + 1);
                watcher.NotifyFilter = NotifyFilters.FileName | NotifyFilters.LastWrite;
                watcher.Filter = fileName.Substring(fileName.LastIndexOf("\\") + 1);
                watcher.Changed += new FileSystemEventHandler(watcher_Changed);
                //watcher.Created += new FileSystemEventHandler(watcher_Created);
                //watcher.Deleted += new FileSystemEventHandler(watcher_Deleted);
                //watcher.Renamed += new RenamedEventHandler(watcher_Renamed);
                watcher.EnableRaisingEvents = true;

                //t = new Thread(new ThreadStart(ShowLog));
                //t.Start();
                ctsLog = new CancellationTokenSource();
                ctsLogToken = ctsLog.Token;
                Task task = Task.Run(() => LogMonitor(ctsLogToken));
                LogToQueue();
            }
            else
            {
                if (ctsLog != null)
                {
                    ctsLog.TryReset();
                }
                rtxtShow.Text = "";
                Offset = 0;
                fileName = Path.Combine(Application.StartupPath, "Logs", "archives", $@"log.{dateTimePicker1.Value.ToString("yyyyMMdd")}.log");
                if (File.Exists(fileName))
                {
                    LogToQueue();
                }
                else
                {
                    MessageBox.Show("no");
                }

            }
        }

        private void frmMain_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (ctsLog != null)
            {
                ctsLog.Cancel();
            }
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
