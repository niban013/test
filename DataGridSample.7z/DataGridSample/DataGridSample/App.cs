﻿using System.ComponentModel;
using Xamarin.Forms;

namespace DataGridSample
{
	public class App : Application
	{
		//private static Container ioCContainer = new SimpleInjector.Container();
		public App()
		{
			//App.IoCContainer.Register<IAnimal, Dog>(Lifestyle.Transient);
			//Load the assembly
			Xamarin.Forms.DataGrid.DataGridComponent.Init(); 
			MainPage = new NavigationPage(new MainPage());
		}
		//public static Container IoCContainer
		//{
		//	get => ioCContainer;
		//	set => ioCContainer = value;
		//}
		#region App Lifecycle
		protected override void OnStart()
		{
		}

		protected override void OnSleep()
		{
		}

		protected override void OnResume()
		{
		}
		#endregion
	}
}
