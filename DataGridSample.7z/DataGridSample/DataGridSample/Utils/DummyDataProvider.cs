﻿using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Reflection;
using DataGridSample.Models;
using Newtonsoft.Json;

namespace DataGridSample.Utils
{
	static class DummyDataProvider
	{
        public static List<Contact> Get()
        {
            return new List<Contact>
            {
                new Contact() {Status ="N",Guid="1", FirstName="Contact", LastName="One", Email="contact.one@gmail.com",
                    Phone="1234131332", PhotoUrl="profile01.png",Country="India" },
                new Contact() {Status ="N",Guid="2", FirstName="Contact", LastName="Two", Email="contact.two@gmail.com",
                    Phone="12894131332", PhotoUrl="profile02.png",Country="India"  },
                new Contact() {Status ="Y",Guid="3", FirstName="Contact", LastName="Three", Email="contact.three@gmail.com",
                    Phone="4234242235", PhotoUrl="profile03.png",Country="India"  },
                new Contact() {Status ="N",Guid="4", FirstName="Contact", LastName="Four", Email="contact.four@gmail.com",
                    Phone="6443245633", PhotoUrl="profile04.png",Country="India"  },
                new Contact() {Status ="N",Guid="5", FirstName="Contact", LastName="Five", Email="contact.five@gmail.com",
                    Phone="4234242235", PhotoUrl="profile05.png",Country="India"  },
                new Contact() {Status ="N",Guid="6", FirstName="Contact", LastName="Six", Email="contact.six@gmail.com",
                    Phone="2344324443", PhotoUrl="profile06.png",Country="India" },
                new Contact() {Status ="N",Guid="7", FirstName="Contact", LastName="Seven", Email="contact.seven@gmail.com",
                    Phone="234234234", PhotoUrl="profile01.png",Country="India" },
                new Contact() {Status ="N",Guid="8", FirstName="Contact", LastName="Eight", Email="contact.eight@gmail.com",
                    Phone="4234242235", PhotoUrl="profile02.png",Country="India"  },
            };
        }
        public static List<Team> GetTeams()
		{
			var assembly = typeof(DummyDataProvider).GetTypeInfo().Assembly;
			Stream stream = assembly.GetManifestResourceStream("DataGridSample.teams.json");
			string json = string.Empty;

			using (var reader = new StreamReader(stream))
			{
				json = reader.ReadToEnd();
			}

			return JsonConvert.DeserializeObject<List<Team>>(json);
		}
        public static List<Item> GetItems()
        {
            var mockItems = new List<Item>
            {
                new Item { Text = "First item", Role = "Admin" },
                new Item { Text = "Second item", Role="Admin" },
                new Item { Text = "Third item", Role="Editor" },
                new Item { Text = "Fourth item", Role="Editor" },
                new Item { Text = "Fifth item",  Role="Student" },
                new Item { Text = "Sixth item",  Role="Student" },
            };
            return mockItems;
        }
             
    }
}
