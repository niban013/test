﻿using Autofac;
using DataGridSample.Models;
using DataGridSample.Utils;
using DataGridSample.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace DataGridSample.Views
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class ContactsPage : ContentPage
    {

        ContactsViewModel viewModel;
        public ContactsPage()
        {
            InitializeComponent();
            BindingContext = App.Container.Resolve(typeof(ContactsViewModel));
            viewModel = (ContactsViewModel)this.BindingContext;
            //viewModel = (ContactsViewModel)App.Container.Resolve(typeof(ContactsViewModel));


            //this.BindingContext = this;

        }

        //protected override void OnAppearing()
        //{
        //    base.OnAppearing();
        //    //AllContacts = new List<Contact>(DummyDataProvider.Get());
        //    //collectionViewListHorizontal.ItemsSource = AllContacts;
           
        //}
        async void OnItemSelected(object sender, SelectionChangedEventArgs args)
        {
            var item = args.CurrentSelection.FirstOrDefault() as Contact;
            if (item != null)
            {

            }
            else 
            {
                return;
            }  
            ((CollectionView)sender).SelectedItem = null;
            //await Navigation.PushAsync(new ItemDetailPage(new ItemDetailViewModel(item)));

            //// Manually deselect item.
            //ItemsCollectionView.SelectedItem = null;
        }
        protected override void OnDisappearing()
        {
            MessagingCenter.Unsubscribe<object, string>(this, "ContactsViewModel");
        }
        protected override void OnAppearing()
        {
            base.OnAppearing();

            if (viewModel.Items.Count == 0)
                viewModel.LoadItemsCommand.Execute(null);

            MessagingCenter.Subscribe<object, string>(this, "ContactsViewModel", (obj, item) =>
            {
                lblCount.Text = item;
                //Debug.WriteLine("User updated from mainPage: " + sUser.firstName);
            });
            //    lblCount.Text = viewModel.Items.Where(k=>k.Status =="Y").Count().ToString() + "/"+viewModel.Items.Count.ToString();

        }
        void CollectionViewListSelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            UpdateSelectionData(e.PreviousSelection, e.CurrentSelection);
        }

        void UpdateSelectionData(IEnumerable<object> previousSelectedContact, IEnumerable<object> currentSelectedContact)
        {
            var selectedContact = currentSelectedContact.FirstOrDefault() as Contact;
            //Debug.WriteLine("FullName: " + selectedContact.FullName);
            //Debug.WriteLine("Email: " + selectedContact.Email);
            //Debug.WriteLine("Phone: " + selectedContact.Phone);
            //Debug.WriteLine("Country: " + selectedContact.Country);
        }

        private void Button_Clicked(object sender, EventArgs e)
        {
            //
            var _button = sender as Button;
            var record = _button.BindingContext as Contact;
            var recordrowindex = viewModel.Items.IndexOf(record);
            var d = viewModel.Items;
            d[recordrowindex].Status = "Y";
            d[recordrowindex].Country = "xxxx";
            viewModel.Items = d;
         
          //  collectionViewListVertical.ItemsSource = viewModel.Items;
            BindingContext = viewModel;
            //var rowindex = collectionViewListVertical.ResolveToRowIndex(recordrowindex);
        }
 
    }
}