﻿using DataGridSample.Views;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;

namespace DataGridSample
{
	public partial class MainPage : ContentPage
	{
		public List<string> Msgs
		{
			get;
		}
		public MainPage()
		{
			InitializeComponent();
			BindingContext = new ViewModels.MainViewModel();
			inc.ItemSelected += SfGrid_GridLongPressed;
			this.Msgs = new List<string>() {
				"After synchonous Subscribe function the subscription is not always ensured",
				"StackExchange.Redis.RedisServerException - MOVED",
				"custom condition within transaction"
			};
			this.BindingContext = this;
		}
		private void SfGrid_GridLongPressed(object sender, SelectedItemChangedEventArgs e)
		{
			int rowindex = e.SelectedItemIndex;
			if (rowindex != -1)
			{
				DisplayAlert("Alert", rowindex.ToString(), "OK");
			}
			inc.SelectedItem = null;
		}
		 
		private async void Button_Clicked(object sender, EventArgs e)
        {
		//	await Navigation.PushAsync(new NavigationPage(new Page1()));
			 
			//var MainPage = new NavigationPage(new Page1());
			await Navigation.PushAsync(new ContactsPage());
			//await NavigationPage.PushAsync(new Page1());
		}
		 
	}
}
