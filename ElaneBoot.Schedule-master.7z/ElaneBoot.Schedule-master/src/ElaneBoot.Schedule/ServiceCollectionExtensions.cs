﻿using Microsoft.AspNetCore.Builder;
using Microsoft.Extensions.DependencyInjection;
using System.Collections.Generic;
using System.Linq;
using System.Xml;
using System;
using System.IO;
using System.Reflection;
using Microsoft.Extensions.FileProviders;
using Microsoft.Extensions.Configuration;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using ElaneBoot.Schedule.Services;
using WangSql;
using ElaneBoot.Schedule.Models;
using ElaneBoot.Schedule.Filters;
using Quartz;
using ElaneBoot.Schedule.Jobs;

namespace ElaneBoot.Schedule
{
    public static class ServiceCollectionExtensions
    {
        public static IServiceCollection AddApiSchedule(this IServiceCollection services, IConfiguration configuration)
        {
            //var dbSettings = configuration.GetSection("Database").Get<List<DbSettings>>();

            ////data
            //if (dbSettings != null && dbSettings.Any())
            //{
            //    foreach (var item in dbSettings)
            //    {
            //        DbProviderManager.Set
            //           (
            //           item.Name,
            //           item.ConnectionString,
            //           item.ConnectionType,
            //           item.UseParameterPrefixInSql,
            //           item.UseParameterPrefixInParameter,
            //           item.ParameterPrefix,
            //           item.UseQuotationInSql,
            //           item.Debug
            //           );
            //    }

            //    //注入SqlMapper
            //    services.AddScoped<ISqlMapper, SqlMapper>();
            //}
            //else
            //{
            //    DbProviderManager.Set
            //                       (
            //                       "SQLite",
            //                       "Data Source=schedule.db;",
            //                       "System.Data.SQLite.SQLiteConnection,System.Data.SQLite",
            //                       true,
            //                       true,
            //                       "@",
            //                       false,
            //                       false
            //                       );

            //    //注入SqlMapper
            //    services.AddScoped<ISqlMapper, SqlMapper>();
            //}
            IFreeSql fsql = new FreeSql.FreeSqlBuilder()
                 .UseConnectionString(FreeSql.DataType.Sqlite, @"Data Source=schedule1.db")
                 .UseAutoSyncStructure(true) //自动同步实体结构到数据库，FreeSql不会扫描程序集，只有CRUD时才会生成表。
                 .Build();

            Func<IServiceProvider, IFreeSql> implementationFreeSql = r =>
            {
              
                return fsql;
            };
            services.AddHostedService<NLogHostService>();   // NLog 壽敕督昢
            services.AddSingleton<IFreeSql>(implementationFreeSql);
            services.AddTransient<ScheduleService>();
            services.AddTransient<HttpJob>();   // 注册job至容器，必须步骤
            services.AddQuartz(config =>
            {
                config.UseTimeZoneConverter();
                // 使用MicrosoftDependencyInjectionJobFactory工厂类从 容器 中创建job实例
                config.UseMicrosoftDependencyInjectionJobFactory(options =>
                {
                    options.AllowDefaultConstructor = false;    // 禁止使用无参构建函数创建 job
                    options.CreateScope = false;
                });
                config.UseDefaultThreadPool(options =>
                {
                    options.MaxConcurrency = 10;    // 最大并发执行线程数
                }); 
            
            });
            //IHostedService宿主启动 Quartz服务 services.AddSingleton<IHostedService, QuartzHostedService>()
            services.AddQuartzServer(options =>
            {
                // when shutting down we want jobs to complete gracefully
                options.WaitForJobsToComplete = true;   // 等待任务执行完，再退出
            });
           
            //mvc
            //services.AddMvc(options =>
            //{
            //    options.Filters.Add<ApiActionFilter>();
            //})
            ////枚举序列化字符串
            ////.AddJsonOptions(options =>
            ////{
            ////    options.SerializerSettings.Converters.Add(new Newtonsoft.Json.Converters.StringEnumConverter());
            ////    options.SerializerSettings.ContractResolver = new Newtonsoft.Json.Serialization.CamelCasePropertyNamesContractResolver();
            ////})
            //.SetCompatibilityVersion(CompatibilityVersion.Version_2_1)
            //;
            IocEngine.Instance.Init(services);
            return services;
        }

        public static IApplicationBuilder UseApiSchedule(this IApplicationBuilder app, IConfiguration configuration)
        {
            //在项目启动时，从容器中获取IFreeSql实例，并执行一些操作：同步表，种子数据,FluentAPI等
            using (IServiceScope serviceScope = app.ApplicationServices.CreateScope())
            {
                var fsql = serviceScope.ServiceProvider.GetRequiredService<IFreeSql>();
                fsql.CodeFirst.SyncStructure(typeof(ScheduleJobInfo));//Topic 为要同步的实体类
                fsql.CodeFirst.SyncStructure(typeof(ScheduleLogInfo));//Topic 为要同步的实体类
            }


            //静态资源
            app.UseStaticFiles();

            app.UseStaticFiles(new StaticFileOptions
            {
                FileProvider = new ManifestEmbeddedFileProvider(Assembly.GetExecutingAssembly(), "wwwroot")
            });

            app.UseRouting(); 
            app.UseEndpoints(endpoints =>
            {
                endpoints.MapRazorPages();
                endpoints.MapControllers();
            });

            ScheduleManager.Start();
            //mvc
        

            return app;
        }
    }
}