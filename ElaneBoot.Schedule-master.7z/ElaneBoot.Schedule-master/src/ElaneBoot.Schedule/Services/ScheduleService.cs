﻿using ElaneBoot.Schedule.Models;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using WangSql;

namespace ElaneBoot.Schedule.Services
{
    public class ScheduleService //: ApiService
    {
        private readonly ILogger<ScheduleService> _logger;
        private IFreeSql _sqlMapper;
        public ScheduleService(IFreeSql _fsql, ILogger<ScheduleService> logger) 
        {
            _sqlMapper = _fsql;
            _logger = logger;
        }
        public ScheduleJobInfo GetJob(string jobId)
        {
            var r = _sqlMapper.Select<ScheduleJobInfo>().Where(x => x.JobId == jobId).ToList().FirstOrDefault();
            return r;
        }

        public IList<ScheduleJobInfo> GetJobList()
        {
            _logger.LogError("GetJobList");
            var r = _sqlMapper.Select<ScheduleJobInfo>().ToList();
            return r;
        }

        public ScheduleJobInfo AddJob(ScheduleJobInfo dto)
        {
            var model = dto;
            model.JobId = Guid.NewGuid().ToString("N").ToLower();
           
                _sqlMapper.Transaction(() => {
                    try
                    { 
                        _sqlMapper.Insert<ScheduleJobInfo>();
                        ScheduleManager.AddJob(model);
                    }
                    catch (Exception ex)
                    {
                        throw ex;
                    }
                }); 
            return GetJob(model.JobId);
        }

        public void DeleteJob(string jobId)
        {
            var job = _sqlMapper.Select<Models.ScheduleJobInfo>().Where(x => x.JobId == jobId).ToList().FirstOrDefault();
            _sqlMapper.Transaction(() => {
                try
                {
                    job.JobState = JobState.Deleted;
                    _sqlMapper.Update<ScheduleJobInfo>().SetSource(job).ExecuteAffrows(); //更新;
                    ScheduleManager.DeleteJob(jobId);
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }); 
        
        }

        public ScheduleJobInfo UpdateJob(ScheduleJobInfo dto)
        {
            var model = dto;

            _sqlMapper.Transaction(() => {
                try
                { 
                    _sqlMapper.Update<ScheduleJobInfo>(model.JobId).Set(a=>a.JobState,model.JobState).ExecuteAffrows(); //更新;
                    ScheduleManager.UpdateJob(model);
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            });
         
            return GetJob(model.JobId);
        }

        public void StartJob(string jobId)
        {
            var job = _sqlMapper.Select<Models.ScheduleJobInfo>().Where(x => x.JobId == jobId).ToList().FirstOrDefault();

            _sqlMapper.Transaction(() => {
                try
                {
                    job.JobState = JobState.Normal;
                    _sqlMapper.Update<ScheduleJobInfo>().SetSource(job).ExecuteAffrows(); //更新;
                    ScheduleManager.AddJob(job);
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            });
        }

        public void StopJob(string jobId)
        {
            var job = _sqlMapper.Select<Models.ScheduleJobInfo>().Where(x => x.JobId == jobId).ToList().FirstOrDefault();
            _sqlMapper.Transaction(() => { 
                try
                {
                    job.JobState = JobState.Disabled;
                    _sqlMapper.Update<ScheduleJobInfo>().SetSource(job).ExecuteAffrows(); //更新;
                    ScheduleManager.DeleteJob(jobId);
                  
                }
                catch (Exception ex)
                {
                  
                    throw ex;
                }
            });
        }

        public IList<ScheduleLogInfo> GetLogList(string jobId, string statusCode)
        {
            var list = _sqlMapper.Select<ScheduleLogInfo>();
            if (!string.IsNullOrEmpty(jobId))
            {
                list.Where(x => x.JobId == jobId);
            }
            if (!string.IsNullOrEmpty(statusCode))
            {
                list.Where(x => x.StatusCode == statusCode);
            }
            return list.OrderByDescending(x => x.DateTime).ToList();
        }

        public PageData<ScheduleLogInfo> GetLogPage(string jobId, string statusCode, int pageIndex, int pageSize)
        {
            var pageInfo = new PageInfo();
            if (pageIndex > 0) pageInfo.PageIndex = pageIndex;
            if (pageSize > 0) pageInfo.PageSize = pageSize;

            var list = _sqlMapper.Select<ScheduleLogInfo>();
            if (!string.IsNullOrEmpty(jobId))
            {
                list.Where(x => x.JobId == jobId);
            }
            if (!string.IsNullOrEmpty(statusCode))
            {
                list.Where(x => x.StatusCode == statusCode);
            }

            PageData<ScheduleLogInfo> result = new PageData<ScheduleLogInfo>();
            var r = list.OrderByDescending(x => x.DateTime);//.ToPaged(pageInfo.PageIndex, pageInfo.PageSize, out int total);
            result.Items = r.ToList();
            result.PageInfo = pageInfo;
            result.PageInfo.TotalCount = 2;// total;
            return result;
        }
    }
}
