﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text.Encodings.Web;
using System.Text.Unicode;
using System.Threading.Tasks;
using ElaneBoot.Schedule;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.FileProviders;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Microsoft.OpenApi.Models;

namespace ElaneZero.Schedule
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddRazorPages()
            .AddJsonOptions(options =>
            {
                //options.JsonSerializerOptions.Converters.Add(new DateTimeConverter());  // 跡宒趙
            })
            //.AddFluentValidation(config =>  // 耀倰統杅桄痐
            //{
            //    config.RunDefaultMvcValidationAfterFluentValidationExecutes = true;    // false : 輦砦蘇耀倰桄痐
            //    config.ValidatorOptions.CascadeMode = CascadeMode.Stop; // 祥撰薊桄痐ㄛ菴珨跺寞寀渣昫憩礿砦
            //    config.RegisterValidatorsFromAssemblyContaining<JobCreateOrUpdateValidator>();
            //})
            ;
            services.AddControllers();
            services.AddApiSchedule(Configuration);
            // services.AddMvc();
            //services.AddMvc(setup => { setup.EnableEndpointRouting = false; });
            services.AddSwaggerGen(c =>
            {
                c.SwaggerDoc("v1", new OpenApiInfo { Title = "webapi", Version = "v1" });
            });
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IHostingEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
                app.UseSwagger();
                app.UseSwaggerUI(c => c.SwaggerEndpoint("/swagger/v1/swagger.json", "webapi v1"));
            }

            app.UseApiSchedule(Configuration);
         
        }
    }
}
