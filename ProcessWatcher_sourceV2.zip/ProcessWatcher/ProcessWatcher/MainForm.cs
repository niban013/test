﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;

namespace ProcessWatcher
{
    public partial class MainForm : Form
    {
        public delegate void DisplayDelegate(string str);
        public DisplayDelegate displayDelegate;
        private EventWatcher ew;
        private StringBuilder sbOutText;
        private bool isStartEnabled;

        public MainForm()
        {
            InitializeComponent();
            displayDelegate = new DisplayDelegate(DisplayResult);
            sbOutText = new StringBuilder();
            isStartEnabled = true;
        }

        public void InitializeStartStop()
        {
            isStartEnabled = !isStartEnabled;
            StartButton.Enabled = isStartEnabled;
            StopButton.Enabled = !StartButton.Enabled;

        }

        private void StartButton_Click(object sender, EventArgs e)
        {
            try
            {
                InitializeStartStop();
                textBox1.BackColor = Color.LightYellow;
                ew = new EventWatcher(this);
            }
            catch
            {
                StartButton.Enabled = isStartEnabled = true;
            }
        }

        private void StopAllWatchers()
        {
            ew.StopAllWatchers();
            ew = null;
        }

        private void StopButton_Click(object sender, EventArgs e)
        {
            try
            {
                InitializeStartStop();
                textBox1.BackColor = Color.White;
                StopAllWatchers();
            }
            catch
            {
                StopButton.Enabled = true;
            }
        }

        private void DisplayResult(string result)
        {
            sbOutText.Append(string.Format("{0}{1}",result,Environment.NewLine));
            textBox1.Text = sbOutText.ToString();
        }

        private void saveToFileMenuItem_Click(object sender, EventArgs e)
        {
            DialogResult dr = saveFileDialog.ShowDialog();
            if (dr == System.Windows.Forms.DialogResult.OK)
            {
                File.AppendAllText(saveFileDialog.FileName, sbOutText.ToString());
            }

        }

        private void selectAllMenuItem_Click(object sender, EventArgs e)
        {
            textBox1.SelectAll();
            textBox1.Focus();
        }

        private void copyMenuItem_Click(object sender, EventArgs e)
        {
            Clipboard.SetText(sbOutText.ToString());
        }

        private void MainForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (ew != null)
            {
                ew.StopAllWatchers();
                ew = null;
            }
        }

    }
}
