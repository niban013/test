﻿using IWshRuntimeLibrary;
using Microsoft.Win32;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Net.Http;
using System.Threading.Tasks;
using static System.Net.Mime.MediaTypeNames;

namespace InnoDriveSys
{
    public static class ClsCommon
    {
        public static void saveReg(string product, string version, string url, string value)
        {
            RegistryKey reg;
            using (reg = Registry.CurrentUser.OpenSubKey($@"Software\{product}\{version}", true))
            {
                if (reg == null)
                {
                    reg = Registry.CurrentUser.CreateSubKey($@"Software\{product}\{version}");
                }

                if (reg.GetValue(url) == null)
                {
                    reg.SetValue(url, value, RegistryValueKind.String);
                }

                if (reg.GetValue(url).ToString() != value)
                {
                    reg.SetValue(url, value, RegistryValueKind.String);
                }
            }
        }

        public static async Task<List<string>> GetWebdavServer(string product, string version, string url)
        {
            List<string> result = new List<string>();
            using (RegistryKey key = Registry.CurrentUser.OpenSubKey($@"Software\{product}\{version}", true))
            {
                HttpClient client = GetHttpClient("");
                string uri = key.GetValue(url).ToString();
                HttpResponseMessage response = await client.GetAsync(uri);
                if (response.StatusCode == System.Net.HttpStatusCode.NotFound)
                {
                    result = new List<string>() { "http://jnvb2bweb01.cminl.oa:8080" };
                }
                else
                {
                    result = JsonConvert.DeserializeObject<List<string>>(response.Content.ReadAsStringAsync().Result);
                }
            }
            return result;
        }
        private static HttpClient GetHttpClient(string ticket)
        {
            HttpClient client = new HttpClient()
            {
                Timeout = TimeSpan.FromMinutes(20)
            };
            if (ticket != "")
            {
                client.DefaultRequestHeaders.Clear();
                client.DefaultRequestHeaders.Add("ticket", ticket);

            }
            return client;
        }

        public static void registerRabitMQ(string product, string version, object rq)
        {
            if (rq == null || rq.ToString() == string.Empty)
            {
                var rabitMQ = ConfigurationManager.AppSettings.Get("RabitMQ");
                ClsCommon.saveReg(product, version, "RabitMQ", rabitMQ);
            }
        }
        public static void registerQuick(string product, string server)
        {
            server = server.TrimEnd('/');
            server = server.Replace("http://", "").Replace("/","\\").Replace(":", "@");
            server = @"\\" + server + @"\DavWWWRoot";
            var path = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "Microsoft", "Windows", "Network Shortcuts");
            string shortcut_link = Path.Combine(path, product, "target.lnk");
            string targetLNKPath = path + @"\" + product;






            //createShortcut(product, shortcut_link, server);
            //  if (!System.IO.File.Exists(shortcut_link))
            // {
            createDesktopini(product, server, 0);
            //  }
        }




        //static void CreateShortcut(string originalFilePathAndName, string destinationSavePath)
        //{
        //    string fileName = Path.GetFileNameWithoutExtension(originalFilePathAndName);
        //    string originalFilePath = Path.GetDirectoryName(originalFilePathAndName);

        //    string link = destinationSavePath + Path.DirectorySeparatorChar + fileName + ".lnk";
        //    var shell = new WshShell();
        //    var shortcut = shell.CreateShortcut(link) as IWshShortcut;
        //    if (shortcut != null)
        //    {
        //        shortcut.TargetPath = originalFilePathAndName;
        //        shortcut.WorkingDirectory = originalFilePath;
        //        shortcut.Save();
        //    }
        //}


        private static void createDesktopini(string name, string targetPath, int iconNumber)
        {

            string networkshortcuts = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "Microsoft", "Windows", "Network Shortcuts");

            var newFolder = Directory.CreateDirectory(networkshortcuts + @"\" + name);

            newFolder.Attributes |= FileAttributes.ReadOnly;

            string desktopiniContents = @"[.ShellClassInfo]" + Environment.NewLine +

                "CLSID2={0AFACED1-E828-11D1-9187-B532F1E9575D}" + Environment.NewLine +

                "Flags=2";

            string shortcutlocation = networkshortcuts + @"\" + name;

            System.IO.File.WriteAllText(shortcutlocation + @"\Desktop.ini", desktopiniContents);

            string targetLNKPath = networkshortcuts + @"\" + name;

            createShortcut(name, targetLNKPath, targetPath);

        }

        static void createShortcut(string product, string shortcutPath, string targetPath)
        {

            ////string path = Environment.GetFolderPath(Environment.SpecialFolder.Desktop);
            ////object shDesktop = (object)"Desktop";
            //WshShell shell = new WshShell();
            ////string shortcutAddress = (string)shell.SpecialFolders.Item(ref shDesktop) + @"\Recycle Bin.lnk";
            //IWshShortcut shortcut = (IWshShortcut)shell.CreateShortcut(shortcutPath);
            //shortcut.Description = "New shortcut for Recycle Bin";
            //shortcut.Hotkey = "Ctrl+Shift+N";
            ////shortcut.IconLocation = @"C:\WINDOWS\System32\imageres.dll";
            //shortcut.TargetPath = targetPath;// Environment.GetFolderPath(Environment.SpecialFolder.System) + @"\Recycle.Bin";
            //shortcut.Save();
            //WshShell shell = new WshShell();
            //IWshShortcut shortcut = (IWshShortcut)shell.CreateShortcut(shortcutPath + @"\target.lnk");
            //shortcut.TargetPath = targetPath;
            //shortcut.Description = product;
            //shortcut.Save();

            WshShell shell = new WshShell();

            IWshShortcut shortcut = (IWshShortcut)shell.CreateShortcut(shortcutPath + @"\target.lnk");

            shortcut.Description = product;

            shortcut.TargetPath = targetPath;

            shortcut.Arguments = targetPath;


            shortcut.IconLocation = Path.Combine(@"C:\InnoLux\InnoDrive\Icon", "inxDrive.ico");
            //// MessageBox.Show(shortcut.IconLocation);
            shortcut.Save();
        }

        private static bool UndoIconedFolder(string folderName)
        {
            #region Private Variables
            DirectoryInfo folder;
            #endregion Private Variables

            #region Data Validation
            if (Directory.Exists(folderName) == false)
            {
                return false;
            }
            #endregion Data Validation

            try
            {
                folder = new DirectoryInfo(folderName);

                //// Remove the file [Desktop.ini]
                //FileInfo file = new FileInfo(Path.Combine(folderName, "desktop.ini"));
                //if (file.Exists)
                //{
                //    file.Delete();
                //}
                //var name = "InnoDrive";
                folder.Attributes = FileAttributes.Normal;
                Directory.Delete(folderName,true);
            }
            catch
            {
                return false;
            }

            return true;
        }

        
        public static void removeShortcut(string product)
        {
            var path = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "Microsoft", "Windows", "Network Shortcuts");
            //string shortcut_link = Path.Combine(path, product, "target.lnk");



            //if (System.IO.File.Exists(shortcut_link))
            //{
            //    System.IO.File.Delete(shortcut_link);

            UndoIconedFolder(Path.Combine(path, product));
                //if (Directory.Exists(Path.Combine(path, product)))
                //{
                //    Directory.Delete(Path.Combine(path, product));
                //}
            //}
        }
    }
}
