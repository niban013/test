﻿using IWshRuntimeLibrary;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using System;
using System.IO;
using System.Timers;

namespace WinFormsApp1
{
    public partial class Form1 : Form
    {


        System.Timers.Timer myTimer = new System.Timers.Timer();
        public static void DisplayTimeEvent(object source, ElapsedEventArgs e)
        {
            // code here will run every second
        }
        public Form1()
        {
            InitializeComponent();

            ContextMenuStrip contextMenuStrip = new System.Windows.Forms.ContextMenuStrip(); // 滑鼠右鍵選單
            this.ContextMenuStrip = contextMenuStrip; // 將 Form1 的滑鼠右鍵選單設定為 contextMenuStrip

            ToolStripMenuItem toolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem(); // 滑鼠右鍵選單選項
            toolStripMenuItem.Text = "按鈕1";
            toolStripMenuItem.Click += (sender, e) => { MessageBox.Show("按鈕1"); Close(); };
            contextMenuStrip.Items.Add(toolStripMenuItem);
            toolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem(); // 滑鼠右鍵選單選項
            toolStripMenuItem.Text = "按鈕1";
            toolStripMenuItem.Click += (sender, e) => { MessageBox.Show("按鈕1"); CreateShortcut(); };
            contextMenuStrip.Items.Add(toolStripMenuItem);
            toolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem(); // 滑鼠右鍵選單選項
            toolStripMenuItem.Text = "按鈕1";
            toolStripMenuItem.Click += (sender, e) => { MessageBox.Show("按鈕1"); };
            contextMenuStrip.Items.Add(toolStripMenuItem);
            notifyIcon1.ContextMenuStrip = contextMenuStrip;

            myTimer.Elapsed += new ElapsedEventHandler(DisplayTimeEvent);
            myTimer.Interval = 1000; // 1000 ms is one second
            myTimer.Start();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            //this.BeginInvoke(new Action(() =>
            //{
            //    this.Hide(); this.Opacity = 1;

            //    notifyIcon1.Text = "New message";
            //    notifyIcon1.Visible = true;
            //    notifyIcon1.ShowBalloonTip(2000, "Information", "A new message received!", ToolTipIcon.Info);

            //}));
        }
        private void menuItem1_Click(object sender, System.EventArgs e)
        {
            Close();
        }

        private void menuItem2_Click(object sender, System.EventArgs e)
        {

            this.Visible = false;
        }

        private void menuItem3_Click(object sender, System.EventArgs e)
        {
            this.Visible = true;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //notifyIcon1.Icon =
        }
        public static void CreateShortcut()
        {
            var shortcutname = "qqqqq";
            string _path = Environment.GetFolderPath(Environment.SpecialFolder.StartMenu);

            var wsh = new WshShell();
            IWshRuntimeLibrary.IWshShortcut shortcut = wsh.CreateShortcut(
              _path + "\\" + shortcutname + ".lnk") as IWshRuntimeLibrary.IWshShortcut;
            shortcut.TargetPath = @"C:\test\2022\inno\WinFormsApp1\bin\Debug\net7.0-windows\WinFormsApp1.exe";
            shortcut.Save();
            //object shDesktop = (object)"Desktop";
            //WshShell shell = new WshShell();
            //string shortcutAddress = (string)shell.SpecialFolders.Item(ref shDesktop) + @"\Notepadqqqq.lnk";
            //IWshShortcut shortcut = (IWshShortcut)shell.CreateShortcut(shortcutAddress);
            //shortcut.Description = "New shortcut for a Notepad";
            //shortcut.Hotkey = "Ctrl+Shift+N";
            //shortcut.TargetPath = @"C:\test\2022\inno\WinFormsApp1\bin\Debug\net7.0-windows\WinFormsApp1.exe";
            ////Environment.GetFolderPath(Environment.SpecialFolder.System) + @"\notepad.exe";
            //shortcut.Save();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            ChangeNotifyIcon(NotifyIconType.OnLine);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            ChangeNotifyIcon(NotifyIconType.Offline);
        }
        public enum NotifyIconType
        {
            OnLine,
            Offline
        }
        private void ChangeNotifyIcon(NotifyIconType notiType)
        {
            const string imageFolderName = "images";
            try
            {
                //內嵌資源的檔名為 namespace.foldername.filename 而且大小寫要相同哦
                System.Reflection.Assembly asm = System.Reflection.Assembly.GetExecutingAssembly();

                string fileName = asm.GetName().Name + "." + imageFolderName + "." + 
                    (notiType== NotifyIconType.OnLine? "inxDrive32": "inxDrive32g") + ".ico";
                Stream iconStream = asm.GetManifestResourceStream(fileName);
                Icon newIcon = new Icon(iconStream);
                this.notifyIcon1.Icon = newIcon;
                iconStream.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}