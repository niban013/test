using IWshRuntimeLibrary;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using System;
using System.IO;

namespace WinFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

            ContextMenuStrip contextMenuStrip = new System.Windows.Forms.ContextMenuStrip(); // ���l�E���I�d
            this.ContextMenuStrip = contextMenuStrip; // �� Form1 �I���l�E���I�d�ݒ�� contextMenuStrip

            ToolStripMenuItem toolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem(); // ���l�E���I�d�I��
            toolStripMenuItem.Text = "����1";
            toolStripMenuItem.Click += (sender, e) => { MessageBox.Show("����1"); Close(); };
            contextMenuStrip.Items.Add(toolStripMenuItem);
            toolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem(); // ���l�E���I�d�I��
            toolStripMenuItem.Text = "����1";
            toolStripMenuItem.Click += (sender, e) => { MessageBox.Show("����1"); CreateShortcut(); };
            contextMenuStrip.Items.Add(toolStripMenuItem);
            toolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem(); // ���l�E���I�d�I��
            toolStripMenuItem.Text = "����1";
            toolStripMenuItem.Click += (sender, e) => { MessageBox.Show("����1"); };
            contextMenuStrip.Items.Add(toolStripMenuItem);
            notifyIcon1.ContextMenuStrip = contextMenuStrip;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            this.BeginInvoke(new Action(() =>
            {
                this.Hide(); this.Opacity = 1;

                notifyIcon1.Text = "New message";
                notifyIcon1.Visible = true;
                notifyIcon1.ShowBalloonTip(2000, "Information", "A new message received!", ToolTipIcon.Info);

            }));
        }
        private void menuItem1_Click(object sender, System.EventArgs e)
        {
            Close();
        }

        private void menuItem2_Click(object sender, System.EventArgs e)
        {
             
            this.Visible = false;
        }

        private void menuItem3_Click(object sender, System.EventArgs e)
        {
            this.Visible = true;
        }

        private void button1_Click(object sender, EventArgs e)
        {
           
        }
        public static void CreateShortcut()
        {
            var shortcutname = "qqqqq";
            string _path = Environment.GetFolderPath(Environment.SpecialFolder.StartMenu);
           
            var wsh = new WshShell();
            IWshRuntimeLibrary.IWshShortcut shortcut = wsh.CreateShortcut(
              _path + "\\" + shortcutname + ".lnk") as IWshRuntimeLibrary.IWshShortcut;
            shortcut.TargetPath = @"C:\test\2022\inno\WinFormsApp1\bin\Debug\net7.0-windows\WinFormsApp1.exe";
            shortcut.Save();
            //object shDesktop = (object)"Desktop";
            //WshShell shell = new WshShell();
            //string shortcutAddress = (string)shell.SpecialFolders.Item(ref shDesktop) + @"\Notepadqqqq.lnk";
            //IWshShortcut shortcut = (IWshShortcut)shell.CreateShortcut(shortcutAddress);
            //shortcut.Description = "New shortcut for a Notepad";
            //shortcut.Hotkey = "Ctrl+Shift+N";
            //shortcut.TargetPath = @"C:\test\2022\inno\WinFormsApp1\bin\Debug\net7.0-windows\WinFormsApp1.exe";
            ////Environment.GetFolderPath(Environment.SpecialFolder.System) + @"\notepad.exe";
            //shortcut.Save();
        }
    }
}