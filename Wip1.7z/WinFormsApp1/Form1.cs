﻿using Downloader;
using Microsoft.VisualBasic.Devices;
using Microsoft.VisualBasic.Logging;
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.IO;
using System.IO.Pipes;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Reflection;
using System.Security.Policy;
using System.Text.Json;
using System.Windows.Forms;
using static System.Net.WebRequestMethods;
using System.Xml.Linq;

namespace WinFormsApp1
{
    public class DataComparer : IEqualityComparer<gg>
    {
        public bool Equals(gg x, gg y)
        {
            //確認兩個物件的資料是否相同
            if (Object.ReferenceEquals(x, y)) return true;

            //確認兩個物件是否有任何資料為空值
            if (Object.ReferenceEquals(x, null) || Object.ReferenceEquals(y, null))
                return false;

            //這邊就依照個人需求比對各個屬性的值，以此範例來說也可以只比對uName或比對uName跟uAge
            return x.s1 == y.s1
                && x.s2 == y.s2;
        }

        public int GetHashCode(gg e)
        {
            //確認物件是否為空值
            if (Object.ReferenceEquals(e, null)) return 0;

            //取得uId欄位的HashCode
            int uId = e.s1 == null ? 0 : e.s1.GetHashCode();

            //取得uName欄位的HashCode
            int uName = e.s2 == null ? 0 : e.s2.GetHashCode();

            //取得uAge欄位的HashCode
            //int uAge = e.uAge == null ? 0 : e.uAge.GetHashCode();

            //計算HashCode，因為是XOR所以要全部都是1才會回傳1，否則都會回傳0
            return uId ^ uName;// ^ uAge;
        }
    }
    public class gg:System.IEquatable<gg>
    { 
      public string s1 { get; set; } = string.Empty;
        public string s2 { get; set; } = string.Empty;
        public gg(string _s1, string _s2) 
      {
            this.s1 = _s1;
            this.s2 = _s1;
      }
        public bool Equals(gg? other) => this.s1 == other?.s1;
        public override int GetHashCode() => (s1).GetHashCode();
    }
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            String KeyString = password.GenerateAPassKey("PassKey");
            String EncryptedPassword = password.Encrypt("25Characterlengthpassword!", KeyString);
            String DecryptedPassword = password.Decrypt(EncryptedPassword, KeyString);
        }

        private async void button2_Click(object sender, EventArgs e)
        {
            var downloadOpt = new DownloadConfiguration()
            {
                // usually, hosts support max to 8000 bytes, default values is 8000
                BufferBlockSize = 10240,
                // file parts to download, default value is 1
                ChunkCount = 8,
                // download speed limited to 2MB/s, default values is zero or unlimited
                MaximumBytesPerSecond = 1024 * 1024 * 2,
                // the maximum number of times to fail
                MaxTryAgainOnFailover = 5,
                // release memory buffer after each 50 MB
                MaximumMemoryBufferBytes = 1024 * 1024 * 50,
                // download parts of file as parallel or not. Default value is false
                ParallelDownload = true,
                // number of parallel downloads. The default value is the same as the chunk count
                ParallelCount = 4,
                // timeout (millisecond) per stream block reader, default values is 1000
                Timeout = 1000,
                // set true if you want to download just a specific range of bytes of a large file
                RangeDownload = false,
                // floor offset of download range of a large file
                RangeLow = 0,
                // ceiling offset of download range of a large file
                RangeHigh = 0,
                // clear package chunks data when download completed with failure, default value is false
                ClearPackageOnCompletionWithFailure = true,
                // minimum size of chunking to download a file in multiple parts, default value is 512
                MinimumSizeOfChunking = 1024,
                // Before starting the download, reserve the storage space of the file as file size, default value is false
                ReserveStorageSpaceBeforeStartingDownload = true,
                // config and customize request headers
                //RequestConfiguration =
                //{
                //    Accept = "*/*",
                //   // CookieContainer = cookies,
                //    Headers = new WebHeaderCollection(), // { your custom headers }
                //    KeepAlive = true, // default value is false
                //    ProtocolVersion = HttpVersion.Version11, // default value is HTTP 1.1
                //    UseDefaultCredentials = false,
                //    // your custom user agent or your_app_name/app_version.
                //    UserAgent = "Mozilla/5.0 (Windows NT 10.0; Win64; x64)",
                //    Proxy = new WebProxy()
                //    {
                //        Address = new Uri("http://YourProxyServer/proxy.pac"),
                //        UseDefaultCredentials = false,
                //        Credentials = System.Net.CredentialCache.DefaultNetworkCredentials,
                //        BypassProxyOnLocal = true
                //    }
                //}
            };
            var downloader = new DownloadService(downloadOpt);
            downloader.DownloadStarted += DownloadStarted;
            downloader.DownloadFileCompleted += DownloadFileCompleted;
            downloader.DownloadProgressChanged += DownloadProgressChanged;

            await downloader.DownloadFileTaskAsync(@"http://ipv4.download.thinkbroadband.com/200MB.zip", @"C:\vm\c.zip");

        }


        void DownloadStarted(object? sender, DownloadStartedEventArgs e)
        {
            Trace.WriteLine(
                $"图片, FileName:{Path.GetFileName(e.FileName)}, TotalBytesToReceive:{e.TotalBytesToReceive}");
        }

        void DownloadFileCompleted(object? sender, AsyncCompletedEventArgs e)
        {
            //Trace.WriteLine($"下载完成, filepath:{filepath}");
            // percentageBar.Dispose();
        }

        void DownloadProgressChanged(object? sender, Downloader.DownloadProgressChangedEventArgs e)
        {
            this.BeginInvoke((Action)(() =>
            {
                label1.Text = ((int)(e.ProgressPercentage * 100)).ToString();
            }));

            //ConsoleProgress.Tick((int)(e.ProgressPercentage * 100));
            //if (sender is DownloadService ds)
            //    e.UpdateTitleInfo(ds.IsPaused);
            //  percentageBar.AsProgress<double>().Report(e.ProgressPercentage);
        }

        private void xx(HttpClient httpClient, int i)
        {
            //make the sync GET request
            using (var request = new HttpRequestMessage(HttpMethod.Get, "https://getsamplefiles.com/download/zip/sample-3.zip"))
            {
                using (var response = httpClient.Send(request, HttpCompletionOption.ResponseHeadersRead))
                {
                    if (response.IsSuccessStatusCode)
                    {
                        var stream = response.Content.ReadAsStreamAsync().ConfigureAwait(false).GetAwaiter().GetResult();
                        // var fileinfo = new FileInfo(@$"C:\vm\c{i}.zip");
                        //using (var fileStream = fileinfo.OpenWrite())
                        using (FileStream fileStream = new FileStream(@$"C:\vm\c{i}.zip", FileMode.Create, FileAccess.Write, FileShare.None, bufferSize: 81920, useAsync: true))
                        //stream.CopyTo(fileStream);
                        {
                            byte[] buffer = new byte[8 * 1024];
                            int len;
                            while ((len = stream.Read(buffer, 0, buffer.Length)) > 0)
                            {
                                fileStream.Write(buffer, 0, len);
                            }
                        }
                    }
                    else
                    {
                        //  throw new exception("file not found");
                    }
                }
                GC.Collect();
            }
        }
        private async void button3_Click(object sender, EventArgs e)
        {
            var httpClient = new HttpClient();

            for (int i = 0; i < 2; i++)
            {
                //using (var request = new HttpRequestMessage(HttpMethod.Get, "https://getsamplefiles.com/download/zip/sample-3.zip"))
                //{
                //    using (HttpResponseMessage response = await httpClient.SendAsync(request))
                //    {
                //        if (response.IsSuccessStatusCode)
                //        {
                //            //using (Stream stream = await response.Content.ReadAsStreamAsync())
                //            //using (FileStream fileStream = File.Create(@$"C:\vm\c{i}.zip"))
                //            using (FileStream fileStream = new FileStream(@$"C:\vm\c{i}.zip", FileMode.Create, FileAccess.Write, FileShare.None, bufferSize: 4096, useAsync: true))
                //            {
                //                Action<long, long> progressCallback = (current, total) =>
                //                {
                //                    double progress = (double)current / total * 100;
                //                    Console.WriteLine($"Download progress: {progress}%");
                //                };

                //                var progressContent = new ProgressHttpContent(response.Content, progressCallback);

                //                await progressContent.CopyToAsync(fileStream);
                //            }
                //        }
                //    }
                //}
                xx(httpClient, i);
                //this.BeginInvoke((Action)(() =>
                //{
                //    label1.Text = ((int)(i * 100)).ToString();
                //}));

            }

        }

        void GetDirsPath(string getPath)
        {
            string[] dirs = Directory.GetDirectories(getPath);

            for (int i = 0; i < dirs.Length; i++)
            {
                listBox1.Items.Add(dirs[i]);
                //    Console.WriteLine(dirs[i]);
                GetDirsPath(dirs[i]);
            }
        }
        private void button4_Click(object sender, EventArgs e)
        {
            //string fileName = @"C:\\vm\\project1\\MyFirstFile.txt";

            //try
            //{
            //    // Delete the file if it exists.
            //    if (File.Exists(fileName))
            //    {
            //   //     File.Delete(fileName);
            //    }
            //    Console.Write("\n\n Create a file in the disk if it is exists:\n");
            //    Console.Write("-----------------------------------------------\n");
            //    // Create the file.
            //    Directory.CreateDirectory(Path.GetDirectoryName(fileName));
            //    using (FileStream fileStr = new FileStream(fileName, FileMode.Create))
            //    {
            //        Console.WriteLine(" A file created with name mytest.txt\n\n");
            //    }
            //}
            //catch (Exception MyExcep)
            //{
            //    Console.WriteLine(MyExcep.ToString());
            //}
            //File.Create("C:\\vm\\project1\\MyFirstFile.txt");
            listBox1.Items.Clear();
            ProcessFiles2(@"C:\vm\test");
        }
        void ProcessFiles2(string path)
        {
            Stack<string> stack;
            string[] files;
            string[] directories;
            string dir;

            stack = new Stack<string>();
            stack.Push(path);

            while (stack.Count > 0)
            {

                // Pop a directory
                dir = stack.Pop();

                files = Directory.GetFiles(dir);
                foreach (string file in files)
                {
                    Directory.CreateDirectory(Path.GetDirectoryName(file.Replace(@"C:\vm\test", @"C:\vm1\test")));
                    using (FileStream fileStr = new FileStream(file.Replace(@"C:\vm\test", @"C:\vm1\test"), FileMode.Create))
                    {
                        Console.WriteLine(" A file created with name mytest.txt\n\n");
                    }
                    listBox1.Items.Add(file);
                    // Process each file
                }

                directories = Directory.GetDirectories(dir);
                foreach (string directory in directories)
                {
                    // Push each directory into stack
                    stack.Push(directory);
                }
            }
        }

        void ProcessFiles(string path)
        {
            string[] files;
            string[] directories;

            files = Directory.GetFiles(path);
            foreach (string file in files)
            {
                listBox1.Items.Add(file);
                // Process each file
            }

            directories = Directory.GetDirectories(path);
            foreach (string directory in directories)
            {
                // Process each directory recursively
                ProcessFiles(directory);
            }
        }
        private List<gg> Contains(List<gg> list1, List<gg> list2)
        {
            List<gg> result = new List<gg>();

            result.AddRange(list1.Except(list2, new DataComparer()));
            result.AddRange(list2.Except(list1, new DataComparer()));

            return result;
        }
        private void button5_Click(object sender, EventArgs e)
        {
            var ls1= Enumerable.Range(1, 5).Select(n => new gg("s"+n.ToString(), "g" + n.ToString())).ToList();
            var ls2 = Enumerable.Range(1,6).Select(n => new gg("s" + n.ToString(), "g" + n.ToString())).ToList();
            ls1[0].s1 = "s11";
            var timer = new Stopwatch();
            timer.Start();
            //var d =  Contains(ls1, ls2);
            var d = ls1.Except(ls2);
            timer.Stop();

            TimeSpan timeTaken = timer.Elapsed;
            string foo = "Time taken: " + timeTaken.ToString(@"m\:ss\.fff");

            string cnt = d.Count().ToString();
        }
        //var task = Task.Run(() => httpClient.GetAsync(@"http://ipv4.download.thinkbroadband.com/200MB.zip"));
        //task.Wait();
        //var response = task.Result;

    }

    public class ProgressHttpContent : HttpContent
    {
        private readonly HttpContent _content;
        private readonly Action<long, long> _progressCallback;

        public ProgressHttpContent(HttpContent content, Action<long, long> progressCallback)
        {
            _content = content;
            _progressCallback = progressCallback;
        }

        protected override bool TryComputeLength(out long length)
        {
            length = _content.Headers.ContentLength ?? -1;
            return true;
        }

        protected override async Task SerializeToStreamAsync(Stream stream, TransportContext context)
        {
            var buffer = new byte[81920];
            long totalRead = 0;
            using (var contentStream = await _content.ReadAsStreamAsync())
            {
                var totalReadBytes = contentStream.Length;
                int read;
                while ((read = await contentStream.ReadAsync(buffer, 0, buffer.Length)) != 0)
                {
                    totalRead += read;
                    _progressCallback(totalRead, totalReadBytes);

                    await stream.WriteAsync(buffer, 0, read);
                }
            }
        }
    }
}