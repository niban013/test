﻿using System.Web;
using System.Windows.Forms;

namespace WordAddIn1
{
    public partial class ThisAddIn
    {
        public static Microsoft.Office.Interop.Word.Application app;
        private void ThisAddIn_Startup(object sender, System.EventArgs e)
        {
            app = Application;


            //app.Documents.Open(@"C:\\Users\\Honjay\\Downloads\\駐點人員工作時數管控表 (3).docx");

            //MessageBox.Show("oo");
        }
        public static void Open(string str)
        {
            //System.Diagnostics.Process.Start(str);
            Microsoft.Office.Interop.Word.Application app2 = new Microsoft.Office.Interop.Word.Application();
            app2.Visible = true;
            app2.Documents.Open(str);
        }
        protected override Microsoft.Office.Core.IRibbonExtensibility CreateRibbonExtensibilityObject()
        {
            return new Ribbon1();
        }
        private void ThisAddIn_Shutdown(object sender, System.EventArgs e)
        {
        }

        #region VSTO generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InternalStartup()
        {
            this.Startup += new System.EventHandler(ThisAddIn_Startup);
            this.Shutdown += new System.EventHandler(ThisAddIn_Shutdown);
        }

        #endregion
    }
}
