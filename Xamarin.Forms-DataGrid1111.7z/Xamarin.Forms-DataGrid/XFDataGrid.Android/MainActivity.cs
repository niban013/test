﻿using System;

using Android.App;
using Android.Content.PM;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using Android.OS;
using Android;
using Android.Support.V4.App;

//[assembly: UsesPermission(Name = Android.Manifest.Permission.ReadExternalStorage)]
//[assembly: UsesPermission(Name = Android.Manifest.Permission.WriteExternalStorage)]
namespace XFDataGrid.Droid
{
    [Activity(Label = "XFDataGrid", Icon = "@mipmap/icon", Theme = "@style/MainTheme", MainLauncher = true, ConfigurationChanges = ConfigChanges.ScreenSize | ConfigChanges.Orientation)]
    public class MainActivity : global::Xamarin.Forms.Platform.Android.FormsAppCompatActivity
    {
        protected override void OnCreate(Bundle savedInstanceState)
        {
            TabLayoutResource = Resource.Layout.Tabbar;
            ToolbarResource = Resource.Layout.Toolbar;
            VerifyStoragePermissions(this);
            base.OnCreate(savedInstanceState);

            Xamarin.Essentials.Platform.Init(this, savedInstanceState);
            global::Xamarin.Forms.Forms.Init(this, savedInstanceState);
            LoadApplication(new App());
        }
        //public override void OnRequestPermissionsResult(int requestCode, string[] permissions, [GeneratedEnum] Android.Content.PM.Permission[] grantResults)
        //{
        //    PermissionsImplementation.Current.OnRequestPermissionsResult(requestCode, permissions, grantResults);
        //    base.OnRequestPermissionsResult(requestCode, permissions, grantResults);
        //}
        public override void OnRequestPermissionsResult(int requestCode, string[] permissions, [GeneratedEnum] Android.Content.PM.Permission[] grantResults)
        {
            Xamarin.Essentials.Platform.OnRequestPermissionsResult(requestCode, permissions, grantResults);
            //Plugin.Permissions.PermissionsImplementation.Current.OnRequestPermissionsResult(requestCode, permissions, grantResults);
            base.OnRequestPermissionsResult(requestCode, permissions, grantResults);
        }

        private static int REQUEST_EXTERNAL_STORAGE = 1;
        private static String[] PERMISSIONS_STORAGE = {
           Manifest.Permission.ReadExternalStorage,
           Manifest.Permission.WriteExternalStorage};

        public static bool VerifyStoragePermissions(Activity activity)
        {
            var permission = ActivityCompat.CheckSelfPermission(activity,
              Manifest.Permission.WriteExternalStorage);

            if (permission == Permission.Denied)
            {
                ActivityCompat.RequestPermissions(activity, PERMISSIONS_STORAGE,
                  REQUEST_EXTERNAL_STORAGE);
                return false;
            }
            return true;
        }
    }
}