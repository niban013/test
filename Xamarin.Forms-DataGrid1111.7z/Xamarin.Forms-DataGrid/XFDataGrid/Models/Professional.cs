﻿using System;
namespace XFDataGrid.Models
{
    public class Professional
    {
        public string Id { get; set; }
        public string Name { get; set; }
        public string Desigination { get; set; }
        public string Domain { get; set; }
        public string Experience { get; set; }
    }
}
