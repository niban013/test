﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xamarin.Forms;
using XFDataGrid.Utils;
using XFDataGrid.ViewModels;

namespace XFDataGrid
{
    // Learn more about making custom code visible in the Xamarin.Forms previewer
    // by visiting https://aka.ms/xamarinforms-previewer
    [DesignTimeVisible(false)]
    public partial class MainPage : ContentPage
    {
        public MainPage()
        {
            InitializeComponent();
            BindingContext = new MainPageViewModel();
            inc.ItemSelected += SfGrid_GridLongPressed;
        }
        private void SfGrid_GridLongPressed(object sender, SelectedItemChangedEventArgs e)
        {
            int rowindex = e.SelectedItemIndex;
            DisplayAlert("Alert", rowindex.ToString(), "OK");
        }

        private async void Button_Clicked(object sender, EventArgs e)
        {

            down d = new down();
            d.downloadAsync(); 
        }

    }
}
