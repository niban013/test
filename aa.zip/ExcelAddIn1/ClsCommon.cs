﻿using ExcelAddIn1.Properties;
using Microsoft.Win32;
using Newtonsoft.Json;
using RabbitMQ.Client.Events;
using RabbitMQ.Client;
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Threading.Tasks;
using System.Text;
using System.Diagnostics;
using System.Security.Policy;
using System.Linq;
using System.Windows.Forms;
using MQTTnet;
using MQTTnet.Client;
using System.Threading;
using MQTTnet.Server;

namespace ExcelAddIn1
{
    public static class ClsCommon
    {
        public static IMqttClient mqttClient;
        public static void saveReg(string product, string version, string url, string value)
        {
            RegistryKey reg;
            using (reg = Registry.CurrentUser.OpenSubKey($@"Software\{product}\{version}", true))
            {
                if (reg == null)
                {
                    reg = Registry.CurrentUser.CreateSubKey($@"Software\{product}\{version}");
                }

                if (reg.GetValue(url) == null)
                {
                    reg.SetValue(url, value, RegistryValueKind.String);
                }

                if (reg.GetValue(url).ToString() != value)
                {
                    reg.SetValue(url, value, RegistryValueKind.String);
                }
            }
        }
        public static async Task<List<string>> GetWebdavServer(string product, string version,string url)
        {
            List<string> result = new List<string>();
            using (RegistryKey key = Registry.CurrentUser.OpenSubKey($@"Software\{product}\{version}", true))
            { 
                HttpClient client = GetHttpClient("");
                string uri = key.GetValue(url).ToString();
                HttpResponseMessage response = await client.GetAsync(uri);
                if (response.StatusCode == System.Net.HttpStatusCode.NotFound)
                {
                    result = new List<string>() { "http://jnvb2bweb01.cminl.oa:8080" };
                }
                else
                {
                    result = JsonConvert.DeserializeObject<List<string>>(response.Content.ReadAsStringAsync().Result);
                } 
            } 
            return result;
        }
        public static HttpClient GetHttpClient(string ticket)
        {
            HttpClient client = new HttpClient()
            {
                Timeout = TimeSpan.FromMinutes(20)
            };
            if (ticket != "")
            {
                client.DefaultRequestHeaders.Clear();
                client.DefaultRequestHeaders.Add("ticket", ticket);

            }
            return client;
        }

        public static async void registerMQTT(string user)
        {
            try
            {
                if (mqttClient != null)
                    return;

                using (RegistryKey key = Registry.CurrentUser.OpenSubKey($@"Software\{ThisAddIn.product}\{ThisAddIn.version}", true))
                {
                    string rq = key.GetValue("WebDavUrl").ToString();

                    var UserName = "webdav";
                    var Password = "webdav";
                    var HostName = rq.Replace("http://", "").Split(':').First();
                    HostName = HostName.Split('/').First();
                    mqttClient = new MqttFactory().CreateMqttClient();
                    var options = new MqttClientOptionsBuilder().WithClientId(user)
                        .WithCredentials(UserName, Password)
                        .WithTcpServer(HostName, 61613)
                        .Build();
                    // When client connected to the server
                    //MessageBox.Show("HostName:" + HostName);
                    mqttClient.ConnectedAsync += (async e =>
                    {
                        await mqttClient.SubscribeAsync(new MqttTopicFilterBuilder().WithTopic("webdav-" + user).Build());
                    });


                    mqttClient.ApplicationMessageReceivedAsync += (async e =>
                    {
                        var payload = e.ApplicationMessage.ConvertPayloadToString();
                       // MessageBox.Show("payload:" + payload);
                        showMessage(payload);
                    });

                    mqttClient.DisconnectedAsync += (async e =>
                    {
                       // MessageBox.Show("MQTT:" + "MQTT reconnecting");
                        Console.WriteLine("MQTT reconnecting");
                        await Task.Delay(TimeSpan.FromSeconds(5));
                        await mqttClient.ConnectAsync(options, CancellationToken.None);
                    });
                    await mqttClient.ConnectAsync(options, CancellationToken.None); 
                }
            }
            catch (Exception ex)
            {
           
            }
        }

        [Obsolete]
        public static RabbitMQ.Client.IConnection CreateConnection() 
        {
            ConnectionFactory factory;
            using (RegistryKey key = Registry.CurrentUser.OpenSubKey($@"Software\{ThisAddIn.product}\{ThisAddIn.version}", true))
            {
                string rq = key.GetValue("RabitMQ").ToString();
                factory = new ConnectionFactory
                {
                    UserName = rq.Split('@').FirstOrDefault().Split('/').FirstOrDefault(),
                    Password = rq.Split('@').FirstOrDefault().Split('/').Last(),
                    HostName = rq.Split('@').Last(),

                    //自動回復連線
                    //  AutomaticRecoveryEnabled = true,
                    //心跳檢測頻率
                    // RequestedHeartbeat = TimeSpan(10),
                };
            }
            factory.DispatchConsumersAsync = true;
            return  factory.CreateConnection();
        }

        [Obsolete]
        public static void registerMessage(RabbitMQ.Client.IConnection connection ,string user)
        {
            try
            { 
                    var exchangeName = "Webdav";
                    var queueName = user;
                    var routeKey = user; 
                    using (var channel = connection.CreateModel())
                    {
                        channel.ExchangeDeclare(exchange: exchangeName, ExchangeType.Direct);
                        channel.QueueDeclare(queueName, true, false, false, null);
                        channel.QueueBind(queueName, exchangeName, routeKey); //綁定一個消費者
                                                                              //channel.QueueBind
                        var consumerAsync = new AsyncEventingBasicConsumer(channel);
                        channel.BasicQos(0, 1, false);
                        //接收到消息事件 consumer.IsRunning
                        consumerAsync.Received += async (ch, ea) =>
                        {
                            var body = ea.Body.ToArray();
                            // var msg = JsonConvert.DeserializeObject<Message>(Encoding.UTF8.GetString(body)); 
                            showMessage(Encoding.UTF8.GetString(body));
                            // Console.WriteLine($"Queue:{queueName}收到資料： {msg.msg}");
                            channel.BasicAck(ea.DeliveryTag, false);
                        };

                        channel.BasicConsume(queueName, true, consumerAsync);
                    } 
            }
            catch(Exception ex) 
            { 
            
            } 
        }
        private static string toBase64(string inputText)
        {
            Byte[] bytesEncode = System.Text.Encoding.UTF8.GetBytes(inputText);
            return Convert.ToBase64String(bytesEncode);
        }
        private static void showMessage(string msg)
        {
            //MessageBox.Show(toBase64(msg));
            using (RegistryKey key = Registry.CurrentUser.OpenSubKey($@"Software\{ThisAddIn.product}\{ThisAddIn.version}", true))
            {
                object exe = key.GetValue("Message");
                if (exe == null)
                {
                    return;
                }
                else if (exe.ToString() == "")
                {
                    return;
                }
                else
                {
                    //MessageBox.Show(toBase64(msg));
                    ProcessStartInfo pInfo = new ProcessStartInfo(exe.ToString());
                    pInfo.Arguments = toBase64(msg);
                    pInfo.UseShellExecute = true;
                    using (Process p = new Process())
                    {
                        p.StartInfo = pInfo;
                        p.Start();
                    }
                }
            } 
        }
    } 
}
