﻿using System;
using System.Windows.Forms;
using System.Security.Principal;

namespace ExcelAddIn1
{
    public partial class ThisAddIn
    {
        public static string product = "InnoDrive";//, "1.0", "WebDavUrl"
        public static string version = "1.0";
        public RabbitMQ.Client.IConnection connection;
        Timer timer1 = new Timer();
        private void ThisAddIn_Startup(object sender, System.EventArgs e)
        {
            timer1.Start();
            this.timer1.Interval = 2000;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick); 



        }
        private void ThisAddIn_Shutdown(object sender, System.EventArgs e)
        {
            if (ClsCommon.mqttClient != null)
                ClsCommon.mqttClient = null; 
        }
        private void timer1_Tick(object sender, EventArgs e)
        {
            try
            {
                ClsCommon.registerMQTT(WindowsIdentity.GetCurrent().Name);
               
            }
            catch (Exception ex)
            {

            }
        }
        protected override Microsoft.Office.Core.IRibbonExtensibility CreateRibbonExtensibilityObject() => new Ribbon1();
        #region VSTO 產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InternalStartup()
        {
            this.Startup += new System.EventHandler(ThisAddIn_Startup);
            this.Shutdown += new System.EventHandler(ThisAddIn_Shutdown);
        }
        
        #endregion
    }
}
