﻿using Microsoft.Toolkit.Uwp.Notifications;
using Newtonsoft.Json;
using System.Windows.Forms;

namespace ShowMessage
{
    public partial class Form1 : Form
    {
        private string _args = string.Empty;

        public Form1()
        {
            InitializeComponent();
        }


        public Form1(string value)

        {
            InitializeComponent();
            if (!string.IsNullOrEmpty(value))
            {
                _args = value;
            }
        }
        public class Message
        {
            public string msg { get; set; }

        }
        private string fromBase64(string resultEncode)
        {
            Byte[] bytesDecode = Convert.FromBase64String(resultEncode);
            return System.Text.Encoding.UTF8.GetString(bytesDecode);
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            try
            {
                //_args = "eyJtc2ciOiLmqpTlkI06bGluZTEwLnR4dCzntZDmnpw65a2Y5qqU5oiQ5YqfIn0=";
                //MessageBox.Show("1:" + _args);
                //MessageBox.Show("1:" + fromBase64(_args));
                var _argsParse = JsonConvert.DeserializeObject<Message>(fromBase64(_args));

                if (string.IsNullOrEmpty(_argsParse.msg.ToString()))
                {
                    this.Close();
                    return;
                }
                var lsMag = _argsParse.msg.ToString().Split(',');
                var text = lsMag[0];
                var text2 = lsMag[1];
                show(text, text2);

            }
            catch (Exception ex)
            {
                MessageBox.Show("2:" + ex.Message);
            }
            finally
            {
                this.Close();
            }
        }
        void show(string msg, string msg2)
        { 
            var iconUri = "file:///" + Path.GetFullPath("images/inxDrive.png");
            new ToastContentBuilder()
               //.SetToastScenario(ToastScenario.Reminder)
               .AddAppLogoOverride(new Uri(iconUri), ToastGenericAppLogoCrop.Default)
               .AddText(msg)
               .AddAttributionText(msg2)
               .Show();
        }
    }
}