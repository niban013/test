﻿// See https://aka.ms/new-console-template for more information
using InnoDriveSys;
using Microsoft.Win32;
using System.Configuration;
using System.Security.Principal;

try
{
    var product = ConfigurationManager.AppSettings.Get("Product");
    var version = ConfigurationManager.AppSettings.Get("Version");
    var server = ConfigurationManager.AppSettings.Get("Server");
    var fileWatch = ConfigurationManager.AppSettings.Get("FileWatch");
    var mesage = ConfigurationManager.AppSettings.Get("Mesage");
    var rabitMQ = ConfigurationManager.AppSettings.Get("RabitMQ");
    string[] arguments = Environment.GetCommandLineArgs();
    if (arguments.Length > 0)
    {
        //var path = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "Microsoft", "Windows", "Network Shortcuts");
        //string shortcut_link = Path.Combine(path, product);
        //if (Directory.Exists(Path.Combine(path, product)))
        //{
        //    Directory.Delete(Path.Combine(path, product));
        //}

        ClsCommon.registerQuick(product, "http://jnvtssoap01.cminl.oa/webdav");
        if (arguments[1] == "/uninstall")
        {
            ClsCommon.removeShortcut(product);
        }
        else 
        { 
            Console.WriteLine("組態設定中，請稍候.............");
            ClsCommon.saveReg(product, version, "WebApiUrl", server);
            Console.WriteLine("WebApiUrl新增完成.............");
            ClsCommon.saveReg(product, version, "FileWatch", fileWatch);
            Console.WriteLine("檔安組件新增完成.............");
            ClsCommon.saveReg(product, version, "Message", mesage);
            Console.WriteLine("訊息組件新增完成.............");
            var lsServer = ClsCommon.GetWebdavServer(product, version, "WebApiUrl").Result;
            server = lsServer.Count > 0 ? lsServer[0] : "";
            using (RegistryKey key = Registry.CurrentUser.OpenSubKey($@"Software\{product}\{version}", true))
            {
                object uri = key.GetValue("WebDavUrl");
                if (uri == null)
                {
                    // server = lsServer.Count > 0 ? lsServer[0] : "";
                    if (server.Length > 0)
                    {
                        ClsCommon.saveReg(product, version, "WebDavUrl", server);
                    }
                }
                else if (string.IsNullOrEmpty(uri.ToString()))
                {
                    // server = lsServer.Count > 0 ? lsServer[0] : "";
                    if (server.Length > 0)
                    {
                        ClsCommon.saveReg(product, version, "WebDavUrl", server);
                    }
                }
                else
                {
                    // server = lsServer.Count > 0 ? lsServer[0] : "";
                    if (server != uri.ToString())
                    {
                        ClsCommon.saveReg(product, version, "WebDavUrl", server);
                    }
                }
                ClsCommon.registerQuick(product, server);
                Console.WriteLine("快捷組件新增完成.............");
                //ClsCommon.registerRabitMQ(product, version,key.GetValue("RabitMQ"));
            }

        }

    } 
}
catch (Exception ex)
{
    Console.WriteLine(ex.Message);
}
