using Microsoft.Win32;
using Microsoft.WindowsAPICodePack.Dialogs;
using System.Diagnostics;

namespace OpenFileDialogCore
{
    public partial class Form1 : Form
    {
        private string _args;
#pragma warning disable CS8618 // �h�X�غc�禡�ɡA���i�� Null ����쥲���]�t�D Null �ȡC�ЦҼ{�ŧi���i�� Null�C
        public Form1()
#pragma warning restore CS8618 // �h�X�غc�禡�ɡA���i�� Null ����쥲���]�t�D Null �ȡC�ЦҼ{�ŧi���i�� Null�C
        {
            InitializeComponent();
        }

#pragma warning disable CS8618 // �h�X�غc�禡�ɡA���i�� Null ����쥲���]�t�D Null �ȡC�ЦҼ{�ŧi���i�� Null�C
        public Form1(string value)
#pragma warning restore CS8618 // �h�X�غc�禡�ɡA���i�� Null ����쥲���]�t�D Null �ȡC�ЦҼ{�ŧi���i�� Null�C
        {
            InitializeComponent();
            if (!string.IsNullOrEmpty(value))
            {
                _args = value;
            }
        }
        private void Form1_Load(object sender, EventArgs e)
        {
          //  _args = "http://tw075371p:5354";
            var product = "InnoDrive";//, "1.0", "WebDavUrl"
#pragma warning disable CS0219 // �w�����ܼơA���q���ϥιL���
            var version = "1.0";
#pragma warning restore CS0219 // �w�����ܼơA���q���ϥιL���
            var uri = "";
            var uri2 = "";
            var bUnc = false;
            if (string.IsNullOrEmpty(_args))
            {
                this.Close();
                return;
            }
            string path = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "Microsoft", "Windows", "Network Shortcuts", product);
          
            //using (RegistryKey key = Registry.CurrentUser.OpenSubKey($@"Software\{product}\{version}", true))
            //{
            //    uri2 = uri = "http://tw075371p:5354";// key.GetValue("WebDavUrl").ToString(); 
            //}
         
           // MessageBox.Show(_args);
            uri2 = uri = _args;

            if (uri.Length > 0)
            {
                uri = uri.TrimEnd('/');
                uri = uri.Replace("http://", "").Replace(":", "@");
                uri = @"\\" + uri + @"\DavWWWRoot";

                var fileName = Directory.GetFiles(path, "*.lnk").FirstOrDefault();
                if (!string.IsNullOrEmpty(fileName))
                {
                    try
                    {
                        CommonOpenFileDialog dialog = new CommonOpenFileDialog()
                        {
                            AllowNonFileSystemItems = true,
                            EnsurePathExists = true,
                            Multiselect = false,
                            NavigateToShortcut = false,
                            Title = "�}��"
                        };
                        dialog.Filters.Add(new CommonFileDialogFilter("Excel", "xlsx,xls"));
                        dialog.InitialDirectory = uri;

                        try
                        {
                            bUnc = Directory.Exists(uri);
                            if (!bUnc)
                            {
                                ProcessStartInfo pInfo = new ProcessStartInfo(uri);
                                pInfo.UseShellExecute = true;
                                using (Process p = new Process())
                                {
                                    p.StartInfo = pInfo;
                                    p.Start();
                                }
                            }
                            else
                            {
                                //  dialog.RestoreDirectory = false;
                                if (dialog.ShowDialog() == CommonFileDialogResult.Ok)
                                {
#pragma warning disable CS8604 // �i�঳ Null �ѦҤ޼ơC
                                    ProcessStartInfo pInfo = new ProcessStartInfo(dialog.FileName);
#pragma warning restore CS8604 // �i�঳ Null �ѦҤ޼ơC
                                    pInfo.UseShellExecute = true;
                                    using (Process p = new Process())
                                    {
                                        p.StartInfo = pInfo;
                                        p.Start();
                                    }
                                }
                                else
                                {


                                }
                            }
                        }
                        catch (Exception ex)
                        {
                            if (ex.Message.Contains("�t�Χ䤣����w���ɮ�"))
                            {
                                MessageBox.Show("WebDav �s�u����");
                            }
                            else if (ex.Message.Contains("�䤣������W��"))
                            {
                                MessageBox.Show("WebDav �s�u����");
                            }
                            else
                            {
                                ProcessStartInfo pInfo = new ProcessStartInfo(fileName);
                                pInfo.UseShellExecute = true;
                                using (Process p = new Process())
                                {
                                    p.StartInfo = pInfo;
                                    p.Start();
                                }
                            }

                        } 
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message);
                    }
                    finally
                    {
                        this.Close();
                    }
                }
            }
        }
    }
}