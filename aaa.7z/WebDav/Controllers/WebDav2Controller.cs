﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.StaticFiles;
using System.Buffers;
using System.IO;
using System.Net;
using System.Web;
using System.Xml.Linq;
using WebDav.Helpers;
using WebDav.Model;
using WebDav.Services;

namespace WebDav.Controllers
{
    [Authorize]
    [Route("{**path}")]
    public class WebDav2Controller : ControllerBase
    {
 
        private readonly ILogger<WebDavController> _logger;
        private IHttpContextAccessor httpContextAccessor;
        private readonly IRabitMQProducer _rabitMQProducer;
        private readonly WebService webService;
        private readonly SessionService sessionService;
        private readonly IConfiguration _config;

        
        private string currentUser
        {
            get
            {
                return string.IsNullOrEmpty(this.sessionService.Get<string>(this.httpContextAccessor.HttpContext.Session.Id)) ? "Webdav" : this.sessionService.Get<string>(this.httpContextAccessor.HttpContext.Session.Id);
            }
        }

        public WebDav2Controller(IHttpContextAccessor httpContextAccessor, ILogger<WebDavController> logger, IConfiguration _configuration
            , WebService _webService
            , SessionService _sessionService
            , IRabitMQProducer rabitMQProducer)
        { 
          //  ClsCommon.Connect(@"tnoafs01.cminl.oa\INXDrive$", "drvuser", "innoDrv@2021" );
            _config = _configuration;
            _logger = logger;
            _rabitMQProducer = rabitMQProducer;
            this.webService = _webService;
            this.sessionService = _sessionService;
           
            this.httpContextAccessor = httpContextAccessor; 
            this.sessionService.Set(this.httpContextAccessor.HttpContext.Session.Id,
                 _config["ApiAccount"] == "" ? this.httpContextAccessor.HttpContext.User.Identity.Name : "CMINL\\"+_config["ApiAccount"]); 
        
        }


        [HttpGet]
        public async Task GetAsync(string? path, CancellationToken cancellationToken = default)
        {
            var decodePath = webService.GetPath(path);
            try
            {
                webService.callLog(Request, _logger); 
                if (decodePath.Contains("favicon.ico")
                    || decodePath.Contains("desktop.ini")
                      || decodePath.Contains(".git")
                         || decodePath.Contains("HEAD") 
                         //|| decodePath.Contains("~$")
                         || path == null)
                {

                }
                else
                { 
                    var physicalPath = this.webService.GetPhysicalPath(ClsCommon.dicUserDirs[this.currentUser],path);
                    if (System.IO.File.Exists(physicalPath))
                    {
                        if (decodePath.Contains(".txt"))
                        {
                            Response.ContentType = "Content-Type: text/plain; charset=utf-8";
                        }
                        else
                        {
                            Response.ContentType = ClsCommon.GetMimeType(physicalPath);
                        }
                        Response.ContentLength = new FileInfo(physicalPath).Length;

                        using (var stream = new FileInfo(physicalPath).OpenRead())
                        {
                            await stream.CopyToAsync(Response.Body);
                        }
                    }
                    else
                    {

                    }
                } 
                //Response.StatusCode = (int)HttpStatusCode.OK;
            }
            catch (Exception ex)
            {
                Console.WriteLine("User:" + this.currentUser + "," + ex.Message + "," + ex.StackTrace);
                _logger.LogError("User:" + this.currentUser + "," + ex.Message + "," + ex.StackTrace); 
                this.webService.showMessage(_rabitMQProducer,Path.GetFileName(decodePath),ex.Message,this.currentUser);
                Response.StatusCode = (int)HttpStatusCode.NotFound;
                throw;
            }
        }

    
        [ApiExplorerSettings(IgnoreApi = true)]
        [AcceptVerbs("PROPFIND")]
        public async Task<string> PropfindAsync(string? path, CancellationToken cancellationToken)
        {
            var decodePath = webService.GetPath(path);
            var xMultiStatus = new XElement(ClsCommon.DavNs + "multistatus");
            var xml = new XDocument(new XDeclaration("1.0", "utf-8", "yes"), xMultiStatus);
            try
            {
                webService.callLog(Request, _logger);

                if (decodePath.Contains("favicon.ico")
                 || decodePath.Contains("desktop.ini")
                 || decodePath.Contains(".git")
                 || decodePath.Contains("HEAD")
                  //|| decodePath.Contains("~$")
                  || decodePath.EndsWith("exe.Config")
                 )
                {
                    return xml.ToString();
                }
                if (!ClsCommon.dicUserDirs.ContainsKey(this.currentUser))
                {
                    ClsCommon.dicUserDirs[this.currentUser] = new List<webdavInfo>();
                }
                if (!string.IsNullOrEmpty(this.sessionService.Get<string>(this.currentUser + ":" + "D")))
                {
                    this.sessionService.Get<string>(this.currentUser + ":" + "D").Split(',').ToList().ForEach(p => {
                        var item = ClsCommon.dicUserDirs[this.currentUser].Where(o => o.itemId == p).FirstOrDefault();
                        if (item != null)
                        {
                            ClsCommon.dicUserDirs[this.currentUser].Remove(item);
                        }
                    });
                    this.sessionService.Remove(this.currentUser + ":" + "D");
                }

                var urlpath = ""; 
                if (decodePath == "/")
                {
                    urlpath = "ORG";
                    this.webService.refreshItems(this.webService.createInfo(null, true),this.currentUser);
                    var items = await this.webService.getDriveItems(urlpath, this.currentUser);
                    if (items != null)
                    { 
                        for (int i = 0; i < items.Count(); i++)
                        {
                            this.webService.refreshItems(this.webService.createInfo(items[i]), this.currentUser);
                        }
                    } 
                }
                else
                {
                    decodePath = decodePath.EndsWith("/") ? decodePath.TrimEnd('/') : decodePath;  
                    urlpath = decodePath; 
                    await syncWebDavInfo(urlpath);
                }

                var filename = ClsCommon.GetFileName(decodePath);

                webdavInfo currentItem = null;
                ClsCommon.log("currentUser:" + currentUser);
                if (decodePath == "/")
                {
                    currentItem = ClsCommon.dicUserDirs[this.currentUser].Where(p => p.parentPath is null || p.path == Path.Combine("/", decodePath)).FirstOrDefault();
                }
                else
                {
                    currentItem = ClsCommon.dicUserDirs[this.currentUser].Where(p => p.path == Path.Combine("/", decodePath)).FirstOrDefault();
                }

                if (currentItem == null)
                {

                    xml.Root.Add(this.webService.CreateResponseElement(Request, decodePath, !(filename.Length > 0), true));
                    if (filename.Length > 0)
                    { 
                        this.sessionService.Set(this.currentUser + ":" + "AF", "Y");
                    } 
                    Response.StatusCode = (int)HttpStatusCode.NotFound; 
                    return xml.ToString();

                    //  var isDir1 = false;
                    // var response1 = new XElement(DavNs + "response",
                    //new XElement(DavNs + "href", "http://tw075371p.cminl.oa:5002/MARS01/PNG/linux.pdf"),
                    //new XElement(DavNs + "propstat",
                    //    new XElement(DavNs + "prop",
                    //        new XElement(DavNs + "displayname", "linux.pdf"),
                    //        new XElement(DavNs + "getlastmodified", "2023-04-27T01:23:28.109Z"),
                    //        new XElement(DavNs + "getlastaccessed", "2023-04-27T01:23:28.109Z"),
                    //        new XElement(DavNs + "creationdate", "2023-04-27T01:23:28.109Z"),
                    //        new XElement(DavNs + "getcontentlength", isDir1 ? "0" : "111"),
                    //        new XElement(DavNs + "getcontenttype", isDir1 ? "httpd/unix-directory" : "application/octet-stream"),
                    //        new XElement(DavNs + "resourcetype", isDir1 ? new XElement(DavNs + "collection") : null)),
                    //    new XElement(DavNs + "status", "HTTP/1.1 200 OK")));

                    //  xml.Root.Add(response1);
                    //  Response.StatusCode = (int)HttpStatusCode.MultiStatus;
                    //return xml.ToString();
                }
                bool isDir = currentItem.fileType == "D";
                bool isFile = currentItem.fileType == "F";

                XElement response = null;
                xMultiStatus = new XElement(ClsCommon.DavNs + "multistatus");
                xml = new XDocument(new XDeclaration("1.0", "utf-8", "yes"), xMultiStatus);
                if (!isDir && !isFile)
                {

                }
                else
                {
                    int depth = this.webService.GetDepthHeader(Request);
                    if (depth == 0)
                    {
                        if (currentItem.fileType == "F")
                        {
                            xml.Root.Add(this.webService.CreateResponseElement(Request, ClsCommon.dicUserDirs[this.currentUser],currentItem, false));
                        }
                        else
                        {
                            xml.Root.AddFirst(this.webService.CreateResponseElement(Request, ClsCommon.dicUserDirs[this.currentUser], currentItem, true));
                        }
                    }
                    else
                    {
                        if (currentItem.fileType == "F")
                        {
                            xml.Root.Add(this.webService.CreateResponseElement(Request, ClsCommon.dicUserDirs[this.currentUser], currentItem, false));
                        }
                        else
                        {
                            var _dirs = ClsCommon.dicUserDirs[this.currentUser].Where(p => p.parent == currentItem.itemId && p.parentPath != null && p.fileType == "D").ToArray();

                            foreach (var webdavInfo in _dirs)
                            {
                                xml.Root.Add(this.webService.CreateResponseElement(Request, ClsCommon.dicUserDirs[this.currentUser], webdavInfo, true));
                            }

                            var _files = ClsCommon.dicUserDirs[this.currentUser].Where(p => p.parent == currentItem.itemId && p.fileType == "F").ToArray();
                            foreach (var file in _files)
                            {
                                xml.Root.Add(this.webService.CreateResponseElement(Request, ClsCommon.dicUserDirs[this.currentUser], file, false));
                            }
                            if (_dirs.Length > 0 || _files.Length > 0)
                            {
                                xml.Root.AddFirst(this.webService.CreateResponseElement(Request, ClsCommon.dicUserDirs[this.currentUser], currentItem, true));
                            }
                            if (_files.Count() == 0 && _dirs.Length == 0)
                            {
                                xml.Root.Add(this.webService.CreateResponseElement(Request, ClsCommon.dicUserDirs[this.currentUser], currentItem, true));
                            }
                        }
                    }
                }
                Response.StatusCode = (int)HttpStatusCode.MultiStatus;
                return xml.ToString();
            }
            catch (Exception ex)
            {
                _logger.LogError("User:" + this.currentUser + "," + ex.Message + "," + ex.StackTrace);
                Console.WriteLine("User:"+this.currentUser +","+ex.Message);
                this.webService.showMessage(_rabitMQProducer, decodePath, "目錄:查詢出現問題", this.currentUser);
                Response.StatusCode = (int)HttpStatusCode.NotFound;
                return xml.ToString();
            } 
        }

        private async Task<bool> syncWebDavInfo(string? path)
        {
            var items = await this.webService.getDriveItems(path, this.currentUser);
            if (items != null)
            {
                this.webService.reCreateWebDav(items, this.currentUser);
            }
            return true;
        }
       
        [HttpHead]
        public async Task<IActionResult> Head(string? path)
        {
            try
            { 
                path = webService.GetPath(path);
                webService.callLog(Request, _logger);
             
                path = path.EndsWith("/") ? path.TrimEnd('/') : path;
                await syncWebDavInfo(path);

                try
                {
                    var truePath = this.webService.GetPhysicalPath(ClsCommon.dicUserDirs[this.currentUser],path);
                }
                catch (Exception ex)
                {
               
                    return StatusCode((int)HttpStatusCode.OK);
                }
               
                //Response.ContentLength = 0;
                //Response.Headers.Add("Content-Type", "text/html");
                Response.Headers.Add("Last-Modified", DateTime.Now.ToString());
                return Ok();
            }
            catch (Exception ex)
            {
                return NotFound();
            }


            //string head = null!;

            //if (head != null)
            //{
            //    Response.Headers.Add("Last-Modified", DateTime.Now.ToString());
            //    return Ok();
            //}
            //else
            //    return NotFound();
            //return Ok();
        }
        //
        [HttpOptions]
        public ActionResult Options(string? path)
        {
            webService.callLog(Request, _logger);
            var methods = new string[]
            {
                    "OPTIONS", "GET", "HEAD", "PROPFIND", "MKCOL", "PUT", "DELETE", "COPY", "MOVE", "LOCK", "UNLOCK", "PROPPATCH"
            }; 
            Response.Headers.Add("Allow", String.Join(',', methods));
            Response.Headers.Add("DAV", "1,2,extend");
            Response.Headers.Add("MS-Author-Via", "DAV");
            //Response.Headers.Add("Allow", "COPY, DELETE, GET, HEAD, LOCK, MOVE, OPTIONS, POST, PROPFIND, PROPPATCH, PUT, REPORT, SEARCH, UNLOCK");
            //Response.Headers.Add("Public", "COPY, DELETE, GET, HEAD, LOCK, MOVE, OPTIONS, POST, PROPFIND, PROPPATCH, PUT, REPORT, SEARCH, UNLOCK");
            //Response.Headers.Add("DAV", "1,2,3");
            Response.Headers.Add("Versioning-Support", "DAV:basicversioning");
            return Ok();
        }

        [HttpDelete] 
        public async Task<IActionResult> Delete(string? path)
        {
            webdavInfo item = null;
            try
            {
                webService.callLog(Request, _logger);
                path = webService.GetPath(path);
                if (path is null)
                {
                    return StatusCode((int)HttpStatusCode.Conflict);
                }
                await syncWebDavInfo(path);
              
                item = ClsCommon.dicUserDirs[this.currentUser].Where(p => p.path == ("/" + path)).FirstOrDefault();
                if (item != null)
                {
                    var itemId = item.itemId;
                    if (!string.IsNullOrEmpty(itemId))
                    {
                        await ClsCommon.DeleteFile(itemId, this.currentUser);
                        var sDel = this.sessionService.Get<string>(this.currentUser + ":" + "D");
                        if (string.IsNullOrEmpty(sDel))
                        {
                            sDel = itemId;
                        }
                        else
                        {
                            sDel += "," + itemId;
                        }
                        this.sessionService.Set(this.currentUser + ":" + "D", sDel);
                    }
                } 
                return StatusCode((int)HttpStatusCode.OK);
            }
            catch (Exception ex)
            {
                _logger.LogError("User:" + this.currentUser + "," + ex.ToString());
                this.webService.showMessage(_rabitMQProducer, Path.GetFileName(path), "請重新整理畫面再執行一次", this.currentUser);
                throw;
            }
            finally
            {
                if (item != null)
                {
                    ClsCommon.dicUserDirs[this.currentUser].Remove(item);
                }
            }
        }

        [HttpPut]
        [DisableRequestSizeLimit]
        public async Task<ActionResult> PutAsync(string? path, CancellationToken cancellationToken)
        {
            path = webService.GetPath(path);
            try
            {
                if (!path.Contains("/"))
                {
                    throw new Exception("不可向根節點新增檔案");
                }
                string operationMessage = string.Empty;
                webService.callLog(Request, _logger); 
                var contentLength = Request.ContentLength ?? 0;
                if (this.sessionService.Get<string>(this.currentUser + ":" + "AF") == "Y")
                {
                }
                else
                {
                    if (contentLength == 0)
                    {
                        return StatusCode((int)HttpStatusCode.NotModified);
                    }
                }
                (string resourceName, List<string> directories, bool isSearchDirectory) = this.webService.SplitPath(path);
               
                var items = await this.webService.getDriveItems("/" + string.Join('/', directories.ToArray()), this.currentUser);
                
                if (items != null)
                {
                    this.webService.reCreateWebDav(items, this.currentUser);
                }

                var currentItem = ClsCommon.dicUserDirs[this.currentUser].Where(p => p.path == Path.Combine("/", path)).FirstOrDefault();
                if (currentItem == null)
                {
                    //_logger.LogError("startUpload:" + path + "," + contentLength.ToString());
                    //(string resourceName, List<string> directories, bool isSearchDirectory) = this.webService.SplitPath(path);
                    var parentID = ClsCommon.dicUserDirs[this.currentUser].Where(p => p.path == ("/" + string.Join('/', directories.ToArray()))).Select(p => p.itemId).Distinct().First();
                    var nodeID = ClsCommon.dicUserDirs[this.currentUser].Where(p => p.path == ("/" + string.Join('/', directories.ToArray()))).Select(p => p.nodeId).Distinct().First();
                    await ClsCommon.UploadFiles(Request.Body, resourceName, nodeID, parentID, this.currentUser);
                    //_logger.LogError("endUpload:"+path + "@" + ", " + contentLength.ToString());
                    operationMessage = "檔案處理完成";
                }
                else
                {
                    //_logger.LogError("startCopy:" + path + "," + contentLength.ToString());
                    var filePath = this.webService.GetPhysicalPath(ClsCommon.dicUserDirs[this.currentUser],path);
                    await using var fileStream = System.IO.File.Create(filePath); 
                    await Request.Body.CopyToAsync(fileStream, cancellationToken);
                    //_logger.LogError("endCopy:" + path + "@"+ filePath +", " + contentLength.ToString());
                    operationMessage = "存檔成功";
                }
                this.webService.showMessage(_rabitMQProducer, Path.GetFileName(path), operationMessage, this.currentUser); 
                return StatusCode((int)HttpStatusCode.Created);
            }
            catch (Exception ex)
            {
                Console.WriteLine("User:" + this.currentUser + "," + ex.ToString());
                _logger.LogError("User:" + this.currentUser + "," + ex.ToString());
                if (ex.Message.Contains("permitted"))
                {
                    Response.StatusCode = (int)HttpStatusCode.Unauthorized;

                    // return StatusCode(statusCode: (int)HttpStatusCode.Unauthorized, value: new { status = (int)HttpStatusCode.Unauthorized, message = ex.ToString() });
                }
                else if (ex.Message.Contains("不可向根節點新增檔案"))
                {
                    Response.StatusCode = (int)HttpStatusCode.Unauthorized;
                }
                else
                {
                    Response.StatusCode = (int)HttpStatusCode.NotFound;
                    // return StatusCode(statusCode: (int)HttpStatusCode.NotFound, value: new { status = (int)HttpStatusCode.NotFound, message = ex.ToString() });
                }
                this.webService.showMessage(_rabitMQProducer, Path.GetFileName(path), ex.Message, this.currentUser); 
                throw;
            }
            finally
            {
                this.sessionService.Remove(this.currentUser + ":" + "AF");
                await syncWebDavInfo(path);
            }
        } 

        
        [ApiExplorerSettings(IgnoreApi = true)]
        [AcceptVerbs("MKCOL")]
        public async Task<IActionResult> MkCol(string? path, CancellationToken cancellationToken = default)
        {
            path = webService.GetPath(path);
            try
            {
                webService.callLog(Request, _logger);
                path = path.EndsWith("/") ? path.TrimEnd('/') : path;
                await syncWebDavInfo(path);

                (string resourceName, List<string> directories, bool isSearchDirectory) = this.webService.SplitPath(path); 
                var parentID = ClsCommon.dicUserDirs[this.currentUser].Where(p => p.path == ("/" + string.Join('/', directories.ToArray()))).Select(p => p.itemId).Distinct().First();
                if (parentID == "/")
                {
                    throw new Exception("Root can not add folder");
                }
                await ClsCommon.AddFolder(parentID, resourceName, this.currentUser);
                return StatusCode((int)HttpStatusCode.Created);
            }
            catch (Exception ex)
            {
                Console.WriteLine("User:" + this.currentUser + "," + ex.ToString());
                this.webService.showMessage(_rabitMQProducer, Path.GetFileName(path), ex.Message, this.currentUser);
                if (ex.Message.Contains("permitted") || ex.Message.Contains("Root can not add folder"))
                {
                    return StatusCode(statusCode: (int)HttpStatusCode.Unauthorized, value: new { status = (int)HttpStatusCode.Unauthorized, message = ex.ToString() });
                }
                else
                {
                    return StatusCode(statusCode: (int)HttpStatusCode.NotFound, value: new { status = (int)HttpStatusCode.NotFound, message = ex.ToString() });
                }
                throw;
            }
            finally
            {
            }
        }

        [ApiExplorerSettings(IgnoreApi = true)]
        [AcceptVerbs("MOVE")]
        public async Task<IActionResult> Move(string? path, CancellationToken cancellationToken = default)
        {
            webService.callLog(Request, _logger);
            var srcPath = webService.GetPath(Request.Path);
            var desPath = HttpUtility.UrlDecode(Request.Headers["Destination"]).Replace(webService.GetUrlPath(Request), "");
         
            try
            {
                if (Path.GetFileName(srcPath) != Path.GetFileName(desPath))  //改名
                {
                    var currentItem = ClsCommon.dicUserDirs[this.currentUser].Where(p => p.path == srcPath).FirstOrDefault();
                    if (currentItem == null)
                    {
                        return StatusCode((int)HttpStatusCode.NotFound);
                    }
                    else
                    {
                        await ClsCommon.Rename(currentItem.itemId, Path.GetFileName(desPath),this.currentUser);
                    }
                    Console.WriteLine("User:" + this.currentUser + "," + "Rename OK");
                }
                else  //真的移動
                {
                    var srcItem = ClsCommon.dicUserDirs[this.currentUser].Where(p => p.path == srcPath).FirstOrDefault();
                    if (srcItem == null)
                    {
                        return StatusCode((int)HttpStatusCode.NotFound);
                    }

                    var dirs = desPath.Split("/").Where(x => !string.IsNullOrEmpty(x)).ToList(); 
                    var resourceName = dirs.Last();
                    dirs.RemoveAt(dirs.Count - 1);
                    desPath = string.Join("/", dirs);

                    var desItem = ClsCommon.dicUserDirs[this.currentUser].Where(p => p.path == "/"+desPath).FirstOrDefault();
                    if (desItem == null)
                    {
                        return StatusCode((int)HttpStatusCode.NotFound);
                    }
                    if (srcItem.nodeId != desItem.nodeId)
                    {
                        throw new Exception("不可跨node移動");
                    } 
                    await ClsCommon.createClipboard(srcItem.itemId,this.currentUser);
                    await ClsCommon.pasteClipboard(desItem.itemId, this.currentUser);
                    Console.WriteLine("User:" + this.currentUser + "," + "Move OK");
                }
            
                return StatusCode((int)HttpStatusCode.Created);
            }
            catch (Exception ex)
            {
                Console.WriteLine("User:" + this.currentUser + "," + ex.ToString());
                if (ex.Message.Contains("不可跨node移動"))
                {
                    return StatusCode(statusCode: (int)HttpStatusCode.Unauthorized, value: new { status = (int)HttpStatusCode.Unauthorized, message = ex.ToString() });
                }
                else
                {
                    return StatusCode(statusCode: (int)HttpStatusCode.InternalServerError, value: new { status = (int)HttpStatusCode.InternalServerError, message = ex.ToString() });
                }
                throw;
            } 
        }
         
        [ApiExplorerSettings(IgnoreApi = true)]
        [AcceptVerbs("COPY")]
        public async Task<IActionResult> Copy(string? path, string? destination, CancellationToken cancellationToken = default)
        {
            webService.callLog(Request, _logger);
            //path = GetPath(path);
            //var sourceFilePath = GetPhysicPath(path);
            //string destination = HttpUtility.UrlDecode(Request.Headers["Destination"]).Replace(GetUrlPath(Request), "").TrimStart('/').Replace("/", "\\");
            //string destinationFilePath = "";
            //if (Directory.Exists(sourceFilePath))
            //{
            //    destinationFilePath = Path.Combine(directory, destination);
            //}
            //else
            //{
            //    destinationFilePath = AutoRenameFilename(Path.Combine(directory, destination));
            //}
            //if (System.IO.File.Exists(destinationFilePath))
            //{
            //    return StatusCode((int)HttpStatusCode.Conflict);
            //}
            //else
            //{
            //    try
            //    {
            //        if (Directory.Exists(sourceFilePath))
            //        {
            //            DirectoryCopy(sourceFilePath, destinationFilePath, true);
            //        }
            //        else
            //        {
            //            System.IO.File.Copy(sourceFilePath, destinationFilePath);
            //        }
            return StatusCode((int)HttpStatusCode.Created);
            //    }
            //    catch (IOException)
            //    {
            //        return StatusCode((int)HttpStatusCode.InternalServerError);
            //    }
            //}
        }

        [ApiExplorerSettings(IgnoreApi = true)]
        [AcceptVerbs("LOCK")]
        public async Task<string> LockAsync(string? path, CancellationToken cancellationToken = default)
        {
            webService.callLog(Request, _logger);

            //var result = await Request.BodyReader.ReadAsync(cancellationToken); 
            //var responseXml =  Encoding.UTF8.GetString(result.Buffer.ToArray());
            string lockToken = Guid.NewGuid().ToString();
            string href = Path.Combine(webService.GetUrlPath(Request), path).Replace("\\", "/");
            Response.Headers.Add("Lock-Token", $"<urn:uuid:{lockToken}>");
            string responseXml = this.webService.createLockResponse(href,HttpContext.User.ToString()).ToString();
            Response.StatusCode = (int)HttpStatusCode.OK;
            return responseXml;
        }
        
        [ApiExplorerSettings(IgnoreApi = true)]
        [AcceptVerbs("UNLOCK")]
        public ActionResult Unlock(string? path, CancellationToken cancellationToken = default)
        {
            string lockToken = Request.Headers["Lock-Token"];

            if (string.IsNullOrEmpty(lockToken))
            {
                return StatusCode((int)HttpStatusCode.BadRequest);
            }
            return StatusCode((int)HttpStatusCode.NoContent);
        }
        
        [ApiExplorerSettings(IgnoreApi = true)]
        [AcceptVerbs("PROPPATCH")]
        public string Propatch(string? path)
        {
            string href = Path.Combine(webService.GetUrlPath(Request), path).Replace("\\", "/");
            string responseXml = this.webService.createPropatchResponse(href).ToString();
            return responseXml;
        }
    }
}