﻿
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.StaticFiles;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using System;
using System.Buffers;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Web;
using System.Xml.Linq;
using WebDav.Helpers;
using WebDav.Model;
using WebDav.Services;

namespace WebDav.Controllers
{
    //[Authorize]
    //[Route("{**path}")]

    public class WebDavController : ControllerBase
    {
        public static readonly XNamespace DavNs = "DAV:";
        public static readonly string DavNsPrefix = "D";
        private readonly ILogger<WebDavController> _logger;
        private readonly IHttpContextAccessor httpContextAccessor;
        private readonly IRabitMQProducer _rabitMQProducer;
        private readonly WebService webService;
        IConfiguration configuration;
        private string currentUser = ""; 
        private static ConcurrentDictionary<string, List<webdavInfo>> dicUserDirs = new ConcurrentDictionary<string, List<webdavInfo>>();

    
        public string directory
        {
            get
            {
                return configuration["MountDir"];  
            }
        }


        public WebDavController(IHttpContextAccessor httpContextAccessor,
            ILogger<WebDavController> logger, 
            IConfiguration _configuration,
            WebService _webService, IRabitMQProducer rabitMQProducer)
        {
            // Process.Start("cmd.exe", "/X" + @"net use \\tnoafs01.cminl.oa\INXDrive$ innoDrv@2021 /USER:drvuser");

            //ClsCommon.Connect(@"tnoafs01.cminl.oa\INXDrive$", "drvuser", "innoDrv@2021" );
            configuration = _configuration;
            _logger = logger;
            this.webService = _webService;
            _rabitMQProducer = rabitMQProducer;
            this.httpContextAccessor = httpContextAccessor;
            this.currentUser = this.httpContextAccessor.HttpContext.User.Identity.Name;
            this.currentUser = string.IsNullOrEmpty(currentUser) ? "Webdav" : this.currentUser; 
        }
        
      
        [HttpGet]
        public async Task GetAsync(string? path, CancellationToken cancellationToken = default)
        {
            try
            {
                webService.callLog(Request, _logger);
                var decodePath = webService.GetPath(path);
                if (decodePath.Contains("favicon.ico")
                    || decodePath.Contains("desktop.ini")
                      || decodePath.Contains(".git")
                         || decodePath.Contains("HEAD") 
                         //|| decodePath.Contains("~$")
                         || path == null)
                {

                }
                else
                {
                    var physicalPath = GetPhysicPath(path);
                   
                    if (System.IO.File.Exists(physicalPath))
                    {
                        if (decodePath.Contains(".txt"))
                        {
                            Response.ContentType = "Content-Type: text/plain; charset=utf-8";
                        }
                        else
                        {
                            Response.ContentType = GetMimeType(physicalPath);
                        }
                        Response.ContentLength = new FileInfo(physicalPath).Length;

                        using (var stream = new FileInfo(physicalPath).OpenRead())
                        {
                            await stream.CopyToAsync(Response.Body);
                        }
                    }
                    else
                    {

                    }
                }
               // Response.StatusCode = (int)HttpStatusCode.NotModified;
            }
            catch (Exception ex)
            {
                webService.showMessage(this._rabitMQProducer,Path.GetFileName(path),ex.Message,this.currentUser);
                Response.StatusCode = (int)HttpStatusCode.NotFound;
            }
        }

        string GetFileName(string path)
        {
            string resFilename = "";
            if (path == "/")
            {
                resFilename = "";
            }
            else if (path.Contains("."))
            {
                resFilename = path.Split('/').Last();
            }
            else
            {
                resFilename = "";// path.TrimEnd('/').Split('/').Last();
            }
            return resFilename;
        }
         
        [ApiExplorerSettings(IgnoreApi = true)]
        [AcceptVerbs("PROPFIND")]
        public async Task<string> PropfindAsync(string? path, CancellationToken cancellationToken)
        {
            var xMultiStatus = new XElement(DavNs + "multistatus");
            var xml = new XDocument(new XDeclaration("1.0", "utf-8", "yes"), xMultiStatus);
            try
            {
                webService.callLog(Request, _logger);
                path = webService.GetPath(path);
                if (path.Contains("favicon.ico")
                   || path.Contains("desktop.ini")
                   || path.Contains(".git")
                   || path.Contains("HEAD")
                   )
                {
                    return xml.ToString();
                }
                var filePath = GetPhysicPath(path);
                bool isDir = Directory.Exists(filePath);
                bool isFile = System.IO.File.Exists(filePath);

                if (!isDir && !isFile)
                { 
                    xml.Root.Add(CreateResponseElement(Request, filePath, !(Path.GetExtension(filePath).Length > 0), true));
                    HttpContext.Session.SetString(this.currentUser + ":" + "AF", "Y");
                    Response.StatusCode = (int)HttpStatusCode.NotFound; 
                    return xml.ToString();
                }
                else
                {
                    if (Request.Headers["Depth"].ToString() == "0")
                    {
                        if (isFile)
                        {
                            xml.Root.Add(CreateResponseElement(Request, filePath, false));
                        }
                        else
                        {
                            filePath = directory;
                            xml.Root.AddFirst(CreateResponseElement(Request, filePath, true));
                        }
                    }
                    else
                    {
                        string[] dirs = new string[] { };
                        List<FileInfo> files = new List<FileInfo>();
                        if (isDir)
                        {
                            dirs = Directory.GetDirectories(filePath);

                            foreach (string webdavInfo in dirs)
                            {
                                xml.Root.Add(CreateResponseElement(Request, webdavInfo, true));
                            }
                            files = new DirectoryInfo(filePath).GetFiles().Where(f => !f.Attributes.HasFlag(FileAttributes.Hidden)).ToList();

                            foreach (var file in files)
                            {
                                xml.Root.Add(CreateResponseElement(Request, file.FullName, false));
                            }
                            if (dirs.Length > 0 || files.Count() > 0)
                            {
                                xml.Root.AddFirst(CreateResponseElement(Request, filePath, true));
                            }
                            if (files.Count() == 0 && dirs.Length == 0)
                            {
                                xml.Root.Add(CreateResponseElement(Request, filePath, true));
                            }
                        }
                        else
                        {
                            xml.Root.Add(CreateResponseElement(Request, filePath, false));
                        }
                    }
                }
                Response.StatusCode = (int)HttpStatusCode.MultiStatus;
            //    ClsCommon.log(xml.ToString());
                
            }
            catch (Exception ex)
            {
                webService.showMessage(this._rabitMQProducer, Path.GetFileName(path), ex.Message, this.currentUser);
            }
            return xml.ToString();
        }
         
        private XElement CreateResponseElement(HttpRequest request, string path, bool isDir,bool bAdd = false)
        {
            string physicalPath = "";
            path = path.Replace(directory, "").TrimStart('\\');
            string href = Path.Combine(webService.GetUrlPath(request), path).Replace("\\", "/");
            string displayName = Path.GetFileName(path);
            XElement response = null;
            if (isDir)
            {
                href = href.Reverse().First() != '/' ? href + "/" : href;
                physicalPath = Path.Combine(directory, path);
            }
            else 
            { 
                physicalPath = Path.Combine(directory, path);
            }
       
           
            response = new XElement(DavNs + "response",
                new XElement(DavNs + "href", href),
                new XElement(DavNs + "propstat",
                    new XElement(DavNs + "prop",
                        new XElement(DavNs + "displayname", displayName),
                        new XElement(DavNs + "getlastmodified", bAdd?"":System.IO.File.GetLastWriteTimeUtc(physicalPath).ToString("R")),
                        new XElement(DavNs + "getlastaccessed", bAdd ? "":System.IO.File.GetLastAccessTimeUtc(physicalPath).ToString("R")),
                        new XElement(DavNs + "creationdate", bAdd ? "":System.IO.File.GetCreationTimeUtc(physicalPath).ToString("R")),
                        new XElement(DavNs + "getcontentlength", isDir ? "0" : bAdd ? "0":new FileInfo(physicalPath).Length.ToString()),
                        new XElement(DavNs + "getcontenttype", isDir ? "httpd/unix-directory" : GetMimeType(physicalPath)),
                        new XElement(DavNs + "resourcetype", isDir ? new XElement(DavNs + "collection") : null)),
                    new XElement(DavNs + "status", "HTTP/1.1 200 OK")));

            
            return response;
        }

        public static string GetMimeType(string fileName)
        {
            var provider = new FileExtensionContentTypeProvider();
            if (!provider.TryGetContentType(fileName, out string mimeType))
            {
                mimeType = "application/octet-stream";
            }
            return mimeType;
        }
        [HttpHead]
        public ActionResult Head(string? path)
        {
            webService.callLog(Request, _logger);
            //string head = null!;

            //if (head != null)
            //{
            //    Response.Headers.Add("Last-Modified", DateTime.Now.ToString());
            //    return Ok();
            //}
            //else
            //    return NotFound();
            var webdavInfo = new DirectoryInfo(path);
            if (!webdavInfo.Exists)
            {
                return StatusCode((int)HttpStatusCode.NotFound);
            }
            else 
            {
                return Ok();
            }
            
        }
        //
        [HttpOptions]
        public ActionResult Options(string? path)
        {
            webService.callLog(Request, _logger);
            Response.Headers.Add("Allow", "COPY, DELETE, GET, HEAD, LOCK, MOVE, OPTIONS, POST, PROPFIND, PROPPATCH, PUT, REPORT, SEARCH, UNLOCK");
            Response.Headers.Add("Public", "COPY, DELETE, GET, HEAD, LOCK, MOVE, OPTIONS, POST, PROPFIND, PROPPATCH, PUT, REPORT, SEARCH, UNLOCK");
            Response.Headers.Add("MS-Author-Via", "DAV");
            Response.Headers.Add("DAV", "1,2,extend");
            Response.Headers.Add("Versioning-Support", "DAV:basicversioning");
            //Response.Headers.Add("DASL", "<DAV:basicsearch>"); 
            return Ok();
        }

        [HttpDelete]
        public async Task<IActionResult> Delete(string? path)
        {
            webService.callLog(Request, _logger);
            Console.WriteLine("path:" + path);
            if (path is null)
            {
                return StatusCode((int)HttpStatusCode.Conflict);
            }

            path = webService.GetPath(path);
            var filePath = GetPhysicPath(path);
            if (Directory.Exists(filePath))
            {
                var webdavInfo = new DirectoryInfo(filePath);
                webdavInfo.Delete(true);
                return StatusCode((int)HttpStatusCode.OK);
            }
            else if (System.IO.File.Exists(filePath))
            {
                try
                {
                    System.IO.File.Delete(filePath);
                    return StatusCode((int)HttpStatusCode.OK);
                }
                catch (Exception)
                {
                    return StatusCode((int)HttpStatusCode.InternalServerError);
                }
            }
            else
            {
                return StatusCode((int)HttpStatusCode.NotFound);
            }
        } 

        [HttpPut]
        [DisableRequestSizeLimit]
        public async Task<ActionResult> PutAsync(string? path, CancellationToken cancellationToken)
        {
            try
            {
                webService.callLog(Request, _logger);
                var contentLength = Request.ContentLength ?? 0;
                var auth = Request.Headers["Authorization"].ToString();
             
                if (contentLength == 0)
                {
                    if (auth == "")
                    {
                        return StatusCode((int)HttpStatusCode.NotModified);
                    }
              
                }
                var d = HttpContext.Session.GetString(this.currentUser + ":" + "AF");
                path = webService.GetPath(path);
                var filePath = directory +"\\"+ path.Replace("/", "\\"); 
                using (FileStream output = System.IO.File.Create(filePath))
                {
                    await Request.Body.CopyToAsync(output);
                }
                webService.showMessage(this._rabitMQProducer, Path.GetFileName(path), "存檔成功", this.currentUser);
                return StatusCode((int)HttpStatusCode.Created);
            }
            catch(Exception ex)
            {
                webService.showMessage(this._rabitMQProducer, Path.GetFileName(path), ex.Message, this.currentUser);
                return StatusCode((int)HttpStatusCode.BadRequest);
            } 
        }

        [ApiExplorerSettings(IgnoreApi = true)]
        [AcceptVerbs("MKCOL")]
        public async Task<IActionResult> MkCol(string? path, CancellationToken cancellationToken = default)
        {
            webService.callLog(Request, _logger);
            path = webService.GetPath(path);
            var filePath = GetPhysicPath(path);
            System.IO.Directory.CreateDirectory(filePath);
            return StatusCode((int)HttpStatusCode.Created);
        }

        [ApiExplorerSettings(IgnoreApi = true)]
        [AcceptVerbs("MOVE")]
        public async Task<IActionResult> Move(string? path, CancellationToken cancellationToken = default)
        {
            webService.callLog(Request, _logger);
            path = webService.GetPath(path);
            var sourceFilePath = GetPhysicPath(path);
            string destination = HttpUtility.UrlDecode(Request.Headers["Destination"]).Replace(webService.GetUrlPath(Request), directory).TrimStart('/').Replace("/", "\\");
            try
            {
                if (Directory.Exists(sourceFilePath) && !Directory.Exists(destination))
                {
                    Directory.Move(sourceFilePath, destination);
                }
                else
                {
                    if (!System.IO.File.Exists(sourceFilePath))
                    {
                        return StatusCode((int)HttpStatusCode.NotFound);
                    }

                    if (System.IO.File.Exists(destination))
                    {
                        return StatusCode((int)HttpStatusCode.Conflict);
                    }

                    System.IO.File.Move(sourceFilePath, destination);
                    return StatusCode((int)HttpStatusCode.Created);
                }
            }
            catch (Exception)
            {
                return StatusCode((int)HttpStatusCode.InternalServerError);
            }

            return StatusCode((int)HttpStatusCode.Created);
        }
         
        [ApiExplorerSettings(IgnoreApi = true)]
        [AcceptVerbs("COPY")]
        public async Task<IActionResult> Copy(string? path, string? destination, CancellationToken cancellationToken = default)
        {
            webService.callLog(Request, _logger);
            //path = GetPath(path);
            //var sourceFilePath = GetPhysicPath(path);
            //string destination = HttpUtility.UrlDecode(Request.Headers["Destination"]).Replace(GetUrlPath(Request), "").TrimStart('/').Replace("/", "\\");
            //string destinationFilePath = "";
            //if (Directory.Exists(sourceFilePath))
            //{
            //    destinationFilePath = Path.Combine(directory, destination);
            //}
            //else
            //{
            //    destinationFilePath = AutoRenameFilename(Path.Combine(directory, destination));
            //}
            //if (System.IO.File.Exists(destinationFilePath))
            //{
            //    return StatusCode((int)HttpStatusCode.Conflict);
            //}
            //else
            //{
            //    try
            //    {
            //        if (Directory.Exists(sourceFilePath))
            //        {
            //            DirectoryCopy(sourceFilePath, destinationFilePath, true);
            //        }
            //        else
            //        {
            //            System.IO.File.Copy(sourceFilePath, destinationFilePath);
            //        }
            return StatusCode((int)HttpStatusCode.Created);
            //    }
            //    catch (IOException)
            //    {
            //        return StatusCode((int)HttpStatusCode.InternalServerError);
            //    }
            //}
        }

        [ApiExplorerSettings(IgnoreApi = true)]
        [AcceptVerbs("LOCK")]
        public async Task<string> LockAsync(string? path, CancellationToken cancellationToken = default)
        {
            webService.callLog(Request, _logger);

            //var result = await Request.BodyReader.ReadAsync(cancellationToken); 
            //var responseXml =  Encoding.UTF8.GetString(result.Buffer.ToArray());
            string lockToken = Guid.NewGuid().ToString();
            string href = Path.Combine(webService.GetUrlPath(Request), path).Replace("\\", "/");
            Response.Headers.Add("Lock-Token", $"<urn:uuid:{lockToken}>");
            string responseXml = createLockResponse(href).ToString();
            Response.StatusCode = (int)HttpStatusCode.OK;
            return responseXml;
        }
        XDocument createLockResponse(string href)
        {
            var xprop = new XElement(DavNs + "prop");
            var xml = new XDocument(new XDeclaration("1.0", "utf-8", "yes"), xprop); 
            XElement response = null;
            response = new XElement(DavNs + "lockdiscovery", 
                        new XElement(DavNs + "activelock",
                            new XElement(DavNs + "locktype", new XElement(DavNs + "write")),
                            new XElement(DavNs + "lockscope", new XElement(DavNs + "exclusive")),
                            new XElement(DavNs + "depth", "0"),
                            new XElement(DavNs + "owner", string.IsNullOrEmpty(HttpContext.User.Identity.Name) ? "":HttpContext.User.Identity.Name),
                            new XElement(DavNs + "timeout", "Second-3600"),
                            new XElement(DavNs + "locktoken", new XElement(DavNs + "href", Guid.NewGuid().ToString())),
                            new XElement(DavNs + "lockroot", new XElement(DavNs + "href", href))
                      ));
            xml.Root.Add(response);
            return xml;
        }
        [ApiExplorerSettings(IgnoreApi = true)]
        [AcceptVerbs("UNLOCK")]
        public ActionResult Unlock(string? path, CancellationToken cancellationToken = default)
        {
            string lockToken = Request.Headers["Lock-Token"];

            if (string.IsNullOrEmpty(lockToken))
            {
                return StatusCode((int)HttpStatusCode.BadRequest);
            }
            return StatusCode((int)HttpStatusCode.NoContent);
        }
        
        [ApiExplorerSettings(IgnoreApi = true)]
        [AcceptVerbs("PROPPATCH")]
        public string  Propatch(string? path)
        {
            string href = Path.Combine(webService.GetUrlPath(Request), path).Replace("\\", "/");
            string responseXml = createPropatchResponse(href).ToString();
            return responseXml;
        }
        XDocument createPropatchResponse(string href)
        {
            var xMultiStatus = new XElement(DavNs + "multistatus");
            var xml = new XDocument(new XDeclaration("1.0", "utf-8", "yes"), xMultiStatus);
            var response = new XElement(DavNs + "response",
                 new XElement(DavNs + "href", href),
                 new XElement(DavNs + "propstat",
                     new XElement(DavNs + "prop"//, 
                                                //new XElement("n3", "Win32CreationTime"),
                                                //new XElement("n3", "Win32LastAccessTime"),
                                                //new XElement("n3", "Win32LastModifiedTime"),
                                                //new XElement("n3", "Win32FileAttributes")
                     ),
                     new XElement(DavNs + "status", "HTTP/1.1 424 Failed Dependency")));

            xml.Root.Add(response);
            return xml;
        }
     

        string GetPhysicPath(string path)
        {
            if (path == "/")
            {
                return directory;
            }
            else
            {
                return Path.Combine(directory, path.Replace("/", "\\")); 
            } 
        }
      
    }
}