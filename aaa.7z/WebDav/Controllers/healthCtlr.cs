using Microsoft.AspNetCore.Mvc;
using WebDav.Helpers;

namespace WebDav.Controllers
{
    [ApiController]
    [Route("[controller]")]
    [Produces("application/json")] 
    [ApiExplorerSettings(IgnoreApi = true)]

    public class healthController: ControllerBase
    {
        IConfiguration configuration;
        public string directory
        {
            get
            {
                var path = configuration["MountDir"];
                if (ClsCommon.IsLinuxRunTime())
                    return ClsCommon.GetLinuxDirectory(path);
                //ForWindows
                if (ClsCommon.IsWindowRunTime())
                    return ClsCommon.GetWindowDirectory(path);
                return path; 
            }
        }
        public healthController(IConfiguration _configuration)
        {
            configuration = _configuration;
        }
        [HttpGet("get2")]
        [ApiExplorerSettings(IgnoreApi = true)]
        public string Get2()
        {
            return "OK";
        }
            /// <summary>
            /// for cloud livenessProbe 偵測使用
            /// </summary>
            /// <returns></returns>
            [HttpGet("get1")]
        [ApiExplorerSettings(IgnoreApi = true)]
        public string Get()
         {
            return "OK"; 
        } 
    }
}