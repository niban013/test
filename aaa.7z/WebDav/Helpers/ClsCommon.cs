﻿
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.StaticFiles;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Net;
using System.Net.Http;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;
using WebDav.Model;
using WebDav.Services;

namespace WebDav.Helpers
{
    public static class ClsCommon
    {
        public static readonly XNamespace DavNs = "DAV:";
        public static readonly XNamespace DavWinNs = "Z:";
        public static readonly string DavNsPrefix = "D";
        public static Dictionary<string, List<webdavInfo>> dicUserDirs = new Dictionary<string, List<webdavInfo>>();

        public static IConfiguration config = new ConfigurationBuilder()
             .AddJsonFile("appsettings.json", optional: true, reloadOnChange: true)
             .Build();
         
        //private SessionService sessionService;
        //private IHttpContextAccessor httpContextAccessor;

   
        //public void init(SessionService _sessionService, IHttpContextAccessor _httpContextAccessor)
        //{
        //    sessionService = _sessionService;
        //    httpContextAccessor = _httpContextAccessor;
        //}
        public static string GetFileName(string path)
        {
            string resFilename = "";
            if (path == "/")
            {
                resFilename = "";
            }
            else if (path.Contains("."))
            {
                resFilename = path.Split('/').Last();
            }
            else
            {
                resFilename = "";
            }
            return resFilename;
        }
        public static string GetMimeType(string fileName)
        {
            var provider = new FileExtensionContentTypeProvider();
            if (!provider.TryGetContentType(fileName, out string mimeType))
            {
                mimeType = "application/octet-stream";
            }
            return mimeType;
        }

        public static async Task<string> GetTicket(string user)
        {
            HttpClient client = new HttpClient()
            {
                Timeout = TimeSpan.FromMinutes(20)
            };
            var _payload = JsonConvert.SerializeObject(new
            {
                Account = user,
                Password = config["ApiPassword"]
            });
            var content = new StringContent(_payload, Encoding.UTF8, "application/json");
            var response = await client.PostAsync(string.Format(config["GetWebDavTicketUri"], config["InnodriveApiUrl"]), content);
            if (response.StatusCode == System.Net.HttpStatusCode.OK)
            {
                return response.Content.ReadAsStringAsync().Result;
            }
            else
            {
                throw new Exception(response.Content.ReadAsStringAsync().Result);
            }

        }

        public static async Task<string> AddFolder(string parentId, string folderName,string user)
        {
            string uri = string.Format(config["AddFolder"], config["InnodriveApiUrl"]);
            var ticket = await GetTicket(user);
            HttpClient client = GetHttpClient(ticket);
            string payload = JsonConvert.SerializeObject(new
            {
                parentId,
                FolderName = folderName
            });
            var response = client.PostJsonAsync(uri, payload);
            var st = JsonConvert.DeserializeObject<string>(response.Content.ReadAsStringAsync().Result);
            return st;
        }
        public static async Task<string> UploadFiles(Stream stream, string fileName, string nodeId, string parentId, string user,bool overwrite = true)
        {
            string uri = string.Format(config["UploadFiles"], config["InnodriveApiUrl"]);
            var ticket = await GetTicket(user);
            HttpClient client = GetHttpClient(ticket);
            var content = new MultipartFormDataContent();
            content.Add(new StringContent(nodeId), "nodeId");
            content.Add(new StringContent(parentId), "parentId");
            content.Add(new StringContent(overwrite.ToString()), "overwrite");
            content.Add(new StreamContent(stream), fileName, fileName);
            var response = client.PostJsonAsync(uri, content);
            if (response.StatusCode == System.Net.HttpStatusCode.OK)
            {
                return "OK";
            }
            else
            {
                return response.Content.ReadAsStringAsync().Result;
            }
        }


        public static async Task<string> DeleteFile(string fileID, string user)
        {
            string uri = string.Format(config["DeleteFile"], config["InnodriveApiUrl"]);
            var ticket = await GetTicket(user);
            HttpClient client = GetHttpClient(ticket);
            string payload = JsonConvert.SerializeObject(new
            {
                fileID,
                directDelete = false
            });
            var response = client.PostJsonAsync(uri, payload);
            // var st = JsonConvert.DeserializeObject<string>(response.Content.ReadAsStringAsync().Result);
            return "OK";
        }
        public static async Task<string> Rename(string fileID, string name, string user)
        {
            string uri = string.Format(config["Rename"], config["InnodriveApiUrl"]) ;
            var ticket = await GetTicket(user);
            HttpClient client = GetHttpClient(ticket);
            string payload = JsonConvert.SerializeObject(new
            {
                fileID,
                name
            });
            var response = client.PutJsonAsync(uri, payload);
            // var st = JsonConvert.DeserializeObject<string>(response.Content.ReadAsStringAsync().Result);
            return "OK";
        }

        public static async Task<string> createClipboard(string fileID,string NetUser)
        {
            var empNo = NetUser.Split('\\').Last();
            string uri = string.Format(config["CreateClipboard"], config["InnodriveApiUrl"]);
            var ticket = await GetTicket(NetUser);
            HttpClient client = GetHttpClient(ticket);
            string payload = JsonConvert.SerializeObject(new
            {
                action = ClipAction.Cut,
                empNo,
                itemIds = new string[] { fileID }
            });
            var response = client.PutJsonAsync(uri, payload);
            // var st = JsonConvert.DeserializeObject<string>(response.Content.ReadAsStringAsync().Result);
            return "OK";
        }
        public static async Task<List<string>> pasteClipboard(string parentId, string NetUser)
        {
            var empNo = NetUser.Split('\\').Last();
            List<string> result = null;
            var ticket = await GetTicket(NetUser);
            HttpClient client = GetHttpClient(ticket);
            string uri = string.Format(config["PasteClipboard"], empNo, parentId, config["InnodriveApiUrl"]);
            HttpResponseMessage response = await client.GetAsync(uri);
            if (response.StatusCode == System.Net.HttpStatusCode.NotFound)
            {
            }
            else
            {
                result = JsonConvert.DeserializeObject<List<string>>(response.Content.ReadAsStringAsync().Result);
            }
            return result;
        }
        public static HttpClient GetHttpClient(string ticket)
        {
            HttpClient client = new HttpClient()
            {
                Timeout = TimeSpan.FromMinutes(20)
            };
            if (ticket != "")
            {
                client.DefaultRequestHeaders.Clear();
                client.DefaultRequestHeaders.Add("ticket", ticket);

            }
            return client;
        }
        public static HttpResponseMessage PostJsonAsync(this HttpClient client, string uri, MultipartFormDataContent content)
        {
            HttpResponseMessage response = client.PostAsync(uri, content).Result;
            if (response.StatusCode == System.Net.HttpStatusCode.OK)
            {
                return response;
            }
            else
            {
                var message = response.Content.ReadAsStringAsync().Result;
                throw new Exception($"API 連線錯誤 StatusCode={response.StatusCode} :{message}");
            }
        }
        public static HttpResponseMessage PostJsonAsync(this HttpClient client, string uri, string payload)
        {
            var content = new StringContent(payload, Encoding.UTF8, "application/json");
            HttpResponseMessage response = client.PostAsync(uri, content).Result;
            if (response.StatusCode == System.Net.HttpStatusCode.OK)
            {
                return response;
            }
            else
            {
                var result = JsonConvert.DeserializeObject<dynamic>(response.Content.ReadAsStringAsync().Result);
                throw new Exception($"API 連線錯誤 StatusCode={response.StatusCode} :{result.Message}");
            }

        }
        public static HttpResponseMessage PutJsonAsync(this HttpClient client, string uri, string payload)
        {
            var content = new StringContent(payload, Encoding.UTF8, "application/json");
            HttpResponseMessage response = client.PutAsync(uri, content).Result;
            if (response.StatusCode == System.Net.HttpStatusCode.OK)
            {
                return response;
            }
            else if (response.StatusCode == System.Net.HttpStatusCode.NoContent)
            {
                return null;
            }
            else
            {
                var message = response.Content.ReadAsStringAsync().Result;
                throw new Exception($"API 連線錯誤 StatusCode={response.StatusCode} :{message}");
            }
        }
        public static void log(string s)
        {
            //Console.WriteLine("json: {0}", s, DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss ffffff"));
        }

        //OSPlatform.Windows监测运行环境
        public static bool IsWindowRunTime()
        {
            return RuntimeInformation.IsOSPlatform(OSPlatform.Windows);
        }

        //OSPlatform.Linux运行环境
        public static bool IsLinuxRunTime()
        {
            return RuntimeInformation.IsOSPlatform(OSPlatform.Linux);
        }

        public static string GetRuntimeDirectory(string path)
        {
            //ForLinux
            if (IsLinuxRunTime())
                return GetLinuxDirectory(path);
            //ForWindows
            if (IsWindowRunTime())
                return GetWindowDirectory(path);
            return path;
        }


        public static string GetLinuxDirectory(string path)
        {
            string pathTemp = Path.Combine(path);
            return pathTemp.Replace("\\", "/");
        }
        public static string GetWindowDirectory(string path)
        {
            string pathTemp = Path.Combine(path);
            return pathTemp.Replace("/", "\\");
        }

        public static bool DisConnect(string remoteHost)
        {

            bool Flag = true;
            Process proc = new Process();
            proc.StartInfo.FileName = "cmd.exe";
            proc.StartInfo.UseShellExecute = false;
            proc.StartInfo.RedirectStandardInput = true;
            proc.StartInfo.RedirectStandardOutput = true;
            proc.StartInfo.RedirectStandardError = true;
            proc.StartInfo.CreateNoWindow = true;

            try
            {

                proc.Start();
                string command = @"net  use  \\" + remoteHost + " /delete";
                proc.StandardInput.WriteLine(command);
                command = "exit";
                proc.StandardInput.WriteLine(command);

                while (proc.HasExited == false)
                {
                    proc.WaitForExit(1000);
                }

                string errormsg = proc.StandardError.ReadToEnd();
                if (errormsg != "")
                    Flag = false;

                proc.StandardError.Close();
            }
            catch (Exception ex)
            {
                Flag = false;
                throw ex;
            }
            finally
            {
                proc.Close();
                proc.Dispose();
            }
            return Flag;
        }
        public static bool Connect(string remoteHost, string userName, string passWord)
        {

            bool Flag = true;
            Process proc = new Process();
            proc.StartInfo.FileName = "cmd.exe";
            proc.StartInfo.UseShellExecute = false;
            proc.StartInfo.RedirectStandardInput = true;
            proc.StartInfo.RedirectStandardOutput = true;
            proc.StartInfo.RedirectStandardError = true;
            proc.StartInfo.CreateNoWindow = true;

            try
            {

                proc.Start();
                string command = @"net  use  \\" + remoteHost + "  " + passWord + "  " + "  /user:" + userName + ">NUL";
                proc.StandardInput.WriteLine(command);
                command = "exit";
                proc.StandardInput.WriteLine(command);

                while (proc.HasExited == false)
                {
                    proc.WaitForExit(1000);
                }

                string errormsg = proc.StandardError.ReadToEnd();
                if (errormsg != "")
                    Flag = false;

                proc.StandardError.Close();
            }
            catch (Exception ex)
            {
                Flag = false;
                throw ex;
            }
            finally
            {
                proc.Close();
                proc.Dispose();
            }
            return Flag;
        } 
    }
}
