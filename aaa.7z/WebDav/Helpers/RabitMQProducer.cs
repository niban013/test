﻿
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Connections;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Options;
using Microsoft.Win32;
using Newtonsoft.Json;
using RabbitMQ.Client;
using RabbitMQ.Client.Events;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Net.Http;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Channels;
using System.Threading.Tasks;
using WebDav.Controllers;
using WebDav.Model;
using WebDav.Services;

namespace WebDav.Helpers
{
    public class Message
    {
        public string msg { get; set; }
     
    }
    public interface IRabitMQProducer
    {
        public void SendProductMessage<T>(T message, string user);
    }

    
    public class RabitMQProducer : IRabitMQProducer
    {
        private readonly ILogger<WebDavController> _logger;
        private readonly IConfiguration _config;
        public RabbitMQ.Client.IConnection Connection 
        {
            get 
            {
                return CreateConnection();
            }
        }

        public RabitMQProducer(ILogger<WebDavController> logger, IConfiguration _configuration)
        {
            _config = _configuration;
            _logger = logger;
        }
        private  RabbitMQ.Client.IConnection CreateConnection()
        { 
            ConnectionFactory factory = new ConnectionFactory
            {
                UserName = _config["RabitMQ:Username"],
                Password = _config["RabitMQ:Password"],
                HostName = _config["RabitMQ:Hostname"]
            };
            factory.DispatchConsumersAsync = true;
            return factory.CreateConnection();
        }
        public void SendProductMessage<T>(T message,string user)
        { 
            var exchangeName = "Webdav";
            var queueName = user;
            var routeKey = "";
            try
            { 
                using (var channel = Connection.CreateModel())
                {
                    //建立一個Queue
                    channel.QueueDeclare(queueName, true, false, false, null);
                    //建立一個Exchange
                    channel.ExchangeDeclare(exchangeName, ExchangeType.Topic, false, false, null);

                    channel.QueueBind(queueName, exchangeName, routeKey);
                    string input = string.Empty;
                    var MessageInfo = new
                    {
                        msg = message
                    };
                    var body = Encoding.UTF8.GetBytes(JsonConvert.SerializeObject(MessageInfo));
                    channel.BasicPublish(exchangeName, routeKey, null, body);
                }
                _logger.Log(LogLevel.Information, string.Format("RabitMQ:傳送成功,User:{0}--{1}", user, message));
            }
            catch (Exception ex)
            {
                _logger.Log(LogLevel.Error, string.Format("RabitMQ:啟動失敗!{0}",ex.Message));
            }  
        }
    }
}
