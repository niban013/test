﻿namespace WebDav.Model
{
    public enum ClipAction
    {
        None,
        Copy,
        Cut,
        Paste,
        CopyLink
    }
    public class sessionInfo
    {
        public string guid { get; set; }
        public string user { get; set; }
    }
    public class webdavInfo
    {
        public string parent { get; set; }
        public string parentPath { get; set; }
        public string nodeId { get; set; }

        public string itemId { get; set; }
        public string name { get; set; }
        public string path { get; set; }
        public string fileType { get; set; }
        public DateTime getlastModified { get; set; }

        public DateTime getLastAccessed { get; set; }
        public DateTime creationDate { get; set; }
        public long size { get; set; }

        public string fromPath { get; set; }

        public string toPath { get; set; }

        public bool isRootNode { get; set; }
    }
    public class Item
    {
        public string Site { get; set; }
        public string Id { get; set; }
        public string Name { get; set; }
        public string Type { get; set; }
        public string ParentId { get; set; }
        public string Creator { get; set; } //中文姓名
        public DateTime LastModiDate { get; set; }
        public string ExtInfo { get; set; }
        public bool Isolated { get; set; }
        public string StudioType { get; set; }
        public string LinkId { get; set; }
        public string LinkNodeId { get; set; }
        public string LinkType { get; set; }
        public string LinkParentId { get; set; }
        public DateTime DeletedTime { get; set; }
        public string UrlApiServer { get; set; }
        public string UrlWebServer { get; set; }
        public string FullPath { get; set; }
        public string SizeOrCount { get; set; }
    }

    public class DriveItem : Item
    {
        public string NodeId { get; set; }  //i-Studio node id
        public string CreatorEmpNo { get; set; } //工號
        public long Bytes { get; set; }
        public int PrvCode { get; set; }
        public bool IsSelfPrv { get; set; }
        public string PrvInherNode { get; set; }
        public double TotalQuota { get; set; }
        public double UseQuota { get; set; }
        public bool IsFav { get; set; }
        public bool IsSync { get; set; }
        public string chkout_empno { get; set; }
        public string chkout_empName { get; set; }
        public DateTime chkout_time { get; set; }
        public int FileStatus { get; set; }

        public DateTime RestoreStartTime { get; set; }

        public DateTime EstRestCompTime { get; set; }
        public string StudioId { get; set; }

        private string HasArchive { get; set; } = "0";
        public bool IsHasArchive
        {
            get
            {
                return Convert.ToInt32(HasArchive) > 0;
            }
        }
        public int TotalCount { get; set; } = 0;
        public int CurrentPageNum { get; set; } = 0;

        public int MaxUploadSize { get; set; } = 0;
    }
}
