using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.HttpOverrides;
using Microsoft.AspNetCore.Server.HttpSys;
using Microsoft.AspNetCore.Server.IISIntegration;
using Microsoft.Extensions.Options;
using NLog;
using NLog.Web;
using WebDav.Authorization;
using WebDav.Helpers;
using WebDav.Services;


var builder = WebApplication.CreateBuilder(args);
var config = new ConfigurationBuilder()
             .AddJsonFile("appsettings.json", false)
             .Build();
var logger = LogManager.Setup().LoadConfigurationFromFile(Path.Combine("Helpers", "nlog.config")).LoadConfigurationFromAppSettings().GetCurrentClassLogger();
logger.Debug("init main");

try
{
    //builder.Logging.ClearProviders();
    builder.Logging.SetMinimumLevel(Microsoft.Extensions.Logging.LogLevel.Trace);
    builder.Host.UseNLog();

    string MyAllowSpecificOrigins = "_myAllowSpecificOrigins";

    // Add services to the container.
    builder.Services.Configure<IISServerOptions>(options =>
    {
        options.MaxRequestBodySize = Convert.ToInt32(config["UploadSize"]) * 1024 * 1024;
    });

    builder.Services.AddTransient<WebService>();
    builder.Services.AddSingleton<SessionService>();

    builder.Services.AddSingleton<IHttpContextAccessor, HttpContextAccessor>();
    builder.Services.AddScoped<IRabitMQProducer, RabitMQProducer>();
    builder.Services.AddDistributedMemoryCache();
    builder.Services.AddSession(options =>
    {
        options.IdleTimeout = TimeSpan.FromMinutes(60);
        options.Cookie.SecurePolicy = CookieSecurePolicy.Always;
        options.Cookie.SameSite = SameSiteMode.Strict;
        options.Cookie.HttpOnly = true;
        options.Cookie.IsEssential = true;
    });

    builder.Services.AddCors(options =>
    {
        options.AddPolicy(MyAllowSpecificOrigins,
        builder =>
        {
            builder.AllowAnyOrigin().AllowAnyHeader().AllowAnyMethod();
        });
    });

    builder.Services.AddControllers();

    builder.Services.AddHttpClient();


    //builder.Services.AddAuthentication("BasicAuthentication")
    //            .AddScheme<AuthenticationSchemeOptions, WebDav.Authorization.BasicAuthenticationHandler>
    //            ("BasicAuthentication", null);
    //builder.Services.AddAuthorization();

#if (!DEBUG)   //deploy IIS
   //builder.Services.AddAuthentication(IISDefaults.AuthenticationScheme); 
#endif
#if (DEBUG)
    if (Environment.GetEnvironmentVariable("ASPNETCORE_ENVIRONMENT") == "IISDevelopment")
    {
        builder.Services.AddAuthentication(IISDefaults.AuthenticationScheme);
    }
    else
    {
        builder.Services.AddAuthentication(HttpSysDefaults.AuthenticationScheme);
        builder.WebHost.UseHttpSys(options =>
        {
            options.Authentication.Schemes = (Microsoft.AspNetCore.Server.HttpSys.AuthenticationSchemes)(AuthenticationSchemes.NTLM | AuthenticationSchemes.Negotiate);
            options.Authentication.AllowAnonymous = false;
        });
    }
#endif
    //builder.Services.AddScoped<MyBaseAuthorizeHandler>();
    builder.Services.AddSingleton<SessionService>();
    var app = builder.Build();
    app.UseForwardedHeaders(new ForwardedHeadersOptions
    {
        ForwardedHeaders = ForwardedHeaders.XForwardedFor | ForwardedHeaders.XForwardedProto
    });
    //app.UseMiddleware<SecurityHeadersMiddleware>();



    //app.UseMiddleware<BasicAuthMiddleware>();

    //app.UseMiddleware<AuthenticationMiddleware>();
    // Configure the HTTP request pipeline.
    // app.UseMiddleware<BasicAuthenticateScopeMiddleware<MyBaseAuthorizeHandler>>(
    //    Options.Create(new BasicAuthenticateScopeOption()
    //    {
    //        Path = "/",
    //        Realm = "Dev"
    //    }
    //));
    app.UseAuthentication();
    app.UseAuthorization();

    app.UseSession();
   
    app.MapControllers();

    app.Run();
}
catch (Exception exception)
{
    // NLog: catch setup errors
    logger.Error(exception, "Stopped program because of exception");
    throw;
}
finally
{
    // Ensure to flush and stop internal timers/threads before application-exit (Avoid segmentation fault on Linux)
    NLog.LogManager.Shutdown();
}
