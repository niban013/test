﻿using Newtonsoft.Json;
using System.Text;

namespace WebDav.Services
{
    public class SessionService
    {
        private readonly IHttpContextAccessor _httpContextAccessor;
        private ISession _session => _httpContextAccessor.HttpContext.Session;

        public SessionService(IHttpContextAccessor httpContextAccessor)
        {
            _httpContextAccessor = httpContextAccessor;
        }
        public void Set(string key, object value)
        {
            _session.SetString(key, JsonConvert.SerializeObject(value));
        }

        public void Remove(string key)
        {
            _session.Remove(key);
        }

        public T Get<T>(string key)
        {
            var value = _session.GetString(key);
            return value == null ? default : JsonConvert.DeserializeObject<T>(value);
        }
    }

}
