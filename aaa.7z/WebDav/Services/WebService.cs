using Newtonsoft.Json;
using System.Web;
using WebDav.Model;
using WebDav.Helpers;
using Newtonsoft.Json.Linq;
using WebDav.Controllers;
using System.Xml.Linq;
using Microsoft.AspNetCore.StaticFiles;
using System.Net;

namespace WebDav.Services
{
    public class WebService
    { 
        private IEnumerable<dynamic> ApiData { get; set; }
        private readonly ILogger<WebDavController> _logger;
        private readonly IHttpClientFactory _httpClientFactory;
        private const int DepthInfinity = -1;
        private readonly IConfiguration _config;
        private readonly SessionService _sessionService;

        public WebService(IHttpClientFactory httpClientFactory, IConfiguration configuration, ILogger<WebDavController> logger, SessionService sessionService)
        {
            _sessionService = sessionService;
            _logger = logger;
            _httpClientFactory = httpClientFactory;
            _config = configuration;
        }
        string directory
        {
            get
            {
                return _config["MountDir"];
            }
        }
        public async Task<List<DriveItem>> getDriveItems(string name,string user)
        {
            List<DriveItem> result = null;
            string ticket = await ClsCommon.GetTicket(user);
            var client = ClsCommon.GetHttpClient(ticket);
            string uri = string.Format(ClsCommon.config["GetPostDriveItem"], ClsCommon.config["InnodriveApiUrl"]) + "/?pathName=" + name;
            HttpResponseMessage response = await client.GetAsync(uri);
            if (response.StatusCode == System.Net.HttpStatusCode.NotFound)
            {
            }
            else if (response.StatusCode == System.Net.HttpStatusCode.InternalServerError || response.StatusCode == System.Net.HttpStatusCode.Forbidden)
            {
                var res = JsonConvert.DeserializeObject<dynamic>(response.Content.ReadAsStringAsync().Result);
                throw new Exception($"API �s�u���~ StatusCode={response.StatusCode} :{((JProperty)(((JContainer)res).Last as JToken)).Value.ToString()}");
            }
            else
            {
                result = JsonConvert.DeserializeObject<List<DriveItem>>(response.Content.ReadAsStringAsync().Result);
            }
            return result;
        }

        public void MoveDirectory(string source, string target)
        {
            var sourcePath = source.TrimEnd('\\', ' ');
            var targetPath = target.TrimEnd('\\', ' ');
            var files = Directory.EnumerateFiles(sourcePath, "*", SearchOption.AllDirectories)
                                 .GroupBy(s => Path.GetDirectoryName(s));
            foreach (var folder in files)
            {
                var targetFolder = folder.Key.Replace(sourcePath, targetPath);
                Directory.CreateDirectory(targetFolder);
                foreach (var file in folder)
                {
                    var targetFile = Path.Combine(targetFolder, Path.GetFileName(file));
                    if (File.Exists(targetFile)) File.Delete(targetFile);
                    File.Move(file, targetFile);
                }
            }
            Directory.Delete(source, true);
        }
        public string AutoRenameFilename(string destinationFilePath)
        {
            FileInfo file = new FileInfo(destinationFilePath);

            var filename = file.Name.Replace(file.Extension, string.Empty);
            var webdavInfo = file.Directory.FullName;
            var ext = file.Extension;

            if (file.Exists)
            {
                int count = 0;
                string added;

                do
                {
                    count++;
                    added = "(" + count + ")";
                } while (File.Exists(webdavInfo + "\\" + filename + "" + added + ext));

                filename += "" + added;
            }

            return webdavInfo + "\\" + filename + ext;
        }

        public void DirectoryCopy(string sourceDirName, string destDirName, bool copySubDirs)
        {
            // Get the subdirectories for the specified directory.
            DirectoryInfo webdavInfo = new DirectoryInfo(sourceDirName);
            DirectoryInfo[] dirs = webdavInfo.GetDirectories();

            if (!webdavInfo.Exists)
            {
                throw new DirectoryNotFoundException(
                    "Source directory does not exist or could not be found: "
                    + sourceDirName);
            }

            // If the destination directory doesn't exist, create it.
            if (!Directory.Exists(destDirName))
            {
                Directory.CreateDirectory(destDirName);
            }

            // Get the files in the directory and copy them to the new location.
            FileInfo[] files = webdavInfo.GetFiles();
            foreach (FileInfo file in files)
            {
                string temppath = Path.Combine(destDirName, file.Name);
                file.CopyTo(temppath, false);
            }

            // If copying subdirectories, copy them and their contents to new location.
            if (copySubDirs)
            {
                foreach (DirectoryInfo subdir in dirs)
                {
                    string temppath = Path.Combine(destDirName, subdir.Name);
                    DirectoryCopy(subdir.FullName, temppath, copySubDirs);
                }
            }
        }

        public void showMessage(IRabitMQProducer _rabitMQProducer, string file,string message,string currentUser)
        {
            if (_rabitMQProducer != null)
            {
                _rabitMQProducer.SendProductMessage(string.Format("�ɦW:{0},���G:{1}", file, message), currentUser); 
            }  
        }
        public void callLog(HttpRequest request, ILogger<WebDavController> _logger)
        { 
            _logger.Log(LogLevel.Information,string.Format("{2} Request: {0} {1}", request.Method, HttpUtility.UrlDecode(request.Path), DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss ffffff")));
            // Console.WriteLine("{2} Request: {0} {1}", request.Method, HttpUtility.UrlDecode(request.Path), DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss ffffff"));
        }

        public string GetPath(string path) => path is null ? "/" : $"{HttpUtility.UrlDecode(path)}";


        public string GetUrlPath(HttpRequest request)
        {
            return request.Scheme + "://" + request.Host.Host + ":" + request.Host.Port;
        }

        public (string resourceName, List<string> directories, bool isDirectory) SplitPath(string relativePath)
        {
            var relativePathTrim = relativePath.Trim();

            var directories = relativePathTrim.Split("/").Where(x => !string.IsNullOrEmpty(x)).ToList();

            var isDirectory = relativePathTrim.EndsWith("/");

            var resourceName = directories.Last();
            directories.RemoveAt(directories.Count - 1);

            return (resourceName, directories, isDirectory);
        }

        
        public  XElement CreateResponseElement(HttpRequest request, string path, bool isDir, bool bAdd = false)
        {
            string physicalPath = "";
            path = path.Replace(directory, "").TrimStart('\\');
            string href = Path.Combine(GetUrlPath(request), path).Replace("\\", "/");
            string displayName = Path.GetFileName(path);

            if (isDir)
            {
                href = href.Reverse().First() != '/' ? href + "/" : href;
                physicalPath = Path.Combine(directory, path);
            }
            else
            {
                physicalPath = Path.Combine(directory, path);
            }


            var response = new XElement(ClsCommon.DavNs + "response",
                new XElement(ClsCommon.DavNs + "href", href),
                new XElement(ClsCommon.DavNs + "propstat",
                    new XElement(ClsCommon.DavNs + "prop",
                        new XElement(ClsCommon.DavNs + "displayname", displayName),
                        new XElement(ClsCommon.DavNs + "getlastmodified", bAdd ? "" : System.IO.File.GetLastWriteTimeUtc(physicalPath).ToString("R")),
                        new XElement(ClsCommon.DavNs + "getlastaccessed", bAdd ? "" : System.IO.File.GetLastAccessTimeUtc(physicalPath).ToString("R")),
                        new XElement(ClsCommon.DavNs + "creationdate", bAdd ? "" : System.IO.File.GetCreationTimeUtc(physicalPath).ToString("R")),
                        new XElement(ClsCommon.DavNs + "getcontentlength", isDir ? "0" : bAdd ? "0" : new FileInfo(physicalPath).Length.ToString()),
                        new XElement(ClsCommon.DavNs + "iscollection", "0"),
                        new XElement(ClsCommon.DavNs + "getcontenttype", isDir ? "httpd/unix-directory" : ClsCommon.GetMimeType(physicalPath)),
                        new XElement(ClsCommon.DavNs + "resourcetype", isDir ? new XElement(ClsCommon.DavNs + "collection") : null)),
                    new XElement(ClsCommon.DavNs + "status", "HTTP/1.1 200 OK")));
            return response;
        }
        public  XDocument createPropatchResponse(string href)
        {
            var xMultiStatus = new XElement(ClsCommon.DavNs + "multistatus");
            var xml = new XDocument(new XDeclaration("1.0", "utf-8", "yes"), xMultiStatus);
            var response = new XElement(ClsCommon.DavNs + "response",
                 new XElement(ClsCommon.DavNs + "href", href),
                 new XElement(ClsCommon.DavNs + "propstat",
                     new XElement(ClsCommon.DavNs + "prop"//, 
                                                //new XElement("n3", "Win32CreationTime"),
                                                //new XElement("n3", "Win32LastAccessTime"),
                                                //new XElement("n3", "Win32LastModifiedTime"),
                                                //new XElement("n3", "Win32FileAttributes")
                     ),
                     new XElement(ClsCommon.DavNs + "status", "HTTP/1.1 424 Failed Dependency")));

            xml.Root.Add(response);
            return xml;
        }
        public  XDocument createLockResponse(string href, string user)
        {
            var xprop = new XElement(ClsCommon.DavNs + "prop");
            var xml = new XDocument(new XDeclaration("1.0", "utf-8", "yes"), xprop);
            XElement response = null;
            response = new XElement(ClsCommon.DavNs + "lockdiscovery",
                        new XElement(ClsCommon.DavNs + "activelock",
                            new XElement(ClsCommon.DavNs + "locktype", new XElement(ClsCommon.DavNs + "write")),
                            new XElement(ClsCommon.DavNs + "lockscope", new XElement(ClsCommon.DavNs + "exclusive")),
                            new XElement(ClsCommon.DavNs + "depth", "0"),
                            new XElement(ClsCommon.DavNs + "owner", string.IsNullOrEmpty(user) ? "" : user),
                            new XElement(ClsCommon.DavNs + "timeout", "Second-3600"),
                            new XElement(ClsCommon.DavNs + "locktoken", new XElement(ClsCommon.DavNs + "href", Guid.NewGuid().ToString())),
                            new XElement(ClsCommon.DavNs + "lockroot", new XElement(ClsCommon.DavNs + "href", href))
                      ));
            xml.Root.Add(response);
            return xml;
        }

        public XElement CreateResponseElement(HttpRequest request, List<webdavInfo> lsUserDirs, webdavInfo item, bool isDir)
        {
            var path = item.path.TrimStart('/');
            string physicalPath = "";
            string displayName = item.name;//path.Split('/').Last();
            string href = "";
            XElement response = null;
            if (isDir)
            {
                href = Path.Combine(GetUrlPath(request), path).Replace("\\", "/");
                href = href.Reverse().First() != '/' ? href + "/" : href;
            }
            else
            {
                href = Path.Combine(GetUrlPath(request), path).Replace('\\', '/');
            }
           
            try
            {
                FileInfo fileInfo = null;
                physicalPath = GetPhysicalPath(lsUserDirs,item.path); 
                if (!isDir)
                {
                    fileInfo = new FileInfo(physicalPath);
                }

                var lsProp = new List<XElement>();

                lsProp.Add(new XElement(ClsCommon.DavNs + "id", item.itemId));
                lsProp.Add(new XElement(ClsCommon.DavNs + "displayname", displayName));
                if (item.isRootNode)
                {
                    lsProp.Add(new XElement(ClsCommon.DavWinNs + "Win32FileAttributes", "00000021"));
                }
                lsProp.Add(new XElement(ClsCommon.DavNs + "getlastmodified", isDir ? item.getlastModified.ToString("R") : fileInfo.LastWriteTimeUtc.ToString("R")));
                lsProp.Add(new XElement(ClsCommon.DavNs + "getlastaccessed", isDir ? "" : fileInfo.LastAccessTimeUtc.ToString("R")));
                lsProp.Add(new XElement(ClsCommon.DavNs + "creationdate", isDir ? "" : fileInfo.CreationTimeUtc.ToString("R")));
                lsProp.Add(new XElement(ClsCommon.DavNs + "getcontentlength", isDir ? "0" : string.Format("{0}", item.size)));
                lsProp.Add(new XElement(ClsCommon.DavNs + "getcontenttype", isDir ? "httpd/unix-directory" : ClsCommon.GetMimeType(physicalPath)));
                lsProp.Add(new XElement(ClsCommon.DavNs + "resourcetype", isDir ? new XElement(ClsCommon.DavNs + "collection") : null));

                response = new XElement(ClsCommon.DavNs + "response",
                    new XElement(ClsCommon.DavNs + "href", href),
                    new XElement(ClsCommon.DavNs + "propstat",

                        new XElement(ClsCommon.DavNs + "prop",
                           from p in lsProp select p
                           //new XElement(DavNs + "id", item.itemId),
                           //   new XElement(DavNs + "displayname", displayName),
                           //   new XElement(DavWinNs + "Win32FileAttributes", isDir ? "00000000" : "00000000"),
                           //   new XElement(DavNs + "getlastmodified", isDir ? item.getlastModified.ToString("R") : fileInfo.LastWriteTimeUtc.ToString("R")),
                           //   new XElement(DavNs + "getlastaccessed", isDir ? "" : fileInfo.LastAccessTimeUtc.ToString("R")),
                           //   new XElement(DavNs + "creationdate", isDir ? "" : fileInfo.CreationTimeUtc.ToString("R")),
                           //   new XElement(DavNs + "getcontentlength", isDir ? "0" : string.Format("{0}", item.size)),
                           //   new XElement(DavNs + "getcontenttype", isDir ? "httpd/unix-directory" : GetMimeType(physicalPath)),
                           //   new XElement(DavNs + "resourcetype", isDir ? new XElement(DavNs + "collection") : null)

                            )

                        ,
                        new XElement(ClsCommon.DavNs + "status", "HTTP/1.1 200 OK")));
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message + ",StackTrace:" + ex.StackTrace); 
            }
            return response;
        }
        
        public  string GetPhysicalPath(List<webdavInfo> lsUserDirs, string path)
        {
            string finalphysicPath = "";
            var physicItem = new webdavInfo();
            if (path == "/")
            {
                physicItem = lsUserDirs.Where(g => g.path == path).FirstOrDefault();
                finalphysicPath = directory;
            }
            else if (path.Contains("."))
            {
                physicItem = lsUserDirs.Where(g => g.path == Path.Combine("/", path//.Replace("~$", "")
                    )).FirstOrDefault();
                if (physicItem == null)
                {
                    throw new Exception("�ɮפ��s�b");
                }
                finalphysicPath = Path.Combine(directory, physicItem.nodeId, "DOCUMENTS", physicItem.nodeId, physicItem.itemId.Substring(0, 2), physicItem.itemId).Replace("/", "\\");
            }
            else
            {
                physicItem = lsUserDirs.Where(g => g.path == path.TrimEnd('/')).FirstOrDefault();
                if (physicItem == null)
                {
                    throw new Exception("�ɮפ��s�b");
                }
                finalphysicPath = Path.Combine(directory, physicItem.nodeId, "DOCUMENTS", physicItem.nodeId, physicItem.itemId.Substring(0, 2), physicItem.itemId);//.Replace("/", "\\");
            }
            return finalphysicPath;
        }
        public string GetTimeoutHeader(HttpRequest request)
        { 
            string timeout = request.Headers["Timeout"]; 
            if (!String.IsNullOrEmpty(timeout) && !timeout.Equals("infinity") &&
                !timeout.Equals("Infinite, Second-4100000000"))
                return timeout; 
            return "Second-345600";
        }
        public int GetDepthHeader(HttpRequest request)
        {
            string depth = request.Headers["Depth"];
            if (String.IsNullOrEmpty(depth) || depth.Equals("infinity"))
                return DepthInfinity;
            int value;
            if (!int.TryParse(depth, out value))
                return DepthInfinity;
            if (value == 0 || value == 1)
                return value;
            return DepthInfinity;
        }

        public void reCreateWebDav(List<DriveItem> items,string user)
        {
            if (!ClsCommon.dicUserDirs.ContainsKey(user))
            {
                ClsCommon.dicUserDirs[user] = new List<webdavInfo>();
            }

            items.Select(p => p.FullPath).Distinct().ToList().ForEach(d =>
            {
                var childItem = ClsCommon.dicUserDirs[user].Where(p => p.parentPath is not null && (p.parentPath.StartsWith("/" + d))).ToList();
                ClsCommon.dicUserDirs[user].RemoveAll(item => childItem.Contains(item));
            });

            for (int i = 0; i < items.Count(); i++)
            {
                refreshItems(createInfo(items[i]), user);
            }
        }

        public void refreshItems(webdavInfo webdavInfo, string user)
        {
            if (!ClsCommon.dicUserDirs.ContainsKey(user))
            {
                ClsCommon.dicUserDirs[user] = new List<webdavInfo>();
            }
            var item = ClsCommon.dicUserDirs[user].Where(o => o.nodeId == webdavInfo.nodeId && o.itemId == webdavInfo.itemId).FirstOrDefault();
            if (item != null)
            {
                ClsCommon.dicUserDirs[user].Remove(item);
                ClsCommon.dicUserDirs[user].Add(webdavInfo);
            }
            else
            {
                ClsCommon.dicUserDirs[user].Add(webdavInfo);
            } 
        }

        public webdavInfo createInfo(DriveItem item, bool bRoot = false)
        {
            var _webdavInfo = new webdavInfo();
            if (bRoot)
            {
                _webdavInfo.parent = "/";
                _webdavInfo.nodeId = "/";
                _webdavInfo.itemId = "/";
                _webdavInfo.path = "/";
                _webdavInfo.name = "";
                _webdavInfo.fileType = "D";
                _webdavInfo.size = 0;
            }
            else
            {
                _webdavInfo.parent = item.ParentId == null ? "/" : item.ParentId;
                _webdavInfo.parentPath = Path.Combine("/", item.FullPath == null ? "" : item.FullPath);
                _webdavInfo.nodeId = item.NodeId;
                _webdavInfo.itemId = item.Id;
                _webdavInfo.path = Path.Combine(Path.Combine("/", item.FullPath == null ? "" : item.FullPath), item.Name).Replace("\\", "/");
                _webdavInfo.name = item.Name;
                _webdavInfo.fileType = item.Type;
                _webdavInfo.size = item.Bytes;
                _webdavInfo.getlastModified = item.LastModiDate;
                _webdavInfo.isRootNode = item.ParentId == null;
            }
            return _webdavInfo;
        }


    }
}
