﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.IO;
using System.Linq;
using System.Net.Http.Headers;
using System.Threading.Tasks;

namespace Project1.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class FileManagementController : ControllerBase
    {
        [HttpPost]
        [Route("upload")]
        public async Task<IActionResult> Upload()
        { 
            try
            {
                var formCollection = await Request.ReadFormAsync();
                var files = formCollection.Files;

                if (files == null)
                {
                    return NotFound();
                }
                foreach (var file in files)
                {
                    var folderName = Path.Combine("Resources", "Images");
                    var pathToSave = Path.Combine(Directory.GetCurrentDirectory(), folderName);
                    if (file.Length > 0)
                    {
                        if (!Directory.Exists(folderName))
                            Directory.CreateDirectory(folderName);

                        
                        var fileName = ContentDispositionHeaderValue.Parse(file.ContentDisposition).FileName.Trim('"');
                        var fullPath = Path.Combine(pathToSave, fileName);
                        var dbPath = Path.Combine(folderName, fileName);
                        using (var stream = new FileStream(fullPath, FileMode.Create))
                        {
                            file.CopyTo(stream);
                        }
                        //return Ok(new { dbPath });
                    }
                    else
                    {
                        //return BadRequest("");
                    }
                }
                return Ok();
            }
            catch (Exception ex)
            {  
                return StatusCode(500, $"Internal server error: {ex}");
            }




            //        var sniffer = new Sniffer();
            //        var supportedFiles = new List<Record>
            //{
            //    new Record("doc xls ppt msg", "D0 CF 11 E0 A1 B1 1A E1"),
            //    new Record("jpg,jpeg", "ff,d8,ff,db"),
            //    new Record("png", "89,50,4e,47,0d,0a,1a,0a"),
            //    new Record("pdf", "25 50 44 46"),
            //    new Record("gif", "47 49 46 38 39 61")
            //};
            //        sniffer.Populate(supportedFiles);

            //var formCollection = await Request.ReadFormAsync();
            //var files = formCollection.Files;
            //foreach (var file in files)
            //{
            //    //    byte[] fileHead = ReadFileHead(file);
            //    //    var results = sniffer.Match(fileHead);
            //    //    if (results.Count > 0)
            //    //    {
            //    //        var blobContainerClient = new BlobContainerClient("UseDevelopmentStorage=true", "images");
            //    //        blobContainerClient.CreateIfNotExists();
            //    //        var containerClient = blobContainerClient.GetBlobClient(file.FileName);
            //    //        var blobHttpHeader = new BlobHttpHeaders
            //    //        {
            //    //            ContentType = file.ContentType
            //    //        };
            //    //        await containerClient.UploadAsync(file.OpenReadStream(), blobHttpHeader);
            //    //    }
            //}

            //return Ok();
        }

        private static byte[] ReadFileHead(IFormFile file)
        {
            using var fs = new BinaryReader(file.OpenReadStream());
            var bytes = new byte[20];
            fs.Read(bytes, 0, 20);
            return bytes;
        }

        [HttpPost]
        [Route("createprofile")]
        public async Task<IActionResult> CreateProfile([FromForm] Profile profile)
        {
            if (ModelState.IsValid)
            {
                var tempProfile = profile;
                return Ok();
            }

            return BadRequest();
        }
    }

    public class Profile
    {
        //    [Required]
        //    public string Name { get; set; }
        //    [Required]
        //    public string Email { get; set; }
        [Required]
        public IFormFile Picture { get; set; }
    }
}
