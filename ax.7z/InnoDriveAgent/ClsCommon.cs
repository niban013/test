﻿using Microsoft.Win32;
using Newtonsoft.Json;
using MQTTnet;
using MQTTnet.Client;
using MQTTnet.Server;
using NLog;
using Fleck;
using System.Net.Sockets;
using System.Diagnostics;
using System.Management;
using System.Text.RegularExpressions;
using System.Net;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Text;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.Window;
using System.Windows.Forms;
using System.ComponentModel;
using System.Windows.Controls;
using System.ComponentModel.Design;
using IWshRuntimeLibrary;
using System.Windows.Input;
using NLog.Filters;
using System.Collections.Generic;
using Newtonsoft.Json.Linq;
using System.Threading.Tasks;
using System.Threading;

namespace InnoDriveAgent
{
    public enum SendCommand
    {
        WebApiWatch,
        WebApiPut,
        UnLock,
        Mqtt,
        UnCheckOut,
        InnoAgent
    }
    public enum NotifyIconType
    {
        OnLine,
        Offline,
        Fail
    }
    public class WebdavMessage
    {
        public SendCommand command { get; set; }
        public string id { get; set; }
        public string? cmdparams{ get; set; }
        public string msg { get; set; }

    }
    public enum HandleType
    {
        DownLoad,
        Upload
    }
    public class HandleTasks
    {
        public HandleType handleType { get; set; }
        public string taskName { get; set; }
        public Task task { get; set; }

        public CancellationTokenSource cts { get; set; }

        //public CancellationToken ctsToken
        //{
        //    get
        //    {
        //        return cts.Token;
        //    }
        //}
    }
    public static class ClsCommon
    {
        public static CancellationTokenSource ctsMqtt;
        public static CancellationToken ctsMqttToken;

        public static CancellationTokenSource ctsLogin;
        public static CancellationToken ctsLoginToken;

        public static ManagementEventWatcher startWatch;
        public static ManagementEventWatcher stopWatch;

        static List<ProcessInfo> lsProcessInfo = new List<ProcessInfo>();
        public static string product = InxSetting.ClsCommon.Product;
        public static IMqttClient mqttClient;
        public static NotifyIcon notifyIcon;
        private static int retry = Convert.ToInt32(Resource1.retry);
        private static int nowretry = Convert.ToInt32(Resource1.nowretry);
        private static int nowretrySec = Convert.ToInt32(Resource1.nowretrySec);
        public static string currentWebdavServer = "";
        public static string webApiUrl = "";
        private static List<IWebSocketConnection> ClientSockets = new List<IWebSocketConnection>();
        public static Logger logger;
        public static bool reConnection = false;
        private static object ojbProcess = new object();
        private static IniFile InxIni;
       
        public static string autoupdateUrl
        {
            get 
            {
                return  InxSetting.ClsCommon.AutoUpdate;
            }
        }
        public static void Init()
        { 
            nowretry = 0; 
            mqttClient = null;
            notifyIcon = null; 
        }
        public static string GetIni(string section, string key,string iniFile)
        {
            InxIni = new IniFile(@$"C:\\InnoLux\\InnoDrive\\SetupConfig\\{iniFile}.ini");
            if (InxIni.KeyExists(key, section))
            {
                return InxIni.Read(key, section);
            }
            return "";
        }
        public static void SetIni(string section,string key, string value, string iniFile)
        {
            InxIni = new IniFile(@$"C:\\InnoLux\\InnoDrive\\SetupConfig\\{iniFile}.ini");
            InxIni.Write(key, value, section); 
        }
        public static string GetInstallVer()
        {
            InxIni = new IniFile(@"C:\\InnoLux\\InnoDrive\\Setup.ini");
            if (InxIni.KeyExists("Version", "Setup"))
            {
                return InxIni.Read("Version", "Setup");
            }
            return "1.0.0.0";
        }
        public static async Task<bool> isAuth()
        {
            if (currentWebdavServer == "")
            {
                return false;
            }
            else 
            {
                var uri = currentWebdavServer.TrimEnd('/');
                uri = uri.Replace("http://", "").Replace(":", "@");
                uri = @"\\" + uri + @"\DavWWWRoot";
                return Directory.Exists(uri);
            } 
        }

        public static void Login()
        {
            string path = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "Microsoft", "Windows", "Network Shortcuts", ClsCommon.product);
            var fileName = Directory.GetFiles(path, "*.lnk").FirstOrDefault();

            ProcessStartInfo pInfo = new ProcessStartInfo(Path.Combine(path, fileName));
            pInfo.UseShellExecute = true;
            pInfo.WindowStyle = ProcessWindowStyle.Hidden;
            using (Process p = new Process())
            {
                p.StartInfo = pInfo;
                p.Start();
            }
        }

        public static async Task<(bool bWebApi, bool bWebDav)> isConnection()
        {
            try
            {
                var diffUrl = await ClsCommon.ReCreateWebdavServer("WebApiUrl");
                if (diffUrl)
                {
                    ClsCommon.createQuick();
                }
                Uri uri = new Uri(webApiUrl);
                var conn1 = ClsCommon.PingHost(uri.Host, uri.Port);
                var conn2 = false;
                if (ClsCommon.currentWebdavServer == "")
                {
                    conn2 = false;
                }
                else
                { 
                    uri = new Uri(ClsCommon.currentWebdavServer); 
                    conn2 = ClsCommon.PingHost(uri.Host, uri.Port);
                } 
                return (conn1, conn2);
            }
            catch(Exception ex) 
            {
                return (false, false);
            } 
        } 
         
        public static async Task<bool> ReCreateWebdavServer(string _webApiUrl)
        {
            var _diffUrl = false;
            List<string> result = new List<string>();
            webApiUrl = InxSetting.ClsCommon.WebApiUrl;//
            var webDavUrl = InxSetting.ClsCommon.DefaultWebDavUrl != string.Empty ? InxSetting.ClsCommon.DefaultWebDavUrl : InxSetting.ClsCommon.WebdavServer.FirstOrDefault();
            if (webDavUrl == "")
            { 
                using (HttpClient client = GetHttpClient("")) 
                {
                    HttpResponseMessage response = await client.GetAsync(webApiUrl + "/WebDav/GetWebdavParams");
                    if (response.StatusCode == System.Net.HttpStatusCode.NotFound)
                    {
                        result = new List<string>() { "http://innodrvwebdav.cminl.oa" };
                    }
                    else
                    {
                        var dicWebdav =  JsonConvert.DeserializeObject<Dictionary<string, string>>(response.Content.ReadAsStringAsync().Result);
                        if (dicWebdav.ContainsKey("WEBDAV_SERVER"))
                        {
                            result = new List<string>() { dicWebdav["WEBDAV_SERVER"] };
                        }
                        else 
                        {
                            result = new List<string>() { "" };
                        }
                        //if (dicWebdav.ContainsKey("WEBDAV_DNS"))
                        //{
                        //    webdavDns = dicWebdav["WEBDAV_DNS"];
                        //}
                        //if (dicWebdav.ContainsKey("WEBDAV_MQTT"))
                        //{
                        //    webdavMqtt = dicWebdav["WEBDAV_MQTT"];
                        //}
                    }
                } 
            }
            else
            {
                result = new List<string>() { webDavUrl }; 
            }
           
            var _currentWebdavServer = result.Count > 0 ? result[0] : "";
            if (currentWebdavServer == "" || (currentWebdavServer != _currentWebdavServer))
            {
                currentWebdavServer = _currentWebdavServer; 
                _diffUrl = true;
            }
            else  
            {
                _diffUrl = false;
            }
            return _diffUrl;
        }
        public static HttpClient GetHttpClient(string ticket)
        {
            HttpClient client = new HttpClient()
            {
                Timeout = TimeSpan.FromMinutes(20)
            };
            if (ticket != "")
            {
                client.DefaultRequestHeaders.Clear();
                client.DefaultRequestHeaders.Add("ticket", ticket);

            }
            return client;
        }
        public static void createQuick()
        {
             registerQuick(product, currentWebdavServer);
        }

        static string getFileType(string ext)
        {
            var fileType = "";
            switch (ext)
            {
                case ".xls":
                case ".xlsx":
                    fileType = "EXCEL";
                    break;
                case ".doc":
                case ".docx":
                    fileType = "WORD";
                    break;
                case ".ppt":
                case ".pptx":
                    fileType = "POWERPOINT";
                    break;
                case ".txt":
                    fileType = "notepad";
                    break;

            }
            return fileType;
        }

        static string getMatchFile(string ext)
        {
            var fileType = "";
            switch (ext)
            {
                case ".xls":
                case ".xlsx":
                    fileType = "Excel";
                    break;
                case ".doc":
                case ".docx":
                    fileType = "Word";
                    break;
                case ".ppt":
                case ".pptx":
                    fileType = "Powerpoint";
                    break;
                case ".txt":
                    fileType = "Notepad";
                    break;

            }
            return fileType;
        }

        public static async void registerWebSocket()
        {
            ClientSockets = new List<IWebSocketConnection>();
            
            var server = new WebSocketServer(Resource1.websocket);
            server.ListenerSocket.NoDelay = true;
            server.RestartAfterListenError = true;
            server.Start(
                socket =>
                {
                    socket.OnOpen = () =>
                    {
                        ClientSockets.Add(socket);
                    };
                    socket.OnClose = () =>
                    {
                        ClientSockets.Remove(socket);
                    };
                    socket.OnMessage = message =>
                    {
                        var isSendtoClient = false;
                        var webdavAction = JsonConvert.DeserializeObject<WebdavMessage>(message);
                        if (webdavAction.command == SendCommand.Mqtt)
                        {
                            var process = Process.GetProcessesByName(webdavAction.id).FirstOrDefault();
                            if (process == null)
                            {
                                webdavAction.msg = "N";
                            }
                            else
                            {
                                webdavAction.msg = ClsCommon.mqttClient.IsConnected ? "Y" : "N";
                            }
                            isSendtoClient = true;
                        }
                        else if (webdavAction.command == SendCommand.InnoAgent)
                        {
                            ExecuteCommand(webdavAction.cmdparams, webdavAction.id, webdavAction.msg);
                        }
                        else if (webdavAction.command == SendCommand.UnLock)
                        {
                            var isOpen = false;
                            var processes = Process.GetProcessesByName(getFileType(Path.GetExtension(webdavAction.id)));
                            for (int i = 0; i < processes.Length; i++)
                            {
                                if (processes[i].MainWindowTitle.StartsWith(webdavAction.id) && (processes[i].MainWindowTitle.EndsWith(" - " + getMatchFile(Path.GetExtension(webdavAction.id)))))
                                {
                                    isOpen = true;
                                    break;
                                }
                            }
                            webdavAction.msg = isOpen ? "Y" : "N";
                            isSendtoClient = true;
                        }
                        else
                        { 
                        
                        }
                        if (isSendtoClient)
                        {
                            ClientSockets.ToList().ForEach(s => s.Send(JsonConvert.SerializeObject(webdavAction)));
                        }
                    };
                }
           );
        }

        static void AddText(string text,string fileName)
        {
            var path = @$"C:\InnoLux\InnoDrive\{fileName}.txt";
            using (var file = System.IO.File.Open(path, FileMode.OpenOrCreate | FileMode.Append))
            using (var stream = new StreamWriter(file))
                stream.WriteLine(text);
        }
        static string ParseLogPath(string path)
        {
            var matchResult = Regex.Match(path, @"[0-9a-fA-F]{8}(-[0-9a-fA-F]{4}){3}-[0-9a-fA-F]{12}", RegexOptions.IgnoreCase);
            if (matchResult.Success)
            {
                Group g = matchResult.Groups[0];
                return g.ToString();
            }
            return "";
        }
        static void proc_OutputDataReceived(object sender, DataReceivedEventArgs e)
        {
            if (e.Data != null)
            {
                Thread.Sleep(500);
                var path = ParseLogPath(e.Data);
                if (path !="")
                {
                   AddText(e.Data,"test");  
                } 
            }
        }

        public static void cancelBws() 
        {
            //ClsCommon.bws.ForEach(bws => { bws.CancelAsync(); });
            var ls = bws.Keys.ToList();
            ls.ForEach(k =>
            {
                bws[k].CancelAsync();
            });
        }

      
      

       // static CancellationTokenSource cancellationTokenSource;
        static async void SomeMethod(string command2 = @$"download #ids #location *.* /s /y /xo", string ids = "53e63f95-03f0-4511-ac8d-18c5fa8605c0", string folder = "test", CancellationToken token = default(CancellationToken))
        {
            //cancellationTokenSource = new CancellationTokenSource();
            //CancellationToken ct = cancellationTokenSource.Token;
            //Task yourTask = null;
            //try
            //{
            //var localPath = Path.Combine(ClsCommon.GetIni("Folder", "Download", "Config"), folder);
            //Directory.CreateDirectory(localPath);

            //command2 = command2.Replace("#location", localPath);
            //string command = @$"/c drvcmd {command2}";

            //    var p = new Process();
            //    ids.Split('/').ToList().ForEach(f =>
            //    {
            //        dicLog[f] = folder;
            //        command = command.Replace("#ids", f);
            //        ProcessStartInfo startInfo = new ProcessStartInfo("CMD", command);
            //        startInfo.WorkingDirectory = @"C:\InnoLux\InnoDrive\drvcmd";
            //        startInfo.RedirectStandardOutput = true;
            //        startInfo.UseShellExecute = false;
            //        startInfo.CreateNoWindow = true;

            //        // Create the process and start it
            //        Process process = new Process();
            //        process.StartInfo = startInfo;
            //        process.EnableRaisingEvents = true;
            //        process.OutputDataReceived += new DataReceivedEventHandler(proc_OutputDataReceived);


            //        //TODO: more setup

            //        //process.Exited += (object sender, EventArgs e) =>
            //        //{
            //        //    ////TODO: Exceptions will go first, followed by `return;`
            //        //    //t.SetException();

            //        //    //TODO: Finally, if there are no problems, return successfully
            //        //    //t.SetResult(true);
            //        //    // cancellationTokenSource.Cancel();

            //        //};


            //        process.Start();
            //        process.BeginOutputReadLine();
            //        process.WaitForExitAsync(token);
            //    });
            for (int i = 0; i < 1000; i++)
            {
                Thread.Sleep(5000);
                while (token.IsCancellationRequested)
                {
                    Console.Write("* ");
                    Thread.Sleep(1000); //Throw if cancelled
                    return;
                }
            }
            //if (token.IsCancellationRequested)
            //{

            //    token.ThrowIfCancellationRequested();
            //    return;
            //}




            //result = Task.Run(() =>
            //  //Task task = new Task(async() =>
            //  {


            //  }, cancellationTokenSource.Token);
            //cancellationTokenSource.Cancel();

            //}
            //catch (Exception ex)
            //{
            //    Console.WriteLine(ex.Message);
            //}
            //finally
            //{
            //    //cancellationTokenSource.Dispose();
            //    //cancellationTokenSource = null;
            //}
            //return yourTask;
        }


        static Task MostBasicProcess(string command2 = @$"download #ids #location *.* /s /y /xo", string ids = "53e63f95-03f0-4511-ac8d-18c5fa8605c0", string folder = "test", CancellationToken token = default(CancellationToken))
        {
            var localPath = Path.Combine(ClsCommon.GetIni("Folder", "Download", "Config"), folder);
            Directory.CreateDirectory(localPath);

            command2 = command2.Replace("#location", localPath);
            string command = @$"/c drvcmd {command2}";
            var t = new TaskCompletionSource<bool>(); //Using bool, because TaskCompletionSource needs at least one generic param

            var p = new Process();

            ids.Split('/').ToList().ForEach(f =>
            {
                dicLog[f] = folder;
                command = command.Replace("#ids", f);
                ProcessStartInfo startInfo = new ProcessStartInfo("CMD", command);
                startInfo.WorkingDirectory = @"C:\InnoLux\InnoDrive\drvcmd";
                startInfo.RedirectStandardOutput = true;
                startInfo.UseShellExecute = false;
                startInfo.CreateNoWindow = true;

                // Create the process and start it
                Process process = new Process();
                process.StartInfo = startInfo;
                process.EnableRaisingEvents = true;
                process.OutputDataReceived += new DataReceivedEventHandler(proc_OutputDataReceived);


                //TODO: more setup
    
                process.Exited += (object sender, EventArgs e) =>
                {
                    ////TODO: Exceptions will go first, followed by `return;`
                    //t.SetException();

                    //TODO: Finally, if there are no problems, return successfully
                    t.SetResult(true);
                };


                process.Start();
                process.BeginOutputReadLine();
                process.WaitForExitAsync(token);
            });


       




            //TODO: wrap .Start() in try-block and call t.SetException on error

            return t.Task; //We actually don't want the caller using the bool param, it's implicitly casted to plain Task.
        }


        public static List<HandleTasks> lsHandleTasks = new List<HandleTasks>();
        public static Dictionary<string, BackgroundWorker> bws = new Dictionary<string, BackgroundWorker>();
        //public static List<BackgroundWorker> bws = new List<BackgroundWorker>();
        private static void AddDownloadBackGroundService(string _command, string _ids, string _folder)
        {
           
          

            var localPath = Path.Combine(ClsCommon.GetIni("Folder", "Download", "Config"), _folder);
            Directory.CreateDirectory(localPath);
            _command = _command.Replace("#location", localPath);
            string command = @$"/c drvcmd {_command}";

            _ids.Split('/').ToList().ForEach(f =>
            {
                dicLog[f] = _folder;
                command = command.Replace("#ids", f);
                BackgroundWorker bw = new BackgroundWorker();
                bw.DoWork += new DoWorkEventHandler(bw_DoWork);
                bw.WorkerSupportsCancellation = true;
                bw.RunWorkerCompleted += new RunWorkerCompletedEventHandler(bw_RunWorkerCompleted);
                bws[f] = bw;
                bw.RunWorkerAsync(new List<string>() { f, command });
            });

            //_ids.Split('/').ToList().ForEach(f =>
            //{
            //    dicLog[f] = _folder;
            //    command = command.Replace("#ids", f);
            //    BackgroundWorker bw = new BackgroundWorker();
            //    bw.DoWork += new DoWorkEventHandler(bw_DoWork);
            //    bw.WorkerSupportsCancellation = true;
            //    bw.RunWorkerCompleted += new RunWorkerCompletedEventHandler(bw_RunWorkerCompleted); 
            //    bws[f] = bw;
            //    bw.RunWorkerAsync(new List<string>(){ f,command });
            //}); 
        }
        static void bw_DoWork(object sender, DoWorkEventArgs e)
        {
            //int i;
            //for (i = 0; i < 2; i++) 
            //{
            //    Thread.Sleep(1000);
            //    if (((BackgroundWorker)sender).CancellationPending)
            //    { 
            //        e.Cancel = true;
            //        return;
            //    }

            //    e.Result = i.ToString();
            //}
            var args = e.Argument as List<string>;
            ProcessStartInfo startInfo = new ProcessStartInfo("CMD", args[1]);
            startInfo.WorkingDirectory = @"C:\InnoLux\InnoDrive\drvcmd";
            startInfo.RedirectStandardOutput = true;
            startInfo.UseShellExecute = false;
            startInfo.CreateNoWindow = true;

            // Create the process and start it
            Process process = new Process();
            process.StartInfo = startInfo;
            process.EnableRaisingEvents = true;
            process.OutputDataReceived += new DataReceivedEventHandler(proc_OutputDataReceived);
            process.Start();
            process.BeginOutputReadLine();
            process.WaitForExit();
            //e.Result = args[0];
        
            if (((BackgroundWorker)sender).CancellationPending)
            {
                ((BackgroundWorker)sender).ReportProgress(0);
                // e.UserState = args[0];
                e.Cancel = true;
                return;
            }
            e.Result = args[0];
        }

        static void bw_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            //string guid = e.Result.ToString();
            //if (bws.ContainsKey(guid))
            //{
            //    bws[guid] = null;
            //    bws.Remove(guid);
            //    if (bws.Count == 0)
            //    {
            //        if (e.Cancelled)
            //        {
            //            //this.richTextBox1.Text += "線程已經停止";
            //        }
            //        else
            //        {
            //            //  this.richTextBox1.Text += "線程已經完成";
            //        }
            //    }
            //}


        }
        //@$"download 42934707-4562-4504-ac32-b5f51b956671 #folder *.* /s /y /xo"  "42934707-4562-4504-ac32-b5f51b956671"
        private static Dictionary<string, string> dicLog = new Dictionary<string, string>();
      
        public static void ExecuteCommand(string command2 = @$"download #ids #location *.* /s /y /xo",string ids = "53e63f95-03f0-4511-ac8d-18c5fa8605c0", string folder = "test")
        {
            //AddDownloadBackGroundService(command2,ids, folder);
            //cancellationTokenSource = new CancellationTokenSource();
            //CancellationToken ct = cancellationTokenSource.Token;
            try
            {
                var f = new HandleTasks();
                f.handleType = HandleType.DownLoad;
                f.taskName = folder; 
                f.cts = new CancellationTokenSource();
                var task1 = new Task(() =>
                {
                  
                    SomeMethod(command2, ids, folder, f.cts.Token);
                }, f.cts.Token);
                //Task task1 = new Task(() => 
                //{ 
                //    SomeMethod(command2, ids, folder, f.cts.Token); 
                //}, f.cts.Token);
                f.task = task1;
                lsHandleTasks.Add(f);
              //  f = null;
            }
            catch (Exception ex)
            {
            }

            //var localPath = Path.Combine(ClsCommon.GetIni("Folder", "Download", "Config"), folder);
            //Directory.CreateDirectory(localPath);

            //command2 = command2.Replace("#location", localPath); 
            //string command = @$"/c drvcmd {command2}"; 
            //ids.Split('/').ToList().ForEach(f => {
            //    dicLog[f] = folder;
            //    command = command.Replace("#ids", f);
            //    ProcessStartInfo startInfo = new ProcessStartInfo("CMD", command);
            //    startInfo.WorkingDirectory = @"C:\InnoLux\InnoDrive\drvcmd";
            //    startInfo.RedirectStandardOutput = true;
            //    startInfo.UseShellExecute = false;
            //    startInfo.CreateNoWindow = true;

            //    // Create the process and start it
            //    Process process = new Process();
            //    process.StartInfo = startInfo;
            //    process.EnableRaisingEvents = true;
            //    process.OutputDataReceived += new DataReceivedEventHandler(proc_OutputDataReceived);
            //    process.Start();
            //    process.BeginOutputReadLine(); 
            //}); 
        }
        static void sendtoClient(SendCommand cmd, string id, string msg)
        {
            WebdavMessage m = new WebdavMessage();
            m.command = cmd;
            m.id = id;
            m.msg = msg;
            ClientSockets.ToList().ForEach(s => s.Send(JsonConvert.SerializeObject(m)));
        }
        public static async void registerMQTT(string user, NotifyIcon notifyIcon1, CancellationToken cancellationToken)
        {
            try
            {
                Init();
                notifyIcon = notifyIcon1;
                ChangeNotifyIcon(NotifyIconType.Offline, notifyIcon);
                if (mqttClient != null)
                    return; 
                string rq = currentWebdavServer; 
                    var UserName = "webdav";
                    var Password = "webdav";
                    var HostName = rq.Replace("http://", "").Split(':').First().Trim();
                HostName = HostName.Split('/').First();
                mqttClient = new MqttFactory().CreateMqttClient();
                var clientIp = GetLocalIPAddress().ToString();
                 
                var webdavServerIp = GetIPsByName(InxSetting.ClsCommon.WebdavMqtt.Split(':').First(), true, false)[0].MapToIPv4().ToString();
                var webdavServerPort = InxSetting.ClsCommon.WebdavMqtt.Split(':').Last();

                var options = new MqttClientOptionsBuilder()
                        .WithClientId(user + "@" + clientIp)
                        .WithCredentials(UserName, Password)
                        .WithKeepAlivePeriod(TimeSpan.FromSeconds(7.5))
                        .WithCleanSession()
                        .WithProtocolVersion(MQTTnet.Formatter.MqttProtocolVersion.V500)
                        .WithUserProperty(user + "@" + clientIp, clientIp)
                         //.WithTcpServer(webdavServerIp, 61613)
                        .WithTcpServer(webdavServerIp, Convert.ToInt32(webdavServerPort)) 
                        .Build();

               
                // When client connected to the server
                //MessageBox.Show("HostName:" + HostName);
                string topic = ("webdav-" + user).ToUpper();
                    mqttClient.ConnectedAsync += (async e =>
                    {
                        if (cancellationToken.IsCancellationRequested)
                        {
                            return;
                        }
                        
                        await mqttClient.SubscribeAsync(new MqttTopicFilterBuilder().WithTopic(topic).Build()); 
                        sendtoClient(SendCommand.Mqtt, "InnoDriveAgent", "Y"); //通知app agent起動

                        var msg = new WebdavMessage();
                        msg.msg = "連線服務器成功";
                        ChangeNotifyIcon(NotifyIconType.OnLine, notifyIcon);
                        showMessage(NotifyIconType.OnLine, toBase64(JsonConvert.SerializeObject(msg)));
                    });


                    mqttClient.ApplicationMessageReceivedAsync += (async e =>
                    {
                        var payload = e.ApplicationMessage.ConvertPayloadToString(); 
                        var decodeCommand = JsonConvert.DeserializeObject<WebdavMessage>(payload);
                        if (decodeCommand.command == SendCommand.WebApiWatch)
                        {
                            if (decodeCommand.msg == "OK")
                            {
                                if (notifyIcon1.BalloonTipIcon == ToolTipIcon.Info)
                                {
                                }
                                else
                                {
                                    showMessage(NotifyIconType.OnLine, toBase64(payload));
                                }
                            }
                            else
                            {
                                showMessage(NotifyIconType.Offline, toBase64(payload));
                            }
                        }
                        else if (decodeCommand.command == SendCommand.WebApiPut)
                        { 
                            showMessage(NotifyIconType.OnLine, toBase64(payload));
                        }
                        else if (decodeCommand.command == SendCommand.UnLock)// 保留
                        {
                            ClientSockets.ToList().ForEach(s => s.Send(payload));  //send to app
                        }
                    });
                
                    mqttClient.DisconnectedAsync += (async e =>
                    { 
                        sendtoClient(SendCommand.Mqtt, "InnoDriveAgent", "N"); 
                        if (cancellationToken.IsCancellationRequested)
                        {
                            return;
                        }
                        ChangeNotifyIcon(NotifyIconType.Offline, notifyIcon);
                        if (nowretry >= retry)
                        {
                            var msg = new WebdavMessage();
                            msg.msg = "[Error Code:503]MQTT初始化失敗,請嘗試手動重啟"; 
                            showMessage(NotifyIconType.Fail, toBase64(JsonConvert.SerializeObject(msg)));
                            return; 
                        }
                        showMessage(NotifyIconType.Offline);
                        Console.WriteLine("MQTT reconnecting");
                        await Task.Delay(TimeSpan.FromSeconds(nowretrySec));
                        await mqttClient.ConnectAsync(options, cancellationToken);
                    });
                    await mqttClient.ConnectAsync(options, cancellationToken);
                
            }
            catch (Exception ex)
            {
                //throw ex;
               // MessageBox.Show(ex.Message);
                //var msg = new Message();
                //msg.msg = "MQTT初始化失敗";   
                //showMessage(NotifyIconType.Offline, toBase64(JsonConvert.SerializeObject(msg)));
            }
        }
        public static void ChangeNotifyIcon(NotifyIconType notiType, NotifyIcon notifyIcon)
        { 
            try
            {
                notifyIcon.Icon = null;
                notifyIcon.Icon = (notiType == NotifyIconType.OnLine) ? InnoDriveAgent.Resource1.inxdrive32 : InnoDriveAgent.Resource1.inxdrive32g;
                notifyIcon.BalloonTipIcon = ToolTipIcon.Info; 
               
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

       
        public static void showMessage(NotifyIconType notiType, string msg ="")
        { 
            if (notifyIcon != null)
            {
                if (notiType == NotifyIconType.Fail)
                {
                    ChangeNotifyIcon(NotifyIconType.Fail, notifyIcon);
                    var msgInfo = JsonConvert.DeserializeObject<WebdavMessage>(fromBase64(msg));
                    mqttClient = null;
                    notifyIcon.Text = "無法連線......";
                    notifyIcon.BalloonTipIcon = ToolTipIcon.Error;  
                    notifyIcon.BalloonTipTitle = "[Status Code:503] Client=>WebDav";
                    notifyIcon.BalloonTipText = msgInfo.msg;
                    notifyIcon.ShowBalloonTip(1000);
                    logger.Error($@"WebDav:{notifyIcon.Text}");
                    return;
                }
                if (msg == string.Empty)
                {
                    if (notiType == NotifyIconType.OnLine)
                    {
                        ChangeNotifyIcon(NotifyIconType.OnLine, notifyIcon);
                        notifyIcon.Text = "已連線......";
                        notifyIcon.BalloonTipIcon = ToolTipIcon.Info;
                        notifyIcon.BalloonTipTitle = "[Status Code:200] Client=>WebDav";
                        notifyIcon.BalloonTipText = "";
                        nowretry = 0;
                        logger.Info($@"WebDav:{notifyIcon.Text}");
                    }
                    else
                    {
                        ChangeNotifyIcon(NotifyIconType.Fail, notifyIcon);
                        nowretry++;
                        notifyIcon.Text = "重試連線......";
                        notifyIcon.BalloonTipIcon = ToolTipIcon.Error;
                        notifyIcon.BalloonTipTitle = $@"[Status Code:400]服務器斷線(Client=>WebDav)";
                        notifyIcon.BalloonTipText = nowretry > retry ? "請連絡IT" : $@"正在重試中{nowretry}/{retry}......"; 
                        notifyIcon.ShowBalloonTip(1000);
                        logger.Error($@"WebDav:{notifyIcon.Text},{notifyIcon.BalloonTipTitle}");
                    } 
                }
                else
                { 
                    var msgInfo = JsonConvert.DeserializeObject<WebdavMessage>(fromBase64(msg));
                    notifyIcon.Text = "已連線......"; 
                    notifyIcon.BalloonTipText = (msgInfo.msg.Contains("ConnectionRefused") || msgInfo.msg.Contains("結果:無法連線，因為目標電腦拒絕連線")
                        || msgInfo.msg.Contains("結果:連線嘗試失敗")) ? "InnoDriveApi連線失敗" : msgInfo.msg.Replace(",", "\r\n");
                    //notifyIcon.BalloonTipText = notifyIcon.BalloonTipText == "OK" ? "InnoDriveApi已連線":"";
                    if (notifyIcon.BalloonTipText.Contains("InnoDriveApi連線失敗"))
                    {
                        notifyIcon.Text = "重試連線......";
                        ChangeNotifyIcon(NotifyIconType.Fail, notifyIcon);
                        notifyIcon.BalloonTipIcon = ToolTipIcon.Error;
                        notifyIcon.BalloonTipTitle = "[Status Code:503] WebDav=>InxDriveApi";
                    }
                    else
                    { 
                        ChangeNotifyIcon(NotifyIconType.OnLine, notifyIcon);
                        notifyIcon.BalloonTipIcon = ToolTipIcon.Info;
                        notifyIcon.BalloonTipTitle = "[Status Code:200] Client=>WebDav";
                        nowretry = 0;
                    }
                    notifyIcon.ShowBalloonTip(1000);
                    logger.Info($@"WebDav:{notifyIcon.Text},InnoDriveApi:{notifyIcon.BalloonTipText}");
                }  
            } 
        }
        private static string toBase64(string inputText)
        {
            Byte[] bytesEncode = System.Text.Encoding.UTF8.GetBytes(inputText);
            return Convert.ToBase64String(bytesEncode);
        }
        private static string fromBase64(string resultEncode)
        {
            Byte[] bytesDecode = Convert.FromBase64String(resultEncode);
            return System.Text.Encoding.UTF8.GetString(bytesDecode);
        }

        public static void registerQuick(string product, string server)
        {
            server = server.TrimEnd('/');
            server = server.Replace("http://", "").Replace("/", "\\").Replace(":", "@");
            server = @"\\" + server + @"\DavWWWRoot";

            removeShortcut(product);
            createDesktopini(product, server, 0);
        }

        //public static string httpToWebdav(string httpFormat)
        //{
        //    Uri uri = new Uri(httpFormat);


        //    httpFormat = httpFormat.Replace("http://", "").Replace("/", "\\").Replace(":", "@");
        //    httpFormat = @"\\" + httpFormat + @"\DavWWWRoot";
        //    return httpFormat;
        //}

        private static void createDesktopini(string name, string targetPath, int iconNumber)
        {

            string networkshortcuts = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "Microsoft", "Windows", "Network Shortcuts");

            var newFolder = Directory.CreateDirectory(networkshortcuts + @"\" + name);

            newFolder.Attributes |= FileAttributes.ReadOnly;

            string desktopiniContents = @"[.ShellClassInfo]" + Environment.NewLine +

                "CLSID2={0AFACED1-E828-11D1-9187-B532F1E9575D}" + Environment.NewLine +

                "Flags=2";

            string shortcutlocation = networkshortcuts + @"\" + name;

            System.IO.File.WriteAllText(shortcutlocation + @"\Desktop.ini", desktopiniContents);

            string targetLNKPath = networkshortcuts + @"\" + name;

            createShortcut(name, targetLNKPath, targetPath);

        }

        static void createShortcut(string product, string shortcutPath, string targetPath)
        {
           try 
            {
                string shortcutLocation = System.IO.Path.Combine(shortcutPath, "target.lnk");
                var shell = new IWshRuntimeLibrary.WshShell(); 
                var shortcut = (IWshRuntimeLibrary.WshShortcut)shell.CreateShortcut(shortcutLocation);

                shortcut.Description = product;
                shortcut.IconLocation = Path.Combine(@"C:\InnoLux\InnoDrive\Icon", "inxdrive32.ico");
                shortcut.TargetPath = targetPath;
                shortcut.Save();
            }
            catch (Exception ex) 
            { 
            
            }
           
        }
        public static void removeShortcut(string product)
        {
            var path = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "Microsoft", "Windows", "Network Shortcuts");
            string shortcut_link = Path.Combine(path, product, "target.lnk");
            if (System.IO.File.Exists(shortcut_link))
            {
                System.IO.File.Delete(shortcut_link);
                var folder = new DirectoryInfo(Path.Combine(path, product));
                folder.Attributes = FileAttributes.Normal;
                Directory.Delete(folder.FullName, true);
            }
            else 
            {
                var folder = new DirectoryInfo(Path.Combine(path, product));
                if (System.IO.Directory.Exists(folder.FullName))
                {
                    folder.Attributes = FileAttributes.Normal;
                    Directory.Delete(folder.FullName, true);
                } 
            }
        }
        public static bool PingHost(string hostUri, int portNumber = 80)
        {
            bool pingable = false;  
            try
            {
                using (var client = new TcpClient(hostUri, portNumber))
                {
                    pingable = true;
                } 
            }
            catch (SocketException ex)
            {
               
            }  
            return pingable;
        }

      
        public static void NoWebDavSupportFile()
        {
            try
            {
                lsProcessInfo.Clear();
                ProcessInfo p;
                string query = "Select * From Win32_Process WHERE Name = 'notepad.exe'";
                ManagementObjectSearcher searcher = new ManagementObjectSearcher(query);
                ManagementObjectCollection processList = searcher.Get();
                using (var results = processList)
                {
                    foreach (ManagementObject result in results)
                    {
                        p = new ProcessInfo();
                        try
                        {
                            p.PID = Convert.ToInt32(result["processid"].ToString());
                            p.ProcessName = result["name"].ToString();
                            p.CommandLine += result["CommandLine"].ToString() + " ";
                        }
                        catch { }
                        try
                        {
                            string[] argList = new string[2];
                            int returnVal = Convert.ToInt32(result.InvokeMethod("GetOwner", argList));
                            if (returnVal == 0)
                            { 
                                p.UserDomain = argList[1];
                                p.UserName = argList[0];
                            } 
                        }
                        catch { }
                        if (!string.IsNullOrEmpty(p.CommandLine))
                        {
                            p.CommandLine = p.CommandLine.Trim();
                        }
                        lsProcessInfo.Add(p);
                    }
                  
                }

                startWatch = new ManagementEventWatcher(new WqlEventQuery("SELECT * FROM Win32_ProcessStartTrace WHERE ProcessName='notepad.exe'"));
                startWatch.EventArrived += new EventArrivedEventHandler(startWatch_EventArrived);
                startWatch.Start();

                stopWatch = new ManagementEventWatcher(new WqlEventQuery("SELECT * FROM Win32_ProcessStopTrace WHERE ProcessName='notepad.exe'"));
                stopWatch.EventArrived += new EventArrivedEventHandler(stopWatch_EventArrived);
                stopWatch.Start();

            }
            catch (Exception ex)
            {
            
            }
        }
      
        static void stopWatch_EventArrived(object sender, EventArrivedEventArgs e)
        { 
            var proc = GetProcessInfo(e);
            var item = lsProcessInfo.Where(p => p.PID == proc.PID).FirstOrDefault();
            if (item != null)
            {
                lock (ojbProcess)
                {
                    lsProcessInfo.Remove(item);
                }
                MatchCollection matches = Regex.Matches(item.CommandLine, "\"([^\"]*)\"");
                var url = item.CommandLine.Replace(matches[0].Value,"").Trim();
                if (url.StartsWith("//"))
                {
                    sendtoClient(SendCommand.UnLock, Path.GetFileName(url), "UnLock");
                }
                else 
                {
                    //if (url.StartsWith("\""))
                    //{
                    //    var lsUrl = new List<string>();
                    //    var tmp = url.Split('\\');
                    //    for (int i = 4; i < tmp.Length; i++)
                    //    {
                    //        lsUrl.Add(tmp[i]);
                    //    }
                    //    var result = _client.Unlock(currentWebdavServer + "/" + Path.Combine(lsUrl.ToArray()).Replace("\\", "/").Replace("\"", ""),"").Result;
                    //    if (!result.IsSuccessful)
                    //    {
                    //        throw new Exception($"解鎖失敗");
                    //    }
                    //}

                }
            }   
        }

        static void startWatch_EventArrived(object sender, EventArrivedEventArgs e)
        {
            try
            {
                var proc = GetProcessInfo(e);
                var item = lsProcessInfo.Where(p => p.PID == proc.PID).FirstOrDefault();
                if (item == null)
                { 
                    //if (proc.CommandLine.StartsWith("\""))
                    //{ 
                    //    var lsUrl = new List<string>();
                    //    var tmp = proc.CommandLine.Split(' ')[2].Split('\\');
                    //    for (int i = 4; i < tmp.Length; i++)
                    //    {
                    //        lsUrl.Add(tmp[i]);
                    //    }
                    //    var result = _client.Lock("http://" + currentWebdavServer + "/" + Path.Combine(lsUrl.ToArray()).Replace("\\", "/").Replace("\"", "")).Result;
                    //    if (!result.IsSuccessful)
                    //    {
                    //        throw new Exception($"檔案遺失，開啟失敗");
                    //    }
                    //}
                    lock (ojbProcess)
                    { 
                        lsProcessInfo.Add(proc);
                    } 
                } 
            }
            catch (Exception ex)
            {
         
            }
        }

        static ProcessInfo GetProcessInfo(EventArrivedEventArgs e)
        {
            var p = new ProcessInfo();
            var pid = 0;
            int.TryParse(e.NewEvent.Properties["ProcessID"].Value.ToString(), out pid);
            p.PID = pid;
            p.ProcessName = e.NewEvent.Properties["ProcessName"].Value.ToString();
            try
            {
                using (var searcher = new ManagementObjectSearcher("SELECT * FROM Win32_Process WHERE ProcessId = " + pid))
                using (var results = searcher.Get())
                {
                    foreach (ManagementObject result in results)
                    {
                        try
                        {
                            p.CommandLine += result["CommandLine"].ToString() + " ";
                        }
                        catch { }
                        try
                        {
                            var user = result.InvokeMethod("GetOwner", null, null);
                            p.UserDomain = user["Domain"].ToString();
                            p.UserName = user["User"].ToString();
                        }
                        catch { }
                    }
                }
                if (!string.IsNullOrEmpty(p.CommandLine))
                {
                    p.CommandLine = p.CommandLine.Trim();
                }
            }
            catch (ManagementException) { }
            return p;
        }
        static IPAddress GetLocalIPAddress()
        {
            var host = Dns.GetHostEntry(Dns.GetHostName());
            var ipAddress = host.AddressList.FirstOrDefault(ip => ip.AddressFamily == AddressFamily.InterNetwork);
            return ipAddress;
        }
        static IPAddress[] GetIPsByName(string hostName, bool ip4Wanted, bool ip6Wanted)
        { 
            IPAddress outIpAddress;
            if (IPAddress.TryParse(hostName, out outIpAddress) == true)
                return new IPAddress[] { outIpAddress }; 
            IPAddress[] addresslist = Dns.GetHostAddresses(hostName); 
            if (addresslist == null || addresslist.Length == 0)
                return new IPAddress[0]; 
            if (ip4Wanted && ip6Wanted)
                return addresslist; 
            if (ip4Wanted)
                return addresslist.Where(o => o.AddressFamily == AddressFamily.InterNetwork).ToArray(); 
            if (ip6Wanted)
                return addresslist.Where(o => o.AddressFamily == AddressFamily.InterNetworkV6).ToArray();
            return new IPAddress[0];
        }
    }

    class ProcessInfo
    {
        public string ProcessName { get; set; }
        public int PID { get; set; }
        public string CommandLine { get; set; }
        public string UserName { get; set; }
        public string UserDomain { get; set; }
        public string User
        {
            get
            {
                if (string.IsNullOrEmpty(UserName))
                {
                    return "";
                }
                if (string.IsNullOrEmpty(UserDomain))
                {
                    return UserName;
                }
                return string.Format("{0}\\{1}", UserDomain, UserName);
            }
        }
    }

    class IniFile
    {
        string Path;
        string EXE = Assembly.GetExecutingAssembly().GetName().Name;

        [DllImport("kernel32", CharSet = CharSet.Unicode)]
        static extern long WritePrivateProfileString(string Section, string Key, string Value, string FilePath);

        [DllImport("kernel32", CharSet = CharSet.Unicode)]
        static extern int GetPrivateProfileString(string Section, string Key, string Default, StringBuilder RetVal, int Size, string FilePath);

        public IniFile(string IniPath = null)
        {
            Path = new FileInfo(IniPath ?? EXE + ".ini").FullName;
        }

        public string Read(string Key, string Section = null)
        {
            var RetVal = new StringBuilder(255);
            GetPrivateProfileString(Section ?? EXE, Key, "", RetVal, 255, Path);
            return RetVal.ToString();
        }

        public void Write(string Key, string Value, string Section = null)
        {
            WritePrivateProfileString(Section ?? EXE, Key, Value, Path);
        }

        public void DeleteKey(string Key, string Section = null)
        {
            Write(Key, null, Section ?? EXE);
        }

        public void DeleteSection(string Section = null)
        {
            Write(null, null, Section ?? EXE);
        }

        public bool KeyExists(string Key, string Section = null)
        {
            return Read(Key, Section).Length > 0;
        }
    }

    public static class TaskExtensionMethods
    {
        public static async Task<T> WithCancellation<T>(this Task<T> task, CancellationToken cancellationToken)
        {
            var TCS = new TaskCompletionSource<object>(TaskCreationOptions.RunContinuationsAsynchronously);
            using (cancellationToken.Register(state =>
            {
                ((TaskCompletionSource<object>)state).TrySetResult(null);
            }, TCS))
            {
                var resultTask = await Task.WhenAny(task, TCS.Task);
                if (resultTask == TCS.Task)
                {
                    throw new OperationCanceledException(cancellationToken);
                }
                return await task;
            };
        }
    }
}
