﻿using AutoUpdaterDotNET;
using MQTTnet.Client;
using NLog;
using NLog.Web;
using System.Globalization;
using System.Security.Principal;
using System.Windows.Threading;
using MessageBox = System.Windows.Forms.MessageBox;

namespace InnoDriveAgent
{

    public partial class Form1 : Form
    { 
       
        private string[] arrArgs = new string[] { };
        private static object ojbMqtt = new object();
        private async void Process(CancellationToken cancellationToken)
        {
            while (true)
            { 
                reCreateMaqtt(cancellationToken);
                label1.Invoke(new Action(() => label1.Text = $"{DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss.fff")}程序running..."));
                await Task.Delay(TimeSpan.FromSeconds(20));
            }
        }

        private async void LoginMonitor(CancellationToken cancellationToken)
        {
            while (true)
            { 
                if (cancellationToken.IsCancellationRequested)
                {
                    return;
                }

                (bool bWebApi, bool bWebDav) = await ClsCommon.isConnection();
                if (!bWebApi || !bWebDav)
                {
                    notifyIcon1.Text = "連線中......";
                    notifyIcon1.BalloonTipText = "";
                    var lsMsg = new List<string>();
                    if (!bWebDav)
                    {
                        lsMsg.Add("WebDav連線失敗");
                    }
                    if (!bWebApi)
                    {
                        lsMsg.Add("InnoDriveApi連線失敗");
                    }
                    notifyIcon1.BalloonTipText = string.Join("\r\n", lsMsg);


                    if (lsMsg.Count > 0)
                    {
                        notifyIcon1.BalloonTipIcon = ToolTipIcon.Error;
                        notifyIcon1.BalloonTipTitle = "[Status Code:503] WebDav disconnected";
                    }
                    else
                    {
                        notifyIcon1.BalloonTipIcon = ToolTipIcon.Info;
                        notifyIcon1.BalloonTipTitle = "[Status Code:200] WebDav is connected"; 
                    }
                    notifyIcon1.ShowBalloonTip(200);

                    if (!bWebDav)
                    { 
                        //if (ClsCommon.ctsMqtt != null)
                        //{
                        //    ClsCommon.ctsMqtt.Cancel(); //停掉 mtqq
                        //}
                        label1.Invoke(new Action(() => label1.Text = " LoginMonitor disconnected..."));
                    }
                }
                else 
                {
                    if (InxSetting.ClsCommon.AutoRegisterUser)
                    {
                        if (ClsCommon.ctsMqtt == null)
                        {
                            ClsCommon.reConnection = true;
                            ClsCommon.ctsMqtt = new CancellationTokenSource();
                            ClsCommon.ctsMqttToken = ClsCommon.ctsMqtt.Token;
                            Task task = Task.Run(() => Process(ClsCommon.ctsMqttToken));
                        }
                        label1.Invoke(new Action(() => label1.Text = " LoginMonitor running..."));
                    }
                    else
                    {
                        if (await ClsCommon.isAuth())
                        {
                            if (ClsCommon.ctsMqtt == null)
                            {
                                ClsCommon.reConnection = true;
                                ClsCommon.ctsMqtt = new CancellationTokenSource();
                                ClsCommon.ctsMqttToken = ClsCommon.ctsMqtt.Token;
                                Task task = Task.Run(() => Process(ClsCommon.ctsMqttToken));
                            }
                            label1.Invoke(new Action(() => label1.Text = " LoginMonitor running..."));
                        }
                        else
                        {
                            ClsCommon.Login();
                        }
                    }
                    
                } 
               
                await Task.Delay(TimeSpan.FromSeconds(20));
            }
        }
        

        public Form1()
        {
          
            InitializeComponent(); 
            ClsCommon.logger = LogManager.Setup().LoadConfigurationFromFile("nlog.config").LoadConfigurationFromAppSettings().GetCurrentClassLogger();
            ClsCommon.logger.Info("初始化完成");
            CreateMenuItem();
            menuItemUpdate_Click(null, null);
            ClsCommon.ctsLogin = new CancellationTokenSource();
            ClsCommon.ctsLoginToken = ClsCommon.ctsLogin.Token;

            Task task = Task.Run(() => LoginMonitor(ClsCommon.ctsLoginToken));

        }

        async void reCreateMaqtt(CancellationToken cancellationToken)
        {
            try
            { 
                //var isRecreate = ClsCommon.ReCreateWebdavServer("WebApiUrl").Result;
                if (ClsCommon.reConnection)
                { 
                    MqttClientDisconnectOptions opt = new MqttClientDisconnectOptions();
                    opt.Reason = MqttClientDisconnectOptionsReason.NormalDisconnection;
                    if (ClsCommon.mqttClient == null)
                    {

                    }
                    else if (ClsCommon.mqttClient.IsConnected)
                    {
                        await ClsCommon.mqttClient.DisconnectAsync(opt, ClsCommon.ctsMqttToken);
                        ClsCommon.mqttClient.Dispose();
                    }

                    lock (ojbMqtt)
                    {
                        ClsCommon.registerWebSocket(); 
                        ClsCommon.registerMQTT(WindowsIdentity.GetCurrent().Name.ToUpper(), notifyIcon1, cancellationToken);
                        //ClsCommon.NoWebDavSupportFile();
                    }
                    ClsCommon.reConnection = false;
                }
            }
            catch (Exception ex)
            {
                ClsCommon.logger.Error(ex.ToString() + ",StackTrace:" + ex.StackTrace);
                MessageBox.Show(ex.ToString());
            }
        }

        private async void menuItemQuit_Click(object sender, System.EventArgs e)
        {
            try
            {
                await quit();
            }
            catch (ThreadAbortException tae)
            {
                ClsCommon.logger.Error(tae.ToString() + ",StackTrace:" + tae.StackTrace);
                MessageBox.Show(tae.ToString());
            }
            finally
            {
                this.Close();
            }
        }

        private void AutoUpdaterOnCheckForUpdateEvent(UpdateInfoEventArgs args)
        {
            if (args != null)
            {
                if (args.IsUpdateAvailable)
                {
                    var dialogResult = MessageBox.Show(string.Format(
                        "There is new version {0} avilable. You are using version {1}. Do you want to update the application now?", args.CurrentVersion, args.InstalledVersion), @"Update Available", MessageBoxButtons.YesNo, MessageBoxIcon.Information);
                    if (dialogResult.Equals(DialogResult.Yes))
                    {
                        try
                        {
                            // Developer can also use Download Update dialog used by AutoUpdater.NET to download the update.
                           // AutoUpdater.DownloadUpdate();
                        }
                        catch (Exception exception)
                        {
                            MessageBox.Show(exception.Message, exception.GetType().ToString(), MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                }
                else
                {
                    MessageBox.Show(@"There is no update avilable please try again later.", @"No update available", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            else
            {
                MessageBox.Show(@"There is a problem reaching update server please check your internet connection and try again later.", @"Update check failed", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private async void menuItemUpdate_Click(object sender, System.EventArgs e)
        {
            try
            {
                if (ClsCommon.autoupdateUrl != "")
                {
                    Thread.CurrentThread.CurrentCulture = Thread.CurrentThread.CurrentUICulture = CultureInfo.CurrentCulture;
                    //    AutoUpdater.CheckForUpdateEvent += AutoUpdaterOnCheckForUpdateEvent;




                    AutoUpdater.Mandatory = true;
                    AutoUpdater.ReportErrors = true;
                    //AutoUpdater.UpdateMode = Mode.Normal;
                    AutoUpdater.Start(ClsCommon.autoupdateUrl);

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
            finally
            {
                //AutoUpdater.Mandatory = false;
                //AutoUpdater.ReportErrors = false;
            }
        }

        private async void menuItemDownLoad_Click(object sender, System.EventArgs e)
        {
            drvDownloadForm f = new drvDownloadForm();
            f.Show();
        }

        private async void menuItemSetup_Click(object sender, System.EventArgs e)
        {
            SetupForm s = new SetupForm();
            s.Show();
        }
        private async void menuItemRestart_Click(object sender, System.EventArgs e)
        {
            try
            {
                await quit();

                notifyIcon1.ShowBalloonTip(200, "Information", "重新啟動中!", ToolTipIcon.Info);

                ClsCommon.ctsLogin = new CancellationTokenSource();
                ClsCommon.ctsLoginToken = ClsCommon.ctsLogin.Token;
                Task task = Task.Run(() => LoginMonitor(ClsCommon.ctsLoginToken)); 
            }
            catch (ThreadAbortException tae)
            {
                ClsCommon.logger.Error(tae.ToString() + ",StackTrace:" + tae.StackTrace);
                MessageBox.Show(tae.ToString());
            }
        }


        private void CreateMenuItem()
        {
            ContextMenuStrip contextMenuStrip = new ContextMenuStrip();
            this.ContextMenuStrip = contextMenuStrip;

            ToolStripMenuItem toolStripMenuItem = new ToolStripMenuItem();
            toolStripMenuItem.Text = "離開";
            toolStripMenuItem.Click += menuItemQuit_Click;
            contextMenuStrip.Items.Add(toolStripMenuItem);

            toolStripMenuItem = new ToolStripMenuItem();
            toolStripMenuItem.Text = "重啟";
            toolStripMenuItem.Click += menuItemRestart_Click;
            contextMenuStrip.Items.Add(toolStripMenuItem);

            toolStripMenuItem = new ToolStripMenuItem();
            toolStripMenuItem.Text = "更新";
            toolStripMenuItem.Click += menuItemUpdate_Click;
            contextMenuStrip.Items.Add(toolStripMenuItem);
            toolStripMenuItem = new ToolStripMenuItem();
            toolStripMenuItem.Text = "下載";
            toolStripMenuItem.Click += menuItemDownLoad_Click;
            contextMenuStrip.Items.Add(toolStripMenuItem);
            toolStripMenuItem = new ToolStripMenuItem();
            toolStripMenuItem.Text = "設定";
            toolStripMenuItem.Click += menuItemSetup_Click;
            contextMenuStrip.Items.Add(toolStripMenuItem);

            notifyIcon1.ContextMenuStrip = contextMenuStrip;
        }
        public Form1(string[] value)
        {
            InitializeComponent();
            CreateMenuItem();
            if (value.Length == 1)
            {
                //MessageBox.Show(value[0]);
                var command = "";
                if (value[0].Contains("&"))
                {
                    command = value[0].Split("&").LastOrDefault();
                }

                var lsUrl = value[0].Split("&").FirstOrDefault().Split(":").ToList();
                lsUrl.RemoveAt(0);
                var url = string.Join(':', lsUrl.ToArray());
                arrArgs = (new List<string> { command, url }).ToArray();
            }
            else
            {
                arrArgs = value;
            }
        }

        
        public void Form1_Load(object sender, EventArgs e)
        {
            try
            {
                this.BeginInvoke(new Action(() =>
                {
                    this.Hide(); this.Opacity = 1;
                    notifyIcon1.Visible = true; 
                    AutoUpdater.InstalledVersion = new Version(ClsCommon.GetInstallVer());
                    AutoUpdater.ShowSkipButton = false;
                    AutoUpdater.ShowRemindLaterButton = true;
                    AutoUpdater.LetUserSelectRemindLater = true;
                    AutoUpdater.Icon = Resource1.InnoDrive;
                    Thread.CurrentThread.CurrentCulture = Thread.CurrentThread.CurrentUICulture = CultureInfo.CurrentCulture;
                    AutoUpdater.ReportErrors = false; 
                    DispatcherTimer timer = new DispatcherTimer { Interval = TimeSpan.FromMinutes(30) };
                    timer.Tick += delegate 
                    {
                        if (AutoUpdater.ReportErrors)
                        {
                            AutoUpdater.ReportErrors = false;
                        }
                        if (AutoUpdater.Mandatory)
                        {
                            AutoUpdater.Mandatory = false;
                        }
                        if (ClsCommon.autoupdateUrl != "")
                        {
                            AutoUpdater.Start(ClsCommon.autoupdateUrl);
                        } 
                    };
                    timer.Start();

                    if (ClsCommon.autoupdateUrl != "")
                    {
                        Thread.CurrentThread.CurrentCulture = Thread.CurrentThread.CurrentUICulture = CultureInfo.CurrentCulture; 
                        AutoUpdater.Mandatory = true;
                        AutoUpdater.ReportErrors = true;
                        //AutoUpdater.UpdateMode = Mode.Normal;
                        AutoUpdater.Start(ClsCommon.autoupdateUrl); 
                    }
                     
                    if (arrArgs.Length > 0)
                    {
                        if (arrArgs[0] == "message")
                        {
                            notifyIcon1.ShowBalloonTip(200, "Information", "啟動中!", ToolTipIcon.Info);
                            ClsCommon.Init();
                            ClsCommon.notifyIcon = this.notifyIcon1;
                            ClsCommon.showMessage(NotifyIconType.OnLine, arrArgs[1]);
                        }
                    } 
                }));
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
                ClsCommon.logger.Error(ex.ToString() + ",StackTrace:" + ex.StackTrace);
            }
            finally
            {
                // this.Close();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            ClsCommon.ChangeNotifyIcon(NotifyIconType.OnLine, this.notifyIcon1);
            notifyIcon1.ShowBalloonTip(500, "Information", "啟動中!", ToolTipIcon.Info);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            ClsCommon.ChangeNotifyIcon(NotifyIconType.Offline, this.notifyIcon1);
            notifyIcon1.ShowBalloonTip(500, "Information", "啟動中!", ToolTipIcon.Info);
        }

        private async void Form1_FormClosed(object sender, FormClosedEventArgs e)
        {
            await quit();
            LogManager.Shutdown();
        }

        private async Task<bool> quit()
        {
            if (ClsCommon.ctsMqtt != null)// && !ClsCommon.ctsMqtt.IsCancellationRequested)
            {
                MqttClientDisconnectOptions opt = new MqttClientDisconnectOptions();
                opt.Reason = MqttClientDisconnectOptionsReason.NormalDisconnection;
                if (ClsCommon.mqttClient == null)
                {

                }
                else if (ClsCommon.mqttClient.IsConnected)
                {
                    await ClsCommon.mqttClient.DisconnectAsync(opt, ClsCommon.ctsMqttToken);
                    ClsCommon.mqttClient.Dispose();
                }
                ClsCommon.currentWebdavServer = string.Empty;
                ClsCommon.ctsMqtt.Cancel();
                ClsCommon.ctsMqtt = null;
            }

            if (ClsCommon.startWatch != null)
            {
                ClsCommon.startWatch = null;
            }
            if (ClsCommon.stopWatch != null)
            {
                ClsCommon.stopWatch = null;
            }
            if (ClsCommon.ctsLogin != null && !ClsCommon.ctsLogin.IsCancellationRequested)
            {
                ClsCommon.ctsLogin.Cancel();
            }

            return true;
        }
    }
}