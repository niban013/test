﻿namespace InnoDriveAgent
{
    partial class SetupForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            tableLayoutPanel1 = new TableLayoutPanel();
            splitContainer2 = new SplitContainer();
            ttbDownLoad = new TextBox();
            btnDownLoad = new Button();
            splitContainer3 = new SplitContainer();
            ttbMyDrive = new TextBox();
            btnMydrive = new Button();
            label2 = new Label();
            label1 = new Label();
            tableLayoutPanel2 = new TableLayoutPanel();
            btnSave = new Button();
            btnExit = new Button();
            tableLayoutPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)splitContainer2).BeginInit();
            splitContainer2.Panel1.SuspendLayout();
            splitContainer2.Panel2.SuspendLayout();
            splitContainer2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)splitContainer3).BeginInit();
            splitContainer3.Panel1.SuspendLayout();
            splitContainer3.Panel2.SuspendLayout();
            splitContainer3.SuspendLayout();
            tableLayoutPanel2.SuspendLayout();
            SuspendLayout();
            // 
            // tableLayoutPanel1
            // 
            tableLayoutPanel1.BackColor = SystemColors.Control;
            tableLayoutPanel1.ColumnCount = 2;
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 22.8962822F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 77.10372F));
            tableLayoutPanel1.Controls.Add(splitContainer2, 1, 0);
            tableLayoutPanel1.Controls.Add(splitContainer3, 1, 1);
            tableLayoutPanel1.Controls.Add(label2, 0, 1);
            tableLayoutPanel1.Controls.Add(label1, 0, 0);
            tableLayoutPanel1.Controls.Add(tableLayoutPanel2, 1, 2);
            tableLayoutPanel1.Dock = DockStyle.Fill;
            tableLayoutPanel1.Location = new Point(0, 0);
            tableLayoutPanel1.Name = "tableLayoutPanel1";
            tableLayoutPanel1.RowCount = 3;
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 47.5728149F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 52.4271851F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Absolute, 52F));
            tableLayoutPanel1.Size = new Size(511, 151);
            tableLayoutPanel1.TabIndex = 0;
            // 
            // splitContainer2
            // 
            splitContainer2.Dock = DockStyle.Fill;
            splitContainer2.Location = new Point(120, 3);
            splitContainer2.Name = "splitContainer2";
            // 
            // splitContainer2.Panel1
            // 
            splitContainer2.Panel1.Controls.Add(ttbDownLoad);
            // 
            // splitContainer2.Panel2
            // 
            splitContainer2.Panel2.Controls.Add(btnDownLoad);
            splitContainer2.Size = new Size(388, 41);
            splitContainer2.SplitterDistance = 327;
            splitContainer2.TabIndex = 7;
            // 
            // ttbDownLoad
            // 
            ttbDownLoad.Dock = DockStyle.Fill;
            ttbDownLoad.Location = new Point(0, 0);
            ttbDownLoad.Multiline = true;
            ttbDownLoad.Name = "ttbDownLoad";
            ttbDownLoad.Size = new Size(327, 41);
            ttbDownLoad.TabIndex = 2;
            // 
            // btnDownLoad
            // 
            btnDownLoad.Dock = DockStyle.Fill;
            btnDownLoad.Image = Resource1.folder;
            btnDownLoad.Location = new Point(0, 0);
            btnDownLoad.Name = "btnDownLoad";
            btnDownLoad.Size = new Size(57, 41);
            btnDownLoad.TabIndex = 5;
            btnDownLoad.UseVisualStyleBackColor = true;
            btnDownLoad.Click += btnDownLoad_Click;
            // 
            // splitContainer3
            // 
            splitContainer3.Dock = DockStyle.Fill;
            splitContainer3.Location = new Point(120, 50);
            splitContainer3.Name = "splitContainer3";
            // 
            // splitContainer3.Panel1
            // 
            splitContainer3.Panel1.Controls.Add(ttbMyDrive);
            // 
            // splitContainer3.Panel2
            // 
            splitContainer3.Panel2.Controls.Add(btnMydrive);
            splitContainer3.Size = new Size(388, 45);
            splitContainer3.SplitterDistance = 329;
            splitContainer3.TabIndex = 8;
            // 
            // ttbMyDrive
            // 
            ttbMyDrive.Dock = DockStyle.Fill;
            ttbMyDrive.Location = new Point(0, 0);
            ttbMyDrive.Multiline = true;
            ttbMyDrive.Name = "ttbMyDrive";
            ttbMyDrive.Size = new Size(329, 45);
            ttbMyDrive.TabIndex = 9;
            // 
            // btnMydrive
            // 
            btnMydrive.Dock = DockStyle.Fill;
            btnMydrive.Image = Resource1.folder;
            btnMydrive.Location = new Point(0, 0);
            btnMydrive.Name = "btnMydrive";
            btnMydrive.Size = new Size(55, 45);
            btnMydrive.TabIndex = 5;
            btnMydrive.UseVisualStyleBackColor = true;
            btnMydrive.Click += btnMydrive_Click;
            // 
            // label2
            // 
            label2.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            label2.AutoSize = true;
            label2.Location = new Point(3, 47);
            label2.Name = "label2";
            label2.Size = new Size(111, 51);
            label2.TabIndex = 1;
            label2.Text = "My Drive本地目錄";
            label2.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // label1
            // 
            label1.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            label1.AutoSize = true;
            label1.Location = new Point(3, 0);
            label1.Name = "label1";
            label1.Size = new Size(111, 47);
            label1.TabIndex = 9;
            label1.Text = "下載目錄";
            label1.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // tableLayoutPanel2
            // 
            tableLayoutPanel2.ColumnCount = 3;
            tableLayoutPanel2.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            tableLayoutPanel2.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            tableLayoutPanel2.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 81F));
            tableLayoutPanel2.Controls.Add(btnSave, 2, 0);
            tableLayoutPanel2.Controls.Add(btnExit, 1, 0);
            tableLayoutPanel2.Dock = DockStyle.Fill;
            tableLayoutPanel2.Location = new Point(120, 101);
            tableLayoutPanel2.Name = "tableLayoutPanel2";
            tableLayoutPanel2.RowCount = 1;
            tableLayoutPanel2.RowStyles.Add(new RowStyle(SizeType.Percent, 50F));
            tableLayoutPanel2.Size = new Size(388, 47);
            tableLayoutPanel2.TabIndex = 10;
            // 
            // btnSave
            // 
            btnSave.Dock = DockStyle.Fill;
            btnSave.ImageAlign = ContentAlignment.MiddleRight;
            btnSave.Location = new Point(309, 3);
            btnSave.Name = "btnSave";
            btnSave.Size = new Size(76, 41);
            btnSave.TabIndex = 5;
            btnSave.Text = "儲存";
            btnSave.UseVisualStyleBackColor = true;
            btnSave.Click += btnSave_Click;
            // 
            // btnExit
            // 
            btnExit.Dock = DockStyle.Right;
            btnExit.Location = new Point(229, 3);
            btnExit.Name = "btnExit";
            btnExit.RightToLeft = RightToLeft.No;
            btnExit.Size = new Size(74, 41);
            btnExit.TabIndex = 4;
            btnExit.Text = "離開";
            btnExit.UseVisualStyleBackColor = true;
            btnExit.Click += btnExit_Click;
            // 
            // SetupForm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(511, 151);
            Controls.Add(tableLayoutPanel1);
            FormBorderStyle = FormBorderStyle.FixedDialog;
            Name = "SetupForm";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Setup";
            Load += SetupForm_Load;
            tableLayoutPanel1.ResumeLayout(false);
            tableLayoutPanel1.PerformLayout();
            splitContainer2.Panel1.ResumeLayout(false);
            splitContainer2.Panel1.PerformLayout();
            splitContainer2.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)splitContainer2).EndInit();
            splitContainer2.ResumeLayout(false);
            splitContainer3.Panel1.ResumeLayout(false);
            splitContainer3.Panel1.PerformLayout();
            splitContainer3.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)splitContainer3).EndInit();
            splitContainer3.ResumeLayout(false);
            tableLayoutPanel2.ResumeLayout(false);
            ResumeLayout(false);
        }

        #endregion

        private TableLayoutPanel tableLayoutPanel1;
        private Label label2;
        private TextBox ttbDownLoad;
        private Button btnDownLoad;
        private SplitContainer splitContainer2;
        private SplitContainer splitContainer3;
        private TextBox ttbMyDrive;
        private Button btnMydrive;
        private Button btnExit;
        private Button btnSave;
        private Label label1;
        private TableLayoutPanel tableLayoutPanel2;
    }
}