﻿namespace InnoDriveAgent
{
    public partial class SetupForm : Form
    {
        public SetupForm()
        {
            InitializeComponent();
        }


        private void btnDownLoad_Click(object sender, EventArgs e)
        {
            var dialog = new System.Windows.Forms.FolderBrowserDialog();
            DialogResult result = dialog.ShowDialog();
            if (result == DialogResult.OK)
            {
                ttbDownLoad.Text = dialog.SelectedPath;
            }
        }

        private void btnMydrive_Click(object sender, EventArgs e)
        {
            var dialog = new System.Windows.Forms.FolderBrowserDialog();
            DialogResult result = dialog.ShowDialog();
            if (result == DialogResult.OK)
            {
                ttbMyDrive.Text = dialog.SelectedPath;
            }
        }

        private void SetupForm_Load(object sender, EventArgs e)
        {
            ttbDownLoad.Text = ClsCommon.GetIni("Folder", "Download", "Config");
            ttbMyDrive.Text = ClsCommon.GetIni("Folder", "MyDriver", "Config");
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            try
            {
                ClsCommon.SetIni("Folder", "Download", ttbDownLoad.Text.Trim(), "Config");
                ClsCommon.SetIni("Folder", "MyDriver", ttbMyDrive.Text.Trim(), "Config");
                MessageBox.Show("儲存成功");
            }
            catch (Exception ex)
            {
                MessageBox.Show("儲存錯誤");
            }
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
