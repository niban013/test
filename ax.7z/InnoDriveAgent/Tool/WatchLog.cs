﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace InnoDriveAgent.Tool
{
    public class FileOperations : FileSystemWatcher
    {
        public delegate void UpdateUI(object sender, LogResponse e);

        public event UpdateUI OnResultChanged;
        public CancellationTokenSource ctsLog;
        CancellationToken ctsLogToken; 

        public DataTable dtContentLog = new DataTable();
        private string fileName;
        private Queue<string> logQueue = new Queue<string>();
        long Offset = 0;//初始化偏移
        string logPath = @"C:\InnoLux\InnoDrive";
        public FileOperations(string _fileName)
        { 
            fileName = System.IO.Path.Combine(logPath, _fileName+ ".txt");
            dtContentLog.Columns.Add("Content", typeof(string));
            dtContentLog.Columns.Add("CreateDate", typeof(string)); 
            FileSystemWatcher watcher = new FileSystemWatcher();
            watcher.Path = System.IO.Directory.GetParent(fileName).ToString();
            watcher.NotifyFilter = NotifyFilters.FileName | NotifyFilters.LastWrite;
            watcher.Filter = System.IO.Path.GetFileName(fileName);
            watcher.Changed += new FileSystemEventHandler(watcher_Changed); 
            watcher.EnableRaisingEvents = true; 

            ctsLog = new CancellationTokenSource();
            ctsLogToken = ctsLog.Token;
            Task task = Task.Run(() => LogMonitor(ctsLogToken));
            LogToQueue();
        }

        protected virtual void RaiseResultChanged(object sender, LogResponse e)
        {
            var handler = OnResultChanged;
             
            if (handler != null) handler(sender, e);
        }


        void watcher_Changed(object sender, FileSystemEventArgs e)
        {
            LogToQueue();
        }

        private void LogToQueue()
        {
            Mutex mutex = new Mutex(false, "mutex");
            mutex.WaitOne();
            if (File.Exists(fileName))
            {
                using (FileStream fs = new FileStream(fileName, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
                {
                    if (fs.CanSeek)
                    {
                        if (Offset > fs.Length)
                        {
                            Offset = fs.Length - 1;
                        }
                        fs.Seek(Offset, SeekOrigin.Begin);

                        byte[] b = new byte[fs.Length - Offset + 1];
                        int cnt, m = 0;
                        cnt = fs.ReadByte();
                        while (cnt != -1)
                        {
                            b[m++] = Convert.ToByte(cnt);
                            cnt = fs.ReadByte();
                        }

                        List<string> ltInfo = Encoding.UTF8.GetString(b).Split(new string[] { "\r\n", "\0" }, StringSplitOptions.None).Where(p=>p.Length>0).ToList();

                        foreach (string item in ltInfo)
                        {
                            logQueue.Enqueue(item);
                        }
                        Offset = fs.Length;
                    }
                    else
                    {
                        //rtxtShow.Invoke(new Action(() =>
                        //{
                        //    rtxtShow.AppendText("当前流不支持查找");
                        //}));
                    }
                }
            }
            mutex.ReleaseMutex();
        }

        private async void LogMonitor(CancellationToken cancellationToken)
        {
            while (true)
            {
                if (cancellationToken.IsCancellationRequested)
                {
                    return;
                }
                await Task.Delay(TimeSpan.FromSeconds(1));
                while (logQueue.Count > 0)
                { 
                    string logInfo = "";
                    logQueue.TryDequeue(out logInfo);
                    Regex rgx = new Regex(@"(?i)(?<=\[)(.*)(?=\])"); 
                    string progress = rgx.Match(logInfo).Value;
                    var index = logInfo.IndexOf('[');
                    var d = logInfo.Substring(0, index);
                    if (d == "")
                    {
                        d = DateTime.Now.ToString();
                    }
                    var date = DateTime.ParseExact(DateTime.Parse(d).ToString("yyyy/MM/dd hh:mm:ss"), "yyyy/MM/dd hh:mm:ss", System.Globalization.CultureInfo.CurrentCulture);
                    index = logInfo.IndexOf(']');
                    var strContent = logInfo.Substring(index + 1, logInfo.Length - index - 1);

                    //DataRow row = dtLog.NewRow();
                    //row[0] = strContent;
                    //row[1] = date.ToString("yyyy/MM/dd hh:mm:ss");
                    //dtLog.Rows.Add(row);

                    RaiseResultChanged(this, new LogResponse(System.IO.Path.GetFileNameWithoutExtension(fileName), progress, strContent, date)); 
                }
              
            }
        }
    }

    public class LogResponse
    {
        public string TaskName { get; }
        public string Progress { get; }

        public string Content { get; }
        public DateTime CreateTime{ get; }
        public LogResponse(string taskName,string progress,string content, DateTime createTime) 
        {
            TaskName = taskName;
            Progress = progress;
            Content = content;
            CreateTime = createTime;
        }
 
    }
}
