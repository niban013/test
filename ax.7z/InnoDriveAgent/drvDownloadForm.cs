﻿using InnoDriveAgent.Tool;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.DirectoryServices.ActiveDirectory;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace InnoDriveAgent
{
    public partial class drvDownloadForm : Form
    {
        Dictionary<string, FileOperations> dic = new Dictionary<string, FileOperations>();
        private string fileName = string.Empty;
        string current = "";
        DataTable dtMain = new DataTable();
        public drvDownloadForm()
        {
            InitializeComponent();
            dtMain.Columns.Add("TaskName", typeof(string));
            dtMain.Columns.Add("Progress", typeof(string));
        }

        public drvDownloadForm(string value) : base()
        {
            InitializeComponent();
            if (!string.IsNullOrEmpty(value))
            {
                fileName = value;
            }
        }

        void createWatchLog(string TaskName)
        {
            if (!dic.ContainsKey(TaskName))
            {
                var f = new FileOperations(TaskName);
                f.OnResultChanged += calc_OnResultChanged;
                dic[TaskName] = f;

                DataRow row = dtMain.NewRow();
                row[0] = TaskName;
                row[1] = "";
                dtMain.Rows.Add(row);
                dtMain.AcceptChanges();
            }
            else
            {
                var g = "";
            }
        }

        private void drvDownloadForm_Load(object sender, EventArgs e)
        {
            createWatchLog("test");
            // createWatchLog(@"C:\InnoLux\InnoDrive\Log1.txt");

            dataGridView1.Rows.Clear();
            dataGridView2.Rows.Clear();

            BindingSource bindingSource = new BindingSource();
            bindingSource.DataSource = dtMain;
            this.dataGridView1.DataSource = bindingSource;

            if (dic.Count > 0)
            {
                current = dic.Keys.FirstOrDefault();
            }
        }


        void calc_OnResultChanged(object sender, LogResponse e)
        {
            if (e.TaskName == current)
            {
                var row = dtMain.AsEnumerable().Where(p => p["TaskName"].ToString() == e.TaskName).FirstOrDefault();
                if (row == null)
                {

                }
                else
                {
                    int rowIndex = dtMain.Rows.IndexOf(row);
                    dtMain.Rows[rowIndex]["Progress"] = e.Progress;
                    dtMain.AcceptChanges();

                    DataRow row2 = dic[e.TaskName].dtContentLog.NewRow();
                    row2[0] = e.Content;
                    row2[1] = e.CreateTime.ToString("yyyy/MM/dd hh:mm:ss");
                    dic[e.TaskName].dtContentLog.Rows.Add(row2);
                    dic[e.TaskName].dtContentLog.AcceptChanges();

                    dataGridView2.Invoke(new Action(() =>
                    {
                        BindingSource bindingSource2 = new BindingSource();
                        bindingSource2.DataSource = dic[e.TaskName].dtContentLog;
                        dataGridView2.DataSource = bindingSource2;
                    }));

                    dataGridView1.Invoke(new Action(() =>
                    {
                        BindingSource bindingSource1 = new BindingSource();
                        bindingSource1.DataSource = dtMain;
                        dataGridView1.DataSource = bindingSource1;
                    }));
                }

            }
            else
            {
                var row = dtMain.AsEnumerable().Where(p => p["TaskName"].ToString() == e.TaskName).FirstOrDefault();
                if (row == null)
                {

                }
                else
                {
                    //dtMain.Rows[dtMain.Rows.IndexOf(row)]["Progress"] = e.Progress;
                    int rowIndex = dtMain.Rows.IndexOf(row);
                    dtMain.Rows[rowIndex]["Progress"] = e.Progress;
                    dtMain.AcceptChanges();
                    DataRow row2 = dic[e.TaskName].dtContentLog.NewRow();
                    row2[0] = e.Content;
                    row2[1] = e.CreateTime.ToString("yyyy/MM/dd hh:mm:ss");
                    dic[e.TaskName].dtContentLog.Rows.Add(row2);
                    dic[e.TaskName].dtContentLog.AcceptChanges();
                }
            }

        }

        void removeWatchLog()
        {
            var lsTaskNames = dic.Keys.ToList();
            lsTaskNames.ForEach(p =>
            {
                if (dic[p] != null || dic[p].ctsLog != null)
                {
                    dic[p].ctsLog.Cancel();
                    dic.Remove(p);
                }
            });
        }

        private void button3_Click(object sender, EventArgs e)
        {
            try
            {
                removeWatchLog();
            }
            catch
            {

            }
        }


        bool diff = false;

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            int index = e.RowIndex;// get the Row Index
            DataGridViewRow selectedRow = dataGridView1.Rows[index];

            var name = selectedRow.Cells[0].Value.ToString();

            if (dic.ContainsKey(name))
            {
                diff = current == name;
                current = name;
                if (!diff)
                {
                    // dataTable.Rows.Clear();
                    //    dic[current].dtContentLog.Rows.Add(row);
                    dataGridView2.Invoke(new Action(() =>
                    {
                        BindingSource bindingSource2 = new BindingSource();
                        bindingSource2.DataSource = dic[current].dtContentLog;
                        dataGridView2.DataSource = bindingSource2;
                    }));
                }

            }
        }

        private void drvDownloadForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            try
            {
                removeWatchLog();
            }
            catch
            {

            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                ClsCommon.lsHandleTasks = new List<HandleTasks>();
                ClsCommon.ExecuteCommand();
                //  Thread.Sleep(5000);

            }
            catch
            {

            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            //    ClsCommon.cancelBws();
            //ClsCommon.lsHandleTasks.ForEach(f => { 
            //   f.cancellationTokenSource.Cancel();
            //});

            ClsCommon.lsHandleTasks[0].cts.Cancel();
        }

        private async void button3_Click_1(object sender, EventArgs e)
        {
            try
            {
                ClsCommon.lsHandleTasks[0].task.Start();
            }
            catch (OperationCanceledException ex)
            {
               // Console.WriteLine($"{nameof(OperationCanceledException)} thrown with message: {e.Message}");
            }
            finally
            {
              //  tokenSource2.Dispose();
            }
             
        }
    }
}
