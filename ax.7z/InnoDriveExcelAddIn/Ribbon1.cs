﻿using InnoDriveExcelAddIn.Properties;
using Microsoft.Office.Core;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Windows.Forms;
using Office = Microsoft.Office.Core;
// TODO:  Follow these steps to enable the Ribbon (XML) item:

// 1: Copy the following code block into the ThisAddin, ThisWorkbook, or ThisDocument class.

//  protected override Microsoft.Office.Core.IRibbonExtensibility CreateRibbonExtensibilityObject()
//  {
//      return new Ribbon1();
//  }

// 2. Create callback methods in the "Ribbon Callbacks" region of this class to handle user
//    actions, such as clicking a button. Note: if you have exported this Ribbon from the Ribbon designer,
//    move your code from the event handlers to the callback methods and modify the code to work with the
//    Ribbon extensibility (RibbonX) programming model.

// 3. Assign attributes to the control tags in the Ribbon XML file to identify the appropriate callback methods in your code.  

// For more information, see the Ribbon XML documentation in the Visual Studio Tools for Office Help.


namespace InnoDriveExcelAddIn
{
    [ComVisible(true)]
    public class Ribbon1 : Office.IRibbonExtensibility
    {
        private Office.IRibbonUI ribbon;
        private List<string> lsServer;
        private string server;
     
        public Ribbon1()
        {
            lsServer = InxSetting.ClsCommon.WebdavServer;
            server = lsServer.Count > 0 ? lsServer[0] : ""; 
        }
        #region IRibbonExtensibility Members

        public string GetCustomUI(string ribbonID)
        {
            return GetResourceText("InnoDriveExcelAddIn.Ribbon1.xml");
        }

        #endregion
        public Bitmap imageSuper_GetImage(IRibbonControl control)
        {
            return Resources.inxDrive;
        }
        #region Ribbon Callbacks
        //Create callback methods here. For more information about adding callback methods, visit https://go.microsoft.com/fwlink/?LinkID=271226

        public  void Ribbon_Load(Office.IRibbonUI ribbonUI)
        {
            this.ribbon = ribbonUI;  
        }

        #endregion

        #region Helpers

        private static string GetResourceText(string resourceName)
        {
            Assembly asm = Assembly.GetExecutingAssembly();
            string[] resourceNames = asm.GetManifestResourceNames();
            for (int i = 0; i < resourceNames.Length; ++i)
            {
                if (string.Compare(resourceName, resourceNames[i], StringComparison.OrdinalIgnoreCase) == 0)
                {
                    using (StreamReader resourceReader = new StreamReader(asm.GetManifestResourceStream(resourceNames[i])))
                    {
                        if (resourceReader != null)
                        {
                            return resourceReader.ReadToEnd();
                        }
                    }
                }
            }
            return null;
        }

        #endregion
        private string textValue { get; set; } = "";
        public void EditBoxOnChange(Office.IRibbonControl control, string text)
        {
            text = text.Trim();
            if (text.Length == 0)
            {
                MessageBox.Show("不能為空"); 
                return;
                //Only invalidating when the value needs to change. You could invalidate after the if block as well 
            }
            else if (!(text.StartsWith("http://") && text.EndsWith("/"))) 
            {
                MessageBox.Show("請輸入正確的值"); 
                return;
            } 
            else
            { 
                textValue = text;
            }
        }

        public void OnChange(Office.IRibbonControl control, string text)
        {
            try
            {
                switch (control.Id)
                {
                    case "cbo_Division":
                        ribbon.InvalidateControl("cbo_Category");
                        break;

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString(), "Unexpected Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
       
        public void ddlServeronAction(IRibbonControl control, string id, int index)
        {
            server = lsServer[index];
            //if (server.Length > 0)
            //{
            //    ClsCommon.saveReg(ThisAddIn.product, ThisAddIn.version, "WebDavUrl", server);
            //}
        }
 
        public string ddlServerGetSelectedItem(IRibbonControl control, int Index)
        {
            return "dd1";
        }

        public int ddlServerGetItemCount(Office.IRibbonControl Control)
        {
            if (lsServer != null)
            {
                return lsServer.Count;
            }
            else 
            {
                return 0;
            }
        }
        public string ddlServerGetItemLabel(Office.IRibbonControl Control, int Index)
        {
            if (lsServer != null)
            { 
                return lsServer[Index];
            }
            else
            {
                return "";
            }
          
        }
        public string ddlServerGetItemID(Office.IRibbonControl Control, int Index)
        {
            //if (lsServer.IndexOf(server) > -1)
            //{
            //    return "dd" + lsServer.IndexOf(server).ToString();
            //}
            return "dd" + Index.ToString(); 
        }
        public string GetText(Office.IRibbonControl control)
        {
            return textValue;
        }

       
 
        public void CallFileWatch(Office.IRibbonControl control)
        {
            try 
            {

                    object exe = InxSetting.ClsCommon.FileWatch;
                    if (exe == null)
                    {
                        return;
                    }
                    else if (exe.ToString() == "")
                    {
                        return;
                    }
                    else
                    {
                        ProcessStartInfo pInfo = new ProcessStartInfo(exe.ToString());
                        pInfo.Arguments = server +"@"+"Excel";
                        pInfo.UseShellExecute = true;
                        using (Process p = new Process())
                        {
                            p.StartInfo = pInfo;
                            p.Start();
                        }
                    }
                 
            }
            catch (Exception ex) 
            {
                if (ex.Message.StartsWith("系統找不到指定的檔案"))
                {
                    MessageBox.Show("確認是否完整安裝插件");
                }
                else 
                {
                    MessageBox.Show("未知錯誤");
                }
            }  
        }  
    }
}
