﻿using Microsoft.Win32;
using Newtonsoft.Json;
using System;

namespace InnoDriveSys
{
    public static class ClsCommon
    {   
        private static HttpClient GetHttpClient(string ticket)
        {
            HttpClient client = new HttpClient()
            {
                Timeout = TimeSpan.FromMinutes(20)
            };
            if (ticket != "")
            {
                client.DefaultRequestHeaders.Clear();
                client.DefaultRequestHeaders.Add("ticket", ticket);

            }
            return client;
        }

       
        public static void registerQuick(string product, string server)
        {
            server = server.TrimEnd('/');
            server = server.Replace("http://", "").Replace("/","\\").Replace(":", "@");
            server = @"\\" + server + @"\DavWWWRoot";  
            createDesktopini(product, server, 0); 
        }

        private static void createDesktopini(string name, string targetPath, int iconNumber)
        {

            string networkshortcuts = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "Microsoft", "Windows", "Network Shortcuts");

            var newFolder = Directory.CreateDirectory(networkshortcuts + @"\" + name);

            newFolder.Attributes |= FileAttributes.ReadOnly;

            string desktopiniContents = @"[.ShellClassInfo]" + Environment.NewLine +

                "CLSID2={0AFACED1-E828-11D1-9187-B532F1E9575D}" + Environment.NewLine +

                "Flags=2";

            string shortcutlocation = networkshortcuts + @"\" + name;

            System.IO.File.WriteAllText(shortcutlocation + @"\Desktop.ini", desktopiniContents);

            string targetLNKPath = networkshortcuts + @"\" + name;

            createShortcut(name, targetLNKPath, targetPath);

        }

        static void createShortcut(string product, string shortcutPath, string targetPath)
        {
            var shell = new IWshRuntimeLibrary.WshShell(); 
            var shortcut = (IWshRuntimeLibrary.WshShortcut)shell.CreateShortcut(shortcutPath + @"\target.lnk");

            shortcut.Description = product;

            shortcut.TargetPath = targetPath;

            shortcut.Arguments = targetPath;


            shortcut.IconLocation = Path.Combine(@"C:\InnoLux\InnoDrive\Icon", "inxdrive32.ico");
            // MessageBox.Show(shortcut.IconLocation);
            shortcut.Save();
        }
        public static void removeShortcut(string product)
        { 
            var path = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "Microsoft", "Windows", "Network Shortcuts");
            string shortcut_link = Path.Combine(path, product, "target.lnk"); 
            if (System.IO.File.Exists(shortcut_link))
            {
                System.IO.File.Delete(shortcut_link);
                var folder = new DirectoryInfo(Path.Combine(path, product)); 
                folder.Attributes = FileAttributes.Normal;
                Directory.Delete(folder.FullName, true); 
            }
        }
    }
}
