﻿// See https://aka.ms/new-console-template for more information
using InnoDriveSys;
using System.Text;

FileStream ostrm;
StreamWriter writer;
TextWriter oldOut = Console.Out;
try
{
    ostrm = new FileStream("C:/InnoLux/InnoDrive/Cmd/cmdLog.txt", FileMode.OpenOrCreate, FileAccess.Write);
    writer = new StreamWriter(ostrm, Encoding.UTF8);
}
catch (Exception e)
{
    Console.WriteLine("Cannot open Redirect.txt for writing");
    Console.WriteLine(e.Message);
    return;
}
Console.SetOut(writer);
try
{ 
    var product = InxSetting.ClsCommon.Product;
    //var version = InxSetting.ClsCommon.Version; 
    string[] arguments = Environment.GetCommandLineArgs();
    if (arguments.Length > 0)
    {
        if (arguments[1] == "/uninstall")
        {
            Console.WriteLine("解除設定中，請稍候.............");
            ClsCommon.removeShortcut(product);
            Console.WriteLine("請等待,視窗將自動關閉.............");
            Thread.Sleep(2000);
        }
        else
        {
            Console.WriteLine("組態設定中，請稍候............."); 
            var lsServer = InxSetting.ClsCommon.WebdavServer;
            var server = lsServer.Count > 0 ? lsServer[0] : ""; 
            Console.WriteLine(@$"正在建立服務器組件,服務器 {server} .............");
            ClsCommon.removeShortcut(product);

            if (server.Length > 0)
            {
                ClsCommon.registerQuick(product, server);
                Console.WriteLine("快捷組件新增完成.............");
            }
            Console.WriteLine("請等待初始化,視窗將自動關閉.............");
            Thread.Sleep(2000); 
        }
    }
}
catch (Exception ex)
{
    Console.WriteLine(ex.Message);
}
finally
{
    Console.SetOut(oldOut);
    writer.Close();
    ostrm.Close();
}
