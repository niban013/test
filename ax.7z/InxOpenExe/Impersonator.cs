﻿using System.ComponentModel;
using System.Runtime.InteropServices;
using System.Security.Principal;

namespace InxOpenExe
{
    public class Impersonator : IDisposable
    {
        protected const int LOGON32_PROVIDER_DEFAULT = 0; 
        protected const int LOGON32_LOGON_NEW_CREDENTIALS = 9;

        public WindowsIdentity Identity;

        protected IntPtr m_accessToken;

        [DllImport("advapi32.dll", SetLastError = true)]
        private static extern bool LogonUser(string lpszUsername, string lpszDomain, string lpszPassword, int dwLogonType, int dwLogonProvider, ref IntPtr phToken);

        [DllImport("kernel32.dll", CharSet = CharSet.Auto)]
        private static extern bool CloseHandle(IntPtr handle);

        public Impersonator(string username, string domain, string password)
        {
            Login(username, domain, password);
        }

        public void Login(string username, string domain, string password)
        {
            if (Identity != null)
            {
                Identity.Dispose();
                Identity = null;
            }
            try
            {
                m_accessToken = new IntPtr(0);
                Logout();
                m_accessToken = IntPtr.Zero;
                if (!LogonUser(username, domain, password, LOGON32_LOGON_NEW_CREDENTIALS, LOGON32_PROVIDER_DEFAULT, ref m_accessToken))
                {
                    int lastWin32Error = Marshal.GetLastWin32Error();
                    throw new Win32Exception(lastWin32Error);
                }
                Identity = new WindowsIdentity(m_accessToken);
            }
            catch
            {
                throw;
            }
        }

        public void Logout()
        {
            if (m_accessToken != IntPtr.Zero)
            {
                CloseHandle(m_accessToken);
            }
            m_accessToken = IntPtr.Zero;
            if (Identity != null)
            {
                Identity.Dispose();
                Identity = null;
            }
        }

        public void Dispose()
        {
            Logout();
        }
    }
}
