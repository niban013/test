﻿using System.Diagnostics;
using System.Runtime.InteropServices;

try
{
    [DllImport("user32.dll", CharSet = CharSet.Unicode)]
    static extern int MessageBox(IntPtr hWnd, String text, String caption, uint type);
    string[] arrArgs = new string[] { };
    //args = new string[] { "","open", "http://tw075371p:61357/MARS03/line10.txt" };
    //args = new string[] { "","open","http://JNVB2BWEB01:8080/MARS03/line10.txt" };
    //args = new string[] { "","inxopenexe: http://tw075371p:60255/MARS03/line10.txt&open" };

    args = Environment.GetCommandLineArgs();
    if (args.Length > 0)
    {
        var _args = args.ToList();
        _args.RemoveAt(0);
        args = _args.ToArray();
    }
    foreach (string arg in args)
    {
       // MessageBox(new IntPtr(0), arg, "InnoDriveAgent", 0);
    }
    
    if (args.Length > 0)
    {
        if (args.Length == 1)
        { 
            var command = "";
            if (args[0].Contains("&"))
            {
                command = args[0].Split('&').LastOrDefault();
            }

            var lsUrl = args[0].Split('&').FirstOrDefault().Split(':').ToList();
            lsUrl.RemoveAt(0);
            var url = string.Join(":", lsUrl.ToArray());
            arrArgs = (new List<string> { command, url }).ToArray();
        }
        else
        {
            arrArgs = args;
        }
         

        if (arrArgs[0] == "open")
        {
            Process[] processes = System.Diagnostics.Process.GetProcessesByName("InnoDriveAgent");

            if (processes.Length < 1)
            {
                MessageBox(new IntPtr(0), "沒有安裝或啟動InnoDriveAgent, 請確認!!", "InnoDriveAgent", 0);
                return;
            } 
             
            Uri uri = new Uri(arrArgs[1]);

            processes = Process.GetProcessesByName("notepad");
            for (int i = 0; i < processes.Length; i++)
            {　
                if (processes[i].MainWindowTitle.Equals(Path.GetFileName(uri.AbsolutePath) + " - Notepad"))
                {
                    throw new Exception("open:" + "檔案" + Path.GetFileName(uri.AbsolutePath) + "已開啟!");
                }
            }

            ProcessStartInfo  pInfo = new ProcessStartInfo(@"C:\Windows\System32\notepad.exe");
            pInfo.Arguments = uri.AbsoluteUri.Replace("http:", "").Replace(":", "@"); 
            pInfo.UseShellExecute = false; //是否使用操作系統shell啓動           
            pInfo.CreateNoWindow = true;//不顯示程序窗口
                                   
            using (Process p = new Process())
            {
                p.StartInfo = pInfo;
                p.Start();
            }
        }
    }
}
catch (Exception ex)
{
    Console.WriteLine(ex.Message);
}


