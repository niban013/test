﻿using System.Collections.Generic;
using System.Configuration;
using System.Linq;

namespace InxSetting
{
    public static class ClsCommon
    {  
        public static string Product
        {
            get
            {
                if (ConfigurationManager.AppSettings["Product"] != null)
                {
                    return ConfigurationManager.AppSettings["Product"];
                }
                return "";
            }
        }
        public static string WebdavMqtt
        {
            get
            {
                if (ConfigurationManager.AppSettings["WebdavMqtt"] != null)
                {
                    return ConfigurationManager.AppSettings["WebdavMqtt"];
                }
                return "";
            }
        }
        public static bool AutoRegisterUser
        {
            get
            {
                if (ConfigurationManager.AppSettings["AutoRegisterUser"] != null)
                { 
                    return ConfigurationManager.AppSettings["AutoRegisterUser"] =="Y"?true:false;
                }
                return false;
            }
        }
        public static List<string> WebdavServer
        {
            get
            {
                if (ConfigurationManager.AppSettings["WebdavServer"] != null)
                {
                    return ConfigurationManager.AppSettings["WebdavServer"].Split(';').ToList();
                }
                return new List<string>();
            }
        }
        public static string DefaultWebDavUrl
        {
            get
            {
                if (ConfigurationManager.AppSettings["DefaultWebDavUrl"] != null)
                {
                    return ConfigurationManager.AppSettings["DefaultWebDavUrl"];
                }
                return "";
            }
        }
        
        public static string FileWatch
        {
            get
            {
                if (ConfigurationManager.AppSettings["FileWatch"] != null)
                {
                    return ConfigurationManager.AppSettings["FileWatch"];
                }
                return  "";
            }
        }

        public static string WebApiUrl
        {
            get
            {
                if (ConfigurationManager.AppSettings["WebApiUrl"] != null)
                {
                    return ConfigurationManager.AppSettings["WebApiUrl"];
                }
                return "";
            }
        }
        public static string AutoUpdate
        {
            get
            {
                if (ConfigurationManager.AppSettings["AutoUpdate"] != null)
                {
                    return ConfigurationManager.AppSettings["AutoUpdate"];
                }
                return "";
            }
        } 
    }
}
