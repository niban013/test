using Microsoft.WindowsAPICodePack.Dialogs;
using System.CodeDom;
using System.Configuration;
using System.Diagnostics;

namespace OpenFileDialogCore
{ 
    public partial class Form1 : Form
    {
        private string _args ="";
        private string product = InxSetting.ClsCommon.Product;
       
        public Form1() 
        {
            InitializeComponent();
        }

 
        public Form1(string value)
        {
            InitializeComponent();
            if (!string.IsNullOrEmpty(value))
            {
                _args = value;
            }
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            try 
            {
                var d = InxSetting.ClsCommon.FileWatch;
                var f = ConfigurationManager.AppSettings["FileWatch"];
                //_args = "http://tw075371p:61355@Excel";// "http://tw075371p:5354@Excel"; 
                 var uri = "";
                var uri2 = "";
                var bUnc = false;
                var officeType = "";
                if (string.IsNullOrEmpty(_args))
                {
                    this.Close();
                    return;
                }
                string shortCutPath = "";
             
                shortCutPath = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "Microsoft", "Windows", "Network Shortcuts", product);

                if (!Directory.Exists(shortCutPath))
                {
                    throw new Exception("InnoDrive �ୱ����|���w��");
                }
              
                uri2 = uri = _args.Split('@').First();
                officeType = _args.Split('@').Last();
                var fileExt = "";
                if (officeType == "Excel") 
                {
                    fileExt = "xlsx,xls";
                }
                else  if (officeType == "Word")
                {
                    fileExt = "doc,docx";
                }
                else if (officeType == "PowerPoint")
                {
                    fileExt = "ppt,pptx";
                }

                if (uri.Length > 0)
                {
                    uri = uri.TrimEnd('/');
                    uri = uri.Replace("http://", "").Replace(":", "@");
                    uri = @"\\" + uri + @"\DavWWWRoot";

                    var fileName = Directory.GetFiles(shortCutPath, "*.lnk").FirstOrDefault();
                    if (!string.IsNullOrEmpty(fileName))
                    {
                        try
                        {
                            CommonOpenFileDialog dialog = new CommonOpenFileDialog()
                            {
                                AllowNonFileSystemItems = true,
                                EnsurePathExists = true,
                                Multiselect = false,
                                NavigateToShortcut = false,
                                Title = "�}��"
                            };
                            dialog.Filters.Add(new CommonFileDialogFilter(officeType, fileExt));
                            dialog.InitialDirectory = uri;

                            try
                            {
                                bUnc = Directory.Exists(uri);
                                if (!bUnc)
                                {
                                    ProcessStartInfo pInfo = new ProcessStartInfo(uri);
                                    pInfo.UseShellExecute = true;
                                    using (Process p = new Process())
                                    {
                                        p.StartInfo = pInfo;
                                        p.Start();
                                    }
                                }
                                else
                                {
                                    //  dialog.RestoreDirectory = false;
                                    if (dialog.ShowDialog() == CommonFileDialogResult.Ok)
                                    { 
                                        ProcessStartInfo pInfo = new ProcessStartInfo(dialog.FileName); 
                                        pInfo.UseShellExecute = true; 
                                        using (Process p = new Process())
                                        {
                                            p.StartInfo = pInfo;
                                            p.Start();
                                        }
                                    }
                                    else
                                    {


                                    }
                                }
                            }
                            catch (Exception ex)
                            {
                                if (ex.Message.Contains("�t�Χ䤣����w���ɮ�"))
                                {
                                    MessageBox.Show("WebDav �s�u����");
                                }
                                else if (ex.Message.Contains("�䤣������W��"))
                                {
                                    MessageBox.Show("WebDav �s�u����");
                                }
                                else
                                {
                                    ProcessStartInfo pInfo = new ProcessStartInfo(fileName);
                                    pInfo.UseShellExecute = true;
                                    pInfo.WindowStyle = ProcessWindowStyle.Hidden;
                                    using (Process p = new Process())
                                    {
                                        p.StartInfo = pInfo;
                                        p.Start();
                                    }
                                }

                            }
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show(ex.Message);
                        }
                        finally
                        {
                            this.Close();
                        }
                    }
                }
            } 
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                this.Close();
            } 
        }
    } 
}