﻿using Autofac;
using DataGridSample.Models;
using DataGridSample.Utils;
using DataGridSample.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace DataGridSample.Views
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class ContactsPage : ContentPage
    {
        private List<Team> teams;
        ContactsViewModel viewModel;
        public ContactsPage(List<Team> Teams)
        {
            teams = Teams;
            InitializeComponent();
            BindingContext = new ContactsViewModel(teams);//App.Container.Resolve(typeof(ContactsViewModel));
            viewModel = (ContactsViewModel)this.BindingContext;
            //viewModel = (ContactsViewModel)App.Container.Resolve(typeof(ContactsViewModel));


            //this.BindingContext = this;

        }

        //protected override void OnAppearing()
        //{
        //    base.OnAppearing();
        //    //AllContacts = new List<Contact>(DummyDataProvider.Get());
        //    //collectionViewListHorizontal.ItemsSource = AllContacts;
           
        //}
        async void OnItemSelected(object sender, SelectionChangedEventArgs args)
        {
            var item = args.CurrentSelection.FirstOrDefault() as Contact;
            if (item != null)
            {

            }
            else 
            {
                return;
            }  
            ((CollectionView)sender).SelectedItem = null;
            //await Navigation.PushAsync(new ItemDetailPage(new ItemDetailViewModel(item)));

            //// Manually deselect item.
            //ItemsCollectionView.SelectedItem = null;
        }
        protected override void OnDisappearing()
        {
            base.OnDisappearing();
            MessagingCenter.Send<object, List<Team>>(this, "bb", teams);
            //MessagingCenter.Unsubscribe<object, string>(this, "ContactsViewModel");
        }
        protected override void OnAppearing()
        {
            base.OnAppearing();

            if (viewModel.Items.Count == 0)
                viewModel.LoadItemsCommand.Execute(null);

            MessagingCenter.Subscribe<object, string>(this, "ContactsViewModel", (obj, item) =>
            {
                lblCount.Text = item;
                //Debug.WriteLine("User updated from mainPage: " + sUser.firstName);
            });
            //    lblCount.Text = viewModel.Items.Where(k=>k.Status =="Y").Count().ToString() + "/"+viewModel.Items.Count.ToString();

        }
        void CollectionViewListSelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            UpdateSelectionData(e.PreviousSelection, e.CurrentSelection);
        }

        void UpdateSelectionData(IEnumerable<object> previousSelectedContact, IEnumerable<object> currentSelectedContact)
        {
            var selectedContact = currentSelectedContact.FirstOrDefault() as Contact;
            //Debug.WriteLine("FullName: " + selectedContact.FullName);
            //Debug.WriteLine("Email: " + selectedContact.Email);
            //Debug.WriteLine("Phone: " + selectedContact.Phone);
            //Debug.WriteLine("Country: " + selectedContact.Country);
        }
        void EditorCompleted(object sender, EventArgs e) 
        {
            var text = ((Editor)sender).Text;
            if (text.Length > 0)
            {
                var record = viewModel.Items.Where(p => p.Phone == text).FirstOrDefault();
                if (record != null)
                {
                    var recordrowindex = viewModel.Items.IndexOf(record);
                    collectionViewListVertical.ScrollTo(recordrowindex);
                }
            }

        }
        private void Button_Clicked(object sender, EventArgs e)
        {
            // viewModel.change();
            //
            var _button = sender as Button;
            var record = _button.BindingContext as Contact;
            var recordrowindex = viewModel.Items.IndexOf(record);
            var d = viewModel.Items;
            d[recordrowindex].Status = "Y";
            //  d[recordrowindex].Country = "xxxx";
            viewModel.Items = d;

            if (viewModel.Items.Where(p => p.Status == "N").Count() == 0)
            {
                Navigation.PopAsync();
            }

            ////  collectionViewListVertical.ItemsSource = viewModel.Items;
            //  BindingContext = viewModel;
            //var rowindex = collectionViewListVertical.ResolveToRowIndex(recordrowindex);
        }
        void OnBoldSwitchToggled(object sender, ToggledEventArgs args)
        {
            if (args.Value)
            {
                //label.FontAttributes |= FontAttributes.Bold;
            }
            else
            {
                //label.FontAttributes &= ~FontAttributes.Bold;
            }
        }

        private void AddClicked(object sender, EventArgs e)
        {

        }
        private async void ConfigClicked(object sender, EventArgs e)
        {
            await Navigation.PushAsync(new SettingsViewPage());
        }
    }
}