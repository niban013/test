﻿using Xamarin.Essentials;

namespace DataGridSample.Models
{
    public static class Settings
    {
        public static bool Isbarcode12D
        {
            get => Preferences.Get(nameof(Isbarcode12D), false);
            set
            {
                Preferences.Set(nameof(IsRfid), !value);
                Preferences.Set(nameof(Isbarcode12D), value);
            }
        }

        public static bool IsRfid
        {
            get => Preferences.Get(nameof(IsRfid), true);
            set
            {
                Preferences.Set(nameof(IsRfid), value);
                Preferences.Set(nameof(Isbarcode12D), !value);
            }
        }
    }
}
