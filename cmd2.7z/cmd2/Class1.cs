﻿using Microsoft.Win32;
using Spectre.Console;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Net;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace cmd2
{
    internal class Class1
    {
        public static string product = "InnoDrive";//, "1.0", "WebDavUrl"
        public static string version = "1.0";
        public static async Task<string> GetRegValue(string regkey, string defaultValue)
        {
            string value = "";
            List<string> result = new List<string>();
            using (RegistryKey key = Registry.CurrentUser.OpenSubKey($@"Software\{product}\{version}", true))
            {
                if(key == null)
                {
                    value = defaultValue;
                }
                else
                {
                    var objvalue = key.GetValue(regkey);
                    if (objvalue == null)
                    {
                        value = defaultValue;
                    }
                    else if (objvalue.ToString() == "")
                    {
                        value = defaultValue;
                    }
                    else
                    {
                        value = objvalue.ToString();
                    }
                }
                
            }
            return value;
        }

        public static void saveReg(string url, string value)
        {
            RegistryKey reg;
            using (reg = Registry.CurrentUser.OpenSubKey($@"Software\{product}\{version}", true))
            {
                if (reg == null)
                {
                    reg = Registry.CurrentUser.CreateSubKey($@"Software\{product}\{version}");
                }

                if (reg.GetValue(url) == null)
                {
                    reg.SetValue(url, value, RegistryValueKind.String);
                }

                if (reg.GetValue(url).ToString() != value)
                {
                    reg.SetValue(url, value, RegistryValueKind.String);
                }
            }
        }
        public static string AskUsernameIfMissing(string? current)
    => !string.IsNullOrWhiteSpace(current)
        ? current
        : AnsiConsole.Prompt(
            new TextPrompt<string>("What's the username?")
                .Validate(username
                    => !string.IsNullOrWhiteSpace(username)
                        ? ValidationResult.Success()
                        : ValidationResult.Error("[yellow]Invalid username[/]")));

        public static string AskPasswordIfMissing(string? current)
            => TryGetValidPassword(current, out var validPassword)
                ? validPassword
                : AnsiConsole.Prompt(
                    new TextPrompt<string>("What's the password?")
                        .Secret()
                        .Validate(password
                            => TryGetValidPassword(password, out _)
                                ? ValidationResult.Success()
                                : ValidationResult.Error("[yellow]Invalid password[/]")));

        static bool TryGetValidPassword(string? password, [NotNullWhen(true)] out string? validPassword)
        {
            var isValidPassword = !string.IsNullOrWhiteSpace(password) && password.Length > 2;
            validPassword = password;
            return isValidPassword;
        }

        //static Environment AskEnvironmentIfMissing(Environment? current)
        //    => current ?? AnsiConsole.Prompt(
        //        new SelectionPrompt<Environment>()
        //            .Title("What's the target environment?")
        //            .AddChoices(
        //                Environment.Development,
        //                Environment.Staging,
        //                Environment.Production)
        //    );
        public static async Task<bool> GetServerVersionAsync()
        { 
            try
            {
                var filePath = @"c:\test\1.txt";
                using (var client = new HttpClient()) 
                {
                    var response = await client.GetAsync("http://tw.yahoo.com", HttpCompletionOption.ResponseHeadersRead);
                    response.EnsureSuccessStatusCode();
                    //  Console.WriteLine($"Downloaded"); return true;
                    var contentLength = response.Content.Headers.ContentLength ?? -1;
                    var stream = await response.Content.ReadAsStreamAsync();

                    using var fileStream = new FileStream(filePath, FileMode.Create, FileAccess.Write, FileShare.None, bufferSize: 4096, useAsync: true);

                    var buffer = new byte[81920];
                    var totalRead = 0L;
                    var read = 0;
                    Console.WriteLine(contentLength);
                    await AnsiConsole
            .Progress()
            .AutoClear(false)
            .StartAsync(async ctx =>
            {
                //const int max = contentLength;
                var task = ctx.AddTask($"Loading pictures", true, contentLength);
                task.StartTask();
            while ((read = await stream.ReadAsync(buffer, 0, buffer.Length)) > 0)
                {
                    await fileStream.WriteAsync(buffer, 0, read);
                    while (task.Value < task.MaxValue)
            {
                        //const int amount = 10_0000;
                        //await Task.Delay(100);
                        Console.WriteLine("@" + read);
                        task.Increment(read);
                }


                }

                task.StopTask();
            });
                    //while ((read = await stream.ReadAsync(buffer, 0, buffer.Length)) > 0)
                    //{
                    //    await AnsiConsole
                    //    .Progress()
                    //   // .AutoClear(false)
                    //            .StartAsync(async ctx =>
                    //            {

                    //                var task = ctx.AddTask($"Loading pictures - {contentLength}", true, contentLength);
                    //                task.StartTask();
                    //                while (task.Value < task.MaxValue)
                    //                {
                    //                    Console.WriteLine("1:"+task.Value);
                    //                    Console.WriteLine("2:"+task.MaxValue);
                    //                    //const int amount = 10_000;
                    //                    await fileStream.WriteAsync(buffer, 0, read);
                    //                    totalRead += read;
                    //                    var progress = totalRead * 1.0 / contentLength;
                    //                    Console.WriteLine(progress);
                    //                    task.Increment(10000);
                    //                }

                    //                task.StopTask();
                    //            });

                    //}


                    //while ((read = await stream.ReadAsync(buffer, 0, buffer.Length)) > 0)
                    //{


                    //    await AnsiConsole.Progress()
                    //        .StartAsync(async ctx =>
                    //        {
                    //            var task1 = ctx.AddTask("执行中......");
                    //            await fileStream.WriteAsync(buffer, 0, read);
                    //            totalRead += read;

                    //            var progress = totalRead * 1.0 / contentLength;
                    //            while (!ctx.IsFinished)
                    //            {
                    //                // 模拟工作耗时
                    //                await Task.Delay(100);

                    //                task1.Increment(1);
                    //            }
                    //        });
                    //    //Console.WriteLine($"Downloaded {totalRead}/{contentLength} bytes ({progress:P})");
                    //}

                    fileStream.Close();
                }

                   
               
              
              //  Console.ReadLine();
                //HttpResponseMessage response = await _client.GetAsync(builder.Uri);

                //if (response.StatusCode == HttpStatusCode.NoContent)
                //{
                //    return response.Headers.GetValues("X-Influxdb-Version").FirstOrDefault();
                //}
                //else if (response.StatusCode == HttpStatusCode.Unauthorized || response.StatusCode == HttpStatusCode.BadGateway || (response.StatusCode == HttpStatusCode.InternalServerError && response.ReasonPhrase == "INKApi Error")) //502 Connection refused
                //    throw new UnauthorizedAccessException("InfluxDB needs authentication. Check uname, pwd parameters");

            }
            catch (HttpRequestException e)
            {
                if (e.InnerException.Message == "Unable to connect to the remote server")
                    throw e;
            }
            return true;
        }

        public static bool checkAccount()
        {
            var account = Class1.GetRegValue("account", "").Result;
            account = Class1.AskUsernameIfMissing(account);
            var pws = Class1.GetRegValue("pws", "").Result;
            pws = Class1.AskPasswordIfMissing(pws);
            Console.WriteLine(account);
            Console.WriteLine(pws);
            if (account != "bb")
            {
                return false;
            }
            return true;
        }
        public static void hh()
        {
            try
            {
                var filePath = @"c:\test\1.txt";
                var client = new HttpClient();

                var response = client.GetAsync("http://webcode.me", HttpCompletionOption.ResponseHeadersRead).Result;
                response.EnsureSuccessStatusCode();
                //  Console.WriteLine($"Downloaded"); return true;
                var contentLength = response.Content.Headers.ContentLength ?? -1;
                var stream = response.Content.ReadAsStreamAsync().Result;

                using var fileStream = new FileStream(filePath, FileMode.Create, FileAccess.Write, FileShare.None, bufferSize: 4096, useAsync: true);

                var buffer = new byte[81920];
                var totalRead = 0L;
                var read = 0;
                while ((read = stream.ReadAsync(buffer, 0, buffer.Length).Result) > 0)
                {
                    fileStream.WriteAsync(buffer, 0, read);
                    totalRead += read;

                    var progress = totalRead * 1.0 / contentLength;
                    Console.WriteLine($"Downloaded {totalRead}/{contentLength} bytes ({progress:P})");
                }

                fileStream.Close();
                client.Dispose();
                Console.ReadLine();
                //return true;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message );
            //    return true;
            }
            finally 
            { 
             
            }
           
        }
    }
}
