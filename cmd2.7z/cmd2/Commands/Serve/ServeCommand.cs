using System;
using System.ComponentModel;
using cmd2;
using Demo.Utilities;
using Spectre.Console;
using Spectre.Console.Cli;

namespace Demo.Commands.Serve;

[Description("Launches a web server in the current working directory and serves all files in it.")]
public sealed class ServeCommand : Command<ServeCommand.Settings>
{
    public sealed class Settings : CommandSettings
    {
        [CommandOption("-p|--port <PORT>")]
        [Description("Port to use. Defaults to [grey]8080[/]. Use [grey]0[/] for a dynamic port.")]
        public int Port { get; set; }

        [CommandOption("-o|--open-browser [BROWSER]")]
        [Description("Open a web browser when the server starts. You can also specify which browser to use. If none is specified, the default one will be used.")]
        public FlagValue<string> OpenBrowser { get; set; }
    }

    public override int Execute(CommandContext context, Settings settings)
    {
        if (settings.OpenBrowser.IsSet)
        {
            var browser = settings.OpenBrowser.Value;
            if (browser != null)
            {
                //var o=  Class1.GetServerVersionAsync().Result;
                var user = Class1.GetRegValue("user", "").Result;
                var username = Class1.AskUsernameIfMissing(user);
                var pws = Class1.GetRegValue("pws", "").Result;
                var pws1 = Class1.AskPasswordIfMissing(pws);
                Console.WriteLine(username);
                Console.WriteLine(pws1);
                if (username != "bb")
                {
                    Console.WriteLine("1");
                    username = Class1.AskUsernameIfMissing("");

                    pws1 = Class1.AskPasswordIfMissing("");
                    if (username != "bb")
                    {
                        Console.WriteLine("2");
                        username = Class1.AskUsernameIfMissing("");

                        pws1 = Class1.AskPasswordIfMissing("");
                        if (username == "bb")
                        {
                            return 0;
                        }
                    }
                }


                //Class1.saveReg("user", username);
                //Class1.saveReg("pws", pws1);
                //             var name = AnsiConsole.Ask<string>("What's your [green]name[/]?");
                //             AnsiConsole.Prompt(
                //new TextPrompt<string>("Enter [green]password[/]?")
                //    .PromptStyle("red")
                //    .Secret());
                Console.WriteLine($"Open in {browser}");
            }
            else
            {
                Console.WriteLine($"Open in default browser.");
            }
        }

        //SettingsDumper.Dump(settings);
        return 0;
    }
}
