// RaServer.cpp : implementation file
//

#include "stdafx.h"
#include "UsbKey.h"
#include "RaServer.h"
#include "F:\��Ŀ\dll\UsbKey\CA\ca.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CRaServer

CRaServer::CRaServer()
{
}

CRaServer::~CRaServer()
{
}


// Do not edit the following lines, which are needed by ClassWizard.
#if 0
BEGIN_MESSAGE_MAP(CRaServer, CAsyncSocket)
	//{{AFX_MSG_MAP(CRaServer)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()
#endif	// 0

/////////////////////////////////////////////////////////////////////////////
// CRaServer member functions
