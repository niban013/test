void SockMsgBox(DWORD error);
