﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Caching.Distributed;
using Microsoft.Extensions.Logging;
using StackExchange.Redis;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace webapitest.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class WeatherForecastController : ControllerBase
    {
        private static readonly string[] Summaries = new[]
        {
            "Freezing", "Bracing", "Chilly", "Cool", "Mild", "Warm", "Balmy", "Hot", "Sweltering", "Scorching"
        };
        private readonly IHttpContextAccessor _httpContextAccessor;
        //private readonly IDistributedCache _distributedCache;
        private readonly ILogger<WeatherForecastController> _logger;
        //private readonly IDatabase _database;
        public WeatherForecastController(IHttpContextAccessor httpContextAccessor,ILogger<WeatherForecastController> logger)//, IDatabase database)
        {
            //_distributedCache = distributedCache;
            //_database = database;
            _logger = logger;
            _httpContextAccessor = httpContextAccessor;
        }


        [HttpGet]
        [Route("SetCookie")]
        public void SetCookie()
        {
            HttpContext.Response.Cookies.Append("setCookie", "CookieValue");

            CookieOptions options = new CookieOptions();
            // 设置过期时间
            options.Expires = DateTime.Now.AddDays(1);
            HttpContext.Response.Cookies.Append("setCookieExpires", "CookieValueExpires", options);
        }

        [HttpGet]
        public string Get()
        {
            var rng = new Random();
            try
            {
                var name = "hello";
                var defaultKey = $"hello:{name}";
                //_database.StringSet(name, "Redis");
                RedisHaFactory.RedisDB.StringSet("6379", "Write string value to 6379.");
                //_distributedCache.SetString(name, "Redis");

                var connection = _httpContextAccessor.HttpContext.Connection;
                var ipv4 = connection.LocalIpAddress.MapToIPv4().ToString();
                var message = $"Hello from Docker Container：{ipv4}";
                return message;
                //return Enumerable.Range(1, 5).Select(index => new WeatherForecast
                //{
                //    Date = DateTime.Now.AddDays(index),
                //    TemperatureC = rng.Next(-20, 55),
                //    Summary = Summaries[rng.Next(Summaries.Length)]
                //})
                //.ToArray();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message);
                return ex.Message;
              //  return Enumerable.Range(1, 5).Select(index => new WeatherForecast
              //  {
              //      Date = DateTime.Now.AddDays(index),
              //      TemperatureC = rng.Next(-20, 55),
              //      Summary = Summaries[rng.Next(Summaries.Length)]
              //  })
              //.ToArray();
            }
        }
    }
}
